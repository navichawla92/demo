<?php

namespace App\Http\Controllers\MD;

use App\Models\User;
use App\Models\Patient;
use App\Models\PatientAssignment;
use App\Models\PatientPhoneCall;
use App\Models\PatientMedication;
use App\Models\PatientAllergy;
use App\Models\IcdCode;
use App\Services\Medication as MedicationService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ManageableField;
use App\Http\Requests\PatientMdAssessment as PatientMdAssessmentRequest; 
use App\Http\Requests\PatientAllergy as PatientAllergyRequest; 
use App\Http\Requests\PatientMedication as PatientMedicationRequest; 
use Auth;
use DB;
use View;
use Validator;
use Carbon\Carbon;
use Illuminate\Support\Facades\Route;

use App\Services\Allergy as AllergyService;


class PatientRegistrationController extends Controller
{
	
	public function __construct(){
        $this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });

        $this->allergy = new AllergyService();
        $this->medication = new MedicationService();
	}
    public function getIndex(Request $request,Patient $patient)
    {    
        if(true)
        {
            $active = 'patient_registrations';
            if ($request->ajax()) {
                $patient = $patient->newQuery();
                if ($request->has('status') && $request->input('status') !='') {
                        $patient->where('md_case_status', $request->input('status'));
                }
                
                if ($request->has('refernce_number') && $request->input('refernce_number') !='') {
                        $patient->where('case_number', $request->input('refernce_number'));
                }
                if (($request->has('from_date') && $request->input('from_date') !='') && ($request->has('to_date') && $request->input('to_date') == '')) {

                        $patient->whereDate('registered_at', '>=', change_date_format($request->input('from_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') == '')) {
                        $patient->whereDate('registered_at', '<=', change_date_format($request->input('to_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') != '')) {
                     $patient->whereBetween(DB::raw('DATE(registered_at)'), array(change_date_format($request->input('from_date')), change_date_format($request->input('to_date'))));
                    
                }
                $md_id=Auth::id();
                $patient->whereHas('assignedMd', function ($query) use($md_id) {
                        $query->where('user_type', '=', MANAGERDIRECTOR)->where('type_id', '=', $md_id);
                });

                $patients = $patient->registration()->paginate(PAGINATION_COUNT_10);
                $request->flashOnly(['status','from_date','to_date']);

                return view('md.patients.registration.registration_table', ['patients' => $patients])->render();  
            }
            else {
                $filter_status = "";
                $filter_from_date = "";
                $filter_to_date = "";
               
                $patient = $patient->newQuery();
                if ($request->old('status') !='') {
                    $filter_status = $request->old('status');
                    $patient->where('md_case_status', $request->old('status'));
                }
                if ($request->old('refernce_number') && $request->old('refernce_number') !='') {
                    $patient->where('case_number', $request->old('refernce_number'));
                }
                if (($request->old('from_date') && $request->old('from_date') !='') && ($request->old('to_date') && $request->old('to_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $patient->whereDate('created_at', '>=', $request->old('from_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                    $patient->whereDate('created_at', '<=', $request->old('to_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') != '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                     $patient->whereBetween(DB::raw('DATE(created_at)'), array($request->old('from_date'), $request->old('to_date')));
                    
                }

                $request->flashOnly(['status','from_date','to_date']);
                $md_id=Auth::id();
                $patient->whereHas('assignedMd', function ($query) use($md_id) {
                        $query->where('user_type', '=', MANAGERDIRECTOR)->where('type_id', '=', $md_id);
                });
                $patients = $patient->registration()->paginate(PAGINATION_COUNT_10);
                
                return view('md.patients.registration.index',compact('active','filter_status','filter_from_date','filter_to_date'))->with('patients', $patients);
            }
        }
        else
        {
            abort(403);
            exit;
        }
    }   

    // MD Assessment for patient 
    public function getMdAssessment($patient_id,$page_no=1,$tab=null,Request $request){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        
        $active = 'patient_registrations';
        $active_tab = "medical_tab"; 
        $active_step = "medical_tab";   
        
        $patient = Patient::find($patient_id);
        $patient->calc($patient->random_key);
        
        $patient_notes = [];  
        $patient_docs = [];  
        $patient_assessments = [];  
        $patient_notes = $patient->patient_notes()->paginate(PAGINATION_COUNT_10); 
        $patient_docs = $patient->patient_docs()->paginate(PAGINATION_COUNT_10); 
        $patient_assessment_comments = $patient->patient_assessment_comment()->get(); 
        
        $previous_medications = $this->medication->medicationList($patient_id);
        $previous_allergies = $this->allergy->allergyLists($patient_id);
        
        $doc_categories = ManageableField::where('type','document_category')->pluck('name','id')->prepend('Select a document category', '');
        $icd_codes = [];
        if ($patient->icd_code) {
            $icd_codes = IcdCode::select(
                        DB::raw("CONCAT(code,' - ',name) AS code_name"),'id')
                       ->whereIn('id', $patient->icd_code)->pluck('code_name','id');
        }
        

        
       // $icd_codes = $patient->icd_code ? IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id') : [];
         if($tab != null)
            $active_tab = $tab;

        event(new \App\Events\PatientViewLog($patient->id));
        return view('md.patients.registration.md_assessment',compact('active', 'active_step', 'active_tab', 'patient','patient_notes','patient_docs','doc_categories','patient_assessment_comments', 'previous_medications', 'previous_allergies','icd_codes'))->with('role_type', MANAGERDIRECTOR);       
    } 

    // Previous added medications
    public function getPreviousAddedMedication($patient_id){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }


        $active = 'patient_registrations';
        $previous_medications = $this->medication->medicationList($patient_id);
        $type = '';
        $is_careplan = 0;
        $html = view('patients.medications.medication_listing',compact('active', 'previous_medications', 'patient_id','type','is_careplan'))->render();       
        return response()->json(['message' => trans('message.listing_found'), 'html' => $html], 200);
    }

    // MD save new Medication
    public function postMedicationSave(PatientMedicationRequest $request)
    {
        $response = $this->medication->addMedication($request);
        if ($response) {
            $previous_medications = $this->medication->medicationList($request->patient_id);
            $type = '';
            $is_careplan = 0;
            $html = view('patients.medications.medication_listing',compact('active', 'previous_medications', 'patient_id','type','is_careplan'))->render();

            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.medication_created_successfully'));
            return response()->json(['message'=>trans('message.medication_created_successfully'), 'html' => $html],200);
        }

        $request->session()->flash('message.level','danger');
        $request->session()->flash('message.content',trans('message.error_medication_created'));
        return response()->json(['message'=>trans('message.error_medication_created')],200);
    } 

    // Previous added allergies
    public function getPreviousAddedAllergies($patient_id){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';
        $previous_allergies = $this->allergy->allergyLists($patient_id);
        $type = '';
        $is_careplan = 0;
        $html = view('patients.allergies.allergies_listing',compact('active', 'previous_allergies', 'patient_id','type','is_careplan'))->render();       
        return response()->json(['message' => trans('message.listing_found'), 'html' => $html], 200);
    }

    // MD save new Allergy
    public function postAllergySave(PatientAllergyRequest $request){


        $response = $this->allergy->addAllergy($request);        
        if($response)
        {
            $previous_allergies = $this->allergy->allergyLists($request->patient_id);
            $type = '';
            $is_careplan = 0;
            $html = view('patients.allergies.allergies_listing',compact('active', 'previous_allergies', 'patient_id','type','is_careplan'))->render();

            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.allergy_created_successfully'));
            return response()->json(['message'=>trans('message.allergy_created_successfully'), 'html' => $html],200);
        }
        else{
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_allergy_created'));
            return response()->json(['message'=>trans('message.error_allergy_created')],200);  
        }

      //  DB::rollBack();
       
    }     

    // CM Assessment save tabs
    public function postMdAssessment(PatientMdAssessmentRequest $request){
        if($request->step_number == 1)
            $response = self::saveMedicalTabData($request);
        if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.patient_detail_successfully'));

            return response()->json(['message'=>trans('message.patient_detail_successfully'),'patient_id'=>$response,'message_type'=> $request->message_type],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_updated_patient'));
            return response()->json(['message'=>trans('message.error_updated_patient')],200);            
        }
    }    

    public function saveMedicalTabData($request)
    {
        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key);
        
        //check if No medication checkbox ticked
        if($request->medication_not_required == 'on'){
            //if on then delete all previous added medications of current patient
            $request->request->add(['medication_not_required' => 1]);
           // PatientMedication::where('patient_id', $patient->id)->delete();

            //delete all previous Medication
            $oldMedications = PatientMedication::where('patient_id', $patient->id)->get();
            if($oldMedications){
                foreach ($oldMedications as $key => $oldMedication) {
                    PatientMedication::find($oldMedication->id)->delete();
                }
            }
        }
        else {
            $request->request->add(['medication_not_required' => 0]);
        }        

        //check if No allergy checkbox ticked
        if($request->allergy_not_required == 'on'){
            //if on then delete all previous added allergies of current patient
            $request->request->add(['allergy_not_required' => 1]);
           // PatientAllergy::where('patient_id', $patient->id)->delete();

             //delete all previous Allergy
            $oldAllergies = PatientAllergy::where('patient_id', $patient->id)->get();
            if($oldAllergies){
                foreach ($oldAllergies as $key => $oldAllergy) {
                    PatientAllergy::find($oldAllergy->id)->delete();
                }
            }
        }
        else {
            $request->request->add(['allergy_not_required' => 0]);
        }

        if($request->substance_abuse_not_required == 'on'){
            $request->request->add(['substance_abuse_not_required' => 1]);
            $request->request->add(['substance_abuse' => null]);
            $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        }
        else {
            $request->request->add(['substance_abuse_not_required' => 0]);
            $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        }  

        //check if already completed other tabs then do not set its value
        if(($patient->md_tab_completed != null && $patient->md_tab_completed < 1) || !$patient->md_tab_completed)
            $patient_record->md_tab_completed = '1';
        
        //mark assessment status as In-Complete
        $patient_record->md_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }      

    //get HTML of assessment tab when CM fills advanced tab successfully
    public function getAssessmentTabHtml(Request $request)
    {
        if ($request->ajax()) 
        {
            $patient = Patient::find(decrypt($request->patient_id));
            $patient->calc($patient->random_key); 

            $patient_assessment_comments = $patient->patient_assessment_comment()->get();
            return View::make('patients.common.assessment_comments_tab',compact('patient', 'patient_assessment_comments'))->with('role_type', MANAGERDIRECTOR);           
        }
        
    }
}
