<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Patient;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Patient as PatientRequest; 
use App\Models\ManageableField;
use App\Models\Registry;
use App\Models\ContractPayer;
use App\Models\PatientData;
use App\Models\ReferralSource;
use App\Models\PcpInformation;
use App\Models\State;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Models\IcdCode;
use View;
use Helper;
// use Illuminate\Support\Facades\Session;
use App\Models\User;
use Storage;
use Auth;
  

class PatientController extends Controller
{
    
    public function __construct(){
        $this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });
    }
    public function getIndex(Request $request,Patient $patient)
    {    
        $active = 'patient_referral';
        if ($request->ajax()) {
            $patient = $patient->newQuery();
            if ($request->has('status') && $request->input('status') !='') {
                    $patient->where('case_status', $request->input('status'));
            }
            if ($request->has('refernce_number') && $request->input('refernce_number') !='') {
                    $patient->where('case_number', $request->input('refernce_number'));
            }
            if (($request->has('from_date') && $request->input('from_date') !='') && ($request->has('to_date') && $request->input('to_date') == '')) {

                    $patient->whereDate('created_at', '>=', change_date_format($request->input('from_date')));
            }
            if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') == '')) {
                    $patient->whereDate('created_at', '<=', change_date_format($request->input('to_date')));
            }
            if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') != '')) {
                 $patient->whereBetween(DB::raw('DATE(created_at)'), array(change_date_format($request->input('from_date')), change_date_format($request->input('to_date'))));
                
            }

            $patients = $patient->referral()->paginate(PAGINATION_COUNT_10);
            $request->flashOnly(['status','from_date','to_date']);
            return view('patients.table', ['patients' => $patients])->render();  
        }
        else {
            $filter_status = "";
            $filter_from_date = "";
            $filter_to_date = "";
            $patient = $patient->newQuery();
            if ($request->old('status') !='') {
                $filter_status = $request->old('status');
                $patient->where('case_status', $request->old('status'));
            }
            if ($request->old('refernce_number') && $request->old('refernce_number') !='') {
                $patient->where('case_number', $request->old('refernce_number'));
            }
            if (($request->old('from_date') && $request->old('from_date') !='') && ($request->old('to_date') && $request->old('to_date') == '')) {
                $filter_from_date = $request->old('from_date');
                $patient->whereDate('created_at', '>=', $request->old('from_date'));
            }
            if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') == '')) {
                $filter_from_date = $request->old('from_date');
                $filter_to_date = $request->old('to_date');
                $patient->whereDate('created_at', '<=', $request->old('to_date'));
            }
            if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') != '')) {
                $filter_from_date = $request->old('from_date');
                $filter_to_date = $request->old('to_date');
                 $patient->whereBetween(DB::raw('DATE(created_at)'), array($request->old('from_date'), $request->old('to_date')));
                
            }

            $request->flashOnly(['status','from_date','to_date']);
            $patients = $patient->referral()->paginate(PAGINATION_COUNT_10);
            return view('patients.index',compact('active','filter_status','filter_from_date','filter_to_date'))->with('patients', $patients);
        }        
    }
    
    public function getCreateEdit($action,$page_no=1,$id=null,$tab=null,Request $request)
    {
        $request->session()->reflash();
        $active = 'patient_referral';
        $active_tab = "patient_info"; 
        $active_step = "patient_info";       
        $patient_concerns_is_other = false; 
        $patient_concerns_is_other_value = '';
        $checked_patient_concern = [];  
        $patient_insurance_secondary = [];  
        $patient_insurance_primary = [];  
        $patient_notes = [];  
        $patient_docs = [];  
        $patient_icd_codes = [];
        $icd_codes = [];

        if($action == 'create')
        {
            $patient = new Patient;
        }
        else
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $patient = Patient::find($id);
            if(empty($patient)){
                    return abort(404);

            }
            $patient->calc($patient->random_key);
            $checkboxes_of_all_tabs = $patient->patient_data->toArray();
            // echo $patient->dob;exit;
            $patient_insurance_secondary = $patient->insuranceSecondary;
            $patient_insurance_primary = $patient->insurancePrimary;
            $patient_notes = $patient->patient_notes()->paginate(PAGINATION_COUNT_10); 
            $patient_docs = $patient->patient_docs()->paginate(PAGINATION_COUNT_10); 
            
            if($patient->step_number >= 1)
            {
                $active_step = "healthcare";
                $patient_icd_codes = array_values(array_filter($checkboxes_of_all_tabs,function($value){
                    if($value['type'] == 'icd_code')
                        return $value;
                }));
               // $icd_codes = $patient->icd_code ? IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id') : [];

                 $icd_codes = [];
                    if ($patient->icd_code) {
                        $icd_codes = IcdCode::select(
                                    DB::raw("CONCAT(code,' - ',name) AS code_name"),'id')
                                   ->whereIn('id', $patient->icd_code)->pluck('code_name','id');
                    }
               // $icd_codes = IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id');
                

            }
            
            if($patient->step_number >= 2)
            {
                $active_step = "insurance";

                $patient_concerns_with_checkboxes = array_values(array_filter($checkboxes_of_all_tabs,function($value){
                    if($value['type'] == 'patient_concern')
                        return $value;
                }));

                $patient_concerns_is_other = array_column($patient_concerns_with_checkboxes,'is_other');

                $checked_patient_concern = array_column($patient_concerns_with_checkboxes,'value');
                
                if(in_array(1, $patient_concerns_is_other))
                {

                    $key = array_search(1,$patient_concerns_is_other);
                    $patient_concerns_is_other_value = $patient_concerns_with_checkboxes[$key]['value'];
                    $patient_concerns_is_other = true;  
                    $active_step = "healthcare";
                    $patient_icd_codes = array_values(array_filter($checkboxes_of_all_tabs,function($value){
                        if($value['type'] == 'icd_code')
                            return $value;
                    }));

                    $icd_codes = [];
                    if ($patient->icd_code) {
                        $icd_codes = IcdCode::select(
                                    DB::raw("CONCAT(code,' - ',name) AS code_name"),'id')
                                   ->whereIn('id', $patient->icd_code)->pluck('code_name','id');
                    }
                    //$icd_codes = $patient->icd_code ? IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id') : [];
                   // $icd_codes = IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id');
                    


                }
                else
                {
                    $patient_concerns_is_other = false;
                }

            }

            //if particular tab is requested
            if($tab != null)
                $active_tab = $tab;
        }

        //$referral_sources = ManageableField::where('type','patient_referal')->pluck('name','id')->prepend('Please select', '')->toArray();
        $referral_sources = Registry::where('type', 'referral_sources')->get()->pluck('org_name','id')->prepend('Please select', '')->toArray();
        $languages = ManageableField::where('type','language')->pluck('name','id')->prepend('Please select', '')->toArray();
        $counties = ManageableField::where('type','county')->pluck('name','id')->prepend('Please select', '')->toArray();
        $lives_with = ManageableField::where('type','lives_with')->pluck('name','id');
        $insurances = Registry::insurance()->get();
        $contract_payers = Registry::where('type', 'contract_payers')->get();
        $patient_concerns = ManageableField::where('type','patient_concern')->pluck('name','id');
        $doc_categories = ManageableField::where('type','document_category')->pluck('name','id')->prepend('Select a document category', '');
        $referral_source_add= new Registry; 
        $pcp_info_add= new Registry; 
        $pcp_informations = new Registry();
        $pcp_informations = $pcp_informations->newQuery();
        $pcp_informations = $pcp_informations->PcpInformation()->get();

        /*maintain patient view log*/
        if($patient->id){
             event(new \App\Events\PatientViewLog($patient->id));
        }
       
        $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
        return view('patients.create',compact('active','lives_with_is_other_value','page_no','lives_with_is_other','patient_concerns_is_other_value','patient_concerns_is_other','active_tab','active_step','referral_sources','languages','counties','lives_with','patient_concerns','doc_categories','action','insurances','contract_payers','patient_insurance_primary','patient_insurance_secondary','patient_notes','patient_docs','referral_source_add','pcp_informations','states','pcp_info_add','icd_codes'))->with('patient',$patient)->with('checked_patient_concern',$checked_patient_concern)->with('patient_icd_codes',$patient_icd_codes);        
    }    

    public function postCreate(PatientRequest $request)
    {
        $request->session()->reflash();
        if($request->step_number == 1)
            $response = self::savePatientInfoTabData($request);
        if($request->step_number == 2)
            $response = self::savePatientConcernTabData($request);
        if($request->step_number == 3)
            $response = self::savePatientInsuranceTabData($request);
        if($request->step_number == 4)
            $response = self::savePatientDocumentTabData($request);
        if($request->step_number == 5)
            $response = self::savePatientNotesTabData($request);          
        if($response)
        {
            if(!session()->has('message.level') && !session()->has('message.content'))
            {
                $request->session()->flash('message.level','success');
                $request->session()->flash('message.content',trans('message.patient_detail_successfully'));
            }

            return response()->json(['message'=>trans('message.patient_created_successfully'),'patient_id'=>$response,'message_type'=> $request->message_type,'encrypted_patient_id' =>\Crypt::encrypt($response)],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_updated_patient'));
            return response()->json(['message'=>trans('message.error_updated_patient')],200);            
        }
    }    

    public function savePatientInfoTabData($request)
    {
        DB::beginTransaction();

        $imageName = '';
        
        if($request->image != null && $request->upload_image_or_not == 'yes')
        {
            $imageName = time().'.'.request()->image->getClientOriginalExtension();
        }

        $patient_id = null;
  
        if($request->emergency_person1_checkbox == 'on'){
            $request->request->add(['emergency_person1_checkbox'=>1]);
        }
        else {
            $request->request->add(['emergency_person1_checkbox'=>0]);
        }
        if($request->emergency_person2_checkbox == 'on'){
            $request->request->add(['emergency_person2_checkbox'=>1]);
        }
        else {
            $request->request->add(['emergency_person2_checkbox'=>0]);
        }

        if($request->living_with_other == 'on'){
            $request->request->add(['living_with_other'=>1]);
            $request->request->add(['lives_with'=>'']);
        }
        else {
            $request->request->add(['living_with_other'=>0]);
            $request->request->add(['living_with_other_text'=>'']);
        }
        if(!$request->lives_with){
             $request->request->add(['lives_with'=>'']);
        }
       
       
        if($request->action == 'add')
        {
            $patient_record= new Patient();
            //$randomKey= Helper::SayHello(12345678);
            $theOtherKey = bin2hex(random_bytes(16));
            $patient_record->calc($theOtherKey);

            $dob  = change_date_format($request->dob);
            //$dob = explode('-',$request->dob);
            //$dob = $dob[2].'-'.$dob[0].'-'.$dob[1];
            $request->request->add(['dob'=>$dob]);

            $patient_record->fill($request->except('_token','step_number','action','patient_id','upload_image_or_not','image', 'message_type'));
            $patient_record->image = $imageName;
            $patient_record->save();
            
            if($patient_record)
            {
                $patient_id = $patient_record->id;
                $patient_repo = new \App\Repositories\PatientRepository;
                $case_number = $patient_repo->generateCaseNumber($patient_id);
                if(!$patient_record->update(['case_number'=>$case_number,'random_key'=>$theOtherKey]))
                {
                    DB::rollBack();
                    return false;       
                }

                //set session varibales to show message on frontend is patient is new
                $request->session()->flash('message.level','success');
                $request->session()->flash('message.content',trans('message.added_patient'));
            }
            else
            {
                DB::rollBack();
                return false;
            }
        }
        else
        {
            $patient = Patient::find($request->patient_id);
            $patient->calc($patient->random_key);
            
            $dob  = change_date_format($request->dob);
            $request->request->add(['dob'=>$dob]);
            
            $patient_record = $patient->fill($request->except('_token','step_number','action','patient_id','upload_image_or_not', 'assignment_modal', 'message_type'));
            if($request->upload_image_or_not == 'yes')
                $patient_record->image = $imageName;
            $patient_record->save();
            $patient_id = $request->patient_id;

            //set session varibales to show message on frontend if existing patient updated
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.patient_detail_successfully'));
        }
        

        if($request->image != null && $request->upload_image_or_not == 'yes')
        {
            Storage::disk('s3')->put(config('filesystems.s3_patient_images_partial_path').$patient_id.'/'.$imageName, file_get_contents($request->file('image')),'public');
        }

        DB::commit();
        return $patient_id;
    }
    
    
    public function savePatientConcernTabData($request)
    {
     //  echo "<pre>";print_r($request->icd_code);exit;
        DB::beginTransaction();
        if(Patient::find($request->patient_id)->get()[0]->step_number == 3){
            $request->step_number=3;
        }
        $patient = Patient::find($request->patient_id);
        $patient->calc($patient->random_key);

        if($request->patient_concern_other == 'on'){
            $request->request->add(['patient_concern_other'=>1]);
        }
        else {
            $request->request->add(['patient_concern_other'=>0]);
            $request->request->add(['patient_concern_other_text'=>'']);
        }
        if (!$request->has('icd_code')) {
            $request->request->add(['icd_code'=> []]);
        }

        $patient_record = $patient->update($request->except('_token','action','patient_id','pcp_state_id', 'message_type'));
        $patient_id = $request->patient_id;
        $request->step_number=2;


        //show respective message on frontend
        if($request->message_type == 'add')
        {
            //set session varibales to show message on frontend is patient is new
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.added_patient'));
        }
        else
        {
            //set session varibales to show message on frontend is existing patient updated
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.patient_detail_successfully'));
        }

        DB::commit();
        return $patient_id;
    }
    
    public function savePatientInsuranceTabData($request)
    {
        DB::beginTransaction();

        if(Patient::find($request->patient_id)->get()[0]->step_number == 3){
            $request->step_number=3;
        }
        $patient_id = $request->patient_id;
        if ($request->has('reg_status') && $request->input('reg_status') !='') {
            $request->request->add(['case_status'=>2]);
            $request->request->add(['registered_at'=> \Carbon\Carbon::now()]);
            $request->request->add(['registration_status'=>0]);

            //add success message here that patient is moved to registration table
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.register_patient'));
        }
        if($request->is_insured){
            $patient = Patient::find($request->patient_id);
            $patient->calc($patient->random_key);
            $patient_record = $patient->update($request->except('_token','reg_status','insurances','is_insured','type','action','patient_id','step_number', 'message_type'));
            Patient::find($request->patient_id)->update(['is_insured' => 1]);
            \App\Models\PatientInsurance::where('patient_id','=',$patient_id)->delete();
        }
        else {
            $request->is_insured=0;     
            $patient = Patient::find($request->patient_id);
            $patient->calc($patient->random_key);
            $patient_record = $patient->update($request->except('_token','reg_status','insurances','type','action','patient_id', 'message_type'));
            Patient::find($request->patient_id)->update(['is_insured' => 0]);
             if(!empty($request->insurances))
                {
                    foreach ($request->insurances as $key => $insurance) 
                    {
                        if($insurance['insurance_id'] != '')
                        {
                            $insurance['patient_id']=$patient_id;
                            $insurance['user_id']=Auth::user()->id;
                            $insurance_insert_arr[] =$insurance; 
                            $insuranseData=$insurance;
                            unset($insuranseData['primary_id']);
                            $patient = Patient::find($patient_id);
                            $effective_date  = change_date_format($insuranseData['effective_date']);
                            $insuranseData['effective_date'] = $effective_date;
                            $expire_date  = change_date_format($insuranseData['expiration_date']);
                            $insuranseData['expiration_date'] = $expire_date;


                            if($insurance['primary_id']){
                                $PatientInsurance = \App\Models\PatientInsurance::find($insurance['primary_id']);
                                $PatientInsurance->calc($patient->random_key);
                                $PatientInsuranceRecord = $PatientInsurance->update($insuranseData); 
                                if($PatientInsuranceRecord){
                            
                                 }
                                else { 
                                    DB::rollBack();
                                    return false;
                                } 

                            }
                            else {
                                 $PatientInsurance=new \App\Models\PatientInsurance();
                                 $PatientInsurance->calc($patient->random_key);   
                                 $PatientInsurance->fill($insuranseData);
                                 if($PatientInsurance->save()){
                                
                                    }
                                else {
                                    
                                    DB::rollBack();
                                    return false;
                                } 

                            }
                        }
                    }
                    
                    DB::commit();
                    return $patient_id;

                }
            
        }

        //show respective message on frontend by matching condition
        if(!session()->has('message.level') && !session()->has('message.content') && $request->case_status == 1)
        {
            //set session varibales to show message on frontend if moved to pre-registered pressed
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.pre_register_patient'));
        }
        elseif(!session()->has('message.level') && !session()->has('message.content') && $request->message_type == 'add')
        {
            //set session varibales to show message on frontend is patient is new
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.added_patient'));
        }
        elseif(!session()->has('message.level') && !session()->has('message.content'))
        {
            //set session varibales to show message on frontend existing patient get updated
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.patient_detail_successfully'));
        }

        DB::commit();
        return $patient_id;
    }
    
    public function savePatientNotesTabData($request)
    {
        DB::beginTransaction();
        $patient_id = $request->patient_id;                 
  
        $patient_data= new PatientData();
        $patient = Patient::find($patient_id);
        $patient_data->calc($patient->random_key);
        $patient_data->fill(['patient_id'=>$patient_id,'user_id'=>Auth::user()->id,'type'=>'notes','name'=>$request->notes_area,'value'=>$request->notes_subject,'status'=>1]);
            
        if($patient_data->save())
        {
            DB::commit();
            return $patient_id;
        }
        DB::rollBack();
        return false;
    }     

    public function savePatientDocumentTabData($request)
    {
        DB::beginTransaction();
        $patient_id = $request->patient_id;                 
  
        $patient_data= new PatientData();
        $patient = Patient::find($patient_id);
        $patient_data->calc($patient->random_key);

        //move document to local server directory
        $document_name = time().'.'.request()->uploaded_document->getClientOriginalExtension();

        //request()->uploaded_document->move(public_path('documents/patients'), $document_name);
        Storage::disk('s3')->put(config('filesystems.s3_patient_documents_partial_path').$patient_id.'/'.$document_name, file_get_contents($request->file('uploaded_document')),'public');

        $patient_data->fill(['patient_id'=>$patient_id,'user_id'=>Auth::user()->id,'type'=>'document','category_id'=>$request->category_id,'name'=>$request->document_name,'value'=>$document_name,'status'=>1]);
            
        if($patient_data->save())
        {
            DB::commit();
            return $patient_id;
        }

        DB::rollBack();
        return false;
    }
    // this function is not needed yet
    
    public function postFilterPatient(Request $request,Patient $patient)
    {
        $patient = $patient->newQuery();
        if ($request->has('status') && $request->input('status') !='') {
                $patient->where('status', $request->input('status'));
        }
        if ($request->has('refernce_number') && $request->input('refernce_number') !='') {
                $patient->where('case_number', $request->input('refernce_number'));
        }
        if (($request->has('from_date') && $request->input('from_date') !='') && ($request->has('to_date') && $request->input('to_date') == '')) {

                $patient->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') == '')) {
                $patient->whereDate('created_at', '<=', $request->input('to_date'));
        }
        if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') != '')) {
             $patient->whereBetween(DB::raw('DATE(created_at)'), array($request->input('from_date'), $request->input('to_date')));
            
        }
        $data = $patient->referral()->paginate(PAGINATION_COUNT_10);
        return View::make('patients.table')->with('patients', $data);
    }
    
   /* public function getPatientView(Request $request,Patient $patient)
    {  
        if ($request->ajax()) {
            if ($request->has('id') && $request->input('id') !='') {
                    $patient = Patient::find($request->input('id'));
                    $patient->calc($patient->random_key);
            }
            $data = $patient;
        }
        return View::make('patients.patient_view_modal')->with('patient', $data);
    }*/
    
    
    public function getloadTab(Request $request)
    {
         $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
        if ($request->ajax()) {
            if ($request->has('tab') && $request->input('tab') == 2) {
                    $lives_with_is_other = false; 
                    $lives_with_is_other_value = '';        
                    $patient_concerns_is_other = false; 
                    $patient_concerns_is_other_value = '';
                    $patient_concerns = ManageableField::where('type','patient_concern')->pluck('name','id');
                    $doc_categories = ManageableField::where('type','document_category')->pluck('name','id')->prepend('Select a document category', '');
                    $patient = Patient::find($request->input('id'));
                    $patient->calc($patient->random_key);
                    $patient_notes = $patient->patient_notes()->paginate(PAGINATION_COUNT_10); 
                    $patient_docs = $patient->patient_docs()->paginate(PAGINATION_COUNT_10); 
                    $checked_patient_concern = array_column($patient->patient_data->toArray(),'value');

                    $checkboxes_of_all_tabs = $patient->patient_data->toArray();
                   
                    $patient_icd_codes = array_values(array_filter($checkboxes_of_all_tabs,function($value){
                    if($value['type'] == 'icd_code')
                        return $value;
                    }));
                    $patient_concerns_with_checkboxes = array_values(array_filter($checkboxes_of_all_tabs,function($value){
                        if($value['type'] == 'patient_concern')
                            return $value;
                    }));

                    $patient_concerns_is_other = array_column($patient_concerns_with_checkboxes,'is_other');

                    $checked_patient_concern = array_column($patient_concerns_with_checkboxes,'value');
                    
                    if(in_array(1, $patient_concerns_is_other))
                    {
                        $key = array_search(1,$patient_concerns_is_other);
                        $patient_concerns_is_other_value = $patient_concerns_with_checkboxes[$key]['value'];
                        $patient_concerns_is_other = true;  
                    }
                    else
                    {
                        $patient_concerns_is_other = false;
                    }    
                    $pcp_informations = new Registry();
                    $pcp_informations = $pcp_informations->newQuery();
                    $pcp_informations = $pcp_informations->PcpInformation()->get();
                 //   $icd_codes = $patient->icd_code ? IcdCode::whereIn('id', $patient->icd_code)->pluck('code','id') : [];
                    $icd_codes = [];
                    if ($patient->icd_code) {
                        $icd_codes = IcdCode::select(
                                    DB::raw("CONCAT(code,' - ',name) AS code_name"),'id')
                                   ->whereIn('id', $patient->icd_code)->pluck('code_name','id');
                    }
                    $dataView['patient_healthcare_tab']=View::make('patients.patient_healthcare_tab')->with('patient', $patient)->with('patient_concerns', $patient_concerns)->with('checked_patient_concern',$checked_patient_concern)->with('patient_concerns_is_other_value',$patient_concerns_is_other_value)->with('patient_concerns_is_other',$patient_concerns_is_other)->with('icd_codes',$patient_icd_codes)->with('icd_codes',$icd_codes)->with('pcp_informations',$pcp_informations)->with('states',$states)->render();

                    $dataView['patient_documents_tab']=View::make('patients.common.patient_documents_tab')->with('patient', $patient)->with('patient_docs', $patient_docs)->with('doc_categories', $doc_categories)->render();
                    $dataView['patient_notes_tab']=View::make('patients.common.patient_notes_tab')->with('patient', $patient)->with('patient_concerns', $patient_concerns)->with('checked_patient_concern',$checked_patient_concern)->with('patient_notes', $patient_notes)->render();
                    return  response()->json(['html'=>$dataView],200);
            }
            if ($request->has('tab') && $request->input('tab') ==3) {
                    $insurances = Registry::insurance()->get();
                    $patient = Patient::find($request->input('id'));
                    $patient->calc($patient->random_key);
                    $patient_insurance_secondary=$patient->insuranceSecondary;
                    $patient_insurance_primary=$patient->insurancePrimary;
                    $contract_payers = Registry::where('type', 'contract_payers')->get();;
                    return View::make('patients.patient_insurance_tab')->with('patient', $patient)->with('insurances', $insurances)->with('patient_insurance_secondary', $patient_insurance_secondary)->with('patient_insurance_primary', $patient_insurance_primary)->with('contract_payers', $contract_payers)->with('states',$states);
            }
            
        }
        
    }
    
    
    public function postChangeStatus(Request $request)
    {
        
        $response=Patient::where('id',$request->patient_id)->update(['case_status'=>$request->status]);
        
        if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.move_patient'));
            return response()->json(['message'=>trans('message.move_patient'),'status'=>1],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_move_patient'));
            return response()->json(['message'=>trans('message.error_move_patient'),'status'=>0],200);            
        }
    }   
    
    public function updatePasswordExpiry(Request $request)
    {
        $user = \Auth::user();
        User::find($user->id)->update(['password_expiry' => \Carbon\Carbon::now()->addDays(15)]);
        $request->session()->forget('password_expire_time');
        return response()->json(['success' => true], 200);
    }
}
