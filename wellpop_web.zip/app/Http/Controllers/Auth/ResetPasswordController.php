<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Auth\Events\PasswordReset;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/login';


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function rules() {
        //return my custom rules
        return [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8|max:16|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\X])(?=.*[!$#%@]).*$/',
            'password_confirmation' => 'required',
        ];
    }    

    public function rules1() {
        //return my custom rules
        return [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:8|max:16|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\X])(?=.*[!$#%@]).*$/',
            'password_confirmation' => 'required',
        ];
    }

  /*  protected function redirectTo(){
      $user = Auth::user();

      //set in database that user is currently login by saving his session ID
      \App\Models\User::where('id', Auth::user()->id)->update(['session_id' => \Session::getId()]);

      if($user->hasRole('Admin'))
      {
        return '/admin/casemanagers';
      }
      else
      {
        return '/casemanager/patients';
      }

    }*/

    /**
     * Reset the given user's password.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
     */
    public function reset(Request $request)
    {
      if($request->password_confirmation)
        $request->validate($this->rules(), $this->validationErrorMessages());
      else
        $request->validate($this->rules1(), $this->validationErrorMessages());
        // Here we will attempt to reset the user's password. If it is successful we
        // will update the password on an actual user model and persist it to the
        // database. Otherwise we will parse the error and return the response.
        $response = $this->broker()->reset(
            $this->credentials($request), function ($user, $password) {
                $this->resetPassword($user, $password);
            }
        );

        // If the password was successfully reset, we will redirect the user back to
        // the application's home authenticated view. If there is an error we can
        // redirect them back to where they came from with their error message.
        if(Password::PASSWORD_RESET){
          if(Auth::id())
          {
            \App\Models\User::find(Auth::id())->update(['status' => 1, 'password_expiry' => \Carbon\Carbon::now()->addDays(15)]);

            \App\Models\LastPassword::create(['password' =>Hash::make($request->password),'type_id'=>Auth::id(),'type'=>'user']);
          }
        }
        return $response == Password::PASSWORD_RESET
                    ? $this->sendResetResponse($request, $response)
                    : $this->sendResetFailedResponse($request, $response);
    }


    // add this function to not logged in the user after reset the password

    protected function resetPassword($user, $password)
    {
        $user->password = Hash::make($password);
        $user->setRememberToken(Str::random(60));
        $user->status=1;
        $user->save();

        \App\Models\User::find($user->id)->update(['status' => 1, 'password_expiry' => \Carbon\Carbon::now()->addDays(15)]);

        \App\Models\LastPassword::create(['password' =>$user->password,'type_id'=>$user->id,'type'=>'user']);
          event(new PasswordReset($user));

       // $this->guard()->login($user);
    }

}
