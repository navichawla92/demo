<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use URL;
use Illuminate\Support\Facades\Route;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers {
        logout as performLogout;
    }

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    
    protected $maxAttempts = 3;

    /**
     * Create a new controller instance.
     *
     * @return void
    */
    public function __construct()
    {
        $this->middleware('guest')->except(['logout','adminLogout']);
    }
    
    protected function redirectTo(){
      $user = Auth::user();

      //set in database that user is currently login by saving his session ID
      \App\Models\User::where('id', Auth::user()->id)->update(['session_id' => \Session::getId()]);

      if($user->hasRole(ADMIN))
      {
        return '/admin/users';
      }
      elseif($user->hasRole(COMMUNITYHEALTHWORKER))
      {
        return '/chw/patients/registrations';
      }
      elseif($user->hasRole(MANAGERDIRECTOR))
      {
        return '/md/patients/registrations';
      }
      else
      {
        return '/casemanager/patients';
      }

    }


    protected function validateLogin(Request $request)
    {
        $this->validate($request, [
            $this->username() => 'required|email', 
            'password' => 'required'
        ]);
    }


    protected function credentials(\Illuminate\Http\Request $request)
    {
        return ['email' => $request->{$this->username()}, 'password' => $request->password, 'status' => 1];
    }
    
   
    
   protected function hasTooManyLoginAttempts(\Illuminate\Http\Request $request)
		{

			if($this->limiter()->attempts($this->throttleKey($request)) >= $this->maxAttempts){

        $user = \App\Models\User::where(['email'=>$request->email])->first();
        
        //deactivate user if user is not an Admin
        if($user && !$user->hasRole(ADMIN))
        {
          $user->status = '0';
          $user->save();
        }
      }
			
		}
		
   protected function sendFailedLoginResponse(\Illuminate\Http\Request $request)
    {
        $errors = [$this->username() => trans('auth.failed')];
        $user = \App\Models\User::where($this->username(), $request->{$this->username()})->first();
        
        if ($user && \Hash::check($request->password, $user->password) && $user->status != 1) {
            $errors = [$this->username() => trans('auth.notActive')];
        }elseif($user && \Hash::check($request->password, $user->password) && $user->status == 1 && Auth::user()->session_id != NULL && \Session::getHandler()->read(Auth::user()->session_id)){
          $errors = [$this->username() => trans('auth.already_login')];
          Auth::logout();
        }elseif($user && Auth::check() && (($user->hasRole(ADMIN) && Route::getFacadeRoot()->current()->getName() != 'admin-login') || (($user->hasRole(COMMUNITYHEALTHWORKER) || $user->hasRole(CASEMANAGER) || $user->hasRole(MANAGERDIRECTOR)) && Route::getFacadeRoot()->current()->uri() != 'login'))){
          $errors = [$this->username() => trans('auth.login-from-different')];
          Auth::logout();
        }

        if ($request->expectsJson()) {
            return response()->json($errors, 422);
        }
        return redirect()->back()
            ->withInput($request->only($this->username(), 'remember'))
            ->withErrors($errors);
    }	
    
    public function login(\Illuminate\Http\Request $request)
    {
        session()->remove('url.intended');

        $this->validateLogin($request);
         
        if(Auth::attempt(['email' => $request->email, 'password' => $request->password, 'status' => 1 ])) {
          
          //check if user's session id is already there and if that session active or expired
          if(Auth::user()->session_id != NULL && \Session::getHandler()->read(Auth::user()->session_id))
          {
            return $this->sendFailedLoginResponse($request);   
          }
           
          $user = $request->user();
          $password_changed_at = new \Carbon\Carbon($user->password_expiry);
          if (\Carbon\Carbon::now()->diffInDays($password_changed_at,false) <= 0) {
            $request->session()->put('password_expire_time', $password_changed_at);        
          }

          //check if user login from their respective page or not
          if($user->hasRole(ADMIN) && Route::getFacadeRoot()->current()->getName() != 'admin-login')
          {
            return $this->sendFailedLoginResponse($request);
          }
          elseif(($user->hasRole(COMMUNITYHEALTHWORKER) || $user->hasRole(CASEMANAGER) || $user->hasRole(MANAGERDIRECTOR)) && Route::getFacadeRoot()->current()->uri() != 'login')
          {
            return $this->sendFailedLoginResponse($request);
          }
          
          return $this->sendLoginResponse($request);
        }  
        else 
        {
          $this->incrementLoginAttempts($request);

          if ($this->hasTooManyLoginAttempts($request)) {
              $this->fireLockoutEvent($request);
              return $this->sendLockoutResponse($request);
          }

          return $this->sendFailedLoginResponse($request);    
        }
    }

    public function logout(Request $request) {
      
      if(Auth::check())
      {
        //set in database that user is logout
        \App\Models\User::where('id', Auth::user()->id)->update(['session_id' => NULL]);
      }

      $this->performLogout($request);

      //redirect to case-manager login page
      return redirect(\URL::previous());
    }     

    public function adminLogout(Request $request) {
      
      if(Auth::check())
      {
        //set in database that user is logout
        \App\Models\User::where('id', Auth::user()->id)->update(['session_id' => NULL]);
      }

      $this->performLogout($request);

      //redirect to admin login page
      return redirect()->route('admin-login-form');
    }    
}
