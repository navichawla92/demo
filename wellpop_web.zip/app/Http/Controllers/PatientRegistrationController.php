<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Patient;
use App\Models\PatientAssignment;
use App\Models\PatientAssessment;
use App\Models\ManageableField;
use App\Models\State;
use App\Models\PatientPhoneCall;
use App\Models\PcpInformation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\PatientCall as PatientCallRequest; 
use Auth;
use DB;
use View;
use Validator;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use App\Models\PatientForm;
use App\Models\PatientSignature;



class PatientRegistrationController extends Controller
{
    
    public function __construct(){
        $this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });
    }
    public function getIndex(Request $request,Patient $patient)
    {    
        if(true)
        {
            $active = 'patient_registrations';
            if ($request->ajax()) {
                $patient = $patient->newQuery();
                if ($request->has('status') && $request->input('status') !='') {
                        $patient->where('registration_status', $request->input('status'));
                }
                if ($request->has('selected_chw') && $request->input('selected_chw') !='') {
                    $chw_id=$request->input('selected_chw');
                    $patient->whereHas('assignedChw', function ($query) use($chw_id) {
                        $query->where('user_type', '=', COMMUNITYHEALTHWORKER)->where('type_id', '=', $chw_id);
                    });
                }
                if ($request->has('selected_cm') && $request->input('selected_cm') !='') {
                    $cm_id=$request->input('selected_cm');
                    $patient->whereHas('assignedCm', function ($query) use($cm_id) {
                        $query->where('user_type', '=', CASEMANAGER)->where('type_id', '=', $cm_id);
                    });
                }
                if ($request->has('selected_md') && $request->input('selected_md') !='') {
                    $md_id=$request->input('selected_md');
                    $patient->whereHas('assignedMd', function ($query) use($md_id) {
                        $query->where('user_type', '=', MANAGERDIRECTOR)->where('type_id', '=', $md_id);
                    });
                }
                if ($request->has('refernce_number') && $request->input('refernce_number') !='') {
                        $patient->where('case_number', $request->input('refernce_number'));
                }
                if (($request->has('from_date') && $request->input('from_date') !='') && ($request->has('to_date') && $request->input('to_date') == '')) {

                        $patient->whereDate('registered_at', '>=', change_date_format($request->input('from_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') == '')) {
                        $patient->whereDate('registered_at', '<=', change_date_format($request->input('to_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') != '')) {
                     $patient->whereBetween(DB::raw('DATE(registered_at)'), array(change_date_format($request->input('from_date')), change_date_format($request->input('to_date'))));
                    
                }

                $patients = $patient->registration()->with(['assignedChw' => function($q){
                                $q->with('user');
                            },
                            'assignedCm' => function($q){
                                $q->with('user');
                            },
                            'assignedMd' => function($q){
                                $q->with('user');
                            }
                            ])->paginate(PAGINATION_COUNT_10);
                $request->flashOnly(['status','from_date','to_date','selected_cm','selected_md','selected_chw']);
                return view('patients.registration.registration_table', ['patients' => $patients])->render();  
            }
            else {
                $filter_status = "";
                $filter_from_date = "";
                $filter_to_date = "";
                $selected_cm = "";
                $selected_chw = "";
                $selected_md = "";
                $patient = $patient->newQuery();
                if ($request->old('status') !='') {
                    $filter_status = $request->old('status');
                    $patient->where('registration_status', $request->old('status'));
                }
                if ($request->old('refernce_number') && $request->old('refernce_number') !='') {
                    $patient->where('case_number', $request->old('refernce_number'));
                }
                if (($request->old('from_date') && $request->old('from_date') !='') && ($request->old('to_date') && $request->old('to_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $patient->whereDate('created_at', '>=', $request->old('from_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                    $patient->whereDate('created_at', '<=', $request->old('to_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') != '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                     $patient->whereBetween(DB::raw('DATE(created_at)'), array($request->old('from_date'), $request->old('to_date')));
                    
                }
                if ($request->old('selected_chw') !='') {
                    $selected_chw = $request->old('selected_chw');
                    $patient->whereHas('assignedChw', function ($query) use($selected_chw) {
                        $query->where('user_type', '=', COMMUNITYHEALTHWORKER)->where('type_id', '=', $selected_chw);
                    });
                }
                if ($request->old('selected_cm') !='') {
                    $selected_cm = $request->old('selected_cm');
                    $patient->whereHas('assignedCm', function ($query) use($selected_cm) {
                        $query->where('user_type', '=', CASEMANAGER)->where('type_id', '=', $selected_cm);
                    });
                }
                if ($request->old('selected_md') !='') {
                    $selected_md = $request->old('selected_md');
                    $patient->whereHas('assignedMd', function ($query) use($selected_md) {
                        $query->where('user_type', '=', MANAGERDIRECTOR)->where('type_id', '=', $selected_md);
                    });
                }

                $request->flashOnly(['status','from_date','to_date','selected_cm','selected_md','selected_chw']);
                $patients = $patient->registration()->with(['assignedChw' => function($q){
                                $q->with('user');
                            },
                            'assignedCm' => function($q){
                                $q->with('user');
                            },
                            'assignedMd' => function($q){
                                $q->with('user');
                            }
                            ])->paginate(PAGINATION_COUNT_10);
                $chw_users = User::whereHas('roles', function ($query) {
                              $query->where('name', '=', COMMUNITYHEALTHWORKER);
                            })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->toArray();                
                $cm_users = User::whereHas('roles', function ($query) {
                              $query->where('name', '=', CASEMANAGER);
                            })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->toArray();                
                $md_users = User::whereHas('roles', function ($query) {
                              $query->where('name', '=', MANAGERDIRECTOR);
                            })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->toArray();
                
                return view('patients.registration.index',compact('active','filter_status','filter_from_date','filter_to_date', 'chw_users', 'cm_users', 'md_users','selected_md','selected_chw','selected_cm'))->with('patients', $patients);

            }
        }
        else
        {
            abort(403);
            exit;
        }
    }    

    public function postAssignments(Request $request)
    {    
        $validator = Validator::make($request->all(),[
            'assigned_chw' => 'required|chw_user',
            'assigned_cm' => 'required|cm_user',
            'assigned_md' => 'required|md_user'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        $patient_id = decrypt($request->patient_id);
        $oldAssignments = PatientAssignment::getHomeAssignmentTeamByPatientId($patient_id)->get();

        if($oldAssignments->count()) {
            foreach($oldAssignments as $assignment) {
                if($assignment->user_type === COMMUNITYHEALTHWORKER && $assignment->type_id != $request->assigned_chw)
                {
                    $assignment->delete();
                    $this->createAssignment($request->assigned_chw, $patient_id, COMMUNITYHEALTHWORKER);
                }

                if($assignment->user_type === CASEMANAGER && $assignment->type_id != $request->assigned_cm)
                {
                    $assignment->delete();
                    $this->createAssignment($request->assigned_cm, $patient_id, CASEMANAGER);
                }

                if($assignment->user_type === MANAGERDIRECTOR && $assignment->type_id != $request->assigned_md)
                {
                    $assignment->delete();
                    $this->createAssignment($request->assigned_md, $patient_id, MANAGERDIRECTOR);
                }
            }
        } else {

            $this->createAssignment($request->assigned_chw, $patient_id, COMMUNITYHEALTHWORKER);
            $this->createAssignment($request->assigned_cm, $patient_id, CASEMANAGER);
            $this->createAssignment($request->assigned_md, $patient_id, MANAGERDIRECTOR);

            //mark registration status incomplete
            $patient_repo = new \App\Repositories\PatientRepository;
            $registration_number = $patient_repo->generateRegistrationNumber($patient_id);
            Patient::find($patient_id)->update(['registration_status' => 1, 'registration_number' => $registration_number]);
        }


        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content',trans('message.assignments_created_successfully'));
        return response()->json(['message'=>trans('message.assignments_created_successfully')],200);
    }

    // patient contact calls
    public function getPatientCalls(Request $request,$id=null){
        try{
            if ($request->ajax()) {
                if($request->input('id')){
                   $id=$request->input('id');
                }
                $patient = Patient::find($id);
                $patient_calls = PatientPhoneCall::where('patient_id',$id)->orderBy('created_at', 'desc')->paginate(PAGINATION_COUNT_10); 
                return view('patients.registration.patient_calls_table', ['patient_calls' => $patient_calls,'patient_id' => $id])->render();
                

            }
            $id = \Crypt::decrypt($id);
            $active = 'patient_registrations';
            $patient = Patient::find($id);
            $patient->calc($patient->random_key);
            $patient_calls = PatientPhoneCall::where('patient_id',$id)->orderBy('created_at', 'desc')->paginate(PAGINATION_COUNT_10); 
            return view('patients.registration.patient_calls',compact('active','patient'))->with('patient_calls', $patient_calls)->with('patient_id', $id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }


    }

    // patient contact calls
    public function postCreatePatientCall(PatientCallRequest $request){
        try{
           
            $patient_id = \Crypt::decrypt($request->patient_id);
            $type_id = \Crypt::decrypt($request->type_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }
        

        DB::beginTransaction();
        $patient_phone_call = new PatientPhoneCall(); 
    
        $contact_date  = change_date_format($request->contact_date);
        $request->request->add(['contact_date'=>$contact_date]);        

        $contact_time  = date("G:i", strtotime($request->contact_time));
        $request->request->add(['contact_time'=>$contact_time]);

        if($request->agree =='yes'){
            $assessment_date  = change_date_format($request->assessment_date);
            $request->request->add(['assessment_date'=>$assessment_date]);        

            $assessment_time  = date("G:i", strtotime($request->assessment_time));
            $request->request->add(['assessment_time'=>$assessment_time]);

            $data = $request->except('_token','type_id','patient_id');
        }else{
            $data = $request->except('_token','type_id','patient_id', 'assessment_date', 'assessment_time');
        }

        $data['patient_id'] = $patient_id;
        $data['type_id'] = $type_id;
        $patient_phone_call->fill($data);          
        if($patient_phone_call->save())
        {
            DB::commit();
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.contact_created_successfully'));
            return response()->json(['message'=>trans('message.contact_created_successfully'),'patient_id'=>$patient_id],200);
        }
        else
        {
            DB::rollBack();
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_contact_created'));
            return response()->json(['message'=>trans('message.error_contact_created')],200);            
        }  
       
    }    

    // patient contact details view and change pop-ups
    public function getPatientView($patient_id){
        try{
           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';
        //$patient = Patient::find($patient_id);
        $patient = Patient::with('consentSignature')->find($patient_id);

        if(count($patient->consentSignature))
            $patient->consent_form_signature_setup = $patient->consentSignature[0]->signature;
        $patient->calc($patient->random_key);
        // echo "<pre>";
        // print_r($patient->toArray());
        // exit;

        //send all type of users to show options in assignment dropdown
        $chw_users = User::whereHas('roles', function ($query) {
                      $query->where('name', '=', COMMUNITYHEALTHWORKER);
                    })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->prepend('Select CHW', '')->toArray();                
        $cm_users = User::whereHas('roles', function ($query) {
                      $query->where('name', '=', CASEMANAGER);
                    })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->prepend('Select CM', '')->toArray();                
        $md_users = User::whereHas('roles', function ($query) {
                      $query->where('name', '=', MANAGERDIRECTOR);
                    })->where('status', 1)->orderBy('name','asc')->get()->pluck('name','id')->prepend('Select MD', '')->toArray();
        
        //Managable fields values
        $languages = ManageableField::where('type','language')->pluck('name','id')->prepend('Please select', '')->toArray();
        $gender_array=gender_array();

        /*maintain patient view log*/
        event(new \App\Events\PatientViewLog($patient->id));

        $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();

        return view('patients.registration.view_patient',compact('active', 'languages', 'states', 'gender_array', 'patient', 'chw_users', 'cm_users', 'md_users'));       
    }     

    // CM Enrollment Decision
    public function getCmEnroll($patient_id){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';
        $patient = Patient::with('consentSignature','consentFormData')->find($patient_id);

        if(count($patient->consentSignature))
            $patient->consent_form_signature_setup = $patient->consentSignature[0]->signature;
        $patient->calc($patient->random_key);

        //check if already sign then directly show form
        if($patient->patient_decision == 'accepts' && $patient->consent_form_signed != null && $patient->consent_form_signed != '')
        {
            
            $lang = 'eng';
            if(count($patient->consentFormData)){
               $patient_form_data = json_decode($patient->consentFormData[0]->form_data, true); 
               $lang = $patient_form_data['consent_form_language'];
            }
            else {
                $patient_form_data = [] ;
            }

            $patient_form = new PatientForm();
            //$patient_form_data = PatientForm::where(['type' =>'0','patient_id'=>$patient_id])->get();
            return view('patients.registration.consent_form',compact('active', 'patient_id', 'patient','lang','patient_form','patient_form_data'));
        }
        else
        {
            $previous_refusal = PatientAssessment::with('user')->where('comment_type', 'consent_rejection')->where('patient_id', $patient_id)->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_5);
            return view('patients.registration.enroll',compact('active', 'patient', 'previous_refusal'));       
        }
    }    

    // Enrollment Decision previous refusal listing
    public function getPreviousEnrollRefused($patient_id){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';
        $previous_refusal = PatientAssessment::with('user')->where('comment_type', 'consent_rejection')->where('patient_id', $patient_id)->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_5);

        $html = view('patients.registration.refusal_listing_and_add',compact('active', 'previous_refusal', 'patient_id'))->render();       
        return response()->json(['message' => trans('message.error_form_save'), 'html' => $html], 200);
    }     

    // Enrollment Decision previous refusal listing
    public function getCmEnrollPatientConsentForm(Request $request,$id,$langname = null){
        
        if(!$langname){
            $validatedData = $request->validate([
                'accept_or_refused_patient_decision' => 'required|accepted',
            ]);
        }
        try{           
            $patient_id = \Crypt::decrypt($request->patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $lang = 'eng';
        if($request->has('lang')){
            $lang = $request->input('lang');
        }
     
        $active = 'patient_registrations';
        $patient = Patient::with('consentSignature')->find($patient_id);
        $patient->calc($patient->random_key);
        $patient_form = new PatientForm();
        $patient_form_data = [];
        return view('patients.registration.consent_form',compact('active', 'patient_id', 'patient','lang','patient_form','patient_form_data'));
    }     

    // Enrollment Decision previous refusal listing
    public function postSaveConsentFormSignature(Request $request){
        try{           
            $patient_id = \Crypt::decrypt($request->patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';

        $save_signature = Patient::find($patient_id);
        $save_signature->update(['consent_form_signature_setup' => $request->signature_setup ]);
        
        return response()->json(['message' => trans('message.signature_save')], 200);
    }    

    // Enrollment Decision previous refusal listing
    public function postAddNewRefusalReason(Request $request){
        $validator = Validator::make($request->all(),[
            'comment' => 'required'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        try{           
            $patient_id = \Crypt::decrypt($request->patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';
        
        $new_refusal['patient_id'] = $patient_id;
        $new_refusal['user_type'] = Auth::user()->roles->pluck('name')[0];
        $new_refusal['type_id'] = Auth::id();
        $new_refusal['comment_type'] = 'consent_rejection';
        $new_refusal['comment'] = $request->comment;
        $new_refusal['status'] = 1;
        
        $save_new_refusal = PatientAssessment::create($new_refusal);
        $save_decision = Patient::find($patient_id);
        $decision = $save_decision->update(['patient_decision' => 'refuses']);
        if($save_new_refusal && $decision){
            //return view('patients.registration.refusal_listing_and_add',compact('active', 'previous_refusal'));
            return $this->getPreviousEnrollRefused($request->patient_id);
        }

        return response()->json(['message' => 'Some error while saving.'], 500);            
    }    

    // Enrollment Decision previous refusal listing
    public function postCmSavePatientConsentForm(Request $request){
        $validator = Validator::make($request->all(),[
            'consent_form_signature_setup' => 'required',            
            'acknowledge_receive_services' => 'required|in:1',
            'acknowledge_emergency_medical_services' => 'required|in:1',
            'acknowledge_release_medical_records' => 'required|in:1',
            'acknowledge_release_vehicle' => 'required|in:1',
            'acknowledge_patient_bill_of_rights' => 'required|in:1',
            'acknowledge_signature' => 'required|in:1',
            'consent_form_documents_located_at_with' => 'required',
            'consent_form_living_will_executed' => 'required',
            'consent_form_dpoa_executed' => 'required',
            'consent_form_signature_date' => 'required',
            'consent_form_patient_initials' => 'required|max:10',
            'patient_id' => 'required',
            'consent_form_living_will_executed' => 'required',
            'consent_form_dpoa_name' => 'required|max:50|regex:/^[\pL\s]+$/u',
            'consent_form_dpoa_phone_number' => 'required|phone',
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        try{           
            $patient_id = \Crypt::decrypt($request->patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        $active = 'patient_registrations';

        if($request->consent_form_date){
            $request->request->add(['consent_form_date' => Carbon::now()->toDateTimeString()]);
        }
        if($request->consent_form_signature_date){
            $request->request->add(['consent_form_signature_date'=>Carbon::now()->toDateTimeString()]);
        }
        
        if($request->consent_form_signature_setup){
            $request->request->add(['consent_form_signed'=>1]);
        }

        $save_signature = Patient::find($patient_id);
        $request->request->add(['patient_decision' => 'accepts']);
        
        $signedForm['patient_id'] = $patient_id;
        $signedForm['signature'] = $request->consent_form_signature_setup ? $request->consent_form_signature_setup : '';
        $signedForm['type'] = 0;

        $signData = $request->except(['patient_id','_token','consent_form_signed','consent_form_signature_setup','patient_decision']);
        $signFormData['authorize_by'] = Auth::user()->id;
        $signFormData['patient_id'] = $patient_id;
        $signFormData['type'] = 0;
        $signFormData['form_data'] = json_encode($signData);

        PatientSignature::create($signedForm);
        
        $updatePatientData = $request->except(['patient_id','consent_form_language','acknowledge_receive_services','acknowledge_emergency_medical_services','acknowledge_release_medical_records','acknowledge_release_vehicle','acknowledge_patient_bill_of_rights','consent_form_living_will_executed','consent_form_dpoa_executed','consent_form_dpoa_name','consent_form_dpoa_phone_number','consent_form_signature_date','consent_form_date','consent_form_documents_located_at_with','acknowledge_signature','consent_form_patient_initials','consent_form_signature_setup']);
    
 
        PatientForm::create($signFormData);
        //check if all the doctors have also completed their assessment then mark patient registration status as complete
        if($save_signature->cm_case_status == '2' && $save_signature->md_case_status == '2' && $save_signature->chw_case_status == '2')
            $save_signature->registration_status = '2';

//        $save_signature = $save_signature->update($request->except(['patient_id']));

        $save_signature = $save_signature->update($updatePatientData);
        
        if($save_signature){
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.consent_form_save'));
            return response()->json(['message' => trans('message.consent_form_save')], 200);  
        }
        else{
             $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_consent_form_save'));
            return response()->json(['message' => trans('message.error_consent_form_save')], 500);
        }      
                    
    }

    public function postEnrollment(Request $request)
    {    

        $validator = Validator::make($request->all(),[
            'enrollment_status' => 'required|'.Rule::in([ENROLLMENT_STATUS_INTENSE,ENROLLMENT_STATUS_MATURE,ENROLLMENT_STATUS_GRADUATE,ENROLLMENT_STATUS_DISCHARGE,ENROLLMENT_STATUS_ELOPED])
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        $patient_id = decrypt($request->patient_id);
        $patient = Patient::find($patient_id);
        $patient = tap($patient)->update(['enrollment_status' => $request->enrollment_status, 'case_status' => REFERRAL_STATUS_ENROLL,'enroll_at'=> \Carbon\Carbon::now()]);
        $patient->replicateAssignmentForCareplan();

        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content',trans('message.patient_enrolled_successfully'));
        return response()->json(['message'=>trans('message.patient_enrolled_successfully')],200);
    }

    /**
     * @param Request $request
     * @param $patient_id
     */
    public function createAssignment($typeId, $patientId, $userType): void
    {
        PatientAssignment::create([
            'user_type' => $userType,
            'patient_id' => $patientId,
            'type_id' => $typeId,
            'assigned_by' => auth()->user()->id,
            'assignment_type' => PatientAssignment::TYPE_HOME_ASSIGNMENT,
        ]);
    }
}
