<?php

namespace App\Http\Controllers\CHW;

use App\Models\User;
use App\Models\Patient;
use App\Models\PatientAssignment;
use App\Models\ManageableField;
use App\Models\PcpInformation;
use App\Models\Registry;
use Illuminate\Http\Request;
use App\Http\Requests\PatientChwAssessment as PatientChwAssessmentRequest; 
use App\Http\Controllers\Controller;
use App\Models\State;
use App\Models\ContractPayer;
use Auth;
use DB;
use View;
use Validator;
use Carbon\Carbon;


class PatientRegistrationController extends Controller
{
	
	public function __construct(){
		$this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });
	}
    public function getIndex(Request $request,Patient $patient)
    {    
        if(true)
        {
            $active = 'patient_registrations';
            if ($request->ajax()) {
                $patient = $patient->newQuery();
                if ($request->has('status') && $request->input('status') !='') {
                        $patient->where('chw_case_status', $request->input('status'));
                }
                
                if ($request->has('refernce_number') && $request->input('refernce_number') !='') {
                        $patient->where('case_number', $request->input('refernce_number'));
                }
                if (($request->has('from_date') && $request->input('from_date') !='') && ($request->has('to_date') && $request->input('to_date') == '')) {

                        $patient->whereDate('registered_at', '>=', change_date_format($request->input('from_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') == '')) {
                        $patient->whereDate('registered_at', '<=', change_date_format($request->input('to_date')));
                }
                if (($request->has('to_date') && $request->input('to_date') !='') && ($request->has('from_date') && $request->input('from_date') != '')) {
                     $patient->whereBetween(DB::raw('DATE(registered_at)'), array(change_date_format($request->input('from_date')), change_date_format($request->input('to_date'))));
                    
                }
                $chw_id=Auth::id();
                $patient->whereHas('assignedChw', function ($query) use($chw_id) {
                        $query->where('user_type', '=', COMMUNITYHEALTHWORKER)->where('type_id', '=', $chw_id);
                });

                $patients = $patient->registration()->paginate(PAGINATION_COUNT_10);
                $request->flashOnly(['status','from_date','to_date']);

                return view('chw.patients.registration.registration_table', ['patients' => $patients])->render();  
            }
            else {
                $filter_status = "";
                $filter_from_date = "";
                $filter_to_date = "";
               
                $patient = $patient->newQuery();
                if ($request->old('status') !='') {
                    $filter_status = $request->old('status');
                    $patient->where('chw_case_status', $request->old('status'));
                }
                if ($request->old('refernce_number') && $request->old('refernce_number') !='') {
                    $patient->where('case_number', $request->old('refernce_number'));
                }
                if (($request->old('from_date') && $request->old('from_date') !='') && ($request->old('to_date') && $request->old('to_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $patient->whereDate('created_at', '>=', $request->old('from_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') == '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                    $patient->whereDate('created_at', '<=', $request->old('to_date'));
                }
                if (($request->old('to_date') && $request->old('to_date') !='') && ($request->old('from_date') && $request->old('from_date') != '')) {
                    $filter_from_date = $request->old('from_date');
                    $filter_to_date = $request->old('to_date');
                     $patient->whereBetween(DB::raw('DATE(created_at)'), array($request->old('from_date'), $request->old('to_date')));
                    
                }

                $request->flashOnly(['status','from_date','to_date']);
                $chw_id=Auth::id();
                $patient->whereHas('assignedChw', function ($query) use($chw_id) {
                        $query->where('user_type', '=', COMMUNITYHEALTHWORKER)->where('type_id', '=', $chw_id);
                });
                $patients = $patient->registration()->paginate(PAGINATION_COUNT_10);
                
                return view('chw.patients.registration.index',compact('active','filter_status','filter_from_date','filter_to_date'))->with('patients', $patients);
            }
        }
        else
        {
            abort(403);
            exit;
        }
    }


    // CHW Assessment for patient 
    public function getChwAssessment($patient_id,$page_no=1,$tab=null,Request $request){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }
        $active = 'patient_registrations';
        $active_tab = "personal_detail"; 
        $active_step = "personal_detail";   
        $patient = Patient::with(['pcp_info'])->where('id', $patient_id)->first();
        $patient->calc($patient->random_key);
  
        $patient_notes = $patient->patient_notes()->paginate(10); 
        $patient_docs = $patient->patient_docs()->paginate(10); 
        $patient_assessment_comments = $patient->patient_assessment_comment()->get(); 
        $patient_insurance_secondary = $patient->insuranceSecondary;
        $patient_insurance_primary = $patient->insurancePrimary;

        $insurances = Registry::insurance()->get();
        $contract_payers = Registry::where('type', 'contract_payers')->get();
        
        $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
        $lives_with = ManageableField::where('type','lives_with')->pluck('name','id');
        $doc_categories = ManageableField::where('type','document_category')->pluck('name','id')->prepend('Select a document category', '');
        
        if($tab != null)
            $active_tab = $tab;


        event(new \App\Events\PatientViewLog($patient->id));
        return view('chw.patients.registration.chw_assessment',compact('active', 'active_step', 'active_tab', 'pcp_informations', 'patient','patient_notes','patient_docs','doc_categories','patient_assessment_comments','lives_with','states','patient_insurance_primary','patient_insurance_secondary','insurances','contract_payers'))->with('role_type', COMMUNITYHEALTHWORKER);       
    }

    // CHW Assessment save tabs
    public function postChwAssessment(PatientChwAssessmentRequest $request){
        if($request->step_number == 1)
            $response = self::savePersonalDetailsTabData($request);
        if($request->step_number == 2)
            $response = self::saveMedicalCareTabData($request);
        if($request->step_number == 3)
            $response = self::savePatientInsuranceTabData($request);
        if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content','Patient details successfully updated.');

            return response()->json(['message'=>'Patient created successfully.','patient_id'=>$response,'message_type'=> $request->message_type],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while updating patient details.');
            return response()->json(['message'=>'Some error while refer new patient.'],200);            
        }
    }    

    public function savePersonalDetailsTabData($request)
    {
        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key);        

        if($request->emergency_person1_checkbox == 'on'){
            $request->request->add(['emergency_person1_checkbox'=>1]);
        }
        else {
            $request->request->add(['emergency_person1_checkbox'=>0]);
        }
        if($request->emergency_person2_checkbox == 'on'){
            $request->request->add(['emergency_person2_checkbox'=>1]);
        }
        else {
            $request->request->add(['emergency_person2_checkbox'=>0]);
        }

        if($request->living_with_other == 'on'){
            $request->request->add(['living_with_other'=>1]);
            $request->request->add(['lives_with'=>'']);
        }
        else {
            $request->request->add(['living_with_other'=>0]);
            $request->request->add(['living_with_other_text'=>'']);
        }
        if(!$request->lives_with){
             $request->request->add(['lives_with'=>'']);
        }

        $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        
        //check if already completed other tabs then do not set its value
        if(($patient->chw_tab_completed != null && $patient->chw_tab_completed < 1) || !$patient->chw_tab_completed)
            $patient_record->chw_tab_completed = '1';
        
        //mark assessment status as In-Complete
        $patient_record->chw_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }   

    public function saveMedicalCareTabData($request)
    {
        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key);        

        if($request->pcp_not_required == 'on'){
            $request->request->add(['pcp_not_required'=>1]);
            $patient->pcp_id = null;
        }
        else {
            $request->request->add(['pcp_not_required'=>0]);
        }
        $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        
        //check if already completed other tabs then do not set its value
        if(($patient->chw_tab_completed != null && $patient->chw_tab_completed < 2) || !$patient->chw_tab_completed)
            $patient_record->chw_tab_completed = '2';
        
        //mark assessment status as In-Complete
        $patient_record->chw_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }


    public function savePatientInsuranceTabData($request)
    {
        try{           
            $patient_id = \Crypt::decrypt($request->patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }

        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key); 

        if($request->is_insured){
            $patient_record = $patient->fill($request->except('_token','insurances','is_insured','patient_id','step_number'));
            Patient::find(decrypt($request->patient_id))->update(['is_insured' => 1]);
            \App\Models\PatientInsurance::where('patient_id','=',$patient_id)->delete();
        }
        else {
            $request->is_insured=0;     
            $patient_record = $patient->fill($request->except('_token','insurances','patient_id'));
            Patient::find(decrypt($request->patient_id))->update(['is_insured' => 0]);
             if(!empty($request->insurances))
                {
                    foreach ($request->insurances as $key => $insurance) 
                    {
                        if($insurance['insurance_id'] != '')
                        {
                            $insurance['patient_id']=$patient_id;
                            $insurance['user_id']=Auth::user()->id;
                            $insurance_insert_arr[] =$insurance; 
                            $insuranseData=$insurance;
                            unset($insuranseData['primary_id']);
                            $patient = Patient::find($patient_id);
                            $effective_date  = change_date_format($insuranseData['effective_date']);
                            $insuranseData['effective_date'] = $effective_date;
                            $expire_date  = change_date_format($insuranseData['expiration_date']);
                            $insuranseData['expiration_date'] = $expire_date;


                            if($insurance['primary_id']){
                                $PatientInsurance = \App\Models\PatientInsurance::find($insurance['primary_id']);
                                $PatientInsurance->calc($patient->random_key);
                                $PatientInsuranceRecord = $PatientInsurance->update($insuranseData); 
                                if($PatientInsuranceRecord){
                            
                                 }
                                else { 
                                    DB::rollBack();
                                    return false;
                                } 

                            }
                            else {
                                 $PatientInsurance=new \App\Models\PatientInsurance();
                                 $PatientInsurance->calc($patient->random_key);   
                                 $PatientInsurance->fill($insuranseData);
                                 if($PatientInsurance->save()){
                                
                                    }
                                else {
                                    
                                    DB::rollBack();
                                    return false;
                                } 

                            }
                        }
                    }

                }
            
        }

        //check if already completed other tabs then do not set its value
        if(($patient->chw_tab_completed != null && $patient->chw_tab_completed < 3) || !$patient->chw_tab_completed)
            $patient_record->chw_tab_completed = '3';
        
        //mark assessment status as In-Complete
        $patient_record->chw_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }       

    //get HTML of medical care tab when CM fills personal tab successfully
    public function getMedicalCareTabHtml(Request $request)
    {
        if ($request->ajax()) 
        {
            $patient = Patient::with(['pcp_info'])->where('id', decrypt($request->patient_id))->first();
            $patient->calc($patient->random_key); 
            
            if ($request->tab == 'insurance-html') 
            {
                $insurances = Registry::insurance()->get();
                $patient_insurance_secondary=$patient->insuranceSecondary;
                $patient_insurance_primary=$patient->insurancePrimary;
                $contract_payers = Registry::where('type', 'contract_payers')->get();
                return View::make('chw.patients.registration.insurance_payer')->with('patient', $patient)->with('insurances', $insurances)->with('patient_insurance_secondary', $patient_insurance_secondary)->with('patient_insurance_primary', $patient_insurance_primary)->with('contract_payers', $contract_payers);        
            }
            elseif ($request->tab == 'assessment-html') 
            {
                $patient_assessment_comments = $patient->patient_assessment_comment()->get();
                return View::make('patients.common.assessment_comments_tab',compact('patient', 'patient_assessment_comments'))->with('role_type', COMMUNITYHEALTHWORKER);           
            }

            return View::make('chw.patients.registration.medical_care',compact('patient'))->with('role_type', COMMUNITYHEALTHWORKER);
        }
        
    }    

    //get HTML of medical care tab listing of requested type
    public function getListingByType(Request $request)
    {
        if ($request->ajax()) 
        {
            if($request->type == 'pcp_informations'){
                if($request->has('is_search') && $request->search_string != '')
                {
                    $records = Registry::where('type', 'pcp_informations')
                                            ->where(function($q) use($request){ 
                                                $q->orWhere('name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('org_name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('speciality', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('phone_number', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('contact_phone', 'like', '%'.$request->search_string.'%');
                                            })
                                            ->orderBy('created_at','desc')
                                            ->paginate(PAGINATION_COUNT_10);
                }
                else
                {
                    $records = Registry::where('type', 'pcp_informations')->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_10);
                }
            }                
            elseif($request->type == 'specialities'){
                if($request->has('is_search') && $request->search_string != '')
                {
                    $records = Registry::where('type', 'specialities')
                                            ->where(function($q) use($request){ 
                                                $q->orWhere('name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('org_name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('speciality', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('phone_number', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('contact_phone', 'like', '%'.$request->search_string.'%');
                                            })
                                            ->orderBy('created_at','desc')
                                            ->paginate(PAGINATION_COUNT_10);
                }
                else
                {
                    $records = Registry::where('type', 'specialities')->orderBy('created_at','desc')->paginate(10);
                }   
            }            
            elseif($request->type == 'rehabs'){
                if($request->has('is_search') && $request->search_string != '')
                {
                    $records = Registry::where('type', 'rehabs')
                                            ->where(function($q) use($request){ 
                                                $q->orWhere('name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('org_name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('contact_phone', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('phone_number', 'like', '%'.$request->search_string.'%');
                                            })
                                            ->orderBy('created_at','desc')
                                            ->paginate(PAGINATION_COUNT_10);
                }
                else
                {
                    $records = Registry::where('type', 'rehabs')->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_10); 
                }  
            }
            elseif($request->type == 'housing_assistances'){
                if($request->has('is_search') && $request->search_string != '')
                {
                    $records = Registry::where('type', 'housing_assistances')
                                            ->where(function($q) use($request){ 
                                                $q->orWhere('name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('org_name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('contact_phone', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('phone_number', 'like', '%'.$request->search_string.'%');
                                            })
                                            ->orderBy('created_at','desc')
                                            ->paginate(PAGINATION_COUNT_10);
                }
                else
                {
                    $records = Registry::where('type', 'housing_assistances')->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_10); 
                } 
            }
            elseif($request->type == 'mental_health_assistances'){
                if($request->has('is_search') && $request->search_string != '')
                {
                    $records = Registry::where('type', 'mental_health_assistances')
                                            ->where(function($q) use($request){ 
                                                $q->orWhere('name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('org_name', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('contact_phone', 'like', '%'.$request->search_string.'%')
                                                  ->orWhere('phone_number', 'like', '%'.$request->search_string.'%');
                                            })
                                            ->orderBy('created_at','desc')
                                            ->paginate(PAGINATION_COUNT_10);
                }
                else
                {
                    $records = Registry::where('type', 'mental_health_assistances')->orderBy('created_at','desc')->paginate(PAGINATION_COUNT_10); 
                }
            }

            $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();

            if(!$request->has('search_string'))
                $search_string = '';
            else
                $search_string = $request->search_string;
            
            if($request->has('is_pagination') && $request->is_pagination == 'yes')
            {
                return View::make('chw.patients.registration.'.$request->required_listing,compact('records', 'search_string'))->with('role_type', COMMUNITYHEALTHWORKER); 
            }
            return View::make('chw.patients.registration.'.$request->required_listing,compact('records', 'states', 'search_string'))->with('role_type', COMMUNITYHEALTHWORKER);           
        }
        
    }    

    //get HTML of medical care tab listing of requested type
    public function getUpdatePatientInfo(Request $request)
    {
        if ($request->ajax()) 
        {
            $message = 'Item';
            $validator = Validator::make($request->all(),[
                'type' => 'required|in:pcp_informations,specialities,rehab,housing_assistance,mental_health_assistance',
                'pcp_id' => 'required_if:type,pcp_informations',
                'specialist_id' => 'required_if:type,specialities',
                'rehab_information_id' => 'required_if:type,rehab',
                'housing_assistance_id' => 'required_if:type,housing_assistance',
                'mental_health_assistance_id' => 'required_if:type,mental_health_assistance'
            ]);

            if($validator->fails()){
                return response()->json(['errors'=>$validator->errors()],422);
            }

            $patient = Patient::find(decrypt($request->patient_id));
            $patient->calc($patient->random_key);

            if($request->type == 'specialities')
            {
                if($patient->specialist_id == null || !is_array($patient->specialist_id))
                {
                    $specialist_ids = [];
                    array_push($specialist_ids, $request->specialist_id);
                    $patient->specialist_id = $specialist_ids;
                }
                else
                {
                    if(!in_array($request->specialist_id, $patient->specialist_id) && count($patient->specialist_id) < 5)
                    {
                        $specialist_ids = $patient->specialist_id;
                        array_push($specialist_ids, $request->specialist_id);
                        $patient->specialist_id = $specialist_ids;
                    }elseif(in_array($request->specialist_id, $patient->specialist_id)){
                        $validator->getMessageBag()->add('custom', 'This specialist is already assigned to patient.');
                        return response()->json(['errors'=>$validator->errors()],422);
                    }elseif(count($patient->specialist_id) >= 5){
                        $validator->getMessageBag()->add('custom', 'Only 5 specialist are allowed for single patient.');
                        return response()->json(['errors'=>$validator->errors()],422);
                    }
                }
            }elseif($request->type == 'pcp_informations'){
                $request->request->add(['pcp_not_required'=>0]);
                $patient->fill($request->except(['_token', 'patient_id', 'type']));
            }else{
                $patient->fill($request->except(['_token', 'patient_id', 'type']));
            }
            $type = $request->type;
            $type = str_replace("_"," ", $type);
            $message = ucfirst($type);
            if($request->type == 'pcp_informations'){
               $message = 'Primary Care Physician Information';
            }
            elseif($request->type == 'specialities' || $request->type == 'rehab'){
                $message.= ' Information';

            }

            $patient->save();
            $request->session()->flash('message.'.$request->type.'-level','success');
            $request->session()->flash('message.content',''. $message.' assigned successfully.');

            return response()->json(['message'=>''.$message.' assigned successfully.'],200);            
        }
        
    }

    //remove already assigned PCP/Rehab/Speciality/Housing/Mental Assistance
    public function getRemoveAssignedInfo(Request $request)
    {
        if ($request->ajax()) 
        {
            $validator = Validator::make($request->all(),[
                'type' => 'required|in:pcp_informations,specialities,rehab,housing_assistance,mental_health_assistance'
            ]);

            if($validator->fails()){
                return response()->json(['errors'=>$validator->errors()],422);
            }

            $patient = Patient::find(decrypt($request->patient_id));$patient->calc($patient->random_key);

            if($request->type == 'pcp_informations'){
                $patient->pcp_id = NULL;
                $patient->pcp_not_required = 1;
            }
            elseif($request->type == 'specialities'){
                if(in_array($request->specialist_id, $patient->specialist_id) && count($patient->specialist_id) > 0)
                {
                    $specialist_ids = $patient->specialist_id;
                    $key = array_search($request->specialist_id,$specialist_ids);
                    unset($specialist_ids[$key]);
                    $specialityId = array_values($specialist_ids);
                    $patient->specialist_id = $specialityId;
                }  
            }
            elseif($request->type == 'rehab')
                $patient->rehab_information_id = NULL;      
            elseif($request->type == 'housing_assistance')
                $patient->housing_assistance_id = NULL;
            elseif($request->type == 'mental_health_assistance')
                $patient->mental_health_assistance_id = NULL;

            $patient->save();

            return response()->json(['message'=>'Assigned item removed successfully.'],200);   
        }
        
    } 
}
