<?php

namespace App\Http\Controllers\Admin\CarePlan;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Admin\CarePlan\Tool;
use App\Http\Requests\ToolRequest; 
use Auth;
use DataTables;
use App\Traits\Admin\CarePlan\ToolTrait;


class ToolController extends Controller {

    use ToolTrait;
  
    /*Metric Or flag Index Page */

    public function getCarePlanToolList() {
        return view('admin.careplan.tools.index')->with('active', 'care-plan')->with('sub_active', 'tools');
    }


     /*Metric Or flag  Datatable */

    public function getCarePlanToolDataTable()
    {
      $tools = Tool::query()->active()->orderBy('id', 'ASC');
        return DataTables::of($tools)
                 ->addIndexColumn()
                 ->addColumn('action', function ($tool) {
                            return '<a href="' . route("tool-create", encrypt_decrypt('encrypt', $tool->id)) . '"  class="" title="Edit Tool" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="#"  style="color:red" data-id="'.encrypt_decrypt('encrypt',$tool->id).'"  data-model="Tool" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['value', 'action','id'])
            ->make(true);
    }



    /**
     * Tool Add/Edit Form
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function getToolCreateEdit($id=null)
    {
      if($id) {
        $id = encrypt_decrypt('decrypt', $id);
        $tool = Tool::findOrFail($id);
      } else {
        $tool = new Tool;   
      }
      return view('admin.careplan.tools.add', ['tool'=>$tool])->with('active', 'care-plan')->with('sub_active', 'tools');
    }


    /**
     * Save and Update Tool Details
     *
     * @param ToolRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function postToolCreate(ToolRequest $request)
    {
      $response = $this->saveTool($request);
      if($response)
      {
        $request->session()->flash('message.level','success');
        return $request->submit_btn_type == 1 ? redirect()->route('get_careplan_tools') : redirect()->route('tool-create');
      }
      else
      {
        $request->session()->flash('message.level','danger');
        $request->session()->flash('message.content',trans('message.error_added_tool'));
        return $request->submit_btn_type == 1 ? redirect()->route('get_careplan_tools') : redirect()->route('tool-create');
      }
    }

}
