<?php

namespace App\Http\Controllers\Admin\CarePlan;

use App\Http\Requests\ContentDiscussedRequest;
use App\Models\Admin\CarePlan\ContentDiscussed;
use App\Traits\Admin\CarePlan\ContentDiscussedTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class ContentDiscussedController extends Controller
{

    use ContentDiscussedTrait;


    /**
     * Show Listing view of Content Discussed
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view('admin.careplan.content_discussed.index')->with('active', 'care-plan')->with('sub_active', 'contents');
    }

    /**
     * Get Content Discussed Datatable List
     * @return mixed
     * @throws \Exception
     */
    public function getContentsList()
    {
        $contentDiscussed = ContentDiscussed::query()->orderBy('id', 'DESC');
        return DataTables::of($contentDiscussed)
            ->addIndexColumn()
            ->addColumn('action', function ($content) {
                return '<a href="' . route("content-create", encrypt_decrypt('encrypt', $content->id)) . '"  class="" title="Edit Content Discussed" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="#"  style="color:red" data-id="'.encrypt_decrypt('encrypt',$content->id).'"  data-model="Content" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
            })
            ->orderColumn('id', 'id -$1')
            ->rawColumns(['value', 'action','id'])
            ->make(true);
    }


    /*Tool Add/Edit Form */

    public function getContentCreateEdit($id=null)
    {

        if($id)
        {
            $id = encrypt_decrypt('decrypt', $id);
            $content = ContentDiscussed::findOrFail($id);
        }
        else
        {
            $content = new ContentDiscussed();
        }
        return view('admin.careplan.content_discussed.add', ['content'=>$content])->with('active', 'care-plan')->with('sub_active', 'contents');
    }


    /*Tool Save Form */

    public function postContentCreateOrUpdate(ContentDiscussedRequest $request)
    {

        $response = $this->saveContent($request);
        if($response)
        {
            $request->session()->flash('message.level','success');
            return $request->submit_btn_type == 1 ? redirect()->route('get_content_discussed') : redirect()->route('content-create');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_added_content'));
            return $request->submit_btn_type == 1 ? redirect()->route('get_content_discussed') : redirect()->route('content-create');
        }
    }
}
