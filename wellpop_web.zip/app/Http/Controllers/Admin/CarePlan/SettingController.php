<?php

namespace App\Http\Controllers\Admin\CarePlan;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ManageableField;
use Auth;
use DataTables;


class SettingController extends Controller {

    /*Metric Or flag Index Page */

    public function getCarePlanSettingList($type) {
        return view('admin.careplan.settings.'.$type.'')->with('active', 'care-plan')->with('sub_active', $type);
    }


     /*Metric Or flag  Datatable */

    public function getCarePlanSettingDataTable($type)
    {
      if($type == 'metrices'){
        $type = 'metric';
      }
      else if($type == 'flags'){
        $type = 'flag';
      }
      else{
        $type = $type;
      }
      $settings = ManageableField::query()->where('type', $type)->orderBy('id', 'ASC');
        return DataTables::of($settings)
                 ->addIndexColumn()
                 ->editColumn('value', function($setting) {
                    if($setting->type == 'flag'){
                          return '<i class="fa fa-flag '.$setting->value.'" aria-hidden="true"></i>';
                    }
                    else{
                      return $setting->description;
                    }
                  })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['value', 'action','id'])
            ->make(true);
    }

}
