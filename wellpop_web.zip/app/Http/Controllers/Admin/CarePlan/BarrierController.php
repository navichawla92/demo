<?php

namespace App\Http\Controllers\Admin\CarePlan;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ManageableField;
use App\Models\Admin\CarePlan\Barrier;
use App\Http\Requests\BarrierRequest; 
use Auth;
use DataTables;
use App\Traits\Admin\CarePlan\BarrierTrait;


class BarrierController extends Controller {

    use BarrierTrait;
  
    /*Metric Or flag Index Page */

    public function getCarePlanBarrierList() {
        $barrier_categories = ManageableField::where('type','barrier_category')->pluck('name','id')->toArray();
        return view('admin.careplan.barriers.index')->with('active', 'care-plan')->with('sub_active', 'barriers')->with('barrier_categories', $barrier_categories);
    }


     /*Metric Or flag  Datatable */

    public function getCarePlanBarrierDataTable(Request $request)
    {
      $barriers = Barrier::query()->with('category')->active()->orderBy('id', 'ASC');
       if($request->has('category') && $request->get('category')) {
           $barriers->where('category_id',  $request->get('category'));
          // $goals->groupBy('goals.id');
       }
        return DataTables::of($barriers)
                 ->addIndexColumn()
                 ->editColumn('category', function($barrier) {
                  return $barrier->category->name;
                  })
                 ->addColumn('action', function ($barrier) {
                            return '<a href="' . route("barrier-create", encrypt_decrypt('encrypt', $barrier->id)) . '"  class="" title="Edit Barrier" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="#"  style="color:red" data-id="'.encrypt_decrypt('encrypt',$barrier->id).'"  data-model="Barrier" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['value', 'action','id'])
            ->make(true);
    }


    /*Tool Add/Edit Form */

    public function getBarrierCreateEdit($id=null)
    {
     $barrier_categories = ManageableField::where('type','barrier_category')->pluck('name','id')->prepend('Please select', '')->toArray();
      if($id)
      {
        $id = encrypt_decrypt('decrypt', $id);
        $barrier = Barrier::findOrFail($id);
      }
      else
      {
        $barrier = new Barrier;   
      }
      return view('admin.careplan.barriers.add', ['barrier'=>$barrier,'barrier_categories'=>$barrier_categories])->with('active', 'care-plan')->with('sub_active', 'barriers');
    }


    /*Tool Save Form */

    public function postBarrierCreate(BarrierRequest $request)
    {
       
      $response = $this->saveBarrier($request);
      if($response)
      {
        $request->session()->flash('message.level','success');
        return $request->submit_btn_type == 1 ? redirect()->route('get_careplan_barriers') : redirect()->route('barrier-create');
      }
      else
      {
        $request->session()->flash('message.level','danger');
        $request->session()->flash('message.content',trans('message.error_added_barrier'));
        return $request->submit_btn_type == 1 ? redirect()->route('get_careplan_barriers') : redirect()->route('barrier-create');
      }
    }

}
