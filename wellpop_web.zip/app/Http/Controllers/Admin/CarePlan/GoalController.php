<?php

namespace App\Http\Controllers\Admin\CarePlan;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Admin\CarePlan\{ Goal, GoalAssignment, SubGoal, Tool, Diagnosis, Barrier };
use App\Http\Requests\{ GoalRequest, GoalDataRequest };
use App\Repositories\CommonRepository;
use App\Traits\Admin\CarePlan\GoalTrait;
//Importing laravel-permission models
use Spatie\Permission\Models\Role;
use View;
use Auth;
use DataTables;



class GoalController extends Controller {

    use GoalTrait;
  
    /**
    * Render view for listing of the Goal.
    *
    * @return \Illuminate\Http\View
    */

    public function getCarePlanGoalList() {
        $diagnosises = Diagnosis::active()->get();
        return view('admin.careplan.goals.index', compact('diagnosises'))->with('active', 'care-plan')->with('sub_active', 'goals');
    }


    /**
    * Display a listing of the Goal.
    *
    * @return DataTables
    */

    public function getCarePlanGoalDataTable(Request $request)
    {
       $goals = Goal::query()->select('goals.*')->active()->orderBy('id', 'ASC');
       if($request->has('diagnosis') && $request->get('diagnosis')) {
           $diagnosisId = $request->get('diagnosis');
           $goals->leftJoin('goal_assignments as ga', function($join){
               $join->on('ga.goal_id', '=', 'goals.id');
               $join->on('ga.version', '=', 'goals.current_version');
           });
           $goals->where('ga.type', "diagnosis");
           $goals->where('ga.type_id', $diagnosisId);
           $goals->where('ga.status', GoalAssignment::ACTIVE);
           $goals->whereNull('ga.deleted_at');
          // $goals->groupBy('goals.id');
       }

       return DataTables::of($goals)
                 ->addIndexColumn()
                 ->addColumn('status_name', function ($goal) {
                            return $goal->status_name;
                        })
                 ->addColumn('diagnosis_name', function ($goal) {
                            $name = '';
                            $array = $goal->diagnosis()->where("goal_assignments.status", GoalAssignment::ACTIVE)->pluck('code')->toArray();
                            if(count($array) > 0)
                             $name =  implode (", ", $array);
                            return $name;
                        })
                 ->addColumn('action', function ($goal) {
                            return '<a href="' . route("goal-create", encrypt_decrypt('encrypt', $goal->id)) . '"  class="" title="Edit Tool" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="javascript:;"  style="color:red" data-id="'.encrypt_decrypt('encrypt', $goal->id).'"  data-model="Goal" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['value', 'action','id'])
            ->make(true);
    }


    /**
     * Display a Goal Add/Edit Form.
     *
     * @return \Illuminate\Http\View
     * @throws \Throwable
     */

    public function getGoalCreateEdit($id=null)
    {
     $metrics = $metrices = CommonRepository::getMetrices();
     $roles = Role::where('name','!=', 'Admin')->get();
        $subgoals = [];
        $questions = [];
        $barriers = [];
        $tools = [];
        $diagnosis = [];

      if($id) {
         $goal = Goal::findOrFail(encrypt_decrypt('decrypt', $id));
         if($this->isPaginateRequest()) {
             return $this->getGoalData(request());
         } else {
             GoalAssignment::where('goal_id',encrypt_decrypt('decrypt', $id))
                 ->where('status',GoalAssignment::PARTIALLY_SAVE)
                 ->forceDelete();

             GoalAssignment::where('goal_id',encrypt_decrypt('decrypt', $id))
                 ->where('status',GoalAssignment::PARTIALLY_DELETED)
                 ->update(['status'=>GoalAssignment::ACTIVE]);


             $subgoals = $goal->sub_goals()->paginate(5);
             $questions = $goal->questions()->paginate(5);
             $barriers = $goal->barriers()->paginate(5);
             $tools = $goal->tools()->paginate(5);
             $diagnosis = $goal->diagnosis()->paginate(5);
         }
      }
      else {
         $goal = new Goal;
      }
      return view('admin.careplan.goals.add', ['goal'=>$goal,'roles'=> $roles,'subgoals' => $subgoals,'questions' =>$questions,'barriers' => $barriers, 'tools' => $tools,'diagnosis'=>$diagnosis])->with('metrics',$metrics)->with('active', 'care-plan')->with('sub_active', 'goals');

    }


    /**
    * Update/Create a Goal .
    *
    * @return \Illuminate\Http\redirect with message
    */

    public function postGoalCreate(GoalRequest $request)
    {

      $response = $this->saveGoal($request);
      if($response) {
        return response()->json(['message'=>trans('message.goal_created_successfully'),'patient_id'=>$response,'message_type'=> $request->message_type,'encrypted_goal_id' => encrypt_decrypt('encrypt', $response)],200);
      }
      else {
        return response()->json(['message'=>trans('message.goal_created_successfully'),'encrypted_goal_id' => encrypt_decrypt('encrypt', $response)],200);
      }
    }

    /**
    * Add a SubGoal, Question,Barriers , Tools and Diagnosis to a Goal
    *
    * @return \Illuminate\Http\redirect with message
    */

    public function postGoalData(GoalDataRequest $request)
    {

      if($request->save_type == Goal::SUB_GOALS) {
          $this->saveOrUpdateSubGoal($request);
      }

      if($request->save_type == Goal::QUESTIONS) {
          $this->saveOrUpdateQuestion($request);
      }

      if($request->save_type == Goal::BARRIERS) {
          $this->saveBarrier($request);
      }

      if($request->save_type == Goal::TOOLS) {
          $this->saveTool($request);
      }
      if($request->save_type == Goal::DIAGNOSIS) {
          $this->saveDiagnosis($request);
      }

      return response()->json(['html'=>''],200);

    }

    /**
    * Edit a SubGoal 
    *
    * @return \Illuminate\Http\response 
    */

    public function editSubgoal($id)
    {
        $subgoal = SubGoal::find($id);
        return response()->json([
            'data' => $subgoal
        ],200);
    }


    /**
     * Get the goal data with pagination
     *
     * @return \Illuminate\Http\response
     * @throws \Throwable
     */
    
    public function getGoalData(Request $request)
    {   
        $dataView = '';
        $gloalId = encrypt_decrypt('decrypt',$request->get('goal_id'));
        $goal = Goal::find($gloalId);
        if($request->type ==  Goal::SUB_GOALS) {
            $subgoals = $goal->sub_goals()
                ->whereNotIn('goal_assignments.status', [GoalAssignment::PARTIALLY_DELETED])
                ->paginate(CASELOAD_PAGINATION_COUNT);
            
            $dataView = view('admin.careplan.sub_goals.index', compact('subgoals','goal'))->render();
        }

        if($request->type ==  Goal::TOOLS) {
            $tools = $goal->tools()
                ->whereNotIn('goal_assignments.status', [GoalAssignment::PARTIALLY_DELETED])
                ->paginate(CASELOAD_PAGINATION_COUNT);

            $dataView = view('admin.careplan.goal_tools.index', compact('tools','goal'))->render();
        }

        if($request->type == Goal::QUESTIONS) {
            $questions = $goal->questions()
                ->whereNotIn('goal_assignments.status', [GoalAssignment::PARTIALLY_DELETED])
                ->paginate(CASELOAD_PAGINATION_COUNT);
            $dataView = view('admin.careplan.questions.index', compact('questions','goal'))->render();
        }

        if($request->type == Goal::BARRIERS) {
            $barriers = $goal->barriers()
                ->whereNotIn('goal_assignments.status', [GoalAssignment::PARTIALLY_DELETED])
                ->paginate(CASELOAD_PAGINATION_COUNT);
            $dataView = view('admin.careplan.goal_barriers.index', compact('barriers','goal'))->render();
        }

        if($request->type == Goal::DIAGNOSIS) {
            $diagnosis = $goal->diagnosis()
                ->whereNotIn('goal_assignments.status', [GoalAssignment::PARTIALLY_DELETED])
                ->paginate(CASELOAD_PAGINATION_COUNT);
            $dataView = view('admin.careplan.goal_diagnosis.index', compact('diagnosis','goal'))->render();
        }
        return  response()->json(['html'=>$dataView],200);
    }

     
    /**
    * Delete a SubGoal/Question/Barriers,Tools and Diagnosis 
    *
    * @return \Illuminate\Http\response 
    */ 

    public function deleteGoalData(Request $request)
    {
        return $this->handleDeleteGoalType($request);
    }



    /**
    * Common function to search the Tools and Diagnosis
    *
    * @return \Illuminate\Http\response 
    */

    public function GetDataByType(Request $request)
    {

      $dataList = [];

        if ($request->has('data') && $request->input('data') !='' && ($request->input('type') == 'tools' && $request->has('goal_id'))) {
          $goal_id = encrypt_decrypt('decrypt',$request->get('goal_id'));

          $goal = Goal::find($goal_id);
          $alreadyAssigned = GoalAssignment::where('goal_id',$goal_id)
              ->where(['type' =>'tool', 'version' => $goal->current_version])
              ->where('status','!=', GoalAssignment::PARTIALLY_DELETED)
              ->pluck('type_id')->toArray();

          if($request->selected_code){
            $ids = array_merge($request->selected_code,$alreadyAssigned);
            $dataList = Tool::where(function($q) use($request){ 
                              $q->orWhere('code', 'like', $request->input('data') . '%')
                              ->orWhere('description', 'like', '%'.$request->input('data').'%');
                              })->whereNotIn('id', $ids)->limit(100)->get();   
          }
          else{
            $dataList = Tool::where(function($q) use($request){ 
                          $q->orWhere('code', 'like', $request->input('data') . '%')
                          ->orWhere('description', 'like', '%'.$request->input('data').'%');
                          })->whereNotIn('id', $alreadyAssigned)->limit(100)->get();  
          }
        }

        if ($request->has('data') && $request->input('data') !='' && ($request->input('type') == 'barriers' && $request->has('goal_id'))) {
          $goal_id = encrypt_decrypt('decrypt',$request->get('goal_id'));

          $goal = Goal::find($goal_id);
          $alreadyAssigned = GoalAssignment::where('goal_id',$goal_id)
              ->where(['type' =>'barrier', 'version' => $goal->current_version])
              ->where('status','!=', GoalAssignment::PARTIALLY_DELETED)
              ->pluck('type_id')->toArray();

          if($request->selected_code){
            $ids = array_merge($request->selected_code,$alreadyAssigned);
            $dataList = Barrier::where(function($q) use($request){ 
                              $q->orWhere('code', 'like', $request->input('data') . '%')
                              ->orWhere('title', 'like', '%'.$request->input('data').'%');
                              })->whereNotIn('id', $ids)->limit(100)->get();   
          }
          else{
            $dataList = Barrier::where(function($q) use($request){ 
                          $q->orWhere('code', 'like', $request->input('data') . '%')
                          ->orWhere('title', 'like', '%'.$request->input('data').'%');
                          })->whereNotIn('id', $alreadyAssigned)->limit(100)->get();  
          }
        }

        if ($request->has('data') && $request->input('data') !='' && ($request->input('type') == 'diagnosis' && $request->has('goal_id'))) {
          $goal_id = encrypt_decrypt('decrypt',$request->get('goal_id'));

            $goal = Goal::find($goal_id);
            $alreadyAssigned = GoalAssignment::where('goal_id',$goal_id)
                ->where(['type' =>'diagnosis', 'version' => $goal->current_version])
                ->where('status','!=', GoalAssignment::PARTIALLY_DELETED)
                ->pluck('type_id')->toArray();

          if($request->selected_code){
            $ids = array_merge($request->selected_code,$alreadyAssigned);
            $dataList = Diagnosis::where(function($q) use($request){ 
                              $q->orWhere('code', 'like', $request->input('data') . '%')
                              ->orWhere('title', 'like', '%'.$request->input('data').'%');
                              })->whereNotIn('id', $ids)->limit(100)->get();   
          }
          else{
            $dataList = Diagnosis::where(function($q) use($request){ 
                          $q->orWhere('code', 'like', $request->input('data') . '%')
                          ->orWhere('title', 'like', '%'.$request->input('data').'%');
                          })->whereNotIn('id', $alreadyAssigned)->limit(100)->get();  
          }
        }

      return response()->json(['html' => $dataList], 200);
    }

}
