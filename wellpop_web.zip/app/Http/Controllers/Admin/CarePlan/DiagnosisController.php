<?php

namespace App\Http\Controllers\Admin\CarePlan;

use Illuminate\Http\Request;
use App\Http\Requests\DiagnosisRequest;
use App\Http\Controllers\Controller;
use App\Models\Admin\CarePlan\Diagnosis;
use App\Models\IcdCode;
use DataTables;
use App\Traits\Admin\CarePlan\DiagnosisTrait;
use App\Repositories\CommonRepository;
use Crypt;
use DB;

class DiagnosisController extends Controller
{
	use DiagnosisTrait;
	


    /**
    * Render view for listing of the Diagnosis.
    *
    * @return \Illuminate\Http\View
    */
    public function getIndex()
    {
		$active = 'care-plan';
		$sub_active = 'diagnosis';
        return view('admin.careplan.diagnosis.index')->with(compact('active', 'sub_active'));
    }
    

    /**
    * Display a listing of the Diagnosis.
    *
    * @return DataTables
    */

    public function getDiagnosisData()
    {
		$diagnosis = Diagnosis::with('icd_codes')->active()->get();
        return DataTables::of($diagnosis)
                 ->addIndexColumn()
                 ->editColumn('icd_code', function($diagnosis) {

                    $icdCodes = $diagnosis->icd_codes()->where('version',$diagnosis->current_version)->get();
					return CommonRepository::getIcdCodesForDiagnosis($icdCodes);
                  })
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($diagnosis) {
                            return '<a style="color:orange" href="' . route("edit-diagnosis", encrypt_decrypt('encrypt', $diagnosis->id)) . '"  class="" title="Edit Diagnosis"><i class="fa fa-pencil"></i></a>
                            <a style="color:red" href="#" data-id="'.encrypt_decrypt('encrypt',$diagnosis->id).'"  data-model="Diagnosis" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }
    



    /**
    * Display a Diagnosis Add Form.
    *
    * @return \Illuminate\Http\View
    */

    public function create()
    {
		$diagnosis = new Diagnosis;
		$icd_codes = IcdCode::select(DB::raw("CONCAT(code,' - ',name) AS code"),'id')->whereIn('id', old('icd_code')??[])->pluck('code','id');
		$metrices = CommonRepository::getMetrices();
		return view('admin.careplan.diagnosis.create',['diagnosis' => $diagnosis, 'active' => 'care-plan', 'sub_active' => 'diagnosis','metrices' => $metrices,'icd_codes' => $icd_codes]);
	}
	

    /**
    * Create a Diagnosis .
    *
    * @return \Illuminate\Http\redirect with message
    */
	public function store(DiagnosisRequest $request)
    {
		$response = $this->createDiagnosis($request);
		if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.diagnosis_created_successfully'));
            //return redirect()->route('diagnosis');
            return $request->submit_btn_type == 1 ? redirect()->route('diagnosis') : redirect()->route('create-diagnosis');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.diagnosis_created_error'));
          //  return redirect()->route('diagnosis');
            return $request->submit_btn_type == 1 ? redirect()->route('diagnosis') : redirect()->route('create-diagnosis');
        }
	}
	   
     /**
    * Display a Diagnosis Edit Form.
    *
    * @return \Illuminate\Http\View
    */

	public function edit($id)
    {
		$diagnosis = Diagnosis::findOrFail(encrypt_decrypt('decrypt', $id));

        //$diagnosis->icd_codes->pluck('icd_code_id')
        $icdCodesList = $diagnosis->icd_codes()->where('version',$diagnosis->current_version)->pluck('icd_code_id');

		$icd_codes = IcdCode::select(DB::raw("CONCAT(code,' - ',name) AS code"),'id')->whereIn('id', $icdCodesList)->pluck('code','id');
		$metrices = CommonRepository::getMetrices();
		return view('admin.careplan.diagnosis.edit',['diagnosis' => $diagnosis, 'active' => 'care-plan', 'sub_active' => 'diagnosis','metrices' => $metrices,'icd_codes' => $icd_codes]);
	}
	

    /**
    * Update a Diagnosis .
    *
    * @return \Illuminate\Http\redirect with message
    */
	public function update($id,DiagnosisRequest $request)
    {  
		$response = $this->updateDiagnosis($request,encrypt_decrypt('decrypt', $id));
		if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.diagnosis_edit_successfully'));
            return redirect()->route('diagnosis');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.diagnosis_edit_error'));
            return redirect()->route('diagnosis');
        }
	}
}
