<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use View;
use Auth;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Models\LastPassword;
use Validator;
use Storage;


class UserController extends Controller
{
	
	public function __construct(){
		$this->middleware(['auth', 'prevent-back-history']);
        $this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });
	}
    public function getIndex()
    {  
        return view('admin.users.index',['active' => 'users'])->render();
    }      

    public function getMyprofile(Request $request)
    {  
        $request->session()->forget('password_expire_time');
        $active = 'patient_referral';
        $user = User::find(Auth::id());
        return view('users.profile',compact('active','user'))->with('active', 'users');
    }    

    public function updatePersonalInfo(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'name' => 'required|min:2|max:55'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        // echo "<pre>";print_r($request->all());exit;
        $user = User::find(Auth::id())->update(['name'=>$request->name]);
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Name has been successfully updated.');
        return response()->json(['message'=>'Name updated successfully.'],200);
    }    

    public function changePassword(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'password' => 'required|min:8|max:16|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\X])(?=.*[!$#%@]).*$/|old_password:user,'.Auth::id(),
            'password_confirmation' => 'required|min:6|max:55'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        $validator = Validator::make($request->all(),[
            'password' => 'confirmed'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        
        $user = User::find(Auth::id())->update(['password'=>Hash::make($request->password),'password_expiry' => \Carbon\Carbon::now()->addDays(15)]);

        $flight = LastPassword::create(['password' =>Hash::make($request->password),'type_id'=>Auth::id(),'type'=>'user']);
        
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Password has been successfully updated.');
        return response()->json(['message'=>'Password updated successfully.'],200);
    }    

    public function changeProfilePicture(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        
        $imageName = time().'.'.request()->image->getClientOriginalExtension();

        //request()->image->move(public_path('images/profile_pics'), $imageName);
        Storage::disk('s3')->put(config('filesystems.s3_user_images_partial_path').Auth::id().'/'.$imageName, file_get_contents($request->file('image')),'public');

        $user = User::find(Auth::id())->update(['image'=> $imageName]);
        
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Profile picture has been successfully updated.');
        return response()->json(['message'=>'Profile picture updated successfully.'],200);
	}
}
