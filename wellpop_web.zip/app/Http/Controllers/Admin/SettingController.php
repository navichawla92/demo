<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\DB;
use App\Models\Patient;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ReferralSource as ReferralSourceRequest; 
use App\Http\Requests\PcpInfo as PcpInfoRequest; 
use App\Models\ReferralSource;
use App\Models\PcpInformation;
use App\Models\Registry;
use View;
use Helper;
// use Illuminate\Support\Facades\Session;
use App\Models\User;
use Storage;
use Auth;
use Validator;


class SettingController extends Controller
{
	
	public function __construct(){
		$this->middleware(['auth', 'prevent-back-history']);
	}
    
    public function postReferralCreate(ReferralSourceRequest $request)
    {

       
        $referral_record= new Registry();
        $referral_record->fill($request->except('_token'));
        $referral_record->type = 'referral_sources';
		$referral_record->save();

        if($referral_record)
        {
            
            $var = "<option value=$referral_record->id> $referral_record->org_name</option>";
            return response()->json(['message'=>'Referral Source created successfully.','option'=>$var],200);
        }
        else
        {
           
            return response()->json(['message'=>'Some error while added new Referral.'],500);            
        }
    }

    /*
    * This function will be use to add PCP/Specialist from frontend
    */
    public function postPcpInformationCreate(PcpInfoRequest $request)
    {
        $pcp_information= new Registry();
        $pcp_information->fill($request->except('_token'));
        $pcp_information->save();

        if($pcp_information)
        {
            $var =  "<option value='$pcp_information->id' data-address_line1='$pcp_information->address_line1' data-address_line2='$pcp_information->address_line2' data-city='$pcp_information->city' data-zip_code='$pcp_information->zip' data-contact_name='$pcp_information->contact_name' data-contact_phone='$pcp_information->contact_phone' data-contact_email='$pcp_information->contact_email' data-contact_title='$pcp_information->contact_title' data-speciality='$pcp_information->speciality' data-org_name='$pcp_information->org_name' data-state_id='$pcp_information->state_id' data-state_name='$pcp_information->state_name' data-phone='$pcp_information->phone_number' data-fax='$pcp_information->fax' data-email='$pcp_information->email' data-web_address='$pcp_information->web_address'>$pcp_information->name</option>";
            return response()->json(['message'=>'Pcp created successfully.','option'=>$var],200);
        }
        else
        {           
            return response()->json(['message'=>'Some error while added new Pcp.'],500);            
        }
    }      

    /*
    * This function will be use to add Rehab/MentalHealthAssistance/HousingAssistance from frontend
    */
    public function postRegistryCreate(Request $request)
    {
        
        $messages = [
            'name.required' => 'Enter organization name.',
            'name.min' => 'The organization name may not be greater than 60 characters.',
            'name.regex' => "Only special characters - ' . and alphabets are allowed."
        ];

        $validator = Validator::make($request->all(),[
            'name' => "nullable|max:60|regex:/^[\pL\s\-\. ']+$/u",
            'org_name' => "required|max:60|regex:/^[\pL\s\-\. '0-9]+$/u",
            'address_line1' => 'required|max:100',
            'address_line2' => 'nullable|max:100',
            'city' => 'required|max:50',
            'zip' => 'bail|required|min:5|max:5|regex:/^[0-9]+$/u',
            'state_id' => 'required|exists:states,id',
            'phone_number' => 'required|phone',
            'fax' => 'nullable|max:10|regex:/^[0-9]+$/u',
           // 'web_address' => 'nullable|max:100|url',
            'web_address' => ['nullable', 'max:100','regex:/^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/u'],
            'contact_name' => "nullable|max:60|regex:/^[\pL\s\-\. ']+$/u",
            'contact_title' => "nullable|regex:/^[\pL\s\-\. ']+$/u",
          //  'contact_email' => 'nullable|email|max:45|unique:registries,contact_email,type,'.$request->type,
            'contact_email' => 'nullable|email|max:45|unique:registries,contact_email,null,id,type,'.$request->type.'',
            'contact_phone' => 'nullable|phone'
        ],$messages);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        $registry = new Registry();
        $registry->fill($request->except('_token'));
        $registry->save();

        if($registry)
        {
            return response()->json(['message'=>'Registry added successfully.'],200);
        }
        else
        {           
            return response()->json(['message'=>'Some error while added new registry.'],200);            
        }
    }          
}
