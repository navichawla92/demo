<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\LastPassword;
use App\Models\ManageableField;
use App\Models\ContractPayer;
use App\Models\Registry;
use App\Models\PcpInformation;
use App\Models\ReferralSource;
use App\Models\PatientAllergy;
use App\Models\PatientMedication;
use App\Models\Patient;
use Auth;
use App\Mail\PasswordCreate;
use App\Mail\CasemanagerRegistered;
//Importing laravel-permission models
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Permission;
use App\Http\Requests\CaseManager as CaseManagerRequest; 
use App\Http\Requests\ManageAbleField as ManageAbleFieldRequest; 
use App\Http\Requests\ContractPayer as ContractPayerRequest; 
use App\Http\Requests\RegistryType1 as RegistryType1Request; 
use App\Http\Requests\PcpInformation as PcpInformationRequest; 
use App\Http\Requests\Specialist as SpecialistRequest; 
use App\Http\Requests\ReferralSource as ReferralSourceRequest; 
use App\Models\State;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Mail; 
use Illuminate\Contracts\Hashing\Hasher as HasherContract;
//Enables us to output flash messaging
use Session;
use DataTables;
use Validator;
use Storage;

class AdminController extends Controller {

    protected $hashKey;
    public function __construct() {
        $this->middleware(['auth', 'isAdmin', 'prevent-back-history']); //isAdmin middleware lets only users with a //specific permission permission to access these resources
        // $this->hashKey = $hashKey;
        // $this->hasher = $hasher;
    }

    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */
    public function getIndex() {
        //Get all users and pass it to the view
        return view('admin.users.index')->with('active', 'users');
    }

    
    public function getMyprofile(Request $request)
    {  
        $active = 'patient_referral';
        $user = User::find(Auth::id());
        return view('admin.users.profile',compact('active','user'));
    }

    public function updatePersonalInfo(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'name' => 'required|min:2|max:55'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        // echo "<pre>";print_r($request->all());exit;
        $user = User::find(Auth::id())->update(['name'=>$request->name]);
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Name has been successfully updated.');
        return response()->json(['message'=>'Name updated successfully.'],200);
    }    

    public function changePassword(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'password' => 'bail|required|min:8|max:16|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\X])(?=.*[!$#%@]).*$/|old_password:user,'.Auth::id(),
            'password_confirmation' => 'required|min:6|max:55'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }

        $validator = Validator::make($request->all(),[
            'password' => 'confirmed'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        
        $user = User::find(Auth::id())->update(['password'=>Hash::make($request->password),'password_expiry' => \Carbon\Carbon::now()->addDays(15)]);

        $flight = LastPassword::create(['password' =>Hash::make($request->password),'type_id'=>Auth::id(),'type'=>'user']);
        
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Password has been successfully updated.');
        return response()->json(['message'=>'Password updated successfully.'],200);
    }    

    public function changeProfilePicture(Request $request)
    {  
        $validator = Validator::make($request->all(),[
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if($validator->fails()){
            return response()->json(['errors'=>$validator->errors()],422);
        }
        
        $imageName = time().'.'.request()->image->getClientOriginalExtension();

        //request()->image->move(public_path('images/profile_pics'), $imageName);
        Storage::disk('s3')->put(config('filesystems.s3_user_images_partial_path').Auth::id().'/'.$imageName, file_get_contents($request->file('image')),'public');

        $user = User::find(Auth::id())->update(['image'=> $imageName]);
        
        $request->session()->flash('message.level','success');
        $request->session()->flash('message.content','Profile picture has been successfully updated.');
        return response()->json(['message'=>'Profile picture updated successfully.'],200);
  }
  
    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */

    public function getUsers()
    {
        $users = User::query()->whereHas("roles", function($q){ $q->where("name", '!=', "Admin"); })->with("roles")->orderBy('id', 'DESC');
        return \ DataTables::of($users)->editColumn('status', 'admin.users.datatables.status_column')->addColumn('actions', 'admin.users.datatables.action_buttons ')->rawColumns(['actions','status'])->addIndexColumn()->addColumn('role', function ($setting) {
              return $setting->roles[0]->name;
          })->make(true);
    }

    public function postChangeStatus(Request $request)
    {
    
        $response=User::where('id',$request->id)->update(['status'=>$request->status]);
        
        if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content','User status changed successfully.');
            return response()->json(['message'=>'User status changed successfully.','status'=>1],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while changing user status.');
            return response()->json(['message'=>'Some error while changing user status.','status'=>0],200);            
        }
    }

  
    public function getCreateEdit($id=null)
    {
      if($id)
      {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $casemanager = User::find($id);  
            
      }
      else
      {
         $casemanager = new User;   
      }

      $roles = Role::where('name','!=', 'Admin')->pluck('name','id')->toArray();;
      return view('admin.users.add', ['roles'=>$roles,'casemanager'=>$casemanager, 'active' => 'users']);
    }

    public function postCreate(CaseManagerRequest $request)
    {
      $confirmation_code = str_random(30);  
      $userData = $request->only('email', 'name','phone');
      $userData['confirmation_code'] = $confirmation_code;
      $userData['status'] = '2';
      $user = User::create($userData);
      //$user->sendEmailVerificationNotification();

      // $reset_token = bcrypt(strtolower(str_random(64)));
      //$reset_token = Hash::make(Str::random(40));//hash_hmac('sha256', Str::random(40), $this->hashKey);
      //$reset_token = $this->hasher->make($reset_token)

      $reset_token = app('auth.password.broker')->createToken($user);

      /*\DB::table('password_resets')->insert([
          'email' => $user->email,
          'token' => $reset_token,
          'created_at' => Carbon::now(),
      ]);*/

      Mail::to($user->email)->send(new PasswordCreate($reset_token));

      $roles = $request['roles']; //Retrieving the roles field
      if (isset($roles)) {
         $role_r = Role::where('id', '=', $roles)->firstOrFail();  
         if($role_r)
              $user->assignRole($role_r); 
         /* foreach ($roles as $role) {
            $role_r = Role::where('id', '=', $role)->firstOrFail();            
            if($role_r)
              $user->assignRole($role_r); //Assigning role to user
          }*/
      }     

      // $data = ['confirmation_code' => $confirmation_code,'email'=>$userData['email']];
      // Mail::send('emails.verify', $data, function($message) use ($data){
      //   $message->to($data['email'])->subject('Verify your email address');
      // });  

      return redirect()->route('users')
            ->with('flash_message',
             'User successfully added.');
    }


   
     /*ManageAble field Index Page */

    public function getManageAbleFieldList() {
        return view('admin.settings.manageable_fields.index')->with('active', 'settings')->with('sub_active', 'manageable_fields');
    }


     /*ManageAble field Datatable */

    public function getManageAbleField()
    {
      $settings = ManageableField::query()->whereNotIn('type', ['flag','metric'])->orderBy('id', 'DESC');
        return DataTables::of($settings)
                 ->addIndexColumn()
                 ->editColumn('type', function($setting) {
                  return $setting->typevalue;
                  })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['type', 'action','id'])
               /*  ->addColumn('action', function ($setting) {
                            return '<a href="' . route("field-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Feild" style="color:orange"><i class="fa fa-pencil"></i></a>
                            <a href="#"  style="color:red" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="ManageableField" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })*/
            ->make(true);
    }


     /*ManageAble field Add/Edit Form */

    public function getFieldCreateEdit($id=null)
    {
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $manageablefield = ManageableField::find($id);  
            
        }
        else
        {
            $manageablefield = new ManageableField;   
        }
      return view('admin.settings.manageable_fields.add', ['manageablefield'=>$manageablefield])->with('active', 'settings')->with('sub_active', 'manageable_fields');
    }


    /*ManageAble field Save Form */

    public function postFieldCreate(ManageAbleFieldRequest $request)
    {
      $fieldData=$request->only('type', 'name');
      $fieldData['user_id']=Auth::id();
        if($request->field_id){
          try{
                $id = \Crypt::decrypt($request->field_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ManageableField::find($id);  
          $response=$manageablefield->update($fieldData);
          $request->session()->flash('message.content','Field Updated successfully.');
        }
        else {
          $response = ManageableField::create($fieldData);  
          
          $request->session()->flash('message.content','Field added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('manageablefields')->with('flash_message','Field successfully added.');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new field.');
            return redirect()->route('manageablefields')->with('flash_message','Field successfully added.');
        }
      
    }

    
    /*Contract Payer index page */

    public function getContractPayerList() {
        return view('admin.settings.contract_payers.index')->with('active', 'settings')->with('sub_active', 'contract_payers');
    }

    /*Contract Payer Datatable*/

    public function getContractPayers()
    {
        

        $settings = ContractPayer::query()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                 ->addIndexColumn()
                 ->orderColumn('id', '-id $1')
                 //->rawColumns(['type', 'action','id'])
                 ->rawColumns(['action'])
                 ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                 ->editColumn('code', function($setting) {
                    if(!empty($setting->code))
                      return $setting->code;
                    else
                      return '-';
                  }) 
                 ->editColumn('organization', function($setting) {
                    if(!empty($setting->organization))
                      return $setting->organization;
                    else
                      return '-';
                  })
                 ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                  ->addColumn('action', function ($setting) {
                            return '<a href="' . route("contract_payers-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Contract Payer" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="#"  style="color:red" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="ContractPayer" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*Contract Payer Add/Edit Form */

    public function getContractPayerCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $contractPayer = ContractPayer::find($id);  
            
        }
        else
        {
            $contractPayer = new ContractPayer;   
        }
      return view('admin.settings.contract_payers.add', ['contractPayer'=>$contractPayer,'states'=>$states])->with('active', 'settings')->with('sub_active', 'contract_payers');
    }


     /*Contract Payer Save Form */

    public function postContractPayerCreate(ContractPayerRequest $request)
    {

     
        if($request->contractpayer_id){
          try{
                $id = \Crypt::decrypt($request->contractpayer_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ContractPayer::find($id);  
          $start_date  = change_date_format($request->start_date);
          $request->request->add(['start_date'=>$start_date]);
          $end_date  = change_date_format($request->end_date);
          $request->request->add(['end_date'=>$end_date]);
          $data= $request->except('_token','contractpayer_id','name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','Contract Payer Updated successfully.');
        }
        else {
          $start_date  = change_date_format($request->start_date);
          $request->request->add(['start_date'=>$start_date]);
          $end_date  = change_date_format($request->end_date);
          $request->request->add(['end_date'=>$end_date]);
          $data= $request->except('_token','contractpayer_id');
          $data['user_id']=Auth::id();
          $response = ContractPayer::create($data);  
          
          $request->session()->flash('message.content','Contract Payer added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('contract_payers');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new contract payer.');
            return redirect()->route('contract_payers');
        }
      
    }


    /*Insurance index page */

    public function getRegistryType1List($type) {

        return view('admin.settings.'.$type.'.index')->with('active', 'settings')->with('sub_active',$type);
    }

    /*Insurance Datatable*/

    public function getRegistryType1($type)
    {
        
       
      $settings = Registry::registry($type)->orderBy('id', 'DESC');
      
      return DataTables::of($settings)
              ->addIndexColumn()
             ->rawColumns(['action'])
             ->addColumn('action', function ($setting) {
                        return '<a href="'.route("registry_type1-create", [$setting->type,\Crypt::encrypt($setting->id)]) . '"  style="color:orange"
                        class="" title="Edit"><i class="fa fa-pencil"></i></a>
                        <a style="color:red" href="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="Registry" data-type="'.$setting->type.'"  class="delete_model_by_id">
                       <i class="fa fa-trash" aria-hidden="true"></i>
                      </a>';
                    })
        ->make(true);
    }

     /*Insurance Add/Edit Form */

    public function getRegistryType1CreateEdit($type,$id=null)
    {
      
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $registry = Registry::find($id);  
            
        }
        else
        {
            $registry = new Registry;   
        }
      return view('admin.settings.'.$type.'.add', ['registry'=>$registry,'states'=>$states])->with('active', 'settings')->with('sub_active', $type);
    }


     /*Insurance Save Form */

    public function postRegistryType1Create(RegistryType1Request $request)
    {

     
        if($request->id){
          try{
                $id = \Crypt::decrypt($request->id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }

          $typeData = (substr($request->input('type'), -1) == 's')   ? substr($request->input('type'), 0, -1) : $request->input('type');
          $typeData = str_replace("_", " ",$typeData);
          if($typeData == 'rehab'){
            $message = ucfirst($typeData).' Information';
          }
          else {
            $message = ucfirst($typeData);
          }
          $manageablefield = Registry::find($id);  
          $data= $request->except('_token','id','name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content',''.$message.' updated successfully.');
        }
        else {
          
          $typeData = (substr($request->input('type'), -1) == 's')   ? substr($request->input('type'), 0, -1) : $request->input('type');
          $typeData = str_replace("_", " ",$typeData);
          if($typeData == 'rehab'){
            $message = ucfirst($typeData).' Information';
          }
          else {
            $message = ucfirst($typeData);
          }
          $data= $request->except('_token','id');
          
          $data['user_id']=Auth::id();
          $response = Registry::create($data);  
          
          $request->session()->flash('message.content',''.$message.' added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('get_listing',[$request->input('type')]);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new '.$message.'.');
            return redirect()->route('get_listing',[$request->input('type')]);
        }
      
    }



   

 


    /*PCPInfo index page */

    public function getPcpInformationsList() {
        return view('admin.settings.pcp_informations.index')->with('active', 'settings')->with('sub_active', 'pcp_informations');
    }

    /*PCPInfo Datatable*/

    public function getPcpInformations()
    {
        

        $settings = PcpInformation::PcpInformation()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("pcp_informations-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit PCP Information"><i class="fa fa-pencil"></i></a>
                            <a style="color:red"  ="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="PcpInformation" data-type="pcp" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*PCPInfo Add/Edit Form */

    public function getPcpInformationsCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $pcpInformation = PcpInformation::find($id);  
            
        }
        else
        {
            $pcpInformation = new PcpInformation;   
        }
      return view('admin.settings.pcp_informations.add', ['pcpInformation'=>$pcpInformation,'states'=>$states])->with('active', 'settings')->with('sub_active', 'pcp_informations');
    }


     /*PCPInfo Save Form */

    public function postPcpInformationsCreate(PcpInformationRequest $request)
    {

     
        if($request->pcp_information_id){
          try{
                $id = \Crypt::decrypt($request->pcp_information_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = PcpInformation::find($id);  
          $data= $request->except('_token','pcp_information_id','doctor_name');
          $data['type']='pcp';
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','PcpInformation Updated successfully.');
        }
        else {
          $data= $request->except('_token','pcp_information_id');
          $data['type']='pcp';
          $data['user_id']=Auth::id();
          $response = PcpInformation::create($data);  
          $request->session()->flash('message.content','PcpInformation added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('pcp_informations');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new pcpInformation.');
            return redirect()->route('pcp_informations');
        }
      
    }




    /*ReferralSource index page */

    public function getReferralSourceList() {
        return view('admin.settings.referral_sources.index')->with('active', 'settings')->with('sub_active', 'referral_sources');
    }

    /*ReferralSource Datatable*/

    public function getReferralSources()
    {
        

        $settings = ReferralSource::query()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('code', function($setting) {
                    if(!empty($setting->code))
                      return $setting->code;
                    else
                      return '-';
                  })
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('web_address', function($setting) {
                    if(!empty($setting->web_address))
                      return $setting->web_address;
                    else
                      return '-';
                  })
                  ->editColumn('web_address', function($setting) {
                    if(!empty($setting->web_address))
                      return $setting->web_address;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                // ->orderColumn('id', '-id $1')
                 //->rawColumns(['type', 'action','id'])
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("referral_sources-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Referral Source"><i class="fa fa-pencil"></i></a>
                            <a style="color:red" href="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="ReferralSource" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

    /*ReferralSource Add/Edit Form */

    public function getReferralSourceCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $referralSource = ReferralSource::find($id);  
            
        }
        else
        {
            $referralSource = new ReferralSource;   
        }
      return view('admin.settings.referral_sources.add', ['referralSource'=>$referralSource,'states'=>$states])->with('active', 'settings')->with('sub_active', 'referral_sources');
    }


    /*ReferralSource Save Form */

    public function postReferralSourceCreate(ReferralSourceRequest $request)
    {

     
        if($request->referral_source_id){
          try{
                $id = \Crypt::decrypt($request->referral_source_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ReferralSource::find($id);  
          $data= $request->except('_token','referral_source_id','org_name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','Referral Source Updated successfully.');
        }
        else {
          $data= $request->except('_token','referral_source_id');
          $data['user_id']=Auth::id();
          $response = ReferralSource::create($data);  
          $request->session()->flash('message.content','Referral Source added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('referral_sources');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new referral source.');
            return redirect()->route('referral_sources');
        }
      
    }


    /* Delete Method to soft delete the data */
     public function deleteById(Request $request)
     {

        // emergency and specialst pending
        if ($request->has('id') && $request->has('model')){

            try{
                $id = decrypt($request->get('id'));
            } catch (DecryptException $e) {
                 $request->session()->flash('message.level','danger');
                 $request->session()->flash('message.content','Some error while delete record.');
                 exit;
            }

          $model='';
          $value=$request->input('model');
          $type=$request->input('type');
          switch ($value) {
            case 'ManageableField':
                $model = \App\Models\ManageableField::find($id)->delete();
                break;
            case 'ContractPayer':
                if(\App\Models\Patient::where('contract_payer', $id)->exists()){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Contract payer is already assigned to a patient.');
                }
                else {
                   $model = \App\Models\ContractPayer::find($id)->delete();
                   $request->session()->flash('message.level','success');
                   $request->session()->flash('message.content','Contract payer Deleted successfully.');
                }
                break;
            case 'PcpInformation':
                if(\App\Models\Patient::where('pcp_id', $id)->exists() &&  $type == 'pcp'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Pcp Information is already assigned to a patient.');
                }
                else if(\App\Models\Patient::where('specialist_id', 'like', "%\"{$id}\"%")->exists() &&  $type == 'speciality'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Specialty is already assigned to a patient.');
                }
                else {
                  $request->session()->flash('message.level','success');
                  $request->session()->flash('message.content','Specialty Deleted successfully.');
                  $model = \App\Models\PcpInformation::find($id)->delete();
                }
                break;
            case 'ReferralSource':
                 if(\App\Models\Patient::where('referral_source', $id)->exists()){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Referral Source is already assigned to a patient.');
                }
                else {
                    $model = \App\Models\ReferralSource::find($id)->delete();
                    $request->session()->flash('message.level','success');
                    $request->session()->flash('message.content','Referral Source Deleted successfully.');
                }
            case 'Tool':
               $model = \App\Models\Admin\CarePlan\Tool::find($id);
                if (!$model->hasGoal()) {
                    $model->delete();
                    $request->session()->flash('message.level','success');
                    $request->session()->flash('message.content','Record Deleted successfully.');
                } else {
                    $request->session()->flash('message.level','danger');
                    $request->session()->flash('message.content','Tool cannot be deleted because tool is associated with a goal.');
                }

                break;
            case 'Registry':
                if(\App\Models\Patient::where('rehab_information_id', $id)->exists() &&  $type == 'rehabs'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Rehab Information is already assigned to a patient.');
                }
                else if(\App\Models\Patient::where('home_health_provider_id', $id)->exists() &&  $type == 'home_health_providers'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Home Health Provider is already assigned to a patient.');
                }
                else if(\App\Models\Patient::where('mental_health_assistance_id', $id)->exists() &&  $type == 'mental_health_assistances'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Mental Health Assistance is already assigned to a patient.');
                }
                else if(\App\Models\Patient::where('housing_assistance_id', $id)->exists() &&  $type == 'housing_assistances'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Housing Assistance is already assigned to a patient.');
                }
                else if(\App\Models\Patient::where('hospice_provider_id', $id)->exists() &&  $type == 'hospice_providers'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Hospice Provider is already assigned to a patient.');
                }
                else if(\App\Models\PatientInsurance::where('insurance_id', $id)->exists()  &&  $type == 'insurances'){
                  $model = 2;
                  $request->session()->flash('message.level','danger');
                  $request->session()->flash('message.content','This Insurance is already assigned to a patient.');
                }
                else {
                  $model = \App\Models\Registry::find($id)->delete();
                  $request->session()->flash('message.level','success');
                  $request->session()->flash('message.content','Record Deleted successfully.');
                }
                break;

              case 'Goal':
                  $model = \App\Models\Admin\CarePlan\Goal::find($id)->delete();
                  $request->session()->flash('message.level','success');
                  $request->session()->flash('message.content','Record Deleted successfully.');
                  break;

              case 'Diagnosis':
                  $model = \App\Models\Admin\CarePlan\Diagnosis::find($id);
                  if (!$model->hasGoal()) {
                      $model->delete();
                      $request->session()->flash('message.level','success');
                      $request->session()->flash('message.content','Record Deleted successfully.');
                  } else {
                      $request->session()->flash('message.level','danger');
                      $request->session()->flash('message.content','Diagnosis cannot be deleted because diagnosis is associated with a goal.');
                  }

                  break;
            default:
                $model = 0;
                break;
           }
          if($model){
               return response()->json(['message'=>'Record Deleted successfully.','status'=>1],200);
          }
         
          else {
                $request->session()->flash('message.level','danger');
                $request->session()->flash('message.content','Some error while delete record.');
                return response()->json(['message'=>'Some error while delete record.','status'=>0],200);
          }
            

           
        }
        else {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while delete record.');
            return response()->json(['message'=>'','status'=>0],200);

        }
        

     }



     /*Patients Index Page */

    public function getPatientList() {
        return view('admin.patients.index')->with('active', 'patients');
    }


     /*Patients Datatable */

    public function getPatients()
    {
        

        $patients = Patient::query()->orderBy('id', 'DESC');
         return DataTables::of($patients)
                 ->addIndexColumn()
                 ->orderColumn('id', 'id $1')
                 ->rawColumns(['action','id'])
                 ->addColumn('action', function ($patient) {
                            return '<a style="color:orange" href="' . route("patient-log", \Crypt::encrypt($patient->id)) . '"  class="" title="Activity Logs"><i class="fa fa-history"></i></a>';
                })
                 ->addColumn('name', function ($patient) {
                    $patient->calc($patient->random_key);
                    $full_name = $patient->first_name;
                    if(!empty($patient->middle_initial))
                      $full_name .= ' '.$patient->middle_initial;
                    $full_name .= ' '.$patient->last_name;
                    return $full_name;
                })
                ->make(true);
    }

     /*Patients log */

    public function getPatientLog($id=null,Request $request)
    {
      
      $referral_sources = ReferralSource::all()->pluck('org_name','id')->toArray();
      $contract_payers = ContractPayer::all()->pluck('name','id')->toArray();
      $pcp_informations = PcpInformation::all()->pluck('doctor_name','id')->toArray();
      $insurances = Registry::insurance()->pluck('name','id')->toArray();

      if($id)
        {
          try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
           $patient = Patient::find($id);
           $patientIdArray[] = $patient->id;
           $patientDataIdArray=[];
           $patientIsuranceIdArray=[];
           $patientCallIdArray=[];
           $patientAssessmentArray=[];
           $patientAssignmentArray=[];
           $patientAllergyArray=[];
           $patientMedicationArray=[];
           $patientAssignmentArray=[];
           if($patient->patient_data){
              $patientDataIdArray = $patient->patient_data()->withTrashed()->pluck('id')->toArray();
           }
           if($patient->insuranceData){
              $patientIsuranceIdArray = $patient->insuranceData()->withTrashed()->pluck('id')->toArray();
           }
           if($patient->patient_call){
              $patientCallIdArray = $patient->patient_call()->withTrashed()->pluck('id')->toArray();
           }
           if($patient->patient_assessment){
              $patientAssessmentArray = $patient->patient_assessment()->withTrashed()->pluck('id')->toArray();
           }

           if($patient->patient_assignment){
              $patientAssignmentArray = $patient->patient_assignment()->withTrashed()->pluck('id')->toArray();
           }
           if($patient->patient_allergies){
              $patientAllergyArray = $patient->patient_allergies()->withTrashed()->pluck('id')->toArray();
           }
           if($patient->patient_medications){
              $patientMedicationArray = $patient->patient_medications()->withTrashed()->pluck('id')->toArray();
           }

           
           $IdArray = array_merge($patientDataIdArray,$patientIsuranceIdArray);
           $auditIds = array_merge($IdArray,$patientIdArray);
           $auditIds = array_merge($auditIds,$patientCallIdArray);
           $auditIds = array_merge($auditIds,$patientAssessmentArray);
           $auditIds = array_merge($auditIds,$patientAssignmentArray);
           $auditIds = array_merge($auditIds,$patientAllergyArray);
           $auditIds = array_merge($auditIds,$patientMedicationArray);
           $logsData = \ OwenIt\Auditing\Models\Audit::whereIn('auditable_id', $auditIds)->where('patient_id', '=', $patient->id);
           $logs = $logsData->paginate(8);

           $itemExit = 1;
           if(empty($logs->items())){
            $itemExit = 0;
           }
           

           if ($request->ajax()) {
                 $view = view('admin.patients.log_table',['logs' => $logs,'key'=>$patient->random_key,'insurances'=>$insurances,'referral_sources'=>$referral_sources,'contract_payers'=>$contract_payers,'pcp_informations'=>$pcp_informations,'itemExit'=>$itemExit])->render(); 
                return response()->json(['html'=>$view,'itemExit'=>$itemExit]);
            }
           return view('admin.patients.view_log', ['logs' => $logs,'key'=>$patient->random_key,'insurances'=>$insurances,'referral_sources'=>$referral_sources,'contract_payers'=>$contract_payers,'pcp_informations'=>$pcp_informations,'itemExit'=>$itemExit,'active' => 'patients'])->render(); 
        }
       
    }


   



    /*Speciality index page */

    public function getSpecialityList() {
        return view('admin.settings.specialities.index')->with('active', 'settings')->with('sub_active', 'specialities');
    }

    /*Speciality Datatable*/

    public function getSpecialities()
    {
        

        $settings = PcpInformation::speciality()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("specialities-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Specialty"><i class="fa fa-pencil"></i></a>
                            <a style="color:red"  ="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="PcpInformation" data-type="speciality" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*Speciality Add/Edit Form */

    public function getSpecialityCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $speciality = PcpInformation::find($id);  
            
        }
        else
        {
            $speciality = new PcpInformation;   
        }
      return view('admin.settings.specialities.add', ['speciality'=>$speciality,'states'=>$states])->with('active', 'settings')->with('sub_active', 'specialities');
    }


     /*Speciality Save Form */

    public function postSpecialityCreate(SpecialistRequest $request)
    {

     
        if($request->speciality_id){
          try{
                $id = \Crypt::decrypt($request->speciality_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = PcpInformation::find($id);  
          $data= $request->except('_token','speciality_id','doctor_name');
          $data['type']='specialist';
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','Specialty Updated successfully.');
        }
        else {
          $data= $request->except('_token','speciality_id');
          $data['type']='specialist';
          $data['user_id']=Auth::id();
          $response = PcpInformation::create($data);  
          $request->session()->flash('message.content','Specialty added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('specialities');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new speciality.');
            return redirect()->route('specialities');
        }
      
    }


}
