<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\ManageableField;
use App\Models\ContractPayer;
use App\Models\Registry;
use App\Models\PcpInformation;
use App\Models\ReferralSource;
use App\Models\PatientAllergy;
use App\Models\PatientMedication;
use App\Models\Patient;
use Auth;
//Importing laravel-permission models
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Permission;
use App\Http\Requests\ManageAbleField as ManageAbleFieldRequest; 
use App\Http\Requests\ContractPayer as ContractPayerRequest; 
use App\Http\Requests\RegistryType1 as RegistryType1Request; 
use App\Http\Requests\PcpInformation as PcpInformationRequest; 
use App\Http\Requests\Specialist as SpecialistRequest; 
use App\Http\Requests\ReferralSource as ReferralSourceRequest; 
use App\Models\State;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Contracts\Hashing\Hasher as HasherContract;
//Enables us to output flash messaging
use Session;
use DataTables;
use Validator;
use Storage;

class RegistryController extends Controller {

    protected $hashKey;
    public function __construct() {
        $this->middleware(['auth', 'isAdmin', 'prevent-back-history']); //isAdmin middleware lets only users with a //specific permission permission to access these resources
        // $this->hashKey = $hashKey;
        // $this->hasher = $hasher;
    }

   
     /*ManageAble field Index Page */

    public function getManageAbleFieldList() {
        return view('admin.settings.manageable_fields.index')->with('active', 'settings')->with('sub_active', 'manageable_fields');
    }


     /*ManageAble field Datatable */

    public function getManageAbleField()
    {
      $settings = ManageableField::query()->whereNotIn('type', ['flag','metric','barrier_category'])->orderBy('id', 'DESC');
      
        return DataTables::of($settings)
                 ->addIndexColumn()
                 ->editColumn('type', function($setting) {
                  return $setting->typevalue;
                  })
                 ->orderColumn('id', 'id -$1')
                 ->rawColumns(['type', 'action','id'])
            ->make(true);
    }


     /*ManageAble field Add/Edit Form */

    public function getFieldCreateEdit($id=null)
    {
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $manageablefield = ManageableField::find($id);  
            
        }
        else
        {
            $manageablefield = new ManageableField;   
        }
      return view('admin.settings.manageable_fields.add', ['manageablefield'=>$manageablefield])->with('active', 'settings')->with('sub_active', 'manageable_fields');
    }


    /*ManageAble field Save Form */

    public function postFieldCreate(ManageAbleFieldRequest $request)
    {
      $fieldData=$request->only('type', 'name');
      $fieldData['user_id']=Auth::id();
        if($request->field_id){
          try{
                $id = \Crypt::decrypt($request->field_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ManageableField::find($id);  
          $response=$manageablefield->update($fieldData);
          $request->session()->flash('message.content',trans('message.field_update_successfully'));
        }
        else {
          $response = ManageableField::create($fieldData);  
          
          $request->session()->flash('message.content',trans('message.field_added_successfully'));
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('manageablefields')->with('flash_message',trans('message.field_added_successfully'));
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.field_added_error'));
            return redirect()->route('manageablefields')->with('flash_message',trans('message.field_added_error'));
        }
      
    }

    
    /*Contract Payer index page */

    public function getContractPayerList() {
        return view('admin.settings.contract_payers.index')->with('active', 'settings')->with('sub_active', 'contract_payers');
    }

    /*Contract Payer Datatable*/

    public function getContractPayers()
    {
        

        $settings = ContractPayer::query()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                 ->addIndexColumn()
                 ->orderColumn('id', '-id $1')
                 //->rawColumns(['type', 'action','id'])
                 ->rawColumns(['action'])
                 ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                 ->editColumn('code', function($setting) {
                    if(!empty($setting->code))
                      return $setting->code;
                    else
                      return '-';
                  }) 
                 ->editColumn('organization', function($setting) {
                    if(!empty($setting->organization))
                      return $setting->organization;
                    else
                      return '-';
                  })
                 ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                  ->addColumn('action', function ($setting) {
                            return '<a href="' . route("contract_payers-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Contract Payer" style="color:orange"><i class="fa fa-pencil"></i></a>
                              <a href="#"  style="color:red" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="ContractPayer" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*Contract Payer Add/Edit Form */

    public function getContractPayerCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $contractPayer = ContractPayer::find($id);  
            
        }
        else
        {
            $contractPayer = new ContractPayer;   
        }
      return view('admin.settings.contract_payers.add', ['contractPayer'=>$contractPayer,'states'=>$states])->with('active', 'settings')->with('sub_active', 'contract_payers');
    }


     /*Contract Payer Save Form */

    public function postContractPayerCreate(ContractPayerRequest $request)
    {

     
        if($request->contractpayer_id){
          try{
                $id = \Crypt::decrypt($request->contractpayer_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ContractPayer::find($id);  
          $start_date  = change_date_format($request->start_date);
          $request->request->add(['start_date'=>$start_date]);
          $end_date  = change_date_format($request->end_date);
          $request->request->add(['end_date'=>$end_date]);
          $data= $request->except('_token','contractpayer_id','name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content',trans('message.contract_payer_update_successfully'));
        }
        else {
          $start_date  = change_date_format($request->start_date);
          $request->request->add(['start_date'=>$start_date]);
          $end_date  = change_date_format($request->end_date);
          $request->request->add(['end_date'=>$end_date]);
          $data= $request->except('_token','contractpayer_id');
          $data['user_id']=Auth::id();
          $response = ContractPayer::create($data);  
          
          $request->session()->flash('message.content',trans('message.contract_payer_added_successfully'));
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('contract_payers');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.contract_payer_added_error'));
            return redirect()->route('contract_payers');
        }
      
    }


    /*Insurance index page */

    public function getRegistryType1List($type) {

        return view('admin.settings.'.$type.'.index')->with('active', 'settings')->with('sub_active',$type);
    }

    /*Insurance Datatable*/

    public function getRegistryType1($type)
    {
        
       
      $settings = Registry::registry($type)->orderBy('id', 'DESC');
      
      return DataTables::of($settings)
              ->addIndexColumn()
             ->rawColumns(['action'])
             ->addColumn('action', function ($setting) {
                        return '<a href="'.route("registry_type1-create", [$setting->type,\Crypt::encrypt($setting->id)]) . '"  style="color:orange"
                        class="" title="Edit"><i class="fa fa-pencil"></i></a>
                        <a style="color:red" href="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="Registry" data-type="'.$setting->type.'"  class="delete_model_by_id">
                       <i class="fa fa-trash" aria-hidden="true"></i>
                      </a>';
                    })
        ->make(true);
    }

     /*Insurance Add/Edit Form */

    public function getRegistryType1CreateEdit($type,$id=null)
    {
      
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $registry = Registry::find($id);  
            
        }
        else
        {
            $registry = new Registry;   
        }
      return view('admin.settings.'.$type.'.add', ['registry'=>$registry,'states'=>$states])->with('active', 'settings')->with('sub_active', $type);
    }


     /*Insurance Save Form */

    public function postRegistryType1Create(RegistryType1Request $request)
    {

     
        if($request->id){
          try{
                $id = \Crypt::decrypt($request->id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }

          $typeData = (substr($request->input('type'), -1) == 's')   ? substr($request->input('type'), 0, -1) : $request->input('type');
          $typeData = str_replace("_", " ",$typeData);
          if($typeData == 'rehab'){
            $message = ucfirst($typeData).' Information';
          }
          else {
            $message = ucfirst($typeData);
          }
          $manageablefield = Registry::find($id);  
          $data= $request->except('_token','id','name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content',''.$message.trans('message.updated_successfully'));
        }
        else {
          
          $typeData = (substr($request->input('type'), -1) == 's')   ? substr($request->input('type'), 0, -1) : $request->input('type');
          $typeData = str_replace("_", " ",$typeData);
          if($typeData == 'rehab'){
            $message = ucfirst($typeData).' Information';
          }
          else {
            $message = ucfirst($typeData);
          }
          $data= $request->except('_token','id');
          
          $data['user_id']=Auth::id();
          $response = Registry::create($data);  
          
          $request->session()->flash('message.content',''.$message.trans('message.added_successfully'));
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('get_listing',[$request->input('type')]);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.some_error').$message.'.');
            return redirect()->route('get_listing',[$request->input('type')]);
        }
      
    }


    /*PCPInfo index page */

    public function getPcpInformationsList() {
        return view('admin.settings.pcp_informations.index')->with('active', 'settings')->with('sub_active', 'pcp_informations');
    }

    /*PCPInfo Datatable*/

    public function getPcpInformations()
    {
        

        $settings = PcpInformation::PcpInformation()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("pcp_informations-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit PCP Information"><i class="fa fa-pencil"></i></a>
                            <a style="color:red"  ="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="PcpInformation" data-type="pcp" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*PCPInfo Add/Edit Form */

    public function getPcpInformationsCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $pcpInformation = PcpInformation::find($id);  
            
        }
        else
        {
            $pcpInformation = new PcpInformation;   
        }
      return view('admin.settings.pcp_informations.add', ['pcpInformation'=>$pcpInformation,'states'=>$states])->with('active', 'settings')->with('sub_active', 'pcp_informations');
    }


     /*PCPInfo Save Form */

    public function postPcpInformationsCreate(PcpInformationRequest $request)
    {

     
        if($request->pcp_information_id){
          try{
                $id = \Crypt::decrypt($request->pcp_information_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = PcpInformation::find($id);  
          $data= $request->except('_token','pcp_information_id','doctor_name');
          $data['type']='pcp';
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','PcpInformation Updated successfully.');
        }
        else {
          $data= $request->except('_token','pcp_information_id');
          $data['type']='pcp';
          $data['user_id']=Auth::id();
          $response = PcpInformation::create($data);  
          $request->session()->flash('message.content','PcpInformation added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('pcp_informations');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new pcpInformation.');
            return redirect()->route('pcp_informations');
        }
      
    }




    /*ReferralSource index page */

    public function getReferralSourceList() {
        return view('admin.settings.referral_sources.index')->with('active', 'settings')->with('sub_active', 'referral_sources');
    }

    /*ReferralSource Datatable*/

    public function getReferralSources()
    {
        

        $settings = ReferralSource::query()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('code', function($setting) {
                    if(!empty($setting->code))
                      return $setting->code;
                    else
                      return '-';
                  })
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('web_address', function($setting) {
                    if(!empty($setting->web_address))
                      return $setting->web_address;
                    else
                      return '-';
                  })
                  ->editColumn('web_address', function($setting) {
                    if(!empty($setting->web_address))
                      return $setting->web_address;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                // ->orderColumn('id', '-id $1')
                 //->rawColumns(['type', 'action','id'])
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("referral_sources-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Referral Source"><i class="fa fa-pencil"></i></a>
                            <a style="color:red" href="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="ReferralSource" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

    /*ReferralSource Add/Edit Form */

    public function getReferralSourceCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $referralSource = ReferralSource::find($id);  
            
        }
        else
        {
            $referralSource = new ReferralSource;   
        }
      return view('admin.settings.referral_sources.add', ['referralSource'=>$referralSource,'states'=>$states])->with('active', 'settings')->with('sub_active', 'referral_sources');
    }


    /*ReferralSource Save Form */

    public function postReferralSourceCreate(ReferralSourceRequest $request)
    {

     
        if($request->referral_source_id){
          try{
                $id = \Crypt::decrypt($request->referral_source_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = ReferralSource::find($id);  
          $data= $request->except('_token','referral_source_id','org_name');
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','Referral Source Updated successfully.');
        }
        else {
          $data= $request->except('_token','referral_source_id');
          $data['user_id']=Auth::id();
          $response = ReferralSource::create($data);  
          $request->session()->flash('message.content','Referral Source added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('referral_sources');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new referral source.');
            return redirect()->route('referral_sources');
        }
      
    }



    /*Speciality index page */

    public function getSpecialityList() {
        return view('admin.settings.specialities.index')->with('active', 'settings')->with('sub_active', 'specialities');
    }

    /*Speciality Datatable*/

    public function getSpecialities()
    {
        

        $settings = PcpInformation::speciality()->orderBy('id', 'DESC');
      
         return DataTables::of($settings)
                  ->addIndexColumn()
                  ->editColumn('email', function($setting) {
                    if(!empty($setting->email))
                      return $setting->email;
                    else
                      return '-';
                  })
                  ->editColumn('contact_name', function($setting) {
                    if(!empty($setting->contact_name))
                      return $setting->contact_name;
                    else
                      return '-';
                  })
                 ->rawColumns(['action'])
                 ->addColumn('action', function ($setting) {
                            return '<a style="color:orange" href="' . route("specialities-create", \Crypt::encrypt($setting->id)) . '"  class="" title="Edit Speciality"><i class="fa fa-pencil"></i></a>
                            <a style="color:red"  ="#" data-id="'.\Crypt::encrypt($setting->id).'"  data-model="PcpInformation" data-type="speciality" title="Delete" class="delete_model_by_id">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>';
                        })
            ->make(true);
    }

     /*Speciality Add/Edit Form */

    public function getSpecialityCreateEdit($id=null)
    {
      $states = State::all()->pluck('full_name','id')->prepend('Please select', '')->toArray();
       if($id)
        {
            try{
                $id = \Crypt::decrypt($id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
            $speciality = PcpInformation::find($id);  
            
        }
        else
        {
            $speciality = new PcpInformation;   
        }
      return view('admin.settings.specialities.add', ['speciality'=>$speciality,'states'=>$states])->with('active', 'settings')->with('sub_active', 'specialities');
    }


     /*Speciality Save Form */

    public function postSpecialityCreate(SpecialistRequest $request)
    {

     
        if($request->speciality_id){
          try{
                $id = \Crypt::decrypt($request->speciality_id);
            } catch (DecryptException $e) {
                abort(404);
                exit;
            }
          $manageablefield = PcpInformation::find($id);  
          $data= $request->except('_token','speciality_id','doctor_name');
          $data['type']='specialist';
          $data['user_id']=Auth::id();
          $response=$manageablefield->update($data);
          $request->session()->flash('message.content','Speciality Updated successfully.');
        }
        else {
          $data= $request->except('_token','speciality_id');
          $data['type']='specialist';
          $data['user_id']=Auth::id();
          $response = PcpInformation::create($data);  
          $request->session()->flash('message.content','Speciality added successfully.');
        }
         if($response)
        {
            $request->session()->flash('message.level','success');
            return redirect()->route('specialities');
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content','Some error while refer new speciality.');
            return redirect()->route('specialities');
        }
      
    }


}