<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use View;
use Helper;

use App\Models\User;


class LoginController extends Controller
{
	
	public function __construct(){
		//$this->middleware('auth');
	}
    public function getLogin()
    {    
        return view('admin.login')->render();  
    }  
}
