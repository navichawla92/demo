<?php

namespace App\Http\Controllers\CM;

use App\Models\User;
use App\Models\Patient;
use App\Models\PatientAssignment;
use App\Models\PcpInformation;
use App\Models\Registry;
use Illuminate\Http\Request;
use App\Models\ManageableField;
use App\Http\Controllers\Controller;
use App\Http\Requests\PatientCmAssessment as PatientCmAssessmentRequest; 
use Auth;
use DB;
use View;
use Validator;
use Carbon\Carbon;


class PatientRegistrationController extends Controller
{
	
	public function __construct(){
		$this->middleware(function ($request, $next) {
            if(Auth::user()->status != 1)
            {
                Auth::logout();
                return redirect('/login');
            }
            return $next($request);
        });
	}
   
    
    // CM Assessment for patient 
    public function getCmAssessment($patient_id,$page_no=1,$tab=null,Request $request){
        try{           
            $patient_id = \Crypt::decrypt($patient_id);
        } catch (DecryptException $e) {
            abort(404);
            exit;
        }
        
        $request->session()->reflash();
        $active = 'patient_registrations';
        
        $active_tab = "advanced_directive_tab"; 
        $active_step = "advanced_directive_tab"; //cm_tab_completed
        
        $patient = Patient::find($patient_id);
        $patient->calc($patient->random_key);
        $patient_notes = [];  
        $patient_docs = [];  
        $patient_assessments = []; 
        $patient_notes = $patient->patient_notes()->paginate(PAGINATION_COUNT_10); 
        $patient_docs = $patient->patient_docs()->paginate(PAGINATION_COUNT_10); 

        $pcp_informations = new Registry();
        $pcp_informations = $pcp_informations->newQuery();
        $pcp_informations = $pcp_informations->PcpInformation()->get();
        $patient_assessment_comments = $patient->patient_assessment_comment()->get();
        $home_health_providers = new Registry();
        $home_health_providers = $home_health_providers->newQuery();
        $home_health_providers = $home_health_providers->homeHealthProvider()->get();
        $hospic_providers = new Registry();
        $hospic_providers = $hospic_providers->newQuery();
        $hospic_providers = $hospic_providers->hospiceProvider()->get();
        
        $doc_categories = ManageableField::where('type','document_category')->pluck('name','id')->prepend('Select a document category', '');
        $patient_functionings = ManageableField::where('type','patient_functioning')->pluck('name','id');
        $durable_medical_equipments = ManageableField::where('type','durable_medical_equipment')->pluck('name','id');
        $identifying_issues = ManageableField::where('type','identifying_issues')->pluck('name','id');
        
        if($tab != null)
            $active_tab = $tab;
        
        return view('cm.patients.registration.cm_assessment',compact('active', 'active_step', 'active_tab', 'pcp_informations', 'patient','patient_notes','patient_docs','doc_categories','home_health_providers','hospic_providers','patient_assessment_comments', 'patient_functionings', 'durable_medical_equipments', 'identifying_issues'))->with('role_type', CASEMANAGER); 
    }      

    // CM Assessment save tabs
    public function postCmAssessment(PatientCmAssessmentRequest $request){
        if($request->step_number == 1)
            $response = self::saveAdvancedDirectiveTabData($request);
        if($request->step_number == 2)
            $response = self::saveHomeSafetyTabData($request);

        if($response)
        {
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content',trans('message.patient_detail_successfully'));

            return response()->json(['message'=>trans('message.patient_detail_successfully'),'patient_id'=>$response,'message_type'=> $request->message_type],200);
        }
        else
        {
            $request->session()->flash('message.level','danger');
            $request->session()->flash('message.content',trans('message.error_updated_patient'));
            return response()->json(['message'=>trans('message.error_updated_patient')],200);            
        }
    }    

    public function saveAdvancedDirectiveTabData($request)
    {
        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key);
        if ($request->has('pcp_not_required') && $request->get('pcp_not_required') == 'on') {
            $request->request->add(['pcp_not_required'=>1]);   
            $request->request->add(['pcp_id'=>null]);  
        }
        else {
            $request->request->add(['pcp_not_required'=>0]); 
        } 

        if ($request->has('advance_healthcare_on_file') && $request->get('advance_healthcare_on_file') == 'no') {
            $request->request->add(['advance_healthcare_checkboxes'=>null]);   
            
        }
        if ($request->has('polst_on_file') && $request->get('polst_on_file') == 'no') {
            $request->request->add(['polst_checkboxes'=>null]);    
            
        }
        
        $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        
        //check if already completed other tabs then do not set its value
        if(($patient->cm_tab_completed != null && $patient->cm_tab_completed < 1) || !$patient->cm_tab_completed)
            $patient_record->cm_tab_completed = '1';
        
        //mark assessment status as In-Complete
        $patient_record->cm_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }     

    public function saveHomeSafetyTabData($request)
    {
        DB::beginTransaction();

        $patient = Patient::find(decrypt($request->patient_id));
        $patient->calc($patient->random_key);
        
        if($request->durable_medical_equipment_other == 'on'){
            $request->request->add(['durable_medical_equipment_other' => 1]);
        }
        else {
            $request->request->add(['durable_medical_equipment_other' => 0]);
            $request->request->add(['durable_medical_equipment_other_text' => '']);
        }        

        if($request->identifying_issues_other == 'on'){
            $request->request->add(['identifying_issues_other' => 1]);
        }
        else {
            $request->request->add(['identifying_issues_other' => 0]);
            $request->request->add(['identifying_issues_other_text' => '']);
        }

        $patient_record = $patient->fill($request->except('_token','step_number', 'patient_id'));
        
        //check if already completed other tabs then do not set its value
        if(($patient->cm_tab_completed != null && $patient->cm_tab_completed < 2) || !$patient->cm_tab_completed)
            $patient_record->cm_tab_completed = '2';

        //mark assessment status as In-Complete
        $patient_record->cm_case_status = '1';

        //mark registration as in-complete without any condition
        $patient->registration_status = '1';

        $patient_record->save();
        
        DB::commit();
        return '1';
    }   

    //get HTML of home safety tab when CM fills advanced tab successfully
    public function getHomeSafetyTabHtml(Request $request)
    {
        if ($request->ajax()) 
        {
            $patient = Patient::find(decrypt($request->patient_id));
            $patient->calc($patient->random_key); 

            if ($request->tab == 'home-safety-html')
            {
                $patient_functionings = ManageableField::where('type','patient_functioning')->pluck('name','id');
                $durable_medical_equipments = ManageableField::where('type','durable_medical_equipment')->pluck('name','id');
                $identifying_issues = ManageableField::where('type','identifying_issues')->pluck('name','id');

                return View::make('cm.patients.registration.home_safety_evaluation_tab',compact('patient', 'patient_functionings', 'durable_medical_equipments', 'identifying_issues'));           
            }
            elseif ($request->tab == 'assessment-html') 
            {
                $patient_assessment_comments = $patient->patient_assessment_comment()->get();
                return View::make('patients.common.assessment_comments_tab',compact('patient', 'patient_assessment_comments'))->with('role_type', CASEMANAGER);           
            }
        }
        
    }

    
}
