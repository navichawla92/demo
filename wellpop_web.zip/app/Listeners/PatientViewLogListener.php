<?php

namespace App\Listeners;

use App\Events\PatientViewLog;
use App\Models\PatientLog;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class PatientViewLogListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PatientViewLog  $event
     * @return void
     */
    public function handle(PatientViewLog $event)
    {
        $userType = 0;
        $request = request();

        if ($request->user()->roles->count()) {
            $userType = $request->user()->roles()->first()->id;
        }

        PatientLog::firstOrCreate([
            'patient_id' => $event->patientId,
            'user_id' => $request->user()->id,
            'session_id' => $request->user()->session_id,
            'url' => $request->url(),
        ], [
            'user_agent' => $request->userAgent(),
            'ip_address' => $request->ip(),
            'event' => 'PatientView',
            'user_type' => $userType
        ]);

    }
}
