<?php

// constant for role
define('ADMIN', 'Admin');
define('COMMUNITYHEALTHWORKER', 'CHW');
define('CASEMANAGER', 'CM');
define('MANAGERDIRECTOR', 'MD');



// constant for referral status
define('REFERRAL_STATUS_OPEN', '0');
define('REFERRAL_STATUS_PRE_REGISTER', '1');
define('REFERRAL_STATUS_REGISTER', '2');
define('REFERRAL_STATUS_REJECTED', '3');
define('REFERRAL_STATUS_ENROLL', '4');
define('REFERRAL_STATUS_MATURE', '5');

// constant for registration status
define('REGISTRATION_STATUS_NEW', '0');
define('REGISTRATION_STATUS_INCOMPLETE', '1');
define('REGISTRATION_STATUS_COMPLETED', '2');
define('REGISTRATION_STATUS_REJECTED', '3');


// constant for chw/md/cm status
define('ASSESMENT_PENDING', '0');
define('ASSESMENT_INCOMPLETE', '1');
define('ASSESMENT_COMPLETED', '2');
define('ASSESMENT_REJECTED', '3');

// constant for consent form status
define('CONSENT_FORM_ACCEPT', 'accepts');
define('CONSENT_FORM_REFUSE', 'refuses');


// constant for enrollment status
define('ENROLLMENT_STATUS_INTENSE', '0');
define('ENROLLMENT_STATUS_MATURE', '1');
define('ENROLLMENT_STATUS_GRADUATE', '2');
define('ENROLLMENT_STATUS_DISCHARGE', '3');
define('ENROLLMENT_STATUS_ELOPED', '4');


define('USER_STATUS_ACTIVE', 1);
define('USER_STATUS_DEACTIVE', 1);

define('CASELOAD_PAGINATION_COUNT', 5);
define('PAGINATION_COUNT_5', 5);
define('PAGINATION_COUNT_10', 10);

?>