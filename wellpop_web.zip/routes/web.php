<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});
Route::fallback(function () {
    abort(404);
    exit;
});
Auth::routes();
Route::resource('privileges', 'Admin\RoleController')->only([
    'index', 'edit', 'update'
]);
Route::resource('permissions', 'Admin\PermissionController');
//Route::resource('users', 'Admin\UserController');

Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout')->name('logout');
Route::get('password-reset', 'PasswordController@showForm'); //I did not create this controller. it simply displays a view with a form to take the email
Route::post('password-reset', 'PasswordController@sendPasswordResetToken')->name('send-reset-otp');
Route::get('reset-password/{token}', 'PasswordController@showPasswordResetForm');
Route::post('reset-password', 'PasswordController@resetPassword')->name('reset-password-otp');
Route::post('verify-reset-otp', 'PasswordController@verifyOTP')->name('verify-reset-otp');
Route::post('resend-reset-otp', 'PasswordController@resendPasswordResetToken')->name('resend-reset-otp');


Route::post('keep-session-alive',function () {
    return "1";
})->name('keep-session-alive');

/* Route to create the permision */

Route::get('permision', '\App\Http\Controllers\HomeController@permision')->name('permision');

/* 
== Case Manager's Routes
*/
Route::prefix('casemanager')->middleware(['auth', 'prevent-back-history', 'check-permission'])->group(function () {
    //Route::get('patients/view', 'PatientController@getPatientView')->name('patient-view');
    Route::get('patients', 'PatientController@getIndex')->name('patients');
    Route::get('patients/tab', 'PatientController@getloadTab')->name('patient-tab');
    Route::post('patients/create', 'PatientController@postCreate')->name('patient-add');
    Route::post('patients/change_status', 'PatientController@postChangeStatus')->name('patient-status');
    Route::post('patients/filter', 'PatientController@postFilterPatient')->name('patient-filter');
   // Route::get('patients/updatePasswordExpiry', 'PatientController@updatePasswordExpiry')->name('updatePasswordExpiry');
   // Route::get('patients/myprofile', 'Admin\UserController@getMyprofile')->name('my_profile');
    Route::post('patients/updatepersonalinfo', 'Admin\UserController@updatePersonalInfo')->name('update-personal-info');
    Route::post('patients/changepassword', 'Admin\UserController@changePassword')->name('change-password');
    Route::post('patients/changepic', 'Admin\UserController@changeProfilePicture')->name('change-pic');
    Route::get('patients/registrations', 'PatientRegistrationController@getIndex')->name('registrations');
    Route::post('patients/registrations/assignments', 'PatientRegistrationController@postAssignments')->name('registration_assignment');
    Route::post('patients/registrations/enrollment', 'PatientRegistrationController@postEnrollment')->name('patient_enrolled');
    Route::get('patients/registrations/view/{patient_id}', 'PatientRegistrationController@getPatientView')->name('registration_patient_view');
    Route::get('patients/registrations/enroll/{patient_id}', 'PatientRegistrationController@getCmEnroll')->name('registration_cm_patient_enroll');
    
    Route::get('patients/registrations/enroll/refused/{patient_id}', 'PatientRegistrationController@getPreviousEnrollRefused')->name('get_previous_refused_listing');
    Route::post('patients/registrations/enroll/refused/add-new', 'PatientRegistrationController@postAddNewRefusalReason')->name('add_new_refused_entry');
    Route::post('patients/registrations/enroll/consent/add-signature', 'PatientRegistrationController@postSaveConsentFormSignature')->name('save_consent_form_signature');
    
    Route::post('patients/registrations/enroll/consent/save-form', 'PatientRegistrationController@postCmSavePatientConsentForm')->name('registration_cm_patient_consent_save');

    Route::get('patients/registrations/enroll/consent/{patient_id}/{lang?}', 'PatientRegistrationController@getCmEnrollPatientConsentForm')->name('registration_cm_patient_enroll_consent');


    Route::get('patients/registrations/calls/{id}', 'PatientRegistrationController@getPatientCalls')->name('patient-calls');

    Route::post('patients/registrations/calls/create', 'PatientRegistrationController@postCreatePatientCall')->name('patient-call-add');
    
    //Assessment routes started here
    Route::post('patients/registrations/assessment/save', 'CM\PatientRegistrationController@postCmAssessment')->name('registration_cm_assessment_save');
    Route::get('patients/registrations/assessment/home-safety-evaluation-tab', 'CM\PatientRegistrationController@getHomeSafetyTabHtml')->name('registration_cm_assessment_get_home_safety_tab_html');
    Route::get('patients/registrations/assessment/{patient_id}/{page?}/{tab?}', 'CM\PatientRegistrationController@getCmAssessment')->name('registration_cm_assessment');


   
    //place it at last as this will replace any get route for patients/
    Route::get('patients/{action}/{page?}/{id?}/{tab?}', 'PatientController@getCreateEdit')->name('addPatient');
});


/*

== case load
*/
Route::middleware(['auth', 'prevent-back-history'])->group(function () {
  Route::get('patients/caseload', 'PatientCaseloadController@getIndex')->name('patient-caseload');

  Route::post('patients/caseload/update_profile', 'PatientCaseloadController@updatePatientInfo')->name('patient-update');
  Route::post('patients/caseload/update_careplan_team', 'PatientCaseloadController@updateCareplanTeam')->name('update_careplan_team');

  Route::post('patients/caseload/medication', 'PatientCaseloadController@postMedicationSave')->name('caseload_save_or_update_medication');


  Route::post('patients/caseload/medication/status', 'PatientCaseloadController@updateMedicationStatus')->name('caseload_update_medication_status');
  Route::post('patients/caseload/allergy/status', 'PatientCaseloadController@updateAllergyStatus')->name('caseload_update_allergy_status');

  Route::post('patients/caseload/allergy', 'PatientCaseloadController@postAllergySave')->name('caseload_save_or_update_allergy');
  Route::get('patients/caseload/allergy/{patient_id}', 'PatientCaseloadController@getAllergyList')->name('caseload_allergy_list');
  Route::get('patients/caseload/medication/{patient_id}', 'PatientCaseloadController@getMedicationList')->name('caseload_meditation_list');
  Route::get('patients/caseload/medication/{patient_id}/detail', 'PatientCaseloadController@getMedicationDetail')->name('caseload_meditation_detail');
  Route::get('patients/caseload/allergy/{patient_id}/detail', 'PatientCaseloadController@getAllergyDetail')->name('caseload_allergy_detail');

  Route::get('patients/caseload/{patient_id}/careplan', 'PatientCaseloadController@getCarePlan')->name('patient_care_plan');

  Route::post('patients/caseload/careplan', 'PatientCaseloadController@saveCarePlan')->name('save_patient_care_plan');
  Route::get('patients/caseload/careplan/diagnosis', 'PatientCaseloadController@getDiagnosisDetail')->name('get_diagnosis_detail');

  Route::get('patients/caseload/careplan_list/{patient_id}', 'PatientCaseloadController@getCarePlanList')->name('caseload_careplan_list');
  Route::post('patients/caseload/careplan/diagnosis/add', 'PatientCaseloadController@addCareplanDiagnosis')->name('save_diagnosis_care_plan');
 
  Route::get('patients/caseload/{patient_id}/careplan/{id}', 'PatientCaseloadController@getCarePlanDetail')->name('patient_care_plan_detail');

   Route::get('patients/caseload/{patient_id}/careplan/{id}/tabs', 'PatientCaseloadController@getloadTab')->name('patient_care_plan_detail-tab');

    Route::post('patients/caseload/careplan/status', 'PatientCaseloadController@updateCarePlanStatus')->name('caseload_update_careplan_status');

  Route::post('patients/caseload/careplan/diagnosis', 'PatientCaseloadController@removeCareplanDiagnosis')->name('caseload_remove_careplan_diasnosis');


  Route::get('patients/caseload/assessment/{patient_id}', 'PatientCaseloadController@getAssessmentList')->name('caseload_assessment_list');
  Route::get('patients/caseload/checkpoint/{patient_id}', 'PatientCaseloadController@getCheckpointList')->name('caseload_checkpoint_list');
 Route::get('patients/caseload/intervention/{patient_id}', 'PatientCaseloadController@getInterventionList')->name('caseload_intervention_list');
 /* place this route at last otherwise it replace  other */
  Route::get('patients/caseload/{patient_id}/{is_careplan?}', 'PatientCaseloadController@getPatientView')->name('caseload_patient_view');


  Route::get('patients/caseload/{patient_id}/assessments/{user_type}', 'PatientCaseloadController@getAssessments')->name('caseload_patient_assessments');
  Route::get('patients/caseload/{patient_id}/forms/{form_type}', 'PatientCaseloadController@getReleaseForm')->name('caseload_patient_forms');

  Route::get('patients/diagnosis/goal/details','PatientCaseloadController@getDiagnosisGoalDetail')->name('careplan_diagnosis_goal_detail');

  Route::get('patients/caseload/careplan/{careplan_id}/diagnosis', 'PatientCaseloadController@getCareplanDiagnosisList');
  Route::get('patients/caseload/careplan/diagnosis/goals', 'PatientCaseloadController@getCareplanDiagnosisGoal')->name('careplan_diagnosis_goal_list');


  Route::get('patients/careplan/barriers/list', 'PatientCaseloadController@getBarrierList');
  Route::get('patients/careplan/vitals/list', 'PatientCaseloadController@getVitalList');




  // common path
  Route::post('diagnosis_list', 'PatientCaseloadController@postDiagnosisList')->name('diagnosis_list');

  Route::post('patients/caseload/save-release-form', 'PatientCaseloadController@postPatientReleaseForm')->name('patient_release_form_save');

  /* Careplan Assessments */
    Route::group(['namespace' => 'Careplan'], function () {
        Route::get('patients/{id}/assessment', 'AssessmentController@index')->name('patient_assessment');
        Route::get('patients/{id}/assessment/tabs', 'AssessmentController@getTabs')->name('patient_assessment_detail_tab');
        Route::post('patients/assessment/purpose', 'AssessmentController@addOrUpdatePurpose')->name('patient_assessment_purpose_save');
        Route::post('patients/assessment/risk_assessment', 'AssessmentController@saveQuestion')->name('patient_assessment_question_save');

        /*Barriers*/
        Route::get('patients/assessment/barriers', 'AssessmentController@getBarrierById')->name('assessment_barrier_by_id');
        Route::get('patients/assessment/barriers/list', 'AssessmentController@getBarrierList');
        Route::post('patients/assessment/barriers/search', 'AssessmentController@searchBarriers')->name('assessment_search_barriers');
        Route::post('patients/assessment/barriers/add', 'AssessmentController@addBarrier')->name('assessment_barrier_add');
        Route::post('patients/assessment/barriers/delete', 'AssessmentController@deleteBarrier')->name('assessment_barrier_delete');
        Route::post('patients/assessment/copy', 'AssessmentController@copyAssessment')->name('patient_assessment_copy');
        Route::get('patients/{patient_id}/assessment/{assessment_id}', 'AssessmentController@editCopiedAssessment')->name('edit_copy_assessment');

        /*Progress notes*/
        Route::post('patients/assessment/progress_notes/add','AssessmentController@saveProgressNote')->name('assessment_progress_note_add');

        /*vitals add*/
        Route::get('patients/assessment/vitals/list','AssessmentController@getVitalsList');
        Route::post('patients/assessment/vitals/add', 'AssessmentController@addVital')->name('assessment_vital_add');

        /* assessment content discussed and interventions*/
        Route::post('patients/assessment/content_discussed', 'AssessmentController@updateContentDiscussed')->name('patient_assessment_content_discussed_save');
        Route::post('patients/assessment/save', 'AssessmentController@addAssessment')->name('patient_assessment_save');
        Route::post('patients/assessment/intervention', 'AssessmentController@addIntervention')->name('patient_assessment_intervention_save');
        Route::post('patients/assessment/intervention/followup/add', 'AssessmentController@addInterventionFollowUp')->name('patient_assessment_followup_save');
        Route::get('patients/assessment/intervention/followup/list', 'AssessmentController@getFollowupList')->name('patient_assessment_followup_list');

        Route::get('patients/{id}/assessment/{assessment_id}/view', 'AssessmentController@view')->name('patient_assessment_view');

        /* Checkpoint route*/
        Route::get('patients/{id}/checkpoint', 'CheckpointController@index')->name('patient_checkpoint');
        Route::post('patients/checkpoint/purpose', 'CheckpointController@addOrUpdatePurpose')->name('patient_checkpoint_purpose_save');
        Route::get('patients/{id}/checkpoint/{checkpoint_id}/view', 'CheckpointController@view')->name('patient_checkpoint_view');
        Route::get('patients/{id}/intervention/{intervention_id}', 'CheckpointController@viewIntervention')->name('patient_intervention_view');


        Route::post('patients/checkpoint/save', 'CheckpointController@addCheckpoint')->name('patient_checkpoint_save');
        Route::get('patients/{id}/checkpoint/tabs', 'CheckpointController@getTabs')->name('patient_checkpoint_detail_tab');
        Route::post('patients/checkpoint/content_discussed', 'CheckpointController@addOrUpdateContentDiscussed')->name('patient_checkpoint_content_discussed_save');
        Route::post('patients/checkpoint/intervention', 'CheckpointController@addIntervention')->name('patient_checkpoint_intervention_save');
        Route::post('patients/checkpoint/intervention_follow_up', 'CheckpointController@addInterventionFollowUp')->name('patient_checkpoint_followup_save');

        Route::get('patients/checkpoint/intervention_follow_up', 'CheckpointController@getFollowupList')->name('patient_followup_list');
        Route::get('patients/checkpoint/intervention/followup/complete_status', 'CheckpointController@updateFollowupCompleteStatus')->name('update_intervention_followup_complete_status');
        Route::get('patients/tools', 'CheckpointController@toolList')->name('patient_tool_list');

        /* Goal Review */

        Route::get('patients/assessment/goalreivew/diagnosis/list', 'GoalReviewController@getDiagnosisList')->name('goalreview_diagnosis_list');
        Route::get('patients/assessment/goalreivew/diagnosis/goals', 'GoalReviewController@getDiagnosisGoal')->name('goalreview_diagnosis_goal_list');

        Route::post('patients/assessment/goalreivew/diagnosis/delete', 'GoalReviewController@deleteDiagnosis')->name('goal_review_diagnosis_delete');
        Route::post('patients/assessment/goalreivew/save', 'GoalReviewController@postDiagnosisGoal')->name('goalreview_diagnosis_goal_save');
        Route::post('patients/assessment/goalreivewdata/save', 'GoalReviewController@postGoalData')->name('patient_assessment_goaldata_save');
        Route::post('patients/assessment/goalreivewdata/delete', 'GoalReviewController@removeAssessmentGoalData')->name('caseload_remove_goalreview_data');
    });

});
/* 
== CHW's Routes
*/
Route::prefix('chw')->middleware(['auth', 'prevent-back-history', 'check-permission'])->namespace('CHW')->group(function () {
    Route::get('patients/registrations', 'PatientRegistrationController@getIndex')->name('chw-registrations');

    Route::get('patients/registrations/assessment/medical-care-tab', 'PatientRegistrationController@getMedicalCareTabHtml')->name('registration_chw_assessment_get_medical_care_tab_html');
    Route::get('patients/registrations/assessment/medical-care-tab/listing', 'PatientRegistrationController@getListingByType')->name('registration_chw_assessment_listing_by_type');
    Route::get('patients/registrations/assessment/medical-care-tab/assign-item', 'PatientRegistrationController@getUpdatePatientInfo')->name('registration_chw_assessment_assign_item');
    Route::get('patients/registrations/assessment/medical-care-tab/remove-item', 'PatientRegistrationController@getRemoveAssignedInfo')->name('registration_chw_assessment_remove_item');
    
    Route::post('patients/registrations/assessment/save', 'PatientRegistrationController@postChwAssessment')->name('registration_chw_assessment_save');

    //place it at last as this will replace any get route for patients/
     Route::get('patients/registrations/assessment/{patient_id}/{page?}/{tab?}', 'PatientRegistrationController@getChwAssessment')->name('registration_chw_assessment');

});

/* 
== MD's Routes
*/
Route::prefix('md')->middleware(['auth', 'prevent-back-history', 'check-permission'])->namespace('MD')->group(function () {
    Route::get('patients/registrations', 'PatientRegistrationController@getIndex')->name('md-registrations');

    //Assessment routes started here
    

    Route::post('patients/registrations/assessment/save', 'PatientRegistrationController@postMdAssessment')->name('registration_md_assessment_save');
    

    Route::get('patients/registrations/assessment/medications-listing/{patient_id}', 'PatientRegistrationController@getPreviousAddedMedication')->name('registration_md_assessment_medications_listing');
    
    Route::get('patients/registrations/assessment/allergies-listing/{patient_id}', 'PatientRegistrationController@getPreviousAddedAllergies')->name('registration_md_assessment_allergies_listing');
    

    Route::post('patients/registrations/assessment/medication-save', 'PatientRegistrationController@postMedicationSave')->name('registration_md_assessment_medication_save');
    
    Route::post('patients/registrations/assessment/allergy-save', 'PatientRegistrationController@postAllergySave')->name('registration_md_assessment_allergy_save');
    

    Route::get('patients/registrations/assessment/home-safety-evaluation-tab', 'PatientRegistrationController@getAssessmentTabHtml')->name('registration_md_assessment_get_assessment_tab_html');
    

    //place it at last as this will replace any get route for patients/
    Route::get('patients/registrations/assessment/{patient_id}/{page?}/{tab?}', 'PatientRegistrationController@getMdAssessment')->name('registration_md_assessment');
});

/* 
== Common's Routes
*/
Route::middleware(['auth', 'prevent-back-history', 'check-permission'])->group(function () {
    Route::post('patients/documents', 'CommonController@postCreate')->name('patient-documents');
    Route::post('patients/document/delete', 'CommonController@deletePatientDocument')->name('patient-document-delete');
    Route::get('patients/documents', 'CommonController@getDocumentList')->name('patient-document-list');
    Route::get('{role}/patients/registrations/documents/{patient_id}', 'CommonController@getDocsList')->name('registration_patient_documents');
    Route::get('{role}/patients/registrations/notes/{patient_id}', 'CommonController@getNotesList')->name('registration_patient_notes');

    Route::post('patients/assessment', 'CommonController@postCreateAssessment')->name('patient-assessment');
    Route::get('patients/assessments', 'CommonController@getAssessmentList')->name('patient-assessment-list');
    Route::get('patients/view', 'CommonController@getPatientView')->name('patient-view');
    Route::get('patients/assessment/complete', 'CommonController@getCompleteAssessment')->name('registration_assessment_complete');
    Route::post('patients/reject', 'CommonController@postRejectPatient')->name('patient-reject');

    Route::get('user/updatePasswordExpiry', 'CommonController@updatePasswordExpiry')->name('updatePasswordExpiry');

    Route::get('{role}/patients/myprofile', 'Admin\UserController@getMyprofile')->name('my_profile');

    Route::post('icdcode_list', 'CommonController@postIcdCode')->name('ico_code_list');
    Route::post('content_discussed_list', 'CommonController@postContentDiscussed')->name('content_discussed_list');
});


/* 
== Super Admin's Routes
*/
Route::post('/admin/login', 'Auth\LoginController@login')->name('admin-login');
//admin logout
Route::get('/admin/logout', '\App\Http\Controllers\Auth\LoginController@adminLogout')->name('admin-logout');

Route::prefix('admin')->namespace('Admin')->group(function () {

    Route::get('/login', 'LoginController@getLogin')->name('admin-login-form')->middleware('guest');
    Route::get('/users', 'UserController@getIndex')->name('admin-users');
   
});


Route::prefix('admin')->middleware(['auth', 'prevent-back-history', 'isAdmin'])->namespace('Admin')->group(function () {

    Route::get('users', 'AdminController@getIndex')->name('users');
    Route::post('change-status', 'AdminController@postChangeStatus')->name('change-user-status');
    Route::get('datatable/getUsers', 'AdminController@getUsers')->name('datatable/getUsers');
    Route::get('users/create/{id?}', 'AdminController@getCreateEdit')->name('addUser');
    Route::post('users/create', 'AdminController@postCreate')->name('user-add');
    
   
    /* Manageable Field Route*/
    Route::get('setting/manageablefields', 'RegistryController@getManageAbleFieldList')->name('manageablefields');
    Route::get('datatable/getManageAbleField', 'RegistryController@getManageAbleField')->name('datatable/getManageAbleField');
    Route::get('setting/manageablefields/create/{id?}', 'RegistryController@getFieldCreateEdit')->name('field-create');
    Route::post('setting/manageablefields/create/{id?}', 'RegistryController@postFieldCreate')->name('field-edit');
 
    /*  Patient log */
    Route::get('patients', 'AdminController@getPatientList')->name('patient-list');
    Route::get('datatable/getPatients', 'AdminController@getPatients')->name('datatable/getPatients');
    Route::get('patients/patient/log/{id?}', 'AdminController@getPatientLog')->name('patient-log');

    //Profile
    Route::get('my-profile', 'AdminController@getMyprofile')->name('admin_profile');
    Route::post('updatepersonalinfo', 'AdminController@updatePersonalInfo')->name('admin-update-personal-info');
    Route::post('changepassword', 'AdminController@changePassword')->name('admin-change-password');
    Route::post('changepic', 'AdminController@changeProfilePicture')->name('admin-change-pic');

    Route::prefix('careplan')->namespace('CarePlan')->group(function () {
        Route::get('/{type}', 'SettingController@getCarePlanSettingList')->where('type', 'metrices|flags')->name('get_careplan_settings');
        Route::get('datatable/get_careplan_settings/{type}', 'SettingController@getCarePlanSettingDataTable')->where('type', 'metrices|flags')->name('datatable/get_careplan_settings');

        Route::get('/tools', 'ToolController@getCarePlanToolList')->name('get_careplan_tools');
        Route::get('datatable/get_careplan_tools', 'ToolController@getCarePlanToolDataTable')->name('datatable/get_careplan_tools');
        Route::get('/tools/create/{id?}', 'ToolController@getToolCreateEdit')->name('tool-create');
        Route::post('/tools/create/{id?}', 'ToolController@postToolCreate')->name('tool-edit');

        Route::resource('diagnosis', 'DiagnosisController',
                ['names' => ['create' => 'create-diagnosis','edit' => 'edit-diagnosis']]);
        Route::get('diagnosis', 'DiagnosisController@getIndex')->name('diagnosis');
        Route::get('datatable/diagnosis-data', 'DiagnosisController@getDiagnosisData')->name('diagnosis-data');

        Route::get('/goals', 'GoalController@getCarePlanGoalList')->name('get_careplan_goals');
        Route::get('datatable/get_careplan_goals', 'GoalController@getCarePlanGoalDataTable')->name('datatable/get_careplan_goals');
        Route::get('/goals/create/{id?}', 'GoalController@getGoalCreateEdit')->name('goal-create');
        Route::post('/goals/create/{id?}', 'GoalController@postGoalCreate')->name('goal-edit');

        Route::post('/goals/save_data/{id?}', 'GoalController@postGoalData')->name('goal-data');
        Route::get('/goals/save_data', 'GoalController@getGoalData');

        Route::post('goals/delete_data', 'GoalController@deleteGoalData')->name('delete-goal-data');

        /* */

        Route::get('get_data_list_by_type', 'GoalController@GetDataByType')->name('get_data_list_by_type');  

        /* barriers*/
        Route::get('/barriers', 'BarrierController@getCarePlanBarrierList')->name('get_careplan_barriers');
        Route::get('datatable/get_careplan_barriers', 'BarrierController@getCarePlanBarrierDataTable')->name('datatable/get_careplan_barriers');
        Route::get('/barriers/create/{id?}', 'BarrierController@getBarrierCreateEdit')->name('barrier-create');
        Route::post('/barriers/create/{id?}', 'BarrierController@postBarrierCreate')->name('barrier-edit');

        Route::get('contents', 'ContentDiscussedController@index')->name('get_content_discussed');
        Route::get('datatable/get_content_discussed_list', 'ContentDiscussedController@getContentsList')->name('datatable/get_content_discussed_list');
        Route::get('/contents/create/{id?}', 'ContentDiscussedController@getContentCreateEdit')->name('content-create');
        Route::post('contents/create/{id?}', 'ContentDiscussedController@postContentCreateOrUpdate')->name('content-edit');
 // new route
    });
});

Route::namespace('Admin')->group(function () {
    Route::post('referral_source/create', 'SettingController@postReferralCreate')->name('referral-source-add');
    Route::post('pcp_information/create', 'SettingController@postPcpInformationCreate')->name('pcp-information-add');
    Route::post('registry/create', 'SettingController@postRegistryCreate')->name('registry-add');
});
    
/* Registries Payer Routes */
Route::get('/admin/settings/{type}/create', 'RegistryController@getCreate')->name('add_new_registry');
Route::post('/admin/settings/{type}/create', 'RegistryController@postCreate');
Route::get('/admin/settings/{type}/edit/{id}', 'RegistryController@getEdit')->name('edit_existing_registry');
Route::post('/admin/settings/{type}/edit/{id}', 'RegistryController@postEdit');
Route::get('/admin/settings/{type}', 'RegistryController@getIndex')->name('registries');

/* Delete routs for settings*/
Route::post('/admin/settings/delete', 'RegistryController@deleteById')->name('registry_delete');

