<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAssessmentGoals extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessment_goals', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('assessment_id')->default(0);
            $table->integer('diagnosis_id')->default(0);
            $table->integer('patient_id')->default(0);
            $table->integer('goal_id')->default(0);
            $table->string('goal_version', 255)->nullable();
            $table->date('added_date')->nullable();
            $table->integer('status')->default(0)->comment('0=>partially save, 1=>active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessment_goals');
    }
}
