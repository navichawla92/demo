<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('user_id')->nullable();
            $table->text('email')->nullable();
            $table->text('password')->nullable();
            $table->text('phone')->nullable();
            $table->text('image')->nullable();
            $table->text('first_name')->nullable();
            $table->text('middle_initial')->nullable();
            $table->text('patient_alias')->nullable();
            $table->text('last_name')->nullable();
            $table->text('dob')->nullable();
            $table->tinyInteger('language')->nullable();
            $table->tinyInteger('county')->nullable();
            $table->text('ssn')->nullable();
            $table->text('pcp_name')->nullable();
            $table->text('pcp_phone')->nullable();
            $table->text('pcp_address')->nullable();
            $table->tinyInteger('referral_source')->nullable();
            $table->unsignedInteger('contract_payer')->nullable();
            $table->tinyInteger('is_insured')->nullable();
            $table->char('case_number',10)->nullable();
            $table->char('otp', 10)->nullable();
            $table->dateTime('otp_expiration')->nullable(); 
            $table->text('emergency_person1_name')->nullable();
            $table->text('emergency_person1_phone')->nullable();
            $table->text('emergency_person1_address')->nullable();
            $table->text('emergency_person1_relation')->nullable();   
            $table->text('emergency_person2_name')->nullable();
            $table->text('emergency_person2_phone')->nullable();
            $table->text('emergency_person2_address')->nullable();
            $table->text('emergency_person2_relation')->nullable();
            $table->tinyInteger('case_status')->default(0)->comment('0: Open, 1: Pre Register, 2: Registered, 3: Rejected, 4: Enroll,5: Mature');
            $table->tinyInteger('status')->default(0)->comment('0: Email Not Verified, 1: Active, 2: Inactive');
            $table->tinyInteger('step_number')->default(1)->comment('1: patient info tab, 2: patient health tab, 3: patient insurance tab, 4: patient documents tab, 5: patient notes tab');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}
