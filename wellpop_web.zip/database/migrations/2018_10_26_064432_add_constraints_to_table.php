<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddConstraintsToTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::table('patient_insurances', function (Blueprint $table) {
				$table->foreign('user_id')->references('id')->on('users');
				$table->foreign('patient_id')->references('id')->on('patients');
		});
		
	    Schema::table('patient_data', function (Blueprint $table) {
				$table->foreign('user_id')->references('id')->on('users');
				$table->foreign('patient_id')->references('id')->on('patients');
		});
		
		 Schema::table('patients', function (Blueprint $table) {
				$table->foreign('user_id')->references('id')->on('users');
			//	$table->foreign('contract_payer')->references('id')->on('contract_payers');
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
