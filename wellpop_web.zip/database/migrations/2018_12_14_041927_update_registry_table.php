<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateRegistryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('registries', function (Blueprint $table) {
            $table->increments('id');
            $table->enum('type', ['rehabs','housing_assistances','mental_health_assistances','home_health_providers','hospice_providers','insurances','emergency_departments', 'pcp_informations', 'specialities', 'contract_payers', 'referral_sources']);
            $table->string('name',255)->nullable();
            $table->string('org_name', 255)->nullable();
            $table->string('code', 255)->nullable();
            $table->string('email', 255)->nullable();
            $table->string('fax', 255)->nullable();
            $table->string('speciality', 255)->nullable();
            $table->text('web_address')->nullable();
            $table->string('phone', 255)->nullable();
            $table->text('address_line1')->nullable();
            $table->text('address_line2')->nullable();
            $table->string('city', 255)->nullable();
            $table->unsignedInteger('state_id')->nullable();
            $table->string('zip',255)->nullable();
            $table->date('effective_start_date')->nullable();
            $table->date('effective_end_date')->nullable();
            $table->string('auth_confirmation', 255)->nullable();
            $table->string('contact_name', 255)->nullable();
            $table->string('contact_phone', 255)->nullable();
            $table->string('contact_email', 255)->nullable();
            $table->string('contact_fax', 255)->nullable();
            $table->string('contact_title',255)->nullable();
            $table->unsignedInteger('user_id')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1: Active, 0: Inactive');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }

    /*
    ALTER TABLE `registries` ADD `speciality` VARCHAR(255) NULL DEFAULT NULL AFTER `type`, ADD `effective_start_date` DATE NULL DEFAULT NULL AFTER `speciality`, ADD `effective_end_date` DATE NULL DEFAULT NULL AFTER `effective_start_date`, ADD `auth_confirmation` VARCHAR(255) NULL DEFAULT NULL AFTER `effective_end_date`, ADD `contact_fax` VARCHAR(255) NULL DEFAULT NULL AFTER `auth_confirmation`, ADD `status` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `contact_fax`;




    ALTER TABLE `registries` CHANGE `type` `type` ENUM('emergency_departments','rehabs','housing_assistances','mental_health_assistances','home_health_providers','hospice_providers','insurances','pcp_informations ','specialities','contract_payers','referral_sources') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;

    */
}
