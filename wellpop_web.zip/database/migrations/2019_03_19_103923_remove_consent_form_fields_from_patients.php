<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveConsentFormFieldsFromPatients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('patients', function (Blueprint $table) {
            //
            $table->dropColumn(['consent_form_language', 'acknowledge_receive_services','acknowledge_emergency_medical_services','acknowledge_release_medical_records', 'acknowledge_release_vehicle','acknowledge_patient_bill_of_rights','consent_form_living_will_executed', 'consent_form_dpoa_executed','consent_form_dpoa_name','consent_form_dpoa_phone_number', 'consent_form_signature_date','consent_form_date','consent_form_documents_located_at_with', 'acknowledge_signature','consent_form_patient_initials','consent_form_signature_setup']);
            $table->integer('consent_form_signed')->nullable()->comment('0 : Not Signed, 1: Signed');
            $table->integer('hippa_form_signed')->nullable()->comment('0 : Not Signed, 1: Signed');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('patients', function (Blueprint $table) {
            //
        });
    }
}
