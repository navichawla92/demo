<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDiagnosisVersionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('diagnosis_versions', function (Blueprint $table) {
            $table->increments('id');
            $table->string('code');
            $table->string('title');
            $table->text('description')->nullable();
            $table->integer('metric_id');
            $table->integer('diagnosis_id')->unsigned();
            $table->enum('status',['0','1','2'])->comment('0=>Draft,1=>Active,2=>Deactive');
            $table->string('version');
            $table->timestamps();
            $table->softDeletes();
        });
        
        Schema::table('diagnosis_versions', function (Blueprint $table) {
			$table->foreign('diagnosis_id')->references('id')->on('diagnosis');
		}); 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('diagnosis_versions');
    }
}
