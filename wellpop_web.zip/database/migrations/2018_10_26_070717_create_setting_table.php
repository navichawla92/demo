<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('manageable_fields', function (Blueprint $table) {
            $table->increments('id');
            $table->enum('type', ['county','language','patient_concern','lives_with','patient_referal','document_category']);
            $table->char('name',255)->nullable();
            $table->text('value')->nullable();
            $table->text('description')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1: Active, 0: Inactive');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }




    /*
   ALTER TABLE `manageable_fields` CHANGE `type` `type` ENUM('county','language','patient_concern','lives_with','document_category','patient_referal','flag','metric','patient_functioning','durable_medical_equipment','identifying_issues') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;




    INSERT INTO `manageable_fields` (`type`, `name`, `value`, `description`, `status`, `created_at`, `updated_at`) 
    VALUES 
    ('patient_functioning', 'Independent', 'independent', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('patient_functioning', 'Independent with DME', 'independent_with_dme', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('patient_functioning', 'Hired caregivers/IHSS', 'hired_caregivers_ihss', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('patient_functioning', 'Family able to assist', 'family_able_to_assist', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('patient_functioning', 'Family unable to assist/No Resources', 'family_unable_to_assist', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    
    ('durable_medical_equipment', 'FWW', 'fww', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('durable_medical_equipment', 'Wheelchair', 'wheelchair', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('durable_medical_equipment', 'Cane', 'cane', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('durable_medical_equipment', 'Bedside Commode', 'bedside_commode', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    
    ('identifying_issues', 'Age with critical factors', 'age_with_critical_factors', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Homeless/Housing', 'homeless', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Financial', 'financial', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'New Major Diagnosis', 'new_major_diagnosis', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'No PCP', 'no_pcp', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Domestic Violence/Abuse', 'domestic_violence', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Change in Functional Status', 'change_in_functional_status', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Loss and Grief', 'loss_and_grief', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Substance Abuse', 'substance_abuse', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'End of Life', 'end_of_life', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Mental Health', 'mental_health', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00'),
    ('identifying_issues', 'Complex Placement', 'complex_placement', NULL, '1', '2019-02-13 00:00:00', '2019-02-13 00:00:00');
    */
}
