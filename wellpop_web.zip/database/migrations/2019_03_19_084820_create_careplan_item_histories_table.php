<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCareplanItemHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('careplan_item_histories', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('type')->default(0)->comment('0 => medication, 1 => allergy');
            $table->integer('type_id');
            $table->text('form_data')->nullable();
            $table->integer('patient_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('careplan_item_histories');
    }
}
