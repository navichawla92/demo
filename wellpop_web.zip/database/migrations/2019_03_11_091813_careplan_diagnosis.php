<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CareplanDiagnosis extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('careplan_diagnosis', function(Blueprint $table){
            $table->increments('id');
            $table->integer('careplan_id')->nullable();
            $table->integer('diagnosis_id')->default(0);
            $table->string('diagnosis_version', 255)->nullable();
            $table->integer('priority')->default(0);
            $table->integer('patient_id')->default(0);
            $table->date('date_added')->nullable();
            $table->integer('goal_count')->default(0);
            $table->enum('status',[0,1,2])->comment('0=> draft, 1=> active, 2=> deactive')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists('careplan_diagnosis');
    }
}
