<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class PatientsCareplan extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients_careplan', function (Blueprint $table) {
            $table->increments('id');
            $table->string('code', 255)->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->boolean('is_base_line')->default(0)->comment('0->No, 1->yes');
            $table->integer('added_by')->default(0);
            $table->integer('user_type')->default(0);
            $table->enum('status', [0,1,2,3,4])->comment('0=> partially save, 1=> active, 2=> discontinue, 3-> Complete, 4-> Archived');
            $table->text('reason')->nullable();
            $table->text('notes')->nullable();
            $table->integer('patient_id')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients_careplan');
    }
}
