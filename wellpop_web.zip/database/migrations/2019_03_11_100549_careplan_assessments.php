<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CareplanAssessments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('careplan_assessments', function(Blueprint $table){
            $table->increments('id');
            $table->integer('careplan_id')->default(0);
            $table->integer('patient_id')->default(0);
            $table->string('code',255)->nullable();
            $table->dateTime('assessment_date')->nullable();
            $table->integer('user_type');
            $table->integer('assessment_by');
            $table->string('purpose')->nullable();
            $table->string('via')->nullable();
           // $table->enum('patient_priority',[0,1])->comment('0=>no, 1=>yes')->nullable();
            $table->json('visit_content')->nullable();
            $table->text('other_notes')->nullable();
            //$table->enum('patient_confidence', ['low', 'medium', 'high'])->nullable();
           // $table->integer('visit_to_er')->default(0);
            //$table->integer('visit_to_pcp')->default(0);
            $table->text('overall_notes')->nullable();
            $table->enum('status',[0,1,2,3])->comment('0=>partially save, 1=>active, 2=>dis-continue, 3=>complete');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('careplan_assessments');
    }
}
