<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AssessmentGoalReview extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessment_goal_review', function(Blueprint $table){
            $table->increments('id');
            $table->integer('assessment_id')->default(0);
            $table->integer('diagnosis_id')->default(0);
            $table->integer('patient_id')->default(0);
            $table->text('summary')->nullable();
            $table->integer('flag_id')->default(0);
            $table->enum('rate', ['low', 'medium', 'high'])->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessment_goal_review');
    }
}
