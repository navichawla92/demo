<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Vitals extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vitals', function(Blueprint $table){
            $table->increments('id');
            $table->integer('assessment_id')->default(0);
            $table->string('weight',255)->nullable();
            $table->string('a1c', 255)->nullable();
            $table->float('blood_pressure_high')->default(0);
            $table->float('blood_pressure_low')->default(0);
            $table->string('blood_pressure_units',255)->nullable();
            $table->float('pulse')->default(0);
            $table->string('weight_units',255)->nullable();
            $table->integer('patient_id')->default(0);
            $table->integer('careplan_id')->default(0);
            $table->enum('status', [0,1,2])->comment('0=>draft, 1=>active, 2=>de-active');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vitals');
    }
}
