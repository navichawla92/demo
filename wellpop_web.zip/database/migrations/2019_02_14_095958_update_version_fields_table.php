<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateVersionFieldsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        
      /*  Schema::table('goal_versions', function (Blueprint $table) {
				$table->dropColumn('version');
		});*/
		Schema::table('goal_versions', function (Blueprint $table) {
			//	$table->float('version', 8, 2);
				$table->Integer('is_draft')->default(0)->comment('0=>No,1=>Yes');
		});
		/*Schema::table('goals', function (Blueprint $table) {
			    $table->dropColumn('current_version');
		});
		Schema::table('goals', function (Blueprint $table) {
				$table->float('current_version', 8, 2);
		});
		Schema::table('goal_assignments', function (Blueprint $table) {
			    $table->dropColumn('version');
			    $table->dropColumn('type_version');
		});
		Schema::table('goal_assignments', function (Blueprint $table) {
				$table->float('version', 8, 2)->nullable();
				$table->float('type_version', 8, 2)->nullable();
		});
		Schema::table('diagnosis', function (Blueprint $table) {
			    $table->dropColumn('current_version');
		});
		Schema::table('diagnosis', function (Blueprint $table) {
				$table->float('current_version', 8, 2);
		});
		Schema::table('diagnosis_versions', function (Blueprint $table) {
				$table->dropColumn('version');
		}); 
		Schema::table('diagnosis_versions', function (Blueprint $table) {
				$table->float('version', 8, 2);
		}); */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
