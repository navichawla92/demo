<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class UpdateExpirationDateField extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
         DB::statement('ALTER TABLE patient_insurances MODIFY effective_date  Date;');
          DB::statement('ALTER TABLE patient_insurances MODIFY expiration_date  Date;');
        /*Schema::table('patient_insurances', function ($table) {
			$table->date('effective_date')->change();
			$table->date('expiration_date')->change();
		});*/
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
