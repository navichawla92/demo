<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CareplanCheckpoints extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('careplan_checkpoints', function(Blueprint $table){
            $table->increments('id');
            $table->integer('careplan_id')->default(0);
            $table->integer('patient_id')->default(0);
            $table->string('code',255)->nullable();
            $table->integer('assessment_by')->default(0);
            $table->dateTime('assessment_date')->nullable();
            $table->integer('user_type')->default(0);
            $table->string('purpose',255)->nullable();
            $table->string('via',255)->nullable();
            $table->json('visit_content')->nullable();
            $table->text('other_notes')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('careplan_checkpoints');
    }
}
