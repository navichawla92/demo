<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBarriersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('barriers', function (Blueprint $table) {
            $table->increments('id');
            $table->text('name')->nullable();
            $table->text('solution')->nullable();
            $table->enum('status',['0','1','2'])->comment('0=>Draft,1=>Active,2=>Deactive');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('barriers');
    }
}
