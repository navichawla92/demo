<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientAllergies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_allergies', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('patient_id');
            $table->enum('user_type', ['CHW', 'MD', 'CM']);
            $table->integer('type_id');
            $table->text('name');
            $table->text('severity');
            $table->text('type');
            $table->text('comment');
            $table->integer('status')->default(1);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_allergies');
    }





    //ALTER TABLE `patient_allergies` ADD `type` TEXT NULL DEFAULT NULL AFTER `name`;
}
