<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class InterventionFollowup extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('intervention_followups', function(Blueprint $table){
            $table->increments('id');
            $table->integer('assessment_id')->default(0);
            $table->string('follow_up_item')->nullable();
            $table->date('follow_up_date')->nullable();
            $table->date('added_date')->nullable();
            $table->integer('user_type')->default(0);
            $table->integer('added_by')->default(0);
            $table->enum('status', [0, 1])->default(0)->comment('0=>incomplete, 1=>complete');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('intervention_followup');
    }
}
