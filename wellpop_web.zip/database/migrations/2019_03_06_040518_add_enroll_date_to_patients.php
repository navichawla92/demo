<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddEnrollDateToPatients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('patients', function (Blueprint $table) {
            //
            $table->dateTime('enroll_at')->nullable();
            $table->unsignedBigInteger('enrollment_status')->nullable()->comment('0 : Intense, 1: Mature, 2: Graduate, 3: Discharge, 4:Eloped');
            $table->dateTime('chw_complete_assessment_at')->nullable();
            $table->dateTime('cm_complete_assessment_at')->nullable();
            $table->dateTime('md_complete_assessment_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('patients', function (Blueprint $table) {
            //
        });
    }
}
