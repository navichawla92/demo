<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFieldsToUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::table('patients', function (Blueprint $table) {
            $table->text('gender')->nullable();
            $table->text('lives_with')->nullable();
            $table->tinyInteger('living_with_other')->default(0)->comment('0: no, 1: Yes');
            $table->text('living_with_other_text')->nullable();
            $table->json('patient_concern')->nullable();
            $table->tinyInteger('patient_concern_other')->default(0)->comment('0: no, 1: Yes');
            $table->text('patient_concern_other_text')->nullable();
            $table->json('icd_code')->nullable();
        });
        //
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
