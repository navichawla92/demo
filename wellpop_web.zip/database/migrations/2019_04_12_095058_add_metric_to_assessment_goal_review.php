<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddMetricToAssessmentGoalReview extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('assessment_goal_review', function (Blueprint $table) {
            $table->dropColumn('rate');
            $table->integer('metric_id')->nullable();
            $table->string('metric_value',255)->nullable();
            $table->string('diagnosis_version',255)->nullable();
            $table->integer('status')->default(0)->comment('0=>partially save, 1=>active');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('assessment_goal_review', function (Blueprint $table) {
            //
        });
    }
}
