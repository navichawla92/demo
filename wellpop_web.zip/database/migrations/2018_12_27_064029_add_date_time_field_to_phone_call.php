<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDateTimeFieldToPhoneCall extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('patient_phone_calls', function (Blueprint $table) {
            //
            $table->date('assessment_date')->nullable();
            $table->time('assessment_time')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('patient_phone_calls', function (Blueprint $table) {
            //
        });
    }
}
