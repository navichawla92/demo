<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateEnumInManageableFieldsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement("ALTER TABLE manageable_fields CHANGE COLUMN type type ENUM('county', 'language', 'patient_concern','lives_with', 'document_category','patient_referal','flag','metric','patient_functioning','durable_medical_equipment','identifying_issues','barrier_category','careplan_assessment_purpose', 'careplan_assessment_via') NOT NULL");
    }
   
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('manageable_fields', function (Blueprint $table) {
            //
        });
    }


    /* ALTER TABLE `manageable_fields` CHANGE `type` `type` ENUM('county','language','patient_concern','lives_with','document_category','patient_referal','flag','metric','patient_functioning','durable_medical_equipment','identifying_issues','barrier_category') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL; */
}

