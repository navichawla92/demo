<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdatePatientTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::table('patients', function($table) {
             $table->dropColumn('pcp_name');
             $table->dropColumn('pcp_phone');
             $table->dropColumn('pcp_address');
             $table->unsignedInteger('pcp_id')->nullable();
             $table->text('emergency_person1_address2')->nullable();
             $table->text('emergency_person2_address2')->nullable();
             $table->text('emergency_person1_city')->nullable();
             $table->text('emergency_person2_city')->nullable();
             $table->unsignedInteger('emergency_person1_state_id')->nullable();
             $table->unsignedInteger('emergency_person2_state_id')->nullable();
             $table->text('emergency_person1_zip')->nullable();
             $table->text('emergency_person2_zip')->nullable();
             $table->tinyInteger('emergency_person1_checkbox')->nullable();
             $table->tinyInteger('emergency_person2_checkbox')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
