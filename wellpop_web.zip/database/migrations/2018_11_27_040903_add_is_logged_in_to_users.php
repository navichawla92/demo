<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddIsLoggedInToUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
      /*  Schema::table('users', function (Blueprint $table) {
				$table->tinyInteger('is_logged_in')->default(0)->comment('0: no, 1: yes');
				
		});*/
		/*Schema::table('pcp_informations', function (Blueprint $table) {
            $table->softDeletes();
        });
        Schema::table('referral_sources', function (Blueprint $table) {
            $table->softDeletes();
        });*/
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
