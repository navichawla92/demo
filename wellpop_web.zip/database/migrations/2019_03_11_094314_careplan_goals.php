<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CareplanGoals extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('careplan_goals', function(Blueprint $table){
            $table->increments('id');
            $table->integer('careplan_id')->default(0);
            $table->integer('diagnosis_id')->default(0);
            $table->integer('goal_id')->default(0);
            $table->string('goal_version',255)->nullable();
            $table->integer('patient_id')->default(0);

            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists('careplan_goals');
    }
}
