<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientAssignments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_assignments', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('patient_id');
            $table->enum('user_type', ['CHW', 'MD', 'CM']);
            $table->integer('type_id');
            $table->integer('case_status')->default(0);
            $table->integer('status')->default(1);
            $table->integer('assigned_by');
            $table->integer('type')->default(0)->comment('0 => registration, 1 => careplan');
            $table->date('discontinued_on')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_assignments');
    }
}
