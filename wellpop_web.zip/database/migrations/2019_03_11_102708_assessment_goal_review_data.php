<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AssessmentGoalReviewData extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessment_goal_review_data', function(Blueprint $table){
            $table->increments('id');
            $table->integer('assessment_goal_review_id')->default(0);
            $table->integer('assessment_id')->default(0);
            $table->integer('goal_id')->nullable();
            $table->string('goal_version',255)->nullable();
            $table->enum('item_type',['goal','priority_alignment','risk_assessment'])->nullable();
            $table->integer('item_type_id')->nullable()->comment('id of the related item');
            $table->integer('question_id')->default(0);
            $table->integer('patient_id')->default(0);
            $table->date('added_date')->nullable();
            $table->integer('added_by')->default(0);
            $table->integer('flag_id')->default(0);
            $table->integer('metric_id')->nullable();
            $table->string('answer',255)->nullable();
            $table->integer('no_of_visits')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessment_goal_review_data');
    }
}
