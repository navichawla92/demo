<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateTypeInToolTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		
		Schema::table('tools', function (Blueprint $table) {
				$table->dropColumn('type');
		});
		
        Schema::table('tools', function (Blueprint $table) {
			    $table->string('title')->nullable();
				$table->enum('type',['Online','Pdf'])->nullable()->comment('Online=>Online,Pdf=>Pdf');
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tools');
    }
}
