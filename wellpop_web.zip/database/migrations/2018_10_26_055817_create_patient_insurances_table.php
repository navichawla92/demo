<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientInsurancesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_insurances', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('user_id')->nullable();
            $table->unsignedInteger('patient_id')->nullable();
            $table->enum('type', ['primary','secondary']);
            $table->unsignedBigInteger('insurance_id')->nullable();
            $table->text('policy')->nullable();
            $table->text('group')->nullable();
            $table->text('authorized_by')->nullable();
            $table->text('authorization')->nullable();
            $table->dateTime('effective_date')->nullable();
            $table->dateTime('expiration_date')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_insurances');
    }
}
