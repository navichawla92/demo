<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddRegistrationFieldToPatients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('patients', function (Blueprint $table) {
            //

            $table->text('authorization_code')->nullable();

            
            $table->string('registration_number',10)->nullable();
            $table->dateTime('registered_at')->nullable();
            $table->unsignedBigInteger('registration_status')->nullable()->comment('0 : New, 1: Incomplete, 2: Complete, 3: Rejected');
            $table->Integer('pcp_not_required')->default(0)->nullable()->comment('0: Off, 1: On');
            $table->enum('patient_decision', ['pending', 'accepts','refuses']);
            $table->enum('consent_form_language', ['eng','es','fr','vit']);
            $table->date('consent_form_date')->nullable();
            $table->enum('consent_form_living_will_executed', ['yes','no']);
            $table->enum('consent_form_dpoa_executed', ['yes','no']);
            $table->text('consent_form_dpoa_name')->nullable();
            $table->text('consent_form_dpoa_phone_number')->nullable();
            
            $table->text('consent_form_signature_setup')->nullable();            
            $table->text('consent_form_documents_located_at_with')->nullable();
            
            $table->enum('acknowledge_receive_services', ['0', '1'])->default(0)->nullable();
            $table->enum('acknowledge_emergency_medical_services', ['0', '1'])->default(0)->nullable();
            $table->enum('acknowledge_release_medical_records', ['0', '1'])->default(0)->nullable();
            $table->enum('acknowledge_release_vehicle', ['0', '1'])->default(0)->nullable();
            $table->enum('acknowledge_patient_bill_of_rights', ['0', '1'])->default(0)->nullable();
            $table->enum('acknowledge_signature', ['0', '1'])->default(0)->nullable();

            $table->date('consent_form_signature_date')->nullable();
            $table->text('consent_form_patient_initials')->nullable();
            
            //For CHW Assessment
            $table->unsignedBigInteger('ed_visits_last_12_months')->nullable();
            $table->unsignedBigInteger('ed_admissions_last_12_months')->nullable();
            $table->text('specialist_id')->nullable();
            $table->unsignedBigInteger('rehab_information_id')->nullable();
            $table->unsignedBigInteger('housing_assistance_id')->nullable();
            $table->unsignedBigInteger('mental_health_assistance_id')->nullable();
            $table->Integer('chw_tab_completed')->default(0)->nullable();
            $table->Integer('chw_case_status')->default(0)->nullable()->comment('0: Pending, 1: In-complete, 2: Complete, 3: reject');
            
            //For CM Assessment
            $table->enum('advance_healthcare_on_file', ['yes','no']);
            $table->text('advance_healthcare_checkboxes')->nullable();
            $table->text('advance_healthcare_attorney_name')->nullable();
            $table->text('advance_healthcare_attorney_phone')->nullable();
            $table->text('advance_healthcare_attorney_relation')->nullable();
            $table->enum('polst_on_file', ['yes','no']);
            $table->text('polst_checkboxes')->nullable();
            $table->unsignedBigInteger('home_health_provider_id')->nullable();
            $table->unsignedBigInteger('hospice_provider_id')->nullable();
            $table->text('patient_functioning')->nullable();
            $table->text('patient_functioning_text')->nullable();
            $table->text('durable_medical_equipment')->nullable();
            $table->text('durable_medical_equipment_text')->nullable();            
            $table->text('durable_medical_equipment_other')->nullable()->comment('0: No, 1: Yes');
            $table->text('durable_medical_equipment_other_text')->nullable();            
            $table->text('identifying_issues')->nullable();
            $table->text('identifying_issues_text')->nullable();
            $table->text('identifying_issues_other')->nullable()->comment('0: No, 1: Yes');
            $table->text('identifying_issues_other_text')->nullable();
            $table->Integer('cm_tab_completed')->default(0)->nullable();
            $table->Integer('cm_case_status')->default(0)->nullable()->comment('0: Pending, 1: In-complete, 2: Complete, 3: reject');
            
            //For MD Assessment
            $table->Integer('substance_abuse_not_required')->default(0)->nullable()->comment('0: Off, 1: On');
            $table->text('substance_abuse')->nullable();
            $table->Integer('medication_not_required')->default(0)->nullable()->comment('0: Off, 1: On');
            $table->Integer('allergy_not_required')->default(0)->nullable()->comment('0: Off, 1: On');
            $table->Integer('md_tab_completed')->default(0)->nullable();
            $table->Integer('md_case_status')->default(0)->nullable()->comment('0: Pending, 1: In-complete, 2: Complete, 3: reject');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('patients', function (Blueprint $table) {
            //
        });
    }

    /*
    ALTER TABLE `patients` ADD `durable_medical_equipment_other` TEXT NULL DEFAULT NULL AFTER `identifying_issues_text`, ADD `durable_medical_equipment_other_text` TEXT NULL DEFAULT NULL AFTER `durable_medical_equipment_other`, ADD `identifying_issues_other` TEXT NULL DEFAULT NULL AFTER `durable_medical_equipment_other_text`, ADD `identifying_issues_other_text` TEXT NULL DEFAULT NULL AFTER `identifying_issues_other`;

    ALTER TABLE `patients` ADD `substance_abuse_not_required` INT(11) NOT NULL DEFAULT '0' AFTER `substance_abuse`, ADD `medication_not_required` INT(11) NOT NULL DEFAULT '0' AFTER `substance_abuse_not_required`, ADD `medication_allergies` INT(11) NOT NULL DEFAULT '0' AFTER `medication_not_required`;

    ALTER TABLE `patients` ADD `pcp_not_required` INT(11) NOT NULL DEFAULT '0' AFTER `random_key`;

    --------New---------------------
    ALTER TABLE `patients` CHANGE `medication_allergies` `allergy_not_required` INT(11) NOT NULL DEFAULT '0';
    ALTER TABLE `patients` CHANGE `patient_decision` `patient_decision` ENUM('pending','accepts','refuses') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending';
    
    //new signature button added so add new column in database also
    ALTER TABLE `patients` ADD `consent_form_signature_for_emergency_medical_services` TEXT NULL DEFAULT NULL AFTER `consent_form_signature_setup`;
    
    */




    /* 
    -----------------Consent Form Signature changes on 31Jan----------------
    ALTER TABLE `patients` ADD `acknowledge_receive_services` ENUM('0','1') NULL DEFAULT '0' AFTER `consent_form_signature_date`, ADD `acknowledge_emergency_medical_services` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `acknowledge_receive_services`, ADD `acknowledge_release_medical_records` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `acknowledge_emergency_medical_services`, ADD `acknowledge_release_vehicle` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `acknowledge_release_medical_records`, ADD `acknowledge_patient_bill_of_rights` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `acknowledge_release_vehicle`, ADD `acknowledge_signature` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `acknowledge_patient_bill_of_rights`;

    ALTER TABLE `patients` DROP `consent_form_signature`, DROP `consent_form_signature_for_emergency_medical_services`, DROP `consent_form_signature_for_authorization`, DROP `consent_form_signature_for_release`, DROP `consent_form_signature_for_vehicle`;
    */
}
