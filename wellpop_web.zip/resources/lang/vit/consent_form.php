<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Consent Form Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default label value for consent form
    */

    'address_field_1' => 'Wellness Population Solutions',
    'address_field_2' => '5020 Campus Drive',
    'address_field_3' => 'Newport Beach, CA 92660',
    'informed_consent' => 'Informed Consent for Participation',
    'patient_name' => 'TÊN BỆNH NHÂN/KHÁCH HÀNG',
    'signature_setup' => 'Signature Setup',
    'receive_services' => 'Đồng ý tiếp nhận các dịch vụ',
    'authorize_paragraph' => 'Tôi đồng ý rằng Wellness Population Solutions sẽ cung cấp dịch vụ phối hợp chăm sóc cho bệnh nhân/khách hàng có tên ở trên. Tôi hiểu rằng nhân viên được đào tạo bài bản về quản lý chăm sóc sẽ cung cấp dịch vụ chăm sóc này. Tôi hiểu rõ và đồng ý rằng tôi có quyền từ chối điều trị hoặc kết thúc dịch vụ bất cứ lúc nào bằng cách thông báo cho Wellness Population Solutions biết rằng tôi muốn kết thúc dịch vụ. Ngoài ra, Wellness Population Solutions có thể ngừng cung cấp dịch vụ bằng cách thông báo cho tôi biết rằng dịch vụ đã kết thúc và tại sao chúng lại kết thúc.',
    'authorization_paragraph' => 'Cho phép cung cấp các dịch vụ y tế khẩn cấp',
    'receiving_services_paragraphp' => 'Trong trường hợp cấp cứu y khoa, tôi đồng ý rằng Wellness Population Solutions hoặc nhân viên của Wellness Population Solutions sẽ cung cấp hoặc thực hiện điều trị y tế mà họ xét thấy cần thiết cho sức khỏe và sự an toàn của tôi. Tôi đồng ý sẽ chịu trách nhiệm về tất cả các khoản phí cho việc điều trị.',
    'medical_records' => 'Cung cấp bệnh án',
    'acknowledge' => 'Acknowledge',
    'medical_records_paragraph' => 'Tôi muốn cung cấp bản sao bệnh án của mình cho Wellness Population Solutions để bắt đầu hoặc tiếp tục kế hoạch quản lý quá trình chăm sóc sức khỏe của tôi.',
    'release_copies_medical_services_paragraph' => 'Tôi đồng ý rằng Wellness Population Solutions có thể cung cấp bản sao bệnh án hoặc một phần bệnh án của tôi cho những nhà cung cấp dịch vụ chăm sóc sức khỏe khác để tôi có thể nhận được sự chăm sóc tốt nhất từ tất cả nhà cung cấp dịch vụ chăm sóc sức khỏe của mình.',
    'vehicle_release' => 'Cho phép phương tiện',
    'vehicle_release_paragraph' => 'Tôi đồng ý thông báo cho Wellness Population Solutions biết trước và tôi hiểu rằng tôi phải nhận được giấy ủy quyền từ văn phòng làm việc của Welless Population Solutions trước khi bất kỳ nhân viên/nhà thầu nào của Wellness Population Service có thể chở tôi bằng xe ôtô của trong nhân viên/nhà thầu của Wellness Population Solutions. Sau đây tôi cho phép Wellness Population Solutions và nhân viên/nhà thầu của họ được chỉ định cho tôi và giữ cho Wellness Population Solutions và nhân viên/nhà thầu của họ không bị thiệt hại. Ngoài ra, tôi cũng miễn trừ họ khỏi bất kỳ khiếu nại, trách nhiệm hoặc nguyên nhân gây ra bất cứ thương tích nào cho tôi (kể cả tử vong), thương tổn cho cơ thể của bên thứ ba hoặc thiệt hại về tài sản do sử dụng xe ôtô được vận hành bởi nhân viên/nhà thầu của Wellness Population Solutions, cho dù có được sự cho phép trước từ văn phòng của Wellness Population Solutions hay không.',
    'patient_bill_right' => 'Bản tuyên bố về quyền của bệnh nhân',
    'patient_bill_right_paragraph' => 'Tôi xác nhận rằng tôi đã đọc kỹ, nhận được bản sao và hiểu rõ Bản tuyên bố về quyền của bệnh nhân mà đại diện của Wellness Population Solutions đã giải thích cho tôi.',
    'patient_rights_checkbox' => 'Quyền của bệnh nhân về bản chỉ dẫn trước (Vui lòng đánh dấu vào ô thích hợp)',
    'assistance_with_medications' => 'Hỗ trợ về thuốc men',
    'i_certify' => 'Tôi xác nhận rằng tôi',
    'have_executed' => 'đã thực hiện',
    'living_will' => 'chưa thực hiện Ý nguyện Trị liệu.',
    'power_of_attorney' => 'chưa thực hiện Giấy ủy quyền/Giấy ủy nhiệm chăm sóc sức khỏe lâu dài.',
    'DPOA_name' => 'Tên DPOA',
    'phone_number' => 'Số điện thoại',
    'located_at_paragraph' => 'Tôi cho phép Wellness Population Solutions nhận bản sao của bất kỳ tài liệu nào nêu trên. Các tài liệu nằm ở hoặc với',
    'advance_directives_paragraph' => 'Tôi xác nhận rằng tôi đã được hướng dẫn, nhận được bản sao và hiểu rõ Quyền của bệnh nhân về bản chỉ dẫn trước được đại diện của Wellness Population Solutions giải thích cho tôi bằng miệng.',
    'unlicensed_person_paragraph' => 'Tôi đã được Wellness Population Solutions thông báo rằng tôi có thể nhận được sự hỗ trợ từ một người chưa được cấp phép trong việc tự dùng thuốc. (Không bao gồm thuốc gây mê)',
    'signature' => 'Chữ ký',
    'add_signature' => 'Add Signature',
    'date' => 'NGÀY', 
    'patient_client_initials' => 'Tên họ viết tắt của bệnh nhân/khách hàng',
    'patient_digital_signature' => 'Patient Digital Signature',
    'patient_sign_in_box' => 'Patient Signature',
    'clear' => 'Clear',
    'updating_signature_notice' => 'By updating your signature, all your previous acknowledgements will unacknowledge if any.',
    'acknowledge_signature_notice' => 'Acknowledge to provide your consent.',
    'add_setup_signature' => 'Please setup signature first.',
    'setup_signature' => 'Setup Signature',
    

];
