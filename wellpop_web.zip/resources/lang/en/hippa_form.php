<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Consent Form Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default label value for consent form
    */

    'address_field_1' => 'Wellness Population Solutions',
    'address_field_2' => '5020 Campus Drive',
    'address_field_3' => 'Newport Beach, CA 92660',
    'informed_hippa' => 'HIPPA Authorization Form',
    'patient_name' => 'PATIENT/CLIENT NAME',
    'signature_setup' => 'Signature Setup',
    'authorize_process' => 'Authorized persons to use and disclose protected health information',
    'authorize_paragraph' => 'Wellness Population Solutions, Inc. is authorized to disclose my protected health information to all healthcare providers engaged in my treatment and to medical researchers approved by Wellness Population Solutions to evaluate the effectiveness of Wellness Population Solutions’ Community-Based Complex Care Management Program.',
    'authorize_disclose_permission' =>'Wellness Population Solutions, Inc. is also authorized to disclose my protected health information to the following family members',
    'description_heading' => 'Description of information to be disclosed',
    'health_info' => 'The health information that may be disclosed is:',
    'acknowledge' => 'Acknowledge',
    'medical_records' => 'Medical records',
    'alcohol_drug_abuse' => 'Alcohol/drug abuse treatment',
    'mental_health_record' => 'Mental health records',
    'all_treatment_record' => 'All treatment records',
    'all_past_info' => 'All past, present, and future periods of health care information may be shared',
    'purpose_heading' => 'Purpose of the use or disclosure',
    'purpose_paragraph' => 'The purpose of this use or disclosure is for care coordination, treatment and research to assess the effectiveness of Wellness Population Solutions’ Community-Based Complex Care Management Program.',
    'validity_heading' => 'Validity of authorization form',
    'validity_para' => 'This Authorization Form is valid beginning on ',
    'validity_paragraph' => 'and expires on the date when I withdraw permission to use my protected health information.',
    'acknowledgment_para' => 'I understand that the information used or disclosed under this Authorization Form may be subject to re-disclosure by the person(s) or facility receiving it and would then no longer be protected by federal privacy regulations.',
    'acknowledgment_paragraph' => 'I have the right to refuse to sign this Authorization Form. If signed, I have the right to revoke this authorization, in writing, at any time. I understand that any action already taken in reliance on this authorization cannot be reversed, and my revocation will not affect those actions.',
    'signature' => 'Signature',
    'add_signature' => 'Add Signature',
    'date' => 'DATE',
    'patient_client_initials' => 'Patient’s/Client’s Initials',
    'patient_digital_signature' => 'Patient Digital Signature',
    'patient_sign_in_box' => 'Patient Signature',
    'clear' => 'Clear',
    'updating_signature_notice' => 'By updating your signature, all your previous acknowledgements will unacknowledge if any.',
    'acknowledge_signature_notice' => 'Acknowledge to provide your consent.',
    'add_setup_signature' => 'Please setup signature first.',
    'setup_signature' => 'Setup Signature',
    'ACKNOWLEDGMENT' =>'ACKNOWLEDGMENT'
    

];
