<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Message Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default messages 
    */

    // for common controller

    'added_successfully' => ' added successfully.',
    'updated_successfully' => ' updated successfully.',
    'some_error' => 'Some error while added new',
    'document_deleted' => 'Document deleted successfully.',
    'error_document_deleted' => 'Some error while delete document.',
    'comment_added' => 'Comment added successfully.',
    'error_comment_added' => 'Some error while added new Comment.',
    'patient_reject' => 'Patient rejected successfully.',
    'error_patient_reject' => 'Some error while patient reject.',
    'patient_assessment' => 'Patient assessment completed successfully.',

    'sign_successfully' => ' has been signed successfully.',


     // CM: for patient controller

    'patient_detail_successfully' => 'Patient details updated successfully.',
    'patient_created_successfully' => 'Patient created successfully.',
    'error_updated_patient' => 'Some error while updating patient details.',
    'error_added_patient' => 'Some error while refer new patient.',
    'added_patient' => 'Patient added successfully.',
    'register_patient' => 'Patient has been registered successfully and moved to registration listing.',
    'pre_register_patient' => 'Patient pre-registered successfully.',
    'move_patient' => 'Patient move successfully.',
    'error_move_patient' => 'Some error while move patient.',

     // CM:  for patient register controller

    'error_updating_assignments' => 'Some error while updating assignments.',
    'assignments_created_successfully' => 'Care team assigned successfully.',
    'contact_created_successfully' => 'Contact entry added successfully.',
    'error_contact_created' => 'Some error while added new contact entry.',
    'signature_save' => 'Signature saved successfully.',
    'consent_form_save' => 'Patient consent saved successfully.',
    'error_form_save' => 'Some error while saving',
    'error_consent_form_save' => 'Some error while saving consent form',

    // MD:  for patient register controller

    'listing_found.' => 'Listing found.',
    'medication_created_successfully' => 'Medication has been added successfully.',
    'medication_updated_successfully' => 'Medication has been updated successfully.',

    'error_medication_created' => 'Some error while adding new medication.',
    'allergy_created_successfully' => 'Allergy has been added successfully.',
    'allergy_updated_successfully' => 'Allergy has been updated successfully.',
    'error_allergy_created' => 'Some error while adding new allergy.',
    'assign_care_message' => 'Please assign care team members to the patient to perform this action.',

    // for alert message 

    'unsaved_error_message' => 'There is some unsaved data on this page. Please Save or Discard the data to proceed further.',

    // admin panel messages
    'field_update_successfully' => 'Field Updated successfully.',
    'field_added_successfully' => 'Field added successfully.',
    'field_added_error' => 'Some error while refer new field.',
    'contract_payer_update_successfully' => 'Contract Payer Updated successfully.',
    'contract_payer_added_successfully' => 'Contract Payer added successfully.',
    'contract_payer_added_error' => 'Some error while refer new contract payer.',
    'updated_successfully' => ' updated successfully.',
    // admin

    /* Care Plan */

    /* Tools */

    'tool_updated_successfully' => 'Tool has been updated successfully.',
    'tool_added_successfully' => 'Tool has been added successfully.',
    'error_added_tool' => 'Some error while add/edit tool.',
    //diagnosis
	'diagnosis_created_successfully' => 'Diagnosis has been added successfully.',
	'diagnosis_deleted_successfully' => 'Diagnosis has been deleted successfully.',
	'diagnosis_created_error' => 'Diagnosis could not be added.',
	'diagnosis_edit_successfully' => 'Diagnosis has been updated successfully.',
	'diagnosis_edit_error' => 'Diagnosis could not be updated.',

    /* Sub Goals */

    'sub_goal_updated_successfully' => 'Sub Goal has been updated successfully.',
    'sub_goal_added_successfully' => 'Sub Goal has been added successfully.',
    'error_added_sub_goal' => 'Some error while add/edit Sub Goal.',


    /* Questions */

    'question_updated_successfully' => 'Question has been updated successfully.',
    'question_added_successfully' => 'Question has been added successfully.',
    'error_added_question' => 'Some error while add/edit Question.',

     /* Barriers */

    'barrier_updated_successfully' => 'Barrier has been updated successfully.',
    'barrier_added_successfully' => 'Barrier has been added successfully.',
    'error_added_barrier' => 'Some error while add/edit Barrier.',

    'error_for_add_goal_data' =>'Please add atleast one Subgoal, Question and Diagnosis.',

     /* Goal */

    'goal_added_successfully' => 'Goal has been added successfully.',
    'goal_draft_successfully' => 'Goal has been added to draft successfully.',
    'error_added_goal' => 'Some error while add/edit goal.',

    /* Content Discussed */
    'content_updated_successfully' => 'Content has been updated successfully.',
    'content_added_successfully' => 'Content has been added successfully.',
    'error_added_content' => 'Some error while add/edit Content.',
    'not_compelte_assesment' =>'Please add atleast one assessment.',

    'care_team_updated' => 'Care Team updated successfully.',
    'error_care_team' => 'Some error while updated care team.',


    /* medication */
    'medication_started_successfully' => 'Medication has been started successfully.',
    'medication_discontinued_successfully' => 'Medication has been discontinued successfully.',
    'discontinue_medication' => 'Are you sure you wish to discontinue the medication?',
    'start_medication' => 'Are you sure you wish to start the medication?',

    /*Allergy*/
    'allergy_started_successfully' => 'Allergy has been started successfully.',
    'allergy_discontinued_successfully' => 'Allergy has been discontinued successfully.',
    'discontinue_allergy' => 'Are you sure you wish to discontinue the allergy?',
    'start_allergy' => 'Are you sure you wish to start the allergy?',
    'patient_enrolled_successfully' => 'Patient successfully enrolled in case loads.',

    'add_careplan_diagnosis' => 'Diagnosis added successfully.',
    'update_careplan_diagnosis' => 'Diagnosis updated successfully.',
    'error_add_careplan_diagnosis' => 'Some error while added new diagnosis.',
    'patient_careplan_added' => 'Care plan created successfully.',

    /* careplan */
    'careplan_completed_successfully' => 'Care Plan has been completed successfully.',
    'careplan_discontinued_successfully' => 'Care Plan has been discontinued successfully.',
    'careplan_base_line_successfully' => 'Care Plan has been base lined successfully.',
    'remove_diagnosis_warning' => 'Are you sure you want to remove this diagnosis?',
    'baseline_alert_message' => 'Are you sure you want to baseline this care plan?',
    'remove_careplan_diagnosis' => 'Diagnosis deleted successfully.',
    'error_remove_careplan_diagnosis' => 'Some error while deleted diagnosis.',

    /*Assessment Barrier*/
    'assessment_barrier_added_successfully' => 'Barrier added successfully.',
    'assessment_barrier_deleted_successfully' => 'Barrier deleted successfully.',
    'assessment_vital_added_successfully' => 'Vital added successfully.',
    'assessment_progress_notes_saved_successfully' => 'Progress note saved successfully.',
    'assessment_content_discussed_saved_successfully' => 'Content discussed saved successfully.',


    'delete_goal_message' => 'Are you sure you want to remove this goal as this is only available goal for assessment?',
    'delete_goal_review_diagnosis_message' => 'Are you sure you want to remove the diagnosis?',
    'remove_assessment_goal' => 'Goal deleted successfully.',
    'error_remove_assessment_goal' => 'Some error while deleted goal.',


    /* Message for care plan*/

    'goal_selected_for_care_plan' => 'Goal(s) Selected for this Care Plan',
    'goal_checked_for_care_plans' => 'Goals checked off are the ones that have been already added to Care Plan',
    'select_goal_for_care_plan' => 'Select Goal(s) for this Care Plan',
    'please_select_goals_and_provide' => "Please select goals and provide feedback. Click on 'Select Goals' button to choose the goals from Core Plan for this assessment",
    'select_goal_using_checkbox' => "Select Goals using the check box and add them to Assessment.",
    'select_goal_using_checkbox_with_pre_select' => "Select Goals using the check box and add them to Assessment Goals checked off are the ones that have been already added to Care Plan.",

    'intervention_saved_successfully' => 'Intervention saved successfully.',
    'intervention_updated_successfully' => 'Intervention updated successfully.',
    'intervention_followup_saved_successfully' => 'Intervention follow up saved successfully.',

    'no_question_assigned' =>'No question assigned to',

    'patient_assessment_added' => 'Assessment created successfully.',
    'patient_checkpoint_added' => 'Care plan created successfully.',
    'patient_assessment_copied' => 'Assessment copied successfully.',

];
