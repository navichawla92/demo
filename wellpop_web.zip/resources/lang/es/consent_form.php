<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Consent Form Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default label value for consent form
    */

    'address_field_1' => 'Soluciones para la población de bienesta',
    'address_field_2' => '5020 Campus Drive',
    'address_field_3' => 'Newport Beach, CA 92660',
    'informed_consent' => 'Informed Consent for Participation',
    'patient_name' => 'PATIENT/CLIENT NAME',
    'signature_setup' => 'Signature Setup',
    'receive_services' => 'Consent to receive services',
    'authorize_paragraph' => 'I hereby authorize Wellness Population Solutions to render appropriate care coordination services to the patient/client named above. I understand an appropriate level of care coordination personnel will provide such care. I recognize and agree that I have the right to refuse treatment or terminate services at any time by notifying the Wellness Population Solutions office. In addition, Wellness Population Solutions may terminate service by notifying me of termination and the reason.',
    'authorization_paragraph' => 'Authorization for emergency medical services',
    'receiving_services_paragraphp' => 'At any time while receiving services from Wellness Population Solutions, and in the event of any medical emergency, I authorize Wellness Population Solutions or its employees/contractors to provide or obtain such medical treatment as they deem advisable under the circumstances, and I agree to assume sole responsibility for all charges for such treatment.',
    'medical_records' => 'Release of medical records',
    'acknowledge' => 'Acknowledge',
    'medical_records_paragraph' => 'I hereby consent and request that copies, if necessary, of my prior medical records be delivered to Wellness Population Solutions to establish or continue my care coordination plan.',
    'release_copies_medical_services_paragraph' => 'I hereby authorize Wellness Population Solutions to release copies of my medical records or reports or such portions or summaries thereof as may be relevant, to other healthcare providers or regulatory or accrediting bodies for the purpose of continuing and coordinating my care coordination plan and for quality assurance, survey and accreditation purposes.',
    'vehicle_release' => 'Vehicle release',
    'vehicle_release_paragraph' => 'I agree to notify Wellness Population Solutions, in advance, and I understand that I must receive written authorization from the Wellness Population Solutions office, before any Wellness Population Service employees/contractor may transport me in a Wellness Population Solutions employee’s/contractor’s automobile. I hereby release Wellness Population Solutions and its employees/contractors assigned to me, and hold Wellness Population Solutions and such employees/contractors harmless and indemnify them from any claim, liability, or cause of action for any injury to my person (including death), bodily injury to a third party, or property damage resulting from the use of an automobile operated by a Wellness Population Solutions employee/contractor, whether or not prior authorization from the Wellness Population Solutions office has been obtained.',
    'patient_bill_right' => 'Statement of Patient Bill of Rights (Need to develop)',
    'patient_bill_right_paragraph' => 'I certify that I have read, received a copy, and understand the Patient Bill of Rights which has been explained to me orally by a representative of Wellness Population Solutions.',
    'patient_rights_checkbox' => 'Patient Rights on Advance Directives (Please check the appropriate boxes)',
    'assistance_with_medications' => 'Assistance with Medications',
    'i_certify' => 'I certify that I',
    'have_executed' => 'have executed',
    'living_will' => 'have not executed a Living Will.',
    'power_of_attorney' => 'have not executed a Durable Power of Attorney/Health Care Proxy.',
    'DPOA_name' => 'DPOA Name',
    'phone_number' => 'Phone Number',
    'located_at_paragraph' => 'I authorize Wellness Population Solutions to receive a copy of any of the above documents. The documents are located at or with',
    'advance_directives_paragraph' => 'I certify that I have been instructed about, received a copy of, and understand the patient Rights on Advance Directives which was explained to me orally by a representative of Wellness Population Solutions.',
    'unlicensed_person_paragraph' => 'I have been informed by Wellness Population Solutions that I may be receiving assistance with self administration of medication from an unlicensed person. (Excluding Narcotics)',
    'signature' => 'Signature',
    'add_signature' => 'Add Signature',
    'date' => 'DATE',
    'patient_client_initials' => 'Patient’s/Client’s Initials',
    'patient_digital_signature' => 'Patient Digital Signature',
    'patient_sign_in_box' => 'Patient sign in the below box',
    'clear' => 'Clear',
    

];
