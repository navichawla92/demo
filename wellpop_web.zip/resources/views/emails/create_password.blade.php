<p>Your accound has been created!</p>

<p>Follow the link below to set your password.</p>

<a href="{{ route('password.reset', [$reset_token,'type=set']) }}">Click here</a> to set your password!