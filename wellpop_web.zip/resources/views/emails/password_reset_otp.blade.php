<p>Your have requested to reset you password.</p>

<p>Your OTP to password reset is {{ $otp }}.</p>