@extends('layouts.app')

@section('css')
  <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
@endsection

@section('content')
<div class="leftsectionpages">
  <div class="row">
    <div class="col-md-6">
      <div class="headingpage">
        <div class="firstname">My Profile</div>
        <span><i class="fas fa-angle-right"></i></span>
      </div>
    </div>
  </div>
	<div class="tabsmain">


    <div class="textfieldglobal">
      <label class="labelfieldsname" >Full Name</label>
      {!! Form::text('name',null) !!}
      <span class="error" style="color:red"></span>
    </div>      
    <div class="buttonsbottom">
      <button type="button" class="next" onClick="javascript:saveform('saveandnext','#patient-info-form','2')">Update</button>
    </div>



  </div>
</div>
@endsection

@section('script')

@endsection
