@extends('layouts.app')

@section('css')
  <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
@endsection

@section('title')
  My Profile
@endsection

@section('content')
<div class="leftsectionpages">
  <div class="row">
    <div class="col-md-6">
      <div class="headingpage">
        <div class="firstname">My Profile</div>
        <span><i class="fas fa-angle-right"></i></span>
      </div>
    </div>
  </div>
	<div class="tabsmain">

  @if(session()->has('message.level'))
      <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        {!! session('message.content') !!}
      </div>
  @endif  
    
    <!-- Profile Image code started here -->
    <div class="row">
		<div class="profile-box">
			<div class="textfieldglobal profile-img patient_pro_pic_preview">
<!--			  <label class="labelfieldsname" >Profile Picture</label>-->
			  <img id="previewHolder" alt="Uploaded Image Preview Holder" src="@if($user->image) {{ config('filesystems.s3_user_images_full_path').$user->id.'/'.$user->image }} @else {{ asset('images/dummy_user.png') }} @endif" width="150"/>
        <span class="imgcross" <?php if(!$user->image) echo 'style="display:none;"'; ?>>X</span>
			  <form enctype="multipart/form-data" id="upload_pic" role="form" method="POST" action="" <?php if($user->image) echo 'style="display:none;"'; ?>>
				<input type="hidden" name="_token" value="{{ csrf_token()}}">
				<input type="file" name="image" accept="image/x-png,image/gif,image/jpeg" value="" id="profile_pic" class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg">
			  </form>
			  <span class="error" id='image_error' style="color:red"></span>
			</div>
			  <div class="buttonsbottom">
			<button type="button" class="next" id="pro_pic_btn" disabled="" onClick="javascript:changePic()">Update Profile Picture</button>
		  </div> 
			<div class="textfieldglobal">
				<label class="labelfieldsname" >Full Name</label>
				{!! Form::text('name',$user->name) !!}
				<span class="error" style="color:red"></span>
			  </div>      
			  <div class="buttonsbottom">
				<button type="button" class="next" onClick="javascript:updateName()">Update</button>
			  </div>
			  <div class="textfieldglobal">
				<label class="labelfieldsname" >New Password</label>
				{!! Form::password('password',null) !!}
				<span class="error" style="color:red"></span>
			  </div>   
			  <div class="textfieldglobal">
				<label class="labelfieldsname" >Confirm Password</label>
				{!! Form::password('password_confirmation',null) !!}
				<span class="error" style="color:red"></span>
			  </div> 
			  <div class="buttonsbottom">
				<button type="button" class="next" onClick="javascript:changePassword()">Change Password</button>
			  </div> 
			
		</div>
    </div>
    <!-- Profile Image code started here -->

<!--
    <div class="clearfix"></div>
    <br><br>
-->

<!--
    <div class="row" style="border:1px solid #ddd">
      <div class="textfieldglobal">
        <label class="labelfieldsname" >Full Name</label>
        {!! Form::text('name',$user->name) !!}
        <span class="error" style="color:red"></span>
      </div>      
      <div class="buttonsbottom">
        <button type="button" class="next" onClick="javascript:updateName()">Update</button>
      </div>  
    </div>  
-->

<!--
    <div class="clearfix"></div>
    <br><br>
-->

<!--
    <div class="row" style="border:1px solid #ddd">
      

    </div>
-->


  </div>
</div>
@endsection

@section('script')
<script type="text/javascript">

function updateName(){
  $.ajax({
    url:"{{ route('update-personal-info') }}",
    data:{name:$('input[name=name]').val(),'_token':"{{ csrf_token() }}"},
    // processData: false,
    // contentType: false,
    dataType: "json",
    success:function(data){
      window.location.reload();
    }
  });
}

function changePassword(){
  $.ajax({
    url:"{{ route('change-password') }}",
    data:{password:$('input[name=password]').val(),password_confirmation:$('input[name=password_confirmation]').val(),'_token':"{{ csrf_token() }}"},
    // processData: false,
    // contentType: false,
    dataType: "json",
    success:function(data){
      window.location.reload();
    }
  });
}

function changePic(){
  $.ajax({
      url:"{{ route('change-pic') }}",
      data:new FormData($("#upload_pic")[0]),
      dataType:'json',
      processData: false,
      contentType: false,
      success:function(response){
        window.location.reload();
      },
      error:function(error){
            $.each(error.responseJSON.errors,function(key,value){
                if(key == 'image'){
                  $('#image_error').html(value).addClass('active').show();
                } 
            });

            jQuery('html, body').animate({
                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
            }, 500);

      }
    });
}

$("#profile_pic").change(function() {
  $('#pro_pic_btn').attr('disabled',false);
  readURL(this);
  $('.patient_pro_pic_preview span.imgcross').show();
  $('#upload_pic').hide();
});

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#previewHolder').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}
fadeOutAlertMessages();

//user profile image remove on cross click code
$(document).on('click','.patient_pro_pic_preview span.imgcross',function(){
  $('input[type=file][name=image]').val('');
  $('.patient_pro_pic_preview span.imgcross').hide();
  $('.patient_pro_pic_preview img').attr('src',"{{ asset('images/dummy_user.png') }}");
  $('#upload_pic').show();
  $('#image_error').html('').removeClass('active');
  
});
</script>
@endsection
