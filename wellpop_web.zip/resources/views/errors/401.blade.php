@extends('layouts.login_layout')

@section('title')
  Login
@endsection

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="error-template">
                <h1>
                    Oops!</h1>
                <h2>
                    401 ACCESS DENIED</h2>
                <div class="error-details">
                    ACCESS DENIED
                </div>
                <div class="error-actions">
                    <a href="{{route('login')}}" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                        Take Me Home </a><a href="{{route('login')}}" class="btn btn-default btn-lg">
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
