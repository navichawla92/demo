 @include('patients.common.profile_status_bar')
 <div id="notes_table">
      @include('patients.common.notes_table')
 </div>
  <div class="modal fade adddocumentdocuments" id="adddocumentnotes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	 {!! Form::model($patient,['id' => 'patient-notes-form']) !!}
	<input type="hidden" name="step_number" value="5">
	<input type="hidden" name="action" value="edit">
	<input type="hidden" name="patient_id" class="ref_patient_id" value="{{$patient->id}}" data-id="{{\Crypt::encrypt($patient->id)}}">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="headingpage"> {{ trans('label.add_note') }} </div>
         <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>-->
        </div>
        <div class="modal-body">
          <div class="datapopfileds">
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{ trans('label.date') }} </label>
              </div>
              <div class="popdata50"> 
                <span class="labelvaluepop current_date">
                  <!-- Add date here by javascript on modal open -->
              </span> 
            </div>
          </div>
          <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{ trans('label.user') }} </label>
              </div>
              <div class="popdata50"> <span class="labelvaluepop">{!! \Auth::user()->name !!}</span> </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-12">
                <div class="textfieldglobal">
					<label class="labelfieldsname" > {{ trans('label.note_area') }}* </label>
					 <input type="text" placeholder="" name="notes_area" maxlength="100">
					<span class="error" style="color:red"></span>
				</div>
                <div class="textfieldglobal">
					<label class="labelfieldsname" > {{ trans('label.note_subject') }}*</label>
					<textarea rows="4" cols="50" name="notes_subject" maxlength="1000"></textarea>
					<span class="error" id="notes_subject_error" style="color:red"></span>
				</div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom">
           <button type="button" class="next model_box_save" onClick="javascript:saveCommonform('savenotes','#patient-notes-form','5')"> {{ trans('label.save') }} </button>
          <a href="#" class="close" data-dismiss="modal" aria-label="Close"> {{ trans('label.cancel') }} </a> </div>
        </div>
      </div>
    </div>
         {!! Form::close() !!}
  </div>
  
  <div class="modal fade viewdocumentnotes" id="viewdocumentnotes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content info-modal">
        <div class="modal-header">
          <h4> {{ trans('label.note_details') }} </h4>
        </div>
        <div class="modal-body patient-info note-info">
			<p> {{ trans('label.user_name') }}:<span class="note_user"></span></p>
			<p> {{ trans('label.date') }}:<span class="note_date"></span></p>
			<p> {{ trans('label.note_area') }}:<span class="note_area"></span></p>
			<p> {{ trans('label.note_subject') }}:<span class="note_subject"></span></p>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom">
          <a href="#" class="close" data-dismiss="modal" aria-label="Close"> {{ trans('label.close') }} </a> </div>
        </div>
      </div>
    </div>
  </div>

