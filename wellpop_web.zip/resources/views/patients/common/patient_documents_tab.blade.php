@include('patients.common.profile_status_bar')
 <div id="documents_table">
      @include('patients.common.documents_table')
 </div>
<div class="modal fade adddocumentdocuments" id="add_document" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    {!! Form::model($patient,['id' => 'patient-document-form']) !!}
    <input type="hidden" name="step_number" value="4">
    <input type="hidden" name="action" value="edit">
    <input type="hidden" name="patient_id" class="ref_patient_id" value="{{$patient->id}}" data-id="{{\Crypt::encrypt($patient->id)}}">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="headingpage"> {{trans('label.add_document')}} </div>
         <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> -->
        </div>
        <div class="modal-body">
          <div class="datapopfileds">
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{trans('label.date')}} </label>
              </div>
              <div class="popdata50"> 
                <span class="labelvaluepop current_date">
                  <!-- Add date here by javascript on modal open -->
                </span> 
              </div>
            </div>
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{trans('label.user')}} </label>
              </div>
              <div class="popdata50"> <span class="labelvaluepop">{!! \Auth::user()->name !!}</span> </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-12">
                <div class="textfieldglobal">
                  {!! Form::select('category_id', $doc_categories, null,array('class'=>'customselect')) !!}
                  <span class="error" style="color:red"></span>
                </div>
                <div class="textfieldglobal">
                  <input type="text" placeholder="Document name" name="document_name" maxlength="60"> 
                  <span class="error" style="color:red"></span>
                </div>
                <div class="browsebutton">
                  <label> {{trans('label.upload_document')}} </label>
                  <div class="browsebuttontext"> {{trans('label.browse')}} 
                    <input type="file" name="uploaded_document" accept="application/pdf">
                  </div>
                  <span class="error upload_document_error" style="color:red"></span>
                  <div class="filenamecross">
                    <span id="selected_doc_name" style="color:black"> {{trans('label.no_file_selected')}} </span>
                    <span style="color:red;display:none;cursor:pointer;" id="delete_selected_doc">X</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">

          <div class="buttonsbottom">
            <!--  <a href="javascript:void(0)" class="next model_box_save" onClick="javascript:saveCommonform('savedocument','#patient-document-form','4')"> {{trans('message.save')}} </a>
             --> 
           <a href="javascript:void(0)" class="next model_box_save" onClick="javascript:saveCommonform('savedocument','#patient-document-form','4')"> {{trans('label.save')}} </a> <a href="#" data-dismiss="modal" class="close"> {{trans('label.cancel')}} </a> </div>
        </div>
      </div>
    </div>
    {!! Form::close() !!}
  </div>

<div class="modal fade adddocumentdocuments" id="delete_document" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    {!! Form::model($patient,['id' => 'patient-document-delete-form']) !!}

    <input type="hidden" name="patient_id" class="doc_patient_id" >
    <input type="hidden" name="doc_id" class="document_id" >
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="headingpage"> {{trans('label.delete_document')}} </div>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
        </div>
        <div class="modal-body">
          <div class="datapopfileds">
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{trans('label.date')}} </label>
              </div>
              <div class="popdata50"> 
                <span class="labelvaluepop current_date">
                  <!-- Add date here by javascript on modal open -->
                </span> 
              </div>
            </div>
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{trans('label.user')}} </label>
              </div>
              <div class="popdata50"> <span class="labelvaluepop">{!! \Auth::user()->name !!}</span> </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-12">
                <div class="textfieldglobal">
                  <label> {{trans('label.reason')}} </label>
                  <textarea rows="4" cols="50" name="reason" maxlength="1000"></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">

          <div class="buttonsbottom">
           <a href="javascript:void(0)" class="next model_box_save" onClick="javascript:deleteDocument('#patient-document-delete-form')"> {{trans('label.delete')}} </a> </div>
        </div>
      </div>
    </div>
    {!! Form::close() !!}
  </div>