  <div class="personliving">
    @if(session()->has('message.Note-level'))
        <div class="alert alert-{{ session('message.Note-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="row">
      <div class="col-md-6 col-6">
        <div class="headingpage"> {{ trans('label.add_necessary_notes') }}:</div>
      </div>
      <div class="col-md-6 col-6">
        <div class="buttonpatient"><a href="#" data-toggle="modal" data-target="#adddocumentnotes"><i class="fas fa-plus"></i> {{ trans('label.add_note') }}</a></div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.date') }}</th>
            <th> {{ trans('label.note_area') }} </th>
            <th>{{ trans('label.note_subject') }}</th>
            <th>{{ trans('label.added_by') }}</th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($patient_notes))
            <?php  $index=($patient_notes->perPage() * ($patient_notes->currentPage()- 1))+1; ?>
            @foreach($patient_notes as $patient_note)
                <?php
                  $patient_note->calc($patient->random_key);
                ?>
              <tr>
                <td>{{$index}}</td>
                <td>{{ $patient_note->created_at }}</td>
                <td>{{ $patient_note->name }}</td>
                <td>{{ $patient_note->value }}</td>
                <td>{{ $patient_note->user->name }}</td>
                <td>
                  <div class="dropdown more-btn dropup">
                      <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <span>...</span>
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenu2" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -2px, 0px); top: 0px; left: 0px; will-change: transform;">
                        <a href="#" data-id="{{$patient_note->id}}"
                        data-area="{{$patient_note->name}}" data-subject="{{$patient_note->value}}" data-date="{{$patient_note->created_at}}" data-user_name="{{$patient_note->user->name}}" class="dropdown-item view_notes">
                          <i class="fa fa-eye"></i> {{ trans('label.view') }}
                        </a>
                      </div>
                  </div>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>
<div class="document_notes_tabs" data-tab-name="notes">
      <?php echo $patient_notes->render(); ?>
</div>