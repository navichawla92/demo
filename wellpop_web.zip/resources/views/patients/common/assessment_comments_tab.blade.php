@include('patients.common.profile_status_bar')
<div class="personliving">
   <div class="row">
      <div class="col-md-6 col-6">
         <div class="headingpage"> {{ trans('label.add_assessment') }} </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="qa-message-list" id="wallmessages">
      <div id="assessment_messages">
        @include('patients.common.assessment_comments')
      </div>
      <div class="message-item" id="m9">
          {!! Form::model($patient,['id' => 'patient-assessment-form']) !!}
            {!! Form::hidden('patient_id', encrypt($patient->id))  !!}
          <div class="message-inner">
            <div class="comment-box">
               <div class="form-group">
                  <label> {{ trans('label.add_new_assessment') }} </label>
                  <textarea class="form-control" name="comment" maxlength="10000"></textarea>
                   <span class="error" style="color:red"></span>
               </div>
               <button type="button" class="btn btn-success model_box_save" onClick="javascript:saveAssessmentform('add_assessment','#patient-assessment-form')"> {{ trans('label.save_assessment') }} </button>
            </div>
          </div>

          <span class="notes_error error" style="color:red"></span>
          {!! Form::close() !!}
      </div>
   </div>
   <!-- list-end	-->
</div>

<div class="buttonsbottom comment-btn">
   <button class="next model_box_save"  onClick="javascript:assessmentTabButtons('close', '{{ $role_type }}')">{{ trans('label.close') }}</button>
   <button class="movetable model_box_save" onClick="javascript:assessmentTabButtons('complete_assessment', '{{ $role_type }}')"> {{ trans('label.complete_assessment') }} </button>
   @if($role_type == CASEMANAGER || $role_type == MANAGERDIRECTOR)
    <button type="button" class="reject reject_patient"> {{ trans('label.reject') }} </button>
  @endif
</div>
@if($role_type == CASEMANAGER || $role_type == MANAGERDIRECTOR)
<div class="modal fade adddocumentdocuments" id="reject_patient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    {!! Form::model($patient,['id' => 'patient-reject-form']) !!}
    {!! Form::hidden('patient_id', encrypt($patient->id))  !!}
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="headingpage"> {{ trans('label.reject_patient') }} </div>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
        </div>
        <div class="modal-body">
          <div class="datapopfileds">
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{ trans('label.date') }} </label>
              </div>
              <div class="popdata50"> 
                <span class="labelvaluepop current_date">
                  <!-- Add date here by javascript on modal open -->
                </span> 
              </div>
            </div>
            <div class="popdatafull">
              <div class="popdata50">
                <label class="poplabel"> {{trans('label.user')}} </label>
              </div>
              <div class="popdata50"> <span class="labelvaluepop">{!! \Auth::user()->name !!}</span> </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-12">
                <div class="textfieldglobal">
                  <label> {{trans('label.reason')}}* </label>
                  <textarea rows="4" cols="50" name="reason" maxlength="1000"></textarea>
                   <span class="error" style="color:red"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom">
            <a href="javascript:void(0)" class="next model_box_save" onClick="javascript:assessmentTabButtons('reject', '{{ $role_type }}')"> {{trans('label.reject')}} </a>
           </div>
        </div>
      </div>
    </div>
    {!! Form::close() !!}
  </div>


@endif