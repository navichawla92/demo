<div class="patient-detail">
  <div class="subdataofpatient">
    <div class="width50ofname">

        <label>{{ trans('label.name') }}:</label>
    <?php 
      $name = '';
      $name .= $patient->first_name ? ucfirst($patient->first_name) : '-';
      $name .= ' ';
      $name .= $patient->last_name ? ucfirst($patient->last_name) : '-';
    ?>
    <span class="namelabel" title="{{$name}}"> {!! strlen($name) > 15 ? substr($name,0,15)."..." : $name !!}</span>

      @if($patient->case_status_value == 2)      
        <label>{{ trans('label.registration_number') }}:</label>
        <span class="namelabel">{!! $patient->registration_number ? $patient->registration_number : '-' !!}</span>
      @else        
        <label>{{ trans('label.case_number') }}:</label>
        <span class="namelabel">{{$patient->case_number}}</span>
      @endif

      <div class="addnewdetail"><a href="#" class="viewDetail">{{ trans('label.patient_info') }}.</a></div>
    </div>
    <div class="width50ofname">
      <div class="status_label">
      <label>{{ trans('label.status') }}:</label>
      @if($patient->case_status_value == 2)
        @role('CM')
          {!! $patient->cm_case_status_badge !!}
        @endrole
        @role('MD')
         {!! $patient->md_case_status_badge !!}
        @endrole
        @role('CHW')
          {!! $patient->chw_case_status_badge !!} 
        @endrole
      @else
        {!! $patient->case_status_badge !!}
      @endif
      </div>
    </div>
  </div>
</div>