@foreach($patient_assessment_comments as $patient_assessment_comment)
            <div class="message-item" id="m9">
               <div class="message-inner">
                  <div class="message-head clearfix">
                     <div class="avatar fa-pull-left"><a href="#"><img src="@if($patient_assessment_comment->user->image) {{ config('filesystems.s3_user_images_full_path').$patient_assessment_comment->user->id.'/'.$patient_assessment_comment->user->image }} @else {{ asset('images/dummy_user.png') }} @endif"></a></div>
                     <div class="user-detail">
                        <h5 class="handle">{{ $patient_assessment_comment->user->name }} <span class="qa-message-when-data">{{ $patient_assessment_comment->assessment_date_with_time }}</span>
                        {!! $patient_assessment_comment->comment_type == 'assessment_rejection' ? "<span class='badge badge-danger'>Rejected</span>" : "" !!}   
                        </h5>
                        <div class="qa-message-content">
                           <pre>
                              {{ $patient_assessment_comment->comment }}
                           </pre>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
@endforeach
