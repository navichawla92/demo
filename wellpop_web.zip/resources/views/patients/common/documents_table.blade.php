  <div class="personliving">
    @if(session()->has('message.Document-level'))
        <div class="alert alert-{{ session('message.Document-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="row">
      <div class="col-md-6 col-6">
        <div class="headingpage"> {{trans('label.upload_necessary_documents')}}:</div>
      </div>
      <div class="col-md-6 col-6">
        <div class="buttonpatient"><a href="#" data-toggle="modal" data-target="#add_document"><i class="fas fa-plus"></i> {{trans('label.add_document')}}</a></div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="table-responsive care-table common-document-table" style="overflow: auto;">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{trans('label.document_category')}}</th>
            <th> {{trans('label.name_of_the_document')}} </th>
            <th>{{trans('label.upload_date')}}</th>
            <th>{{trans('label.upload_by')}}</th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($patient_docs))
            <?php  $index=($patient_docs->perPage() * ($patient_docs->currentPage() - 1))+1 ?>
            @foreach($patient_docs as $patient_doc)
                <?php
                  $patient_doc->calc($patient->random_key);
                ?>
              <tr>
                <td>{{$index}}</td>
                <td>{{$patient_doc->document_category->name}}</td>
                <td>{{ $patient_doc->name }}</td>
                <td>{{ $patient_doc->created_at }}</td>
                <td>{{ $patient_doc->user->name }}</td>
                <td>
                  <div class="dropdown more-btn dropup">
                      <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <span>...</span>
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenu2" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -2px, 0px); top: 0px; left: 0px; will-change: transform;">
                        <a class="dropdown-item" href="{{ config('filesystems.s3_patient_documents_full_path').$patient->id.'/'.$patient_doc->value }}" target="_blank">
                          <i class="fa fa-eye"></i> {{ trans('label.view') }}
                        </a>
                       
                          <a class="dropdown-item delete_patient_document" href="#" data-doc_id="{{ \Crypt::encrypt($patient_doc->id) }}" data-patient_id="{{ \Crypt::encrypt($patient_doc->patient_id) }}">
                          <i class="fa fa-trash"></i> {{ trans('label.delete') }}
                        </a>
                      </div>
                  </div>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
    </div>
  </div>

<div class="document_notes_tabs" data-tab-name="documents">
      <?php echo $patient_docs->render(); ?>
</div>