<script type="text/javascript">
$(document).ready(function(){

  applpyEllipses('common-note-table', 5, 'no');
  applpyEllipses('common-document-table', 5, 'no');

});
// const monthNames = ["January", "February", "March", "April", "May", "June",
//         "July", "August", "September", "October", "November", "December"
// ];
const monthNumbers = ["01", "02", "03", "04", "05", "06",
         "07", "08", "09", "10", "11", "12"
];

$(document).on('show.bs.modal', '.adddocumentdocuments' ,function(){
	$('span.error').hide().removeClass('active');
	var currentdate = new Date(); 
	var current_date = monthNumbers[currentdate.getMonth()] + "-"
			+("0" + currentdate.getDate()).slice(-2) + "-" 
			+ currentdate.getFullYear();
	$('.current_date').html(current_date);
});

$(document).on('click', '.delete_patient_document', function(e) {
   e.preventDefault();
   var docid = $(this).data('doc_id');
   var patient_id = $(this).data('patient_id');
   bootbox.confirm({ 
	message: "Are you sure, you want to delete this document?", 
	callback: function(result){  
	  if (result) {
		$('#delete_document').find('.doc_patient_id').val(patient_id);
		$('#delete_document').find('.document_id').val(docid);
		$('#delete_document').modal('show');
	  }
	  else {
  		bootbox.hideAll();
  		return false;
	  }
	}
  })
});

//$('body').on('click', '.pagination a', function(e) {
$('body').on('click', '.document_notes_tabs a', function(e) {
    e.preventDefault();
    var page = getURLParameter($(this).attr('href'), 'page');
    var url = "{{ route('patient-document-list') }}"+'?page='+ page;
    //var url = window.location.href+'?page='+ $(this).text();
    var tab_name = $(this).closest(".document_notes_tabs").data('tab-name');
    var patient_id = $('.ref_patient_id').val();
    $.ajax({
        url:url,
        type:"GET",
        data:{tab_name:tab_name,id:patient_id},
        dataType: "html",
            success:function(data){
              if(tab_name == 'documents')
                $("#documents_table").html(data);
              else
                $("#notes_table").html(data);

              applpyEllipses('common-note-table', 5, 'no');
              applpyEllipses('common-document-table', 5, 'no'); 
            },
            error:function(data){
              $("#notes_table").html(data);
            }
    });
});

function saveCommonform(button_pressed,formId,tab){
  
  $('.model_box_save').attr("disabled", "disabled");
  $('span.error').hide().removeClass('active');
  var formData = new FormData($(formId)[0]);
  $.ajax({
    url:"{{ route('patient-documents') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('.model_box_save').removeAttr("disabled");
      $('input,textarea,select').removeClass('changed-input');
     
    if(button_pressed == 'savenotes')
      {
       
        $.ajax({
            url:"{{ route('patient-document-list') }}",
            type:"GET",
            data: {id:data.patient_id,tab_name:'notes'},
            dataType: "html",
            success:function(data){
              $('#adddocumentnotes').modal('hide');
              $("#notes_table").html(data);
              $('#patient-notes-form').find('textarea[name=notes_subject],input[name=notes_area]').val("");

              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
              // $('.care-table').on('show.bs.dropdown', function () {
              //     $('.care-table').css( "overflow", "inherit" );
              // });

              // $('.care-table').on('hide.bs.dropdown', function () {
              //      $('.care-table').css( "overflow", "auto" );
              // });

              applpyEllipses('common-note-table', 5, 'no');

            },
            error:function(data){
              $('#adddocumentnotes').modal('hide');
              $("#notes_table").html(data);

              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
            }
        });      
      }
      else if(button_pressed == 'savedocument')
      {   
        $.ajax({
            url:"{{ route('patient-document-list') }}",
            type:"GET",
            data: {id:data.patient_id,tab_name:'documents'},
            dataType: "html",
            success:function(data){
              $('#add_document').modal('hide');
              $("#documents_table").html(data);
              $('#patient-document-form').find('select[name=category_id],input[type=file],input[name=document_name]').val(""
                );
              $("#selected_doc_name").html('No file selected');
              $("#delete_selected_doc").hide();

              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
              applpyEllipses('common-document-table', 5, 'no');
            },
            error:function(data){
               $('#add_document').modal('hide');
              $("#documents_table").html(data);

              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
            }
        });      
      }
    },
    error:function(error){
        $('.model_box_save').removeAttr("disabled");
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        $.each(error.responseJSON.errors,function(key,value){
            if(key == 'patient_concern')
                $('#patient_concern_error').html(value).addClass('active').show();
            else if(key == 'notes_subject')
                $('#notes_subject_error').html(value).addClass('active').show();            
            else if(key == 'uploaded_document')
                $('.upload_document_error').html(value).addClass('active').show();                  
            else
            {
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
           }
        }); 
        
        jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
          }, 500);    
    }
  });
}

$('body').on('click', '.view_notes', function(e) {
        e.preventDefault();
        $('#viewdocumentnotes').modal('show');
        $('.note_date').text($(this).data('date'));
        $('.note_area').text($(this).data('area'));
        $('.note_subject').html('<pre>'+$(this).data('subject')+'</pre>');  
        $('.note_user').text($(this).data('user_name'));   
});


function deleteDocument(formId){
  
  $('.model_box_save').attr("disabled", "disabled");
  var formData = new FormData($(formId)[0]);
  $.ajax({
    url:"{{ route('patient-document-delete') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('.model_box_save').removeAttr("disabled");
      $('input,textarea,select').removeClass('changed-input');
       $.ajax({
            url:"{{ route('patient-document-list') }}",
            type:"GET",
            data: {id:data.patient_id,tab_name:'documents'},
            dataType: "html",
            success:function(data){
              $('#delete_document').modal('hide');
              $("#documents_table").html(data);
              $('#patient-document-form').find('select[name=category_id],input[type=file],input[name=document_name]').val(""
                );
              $("#selected_doc_name").html('No file selected');
              $("#delete_selected_doc").hide();

              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
              applpyEllipses('common-document-table', 5, 'no');
            },
            error:function(data){
               $('#delete_document').modal('hide');
               $("#documents_table").html(data);
            }
        });      
     
    }
  });
}

$(document).on('change','input[type=file][name=uploaded_document]',function(e){
    $('.upload_document_error').hide().removeClass('active');
    $("#selected_doc_name").html(e.target.files[0].name);
    $("#delete_selected_doc").show();
});
// for modal box close event
$(document).on('hidden.bs.modal', '.adddocumentdocuments',function () {
    $('input,textarea,select').removeClass('changed-input');
    $('.adddocumentdocuments').find('form').trigger('reset');
    $('#patient-document-form').find('select[name=category_id],input[type=file],input[name=document_name]').val("");
    $('#patient-notes-form').find('input[name=document_name],input[name=notes_area],textarea').val("");
    $("#selected_doc_name").html('No file selected');
    $("#delete_selected_doc").hide();
    $('span.error').hide().removeClass('active');
})

$(document).on('click','#delete_selected_doc',function(e){
    $('.upload_document_error').hide().removeClass('active');
    $('#patient-document-form').find('input[type=file]').val("");
    $("#selected_doc_name").html('No file selected');
    $("#delete_selected_doc").hide();
});

// $('.care-table').on('show.bs.dropdown', function () {
//      $('.care-table').css( "overflow", "inherit" );
// });

// $('.care-table').on('hide.bs.dropdown', function () {
//      $('.care-table').css( "overflow", "auto" );
// });

function saveAssessmentform(button_pressed,formId){
  $('.model_box_save').attr("disabled", "disabled");
  $('span.error').hide().removeClass('active');
  var formData = new FormData($(formId)[0]);

  if(button_pressed == 'complete_assessment'){
    //formData.append( 'case_status',1);
  }
  $.ajax({
    url:"{{ route('patient-assessment') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('.model_box_save').removeAttr("disabled");
      $('input,textarea,select').removeClass('changed-input');
     
    if(button_pressed == 'add_assessment')
      {
       
        $.ajax({
            url:"{{ route('patient-assessment-list') }}",
            type:"GET",
            data: {id:data.patient_id},
            dataType: "html",
            success:function(data){
              $("#assessment_messages").html(data);
              $('#patient-assessment-form').find('textarea[name=comment]').val("");
              fadeOutAlertMessages();
            },
            error:function(data){
              $("#assessment_messages").html(data);
              //recall fade out javascript code to remove dynamically added messages
              fadeOutAlertMessages();
            }
        });      
      }
      else if(button_pressed == 'saveandclose')
      {   
              
      }
      else if(button_pressed == 'complete_assessment')
      {   
              
      }
    },
    error:function(error){
        $('.model_box_save').removeAttr("disabled");
        $.each(error.responseJSON.errors,function(key,value){
            $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
        }); 
        jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);    
    }
  });
}

//function for assessment tab buttons for all type of assessments CM, MD and CHW
function assessmentTabButtons(type, role){

  if(type =='reject'){

  }
  else {
    if ($('.changed-input').length){
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }
  }
  

  if(type == 'close'){
    redirectToSpecificPageAfterAssessment(role);
  }else if(type == 'complete_assessment'){
     $('.model_box_save').attr("disabled", "disabled");
    $.ajax({  
        url:"{{ route('registration_assessment_complete') }}",
        type: "GET",
        dataType: "json",
        data: {
          patient_id:"{{ encrypt($patient->id) }}"
        },
        success:function(data){
          $('.model_box_save').removeAttr("disabled");
          redirectToSpecificPageAfterAssessment(role);
       },
        error:function(error){
        $('.model_box_save').removeAttr("disabled");
        $.each(error.responseJSON.errors,function(key,value){
            $('.'+key).html(value).addClass('active').show();
        }); 
        jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);    
       }
    });
  }else if(type == 'reject'){
    var formData = new FormData($('#patient-reject-form')[0]);

    $.ajax({
        url:"{{ route('patient-reject') }}",
        data:formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success:function(data){
          $('.model_box_save').removeAttr("disabled");
          $('textarea[name="reason"]').removeClass('changed-input');
          redirectToSpecificPageAfterAssessment(role);
        },
        error:function(error){
            $('.model_box_save').removeAttr("disabled");
            $.each(error.responseJSON.errors,function(key,value){
                $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            }); 
            jQuery('html, body').animate({
                  scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
            }, 500);    
        }
    });
  }
}

//function to redirect all type of user after assessments 9CM, MD and CHW)
function redirectToSpecificPageAfterAssessment(role){
  if(role == "{{ CASEMANAGER }}")
    window.location.href="{{ route('registration_patient_view', encrypt($patient->id))  }}";  
  if(role == "{{ MANAGERDIRECTOR }}")
    window.location.href="{{ route('md-registrations')  }}";  
  if(role == "{{ COMMUNITYHEALTHWORKER }}")
    window.location.href="{{ route('chw-registrations')  }}";
}



$(document).on('click', '.reject_patient', function(e) {
   e.preventDefault();
   if ($('.changed-input').length){
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }
   $('#reject_patient').modal('show');
});

</script>
