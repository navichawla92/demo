<div class="tab-pane fade {{ ($active_tab == 'patient_info')?'show active':'' }}" id="patientinfo" role="tabpanel" aria-labelledby="home-tab">
  <?php
  $relationshipOptions=relationship_array();
  $gender_array=gender_array();
  ?>
  <!-- Open form here to save only this tab data -->
  {!! Form::model($patient,['id' => 'patient-info-form', 'files' => true]) !!}
  
  <input type="hidden" name="step_number" value="1">
  <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
  <input type="hidden" name="action" value="{{ $patient->id ? 'edit' : 'add' }}">
  <input type="hidden" name="message_type" value="{{ $patient->id ? 'edit' : 'add' }}">
  <input type="hidden" name="patient_id" class="ref_patient_id" value="{{$patient->id}}" data-id="{{\Crypt::encrypt($patient->id)}}">
 <div class="safety-box"> 
    <div class="headingpage">Patient Profile</div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-5">
        <div class="row">
          <div class="col-md-6">
            <div class="textfieldglobal">
              <label class="labelfieldsname" >{{ trans('label.first_name') }}*</label>
              {!! Form::text('first_name',null,array('maxlength' => 20)) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
          <div class="col-md-6">
            <div class="textfieldglobal">
              <label class="labelfieldsname" >{{trans('label.middle_initial')}}</label>
              {!! Form::text('middle_initial',null,array('maxlength' => 1)) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
        </div>
        <div class="textfieldglobal">
          <label class="labelfieldsname">{{trans('label.last_name')}}*</label>
          {!! Form::text('last_name',null,array('maxlength' => 40)) !!}
          <span class="error" style="color:red"></span>
        </div>
        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.patient_alias')}}</label>
          {!! Form::text('patient_alias',null,array('maxlength' => 50)) !!}
          <span class="error" style="color:red"></span>
        </div>
        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{ trans('label.gender') }}</label>         
          {!! Form::select('gender', array('' => 'Please select') + $gender_array,null,array("class" => "customselect")) !!}
          <span class="error" style="color:red"></span>
        </div>

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{ trans('label.patient_dob') }}*</label>
          {!! Form::text('dob',null,['class' => 'datePicker_dob','placeholder' => trans('label.dob_place_holder')]) !!}
          <span class="error" style="color:red"></span>
        </div>

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.patient_email')}}</label>
          {!! Form::text('email',null,array('maxlength' => 45)) !!}
          <span class="error" style="color:red"></span>
        </div>
        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.phone')}}*</label>
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-md-2">
              {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center','disabled'=>true]) !!} 
            </div>
            <div class="col-md-10">
              {!! Form::text('phone',null,['class' => 'set_phone_format']) !!}
              <span class="error" style="color:red"></span>
           </div>
          </div>
          <span class="error" style="color:red"></span>
        </div>


      </div>
      <div class="col-md-5">

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{ trans('label.patient_ssn') }}*</label>
          {!! Form::text('ssn',null,['class'=>'ssn_format']) !!}
          <span class="error" style="color:red"></span>
        </div>
        <div class="textfieldglobal addfieldselect">
          <label class="labelfieldsname" >{{ trans('label.referral_source') }}*</label>
          {!! Form::select('referral_source', $referral_sources, null, ['class' => 'referral_source_drop_down customselect']) !!}
          <span class="error" style="color:red"></span>
          <div class="addreferalplus"><a href="#" data-toggle="modal" data-target="#addreferral_source"><i data-toggle="tooltip" data-placement="top" title="{{trans('label.referral_source')}}" class="fas fa-plus"></i></a></div>
        </div>


        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{ trans('label.preferred_language') }}*</label>
          {!! Form::select('language', $languages, null, ['class' => 'customselect']) !!}
          <span class="error" style="color:red"></span>
        </div>

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{ trans('label.address_line_1') }}*</label>
           {!! Form::text('address_line1',null,['maxlength'=>'100']) !!}
          <span class="error" style="color:red"></span>
        </div>


        <div class="textfieldglobal">
                <label class="labelfieldsname" >{{ trans('label.address_line_2') }}</label>
                 {!! Form::text('address_line2',null,['maxlength'=>'100']) !!}
                <span class="error" style="color:red"></span>
        </div>
        <div class="textfieldglobal">
                <label class="labelfieldsname" >{{ trans('label.city') }}*</label>
                 {!! Form::text('city',null,['maxlength'=>'50']) !!}
                <span class="error" style="color:red"></span>
        </div> 

        <div class="textfieldglobal">
           <div class="row">
              <div class="col-md-6">
                <div class="textfieldglobal">
                <label class="labelfieldsname" >{{ trans('label.state') }}*</label>
               {!! Form::select('state_id', $states,null,['class' => 'customselect']); !!}    
                <span class="error" style="color:red"></span>
                </div>
              </div>
              <div class="col-md-6">
                <div class="textfieldglobal">
                <label class="labelfieldsname" >{{ trans('label.zip_code') }}*</label>
                 {!! Form::text('zip_code',null,['maxlength'=>'5']) !!}
                <span class="error" style="color:red"></span>
                </div>
              </div>
            </div>
        </div>
      </div>
  	  <div class="col-sm-2">
  	   <div class="browsebutton">
  <!--		<label>Upload Patient’s Picture</label>-->
  		
  		<div class="clearfix"></div>
  		<div class="patient_pro_pic_preview">
  		  <img id="previewHolder" src="@if($patient->image) {{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }} @else {{ asset('images/noimage.jpg') }} @endif" alt="" width="150">
  		  <span class="imgcross" <?php if(!$patient->image) echo 'style="display:none;"'; ?>>X</span>
    		<div class="browsebuttontext patient-info-pro-pic-upload" <?php if($patient->image) echo 'style="display:none;"'; ?>> {{ trans('label.upload_picture') }}
    		  {!! Form::file('image', ['accept'=>'image/x-png,image/gif,image/jpeg'])  !!}
    		  {!! Form::hidden('upload_image_or_not', 'no')  !!}
    		 
    		</div>
         <span class="error" id='invalid_image_error' style="color:red"></span>
  		</div>
  		   
  	  </div>
  	  </div>
  </div>
</div>

  <div class="clearfix"></div>
  <div class="personliving check-body">
    <div class="safety-box">
    <div class="headingpage">{{trans('label.patient_living_situation')}}</div>
    <span class="smalltextunderheading checklabel">{{trans('label.check_only_one_which_is_applicable')}}</span>
    <div class="clearfix"></div>
    <div class="row">
        <span class="error" id="lives_with_error" style="color:red"></span>
        @foreach($lives_with as $key=>$live_with)
		   <div class="col-lg-3 col-md-6">
            <div class="checkdiv">
              {!! Form::checkbox('lives_with', $key, ($key == $patient->lives_with ? true : false),['class'=>'customcheck','old-data'=>($key == $patient->lives_with)? 'jcf-checked':'jcf-unchecked']) !!}
              <label>{{ $live_with }}</label>
            </div>
            </div>
        @endforeach
		 <div class="col-lg-3 col-md-6">
        <div class="checkdiv">
          {!! Form::checkbox('living_with_other',null, (($patient->living_with_other) ? true : false),['class'=>'customcheck','old-data'=>($patient->living_with_other)? 'jcf-checked':'jcf-unchecked']) !!}
          <label>Other</label>
        </div>
        <div class="checkdiv is_other textfieldglobal" {!! ((!$patient->living_with_other) ? 'style="display:none;"' : '') !!}>
          {!! Form::text('living_with_other_text',null,array("maxlength" => 100)) !!}
          <span class="error" id="living_with_other_text" style="color:red"></span>
        </div>
      </div>
    </div>
  </div>
  </div>
  <div class="clearfix"></div>
  <div class="personliving">
    <div class="safety-box">
    <div class="headingpage">{{trans('label.family_contact')}}</div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-5">


          <p class="smalltextunderheading margnbootom">{{trans('label.person_1_detail')}}
            <span class="checkdiv">
              {!! Form::checkbox('emergency_person1_checkbox',null, (($patient->emergency_person1_checkbox && !$patient->emergency_person2_checkbox) ? true : false),['class'=>'customcheck emergency_checkbox','old-data'=>($patient->emergency_person1_checkbox && !$patient->emergency_person2_checkbox)? 'jcf-checked':'jcf-unchecked']) !!}
              <label>{{trans('label.emergency_contact')}}</label>
            </span>
    
          </p>



      </div>
      <div class="col-md-5">
        <?php 
          $show_second_person = false;
          if(!empty($patient->emergency_person2_checkbox) || !empty($patient->emergency_person2_name) || !empty($patient->emergency_person2_phone) || !empty($patient->emergency_person2_address) || !empty($patient->emergency_person2_address2) || (!empty($patient->emergency_person2_relation) && $patient->emergency_person2_relation != 'default') || !empty($patient->emergency_person2_state_id) || !empty($patient->emergency_person2_city) || !empty($patient->emergency_person2_zip))
          {
            $show_second_person = true;
          }
        ?>
        <div class="buttonpatient second_emergency_contact_button" style="{{ $show_second_person? "display:none;": "" }}"><a href="javascript:show_second_emergency_contact()"><i class="fas fa-plus"></i> {{trans('label.add_another_emergency_contact')}}</a></div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-5">
        <div class="row">
          <div class="col-md-7">
            <div class="textfieldglobal">
              <label class="labelfieldsname" name="patient_alias">{{trans('label.name')}}</label>
              {!! Form::text('emergency_person1_name',null,array('maxlength' => 60)) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
          <div class="col-md-5">
            <div class="textfieldglobal">
              <label class="labelfieldsname" >{{trans('label.emergency_person1_relation')}}</label>
              {!! Form::select('emergency_person1_relation', array('' => 'Please select') + $relationshipOptions,null,array("class" => "customselect")) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5">

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.emergency_person1_phone')}}</label>
          <div class="clearfix"></div>
          <div class="row">
            <div class="col-2">
              {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center','disabled'=>true]) !!} 
            </div>
            <div class="col-10">
            {!! Form::text('emergency_person1_phone',null,['class' => 'set_phone_format']) !!}
            <span class="error" style="color:red"></span>
           </div>
          </div>
          <span class="error" style="color:red"></span>
        </div>
      </div>
      <div class="col-md-5">

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.address_line_1')}} </label>
          {!! Form::text('emergency_person1_address',null,array('maxlength' => 100)) !!}
          <span class="error" style="color:red"></span>
        </div>
      </div>
      <div class="col-md-5">

        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.address_line_2')}}</label>
          {!! Form::text('emergency_person1_address2',null,array('maxlength' => 100)) !!}
          <span class="error" style="color:red"></span>
        </div>
      </div>

      <div class="col-md-5">
        <div class="textfieldglobal">
          <label class="labelfieldsname" >{{trans('label.city')}}</label>
          {!! Form::text('emergency_person1_city',null,array('maxlength' => 50)) !!}
          <span class="error" style="color:red"></span>
        </div>
      </div>

      <div class="col-md-5">
        <div class="row">
          <div class="col-md-7">
            <div class="textfieldglobal">
              <label class="labelfieldsname" >{{trans('label.state')}}</label>
                {!! Form::select('emergency_person1_state_id',$states,null,array("class" => "customselect")) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
          <div class="col-md-5">
            <div class="textfieldglobal">
              <label class="labelfieldsname" >{{trans('label.zip_code')}}</label>
              {!! Form::text('emergency_person1_zip',null,array('maxlength' => 5)) !!}
              <span class="error" style="color:red"></span>
            </div>
          </div>
      </div>
    </div>
  </div>

  
    <div class="second_emergency_contact_section" style="{{ $show_second_person? "": "display:none;" }}">
      <span class="smalltextunderheading margnbootom">{{trans('label.person_2_detail')}}
      <div class="checkdiv">
            {!! Form::checkbox('emergency_person2_checkbox',null, (($patient->emergency_person2_checkbox && !$patient->emergency_person1_checkbox) ? true : false),['class'=>'customcheck emergency_checkbox','old-data'=>($patient->emergency_person2_checkbox && !$patient->emergency_person1_checkbox)? 'jcf-checked':'jcf-unchecked']) !!}
            <label>{{trans('label.emergency_contact')}}</label>
      </div>

      </span>
      <div class="clearfix"></div>
      <div class="row">




        <div class="col-md-5">
          <div class="row">
            <div class="col-md-7">
              <div class="textfieldglobal">
                <label class="labelfieldsname" name="patient_alias">{{trans('label.name')}}</label>
                {!! Form::text('emergency_person2_name',null,array('maxlength' => 60)) !!}
                <span class="error" style="color:red"></span>
              </div>
            </div>
            <div class="col-md-5">
              <div class="textfieldglobal">
                <label class="labelfieldsname" >{{trans('label.emergency_person2_relation')}}</label>
                {!! Form::select('emergency_person2_relation', array('' => 'Please select') + $relationshipOptions,null,array("class" => "customselect")) !!}
                <span class="error" style="color:red"></span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-5">

          <div class="textfieldglobal">
            <label class="labelfieldsname" >{{trans('label.emergency_person2_phone')}}</label>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-2">
                {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center','disabled'=>true]) !!} 
              </div>
              <div class="col-10">
              {!! Form::text('emergency_person2_phone',null,['class' => 'set_phone_format']) !!}
              <span class="error" style="color:red"></span>
             </div>
            </div>
            <span class="error" style="color:red"></span>
          </div>
        </div>
        <div class="col-md-5">

          <div class="textfieldglobal">
            <label class="labelfieldsname" >{{trans('label.address_line_1')}} </label>
            {!! Form::text('emergency_person2_address',null,array('maxlength' => 100)) !!}
            <span class="error" style="color:red"></span>
          </div>
        </div>
        <div class="col-md-5">

          <div class="textfieldglobal">
            <label class="labelfieldsname" >{{trans('label.address_line_2')}}</label>
            {!! Form::text('emergency_person2_address2',null,array('maxlength' => 100)) !!}
            <span class="error" style="color:red"></span>
          </div>
        </div>

        <div class="col-md-5">
          <div class="textfieldglobal">
            <label class="labelfieldsname" >{{trans('label.city')}}</label>
            {!! Form::text('emergency_person2_city',null,array('maxlength' => 50)) !!}
            <span class="error" style="color:red"></span>
          </div>
        </div>

        <div class="col-md-5">
          <div class="row">
            <div class="col-md-7">
              <div class="textfieldglobal">
                <label class="labelfieldsname" >{{trans('label.state')}}</label>
                  {!! Form::select('emergency_person2_state_id',$states,null,array("class" => "customselect")) !!}
                <span class="error" style="color:red"></span>
              </div>
            </div>
            <div class="col-md-5">
              <div class="textfieldglobal">
                <label class="labelfieldsname" >{{trans('label.zip_code')}}</label>
                {!! Form::text('emergency_person2_zip',null,array('maxlength' => 5)) !!}
                <span class="error" style="color:red"></span>
              </div>
            </div>
        </div>




      </div>
      </div>
  </div>
</div>
</div>
  <div class="buttonsbottom">
    <button type="button" class="next" onClick="javascript:saveform('saveandnext','#patient-info-form','2')">{{trans('label.save_and_next')}}</button>
    <button type="button" class="next" onClick="javascript:saveform('saveandclose','#patient-info-form','2')">{{trans('label.save_and_close')}}</button>
    <a href="#" class="close close_form" >{{ trans('label.cancel') }}</a> 
  </div>

  <!-- Close form here to save only this tab data -->
  {!! Form::close() !!}

</div>
@section('script')
<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
@include('layouts.icd_code_js')
<script type="text/javascript">
$( document ).ready(function() {
  $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
  $(".ssn_format").inputmask("999-99-9999",{showMaskOnFocus : false, showMaskOnHover : false});

  // const monthNames = ["January", "February", "March", "April", "May", "June",
  //   "July", "August", "September", "October", "November", "December"
  // ];

    datePickers();
    addOldVelue();
    insuranceDiv();
    contractPayerValues();
    insuranceDropDown('#insurancePrimary');
    insuranceDropDown('#insuranceSecondary');
    pcpDropDown('#pcp_information');

    $(document).on('show.bs.modal', '.adddocumentdocuments' ,function(){
      $('span.error').hide().removeClass('active');
      /*var currentdate = new Date(); 
      var current_date = monthNames[currentdate.getMonth()] + " "
                + currentdate.getDate() + ", " 
                + currentdate.getFullYear();
      $('.current_date').html(current_date);*/
    });

    //for patient info tab
   /* $('input[type=checkbox][name=living_with_other]').change(function() {
      if(this.checked) {
        $('input[type=checkbox][name="lives_with"]').attr("checked", false);
        $('input[type=checkbox][name="lives_with"]').parent('.jcf-checkbox').removeClass('jcf-checked');
        $(this).attr("checked", true);
        $('.is_other').show();
      }else{
        if($('.is_other').find('input').attr("old_value") == $('.is_other').find('input').val()){
            $('.is_other').find('input').removeClass('changed-input');
            console.log('here');
          }
          else if($('.is_other').find('input').attr("old_value") == ''){
              $('.is_other').find('input').removeClass('changed-input');
          }
          $('.is_other').find('span.error').hide().removeClass('active');
          $('.is_other').hide();
      }
    });*/ 

    //to show cross icon on search something
  $('input[type=checkbox][name=living_with_other]').change(function() {
    
    if(this.checked) {
      $('input[type=checkbox][name="lives_with"]').prop("checked", false);
      $('input[type=checkbox][name="lives_with"]').parent('.jcf-checkbox').removeClass('jcf-checked');
      $('input[type=checkbox][name="lives_with"]').parent('.jcf-checkbox').addClass('jcf-unchecked');
      $(this).attr("checked", true);
      $('.is_other').show();
    }else{
      if($('.is_other').find('input').attr("old_value") == $('.is_other').find('input').val()){
          $('.is_other').find('input').removeClass('changed-input');
          console.log('here');
        }
        else if($('.is_other').find('input').attr("old_value") == ''){
            $('.is_other').find('input').removeClass('changed-input');
        }
        $('.is_other').find('span.error').hide().removeClass('active');
        $('.is_other').hide();
    }
  }); 

    //for patient living

    //for patient living
  $('input[type=checkbox][name="lives_with"]').change(function() {

      $('input[type=checkbox][name="lives_with"]').not(this).prop('checked', false);

     // $('input[type=checkbox][name="lives_with"]').attr("checked", false);
      $('input[name=living_with_other]').prop("checked", false);
      $('.is_other').find('input').removeClass('changed-input');
      $('.is_other').hide(); //uncheck all checkboxes
      $('input[type=checkbox][name="lives_with"],input[name=living_with_other]').parent('.jcf-checkbox').removeClass('jcf-checked');
       $('input[type=checkbox][name="lives_with"],input[name=living_with_other]').parent('.jcf-checkbox').addClass('jcf-unchecked');
       $('input[type=checkbox][name="lives_with"]').each(function(){
          if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
             $(this).removeClass('changed-input');
          }
          else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
           $(this).removeClass('changed-input');
          }
          else {
           $(this).addClass('changed-input');
          } 
       });

       $(this).attr("checked", true);  //check the clicked one

    }); 
    /*
    $('input[type=checkbox][name="lives_with"]').change(function() {


      $('input[type=checkbox][name="lives_with"]').attr("checked", false);
      $('input[name=living_with_other]').attr("checked", false);
      $('.is_other').find('input').removeClass('changed-input');
      $('.is_other').hide(); //uncheck all checkboxes
      $('input[type=checkbox][name="lives_with"],input[name=living_with_other]').parent('.jcf-checkbox').removeClass('jcf-checked');

       $('input[type=checkbox][name="lives_with"]').each(function(){
          if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
             $(this).removeClass('changed-input');
          }
          else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
           $(this).removeClass('changed-input');
          }
          else {
           $(this).addClass('changed-input');
          } 
       });

       $(this).attr("checked", true);  //check the clicked one
    }); */


    //for healthcare tab
    $('body').on('change','input[type=checkbox][name=patient_concern_other]',function() {
      if(this.checked) {
        $('.patient_concern_is_other').show();
      }else{
        $('.patient_concern_is_other').hide();
        $('.patient_concern_is_other').find('input').removeClass('changed-input');
      }
    });
}); 
  
function datePickers(){

  $('.datePicker').datepicker({
    autoclose: true,
    format: 'mm-dd-yyyy',
    endDate: '-0d',
  });
  $('.datePicker_dob').datepicker({
    autoclose: true,
    format: 'mm-dd-yyyy',
    endDate: '-10y',
    startDate: '-100y',
  });
  
  $('.effective_datePickerInsurance').datepicker({
    autoclose: true,
    format: 'mm-dd-yyyy',
    endDate: '-0d'
  });

  $('.expiry_datePickerInsurance').datepicker({
    autoclose: true,
    format: 'mm-dd-yyyy',
    startDate: '+0d'
  });
 $('input,textarea,select').removeClass('changed-input');
}


function saveform(button_pressed,formId,tab){
  
  $('.model_box_save').attr("disabled", "disabled");
  $('span.error').hide().removeClass('active');

  //unmask value of phone number fields
  $(".set_phone_format").inputmask('remove');
  
  var formData = new FormData($(formId)[0]);
  if(button_pressed == 'movetopre'){
    formData.append( 'case_status',1);
  }
  if(button_pressed == 'movetoreg'){
    formData.append( 'reg_status',1);
  }

  $.ajax({
    url:"{{ route('patient-add') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      
      $('.model_box_save').removeAttr("disabled");
      $('input,textarea,select').removeClass('changed-input');
      if(button_pressed == 'saveandclose' || button_pressed == 'movetopre' || button_pressed == 'movetoreg')
      {
        window.location.href="{{ route('patients',['page'=>$page_no]) }}";
      }
      else if(button_pressed == 'saveandnext')
      {
        //enable phone masking again 
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

        $('input[type=hidden][name=action]').val('edit');
        $('input[type=hidden][name=patient_id]').val(data.patient_id);
        $('input[type=hidden][name=patient_id]').attr('data-id',data.encrypted_patient_id);
        $.ajax({  
            url:"{{ route('patient-tab') }}",
            type: "GET",
            dataType: "html",
            data: {tab:tab,id:data.patient_id},
            success:function(data){
              if(tab == '2'){
                
                //activate 2nd and 4,5th tab
                $('#concern-tab').attr('data-toggle','tab')
                $('#document-tab').attr('data-toggle','tab')
                $('#note-tab').attr('data-toggle','tab')

                //
                var success = $.parseJSON(data);

                $('#concern').html(success.html.patient_healthcare_tab);
                $('#document').html(success.html.patient_documents_tab);
                $('#notes').html(success.html.patient_notes_tab);
                 pcpDropDown('#pcp_information');
                $(".Icd_class").chosen({ width:'100%' });
                icdCodeDynamic();
                applpyEllipses('common-note-table', 5, 'no');
                applpyEllipses('common-document-table', 5, 'no');
              }
              if(tab == '3'){
                $(".Icd_class").prop("disabled", true);
                $(".Icd_class").last().prop("disabled", false);
                $('#otherinfo-tab').attr('data-toggle','tab')
                $('#otherinfo').html(data);
                
                insuranceDropDown('#insurancePrimary');
                insuranceDropDown('#insuranceSecondary');
                contractPayerValues();
              }

              datePickers();    
              addOldVelue();
              insuranceDiv();
              initCustomForms();
              $('.nav-tabs a.active').parent().next('li').find('a').trigger('click');

              //scroll top
              jQuery('html, body').animate({
                  scrollTop: jQuery('body').offset().top
              }, 500);

           }
        });
        //move to next available tab
        
      }
      else if(button_pressed == 'savenotes')
      {
        //enable phone masking again 
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

        var url = window.location.href;
        $.ajax({
            url:url,
            type:"GET",
            data: {id:data.patient_id,tab_name:'notes'},
            dataType: "html",
            success:function(data){
              $('#adddocumentnotes').modal('hide');
              $("#notes_table").html(data);
              $('#patient-notes-form').find('textarea[name=notes_subject],input[name=notes_area]').val("");
            },
            error:function(data){
               $('#adddocumentnotes').modal('hide');
              $("#notes_table").html(data);
            }
        });      
      }
      else if(button_pressed == 'savedocument')
      {
        //enable phone masking again 
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

        var url = window.location.href;
        $.ajax({
            url:url,
            type:"GET",
            data: {id:data.patient_id,tab_name:'documents'},
            dataType: "html",
            success:function(data){
              $('#add_document').modal('hide');
              $("#documents_table").html(data);
              $('#patient-document-form').find('select[name=category_id],input[type=file],input[name=document_name]').val(""
                );
              $("#selected_doc_name").html('No file selected');
              $("#delete_selected_doc").hide();
            },
            error:function(data){
               $('#add_document').modal('hide');
              $("#documents_table").html(data);
            }
        });      
      }

      setTimeout(function(){
        $(document).find('input[type=hidden][name=message_type]').val(data.message_type);
      }, 2000);
    },
    error:function(error){
        $('.model_box_save').removeAttr("disabled");
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        $.each(error.responseJSON.errors,function(key,value){
            console.log(key.indexOf("patient_concern"));
            if(key == 'patient_concern')
                $('#patient_concern_error').html(value).addClass('active').show();
            else if(key == 'lives_with')
                $('#lives_with_error').html(value).addClass('active').show();
            else if(key == 'is_insured')
                $('#is_insured_error').html(value).addClass('active').show();   
            else if(key == 'contract_payer')
                $('#contract_payer_error').html(value).addClass('active').show(); 
            else if(key == 'notes_subject')
                $('#notes_subject_error').html(value).addClass('active').show();            
            else if(key == 'uploaded_document')
                $('.upload_document_error').html(value).addClass('active').show();                  
            else if(!key.indexOf("insurances"))
            {
              if (key.indexOf('0') > -1)
              {
                key = key.replace(".0", "[0]");
                key = key.replace(".", "[");
                key += ']';
              }
              else
              {
                key = key.replace(".1", "[1]");
                key = key.replace(".", "[");
                key += ']';
              }
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            }
            // need to add this if manageable field is need to be deleted from admin
            /*else if(!key.indexOf("patient_concern"))
            {
              $('#patient_concern_error').html('Patient concern is invalid.').addClass('active').show();
            }*/
            else if(!key.indexOf("icdCode"))
            {
              $(".after-add-more").last().find('span.error').html(value).addClass('active').show();
            }
            else if(!key.indexOf("icd_code"))
            {
              $('#icd_code').html('Selected medical diagnosis is not valid, please choose different one.').addClass('active').show();
            //  $(".after-add-more").last().find('span.error').html(value).addClass('active').show();
            }
            else if(key == 'image')
            {
              $('#invalid_image_error').html(value).addClass('active').show();
            }
            else
            {
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
           }
        }); 
        
        if($('#Insurance_div span.error.active').length){
          if(!$('#Insurance_div span.error.active:first').closest('.tab-pane').hasClass('active'))
          {
             $('.insure-tabs .nav-pills').find('a').removeClass('active');
             $('.insure-tabs #v-pills-tabContent .tab-pane').removeClass('show active');

             var nav_link_active = $('#Insurance_div span.error.active:first').closest('.tab-pane').attr('aria-labelledby');
             
             $('#Insurance_div .nav-pills').find('a[id='+nav_link_active+']').addClass('active')
             $('#Insurance_div span.error.active:first').closest('.tab-pane').addClass('show active')
          }

          jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
          }, 500);

        }else{
          jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
          }, 500);
        }     
    }
  });
}


function saveReferralSource(formId){

  //unmask value of phone number fields
  $(".set_phone_format").inputmask('remove');
  $('.model_box_save').attr("disabled", "disabled");
  var formData = new FormData($(formId)[0]);
  $.ajax({
    url:"{{ route('referral-source-add') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('.model_box_save').removeAttr("disabled");
      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
     // $(".referral_source_drop_down").append(data.option);
      $(".referral_source_drop_down option:first").after(data.option);
      $('#addreferral_source').modal('hide');
      $('#addreferral_source').find('form').trigger('reset');
    },
    error:function(error){
      $('.model_box_save').removeAttr("disabled");
      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        $.each(error.responseJSON.errors,function(key,value){
            if(key == 'patient_concern')
                $('#patient_concern_error').html(value).addClass('active').show();              
            else
            {
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
           }
        });

        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);
            
    }
  });
}

// function for save Pcp Info
function savePcpInfo(formId){

  //unmask value of phone number fields
  $(".set_phone_format").inputmask('remove');
  $('.model_box_save').attr("disabled", "disabled");
  var formData = new FormData($(formId)[0]);
  $.ajax({
    url:"{{ route('pcp-information-add') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('.model_box_save').removeAttr("disabled");
      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
      $(".pcp_informations option:first").after(data.option);
      //$(".pcp_informations").append(data.option);
      $('#add_pcp_info').modal('hide');
      $('#add_pcp_info').find('form').trigger('reset');
    },
    error:function(error){
      $('.model_box_save').removeAttr("disabled");
      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        $.each(error.responseJSON.errors,function(key,value){
            if(key == 'patient_concern')
                $('#patient_concern_error').html(value).addClass('active').show();     
            else
            {
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
           }
        });

        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);
            
    }
  });
}
//common call to view detail of the patient
/*
$('.wrapper').on('click', '.viewDetail', function(e) {
   e.preventDefault();
   var patientId=$(".ref_patient_id").val();
    $.ajax({
    url:"{{ route('patient-view') }}",
    type: "GET",
    data: {id:patientId},
    dataType: "html",
    success:function(data){
       $('#patientinfopop').html(data); 
       $('#patientinfopop').modal('show');
    }
  });
});
*/

//for insurance tab 

function contractPayerValues(){
  $('span.error').hide().removeClass('active');
  if($('#contract_payer_section option:selected').val() != ''){
    
    if($('#contract_payer_section').parent().parent().parent().find('.readonly_field:first').is(":hidden")){
      $('#contract_payer_section').parent().parent().parent().find('.readonly_field span.error').hide().removeClass('active');
    }
    
    $('#contract_payer_section').parent().parent().parent().find('.readonly_field').show();
    $.each($('#contract_payer_section option:selected').data(), function(i, v) {
        $('#contract_payer_section').parent().parent().parent().find('.'+i).val(v);
    });
  }else{
    $('#contract_payer_section').parent().parent().parent().find('.readonly_field').hide();
    $('#contract_payer_section').parent().parent().parent().find('input:not([type=hidden],[name=authorization_code]),select').val('');
  }
}

//for insurance tab 
$(document).on('change', 'input[name=is_insured]', function(e) {
  insuranceDiv();
});

//for insurance tab 
$('.wrapper').on('change', '#contract_payer_section', function(e) {
  contractPayerValues();
});

$('.wrapper').on('change', '.insurances', function(e) {
  insuranceDropDown('#'+$(this).attr('id'));
});

$('.wrapper').on('change', '.pcp_informations', function(e) {
  pcpDropDown('#'+$(this).attr('id'));
});

function insuranceDropDown(insurancesId) {
  if(insurancesId == '#insurancePrimary' && $(insurancesId).val())
    $("#insuranceSecondary option[value=" + $(insurancesId).val() + "]").attr('disabled','disabled')
        .siblings().removeAttr('disabled');
  if(insurancesId == '#insuranceSecondary' && $(insurancesId).val())
    $("#insurancePrimary option[value=" + $(insurancesId).val() + "]").attr('disabled','disabled')
        .siblings().removeAttr('disabled');
  if($(insurancesId+' option:selected').val() != ''){

    if($(insurancesId).parent().parent().parent().find('.readonly_field:first').is(":hidden")){
      $(insurancesId).parent().parent().parent().find('.readonly_field span.error').hide().removeClass('active');
    }

    $(insurancesId).parent().parent().parent().find('.readonly_field').show();
    $.each($(insurancesId+' option:selected').data(), function(i, v) {
        $(insurancesId).parent().parent().parent().find('.'+i).val(v);
    });
    $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
  }else{
    $(insurancesId).parent().parent().parent().find('.readonly_field').hide();
    $(insurancesId).parent().parent().parent().find('input:not([type=hidden],.do_not_empty),select').val('');
  }
}

function pcpDropDown(pcpClass) {
  if($(pcpClass).find('option:selected').val() != ''){
    $(pcpClass).parent().parent().parent().find('.readonly_field').show();
    $(pcpClass).parent().parent().find('.pcp_address_line_1').val($(pcpClass).find('option:selected').data('address_line1'));
    $(pcpClass).parent().parent().find('.pcp_address_line2').val($(pcpClass).find('option:selected').data('address_line2'));
    $(pcpClass).parent().parent().find('.pcp_city').val($(pcpClass).find('option:selected').data('city'));
    $(pcpClass).parent().parent().find('.pcp_phone').val($(pcpClass).find('option:selected').data('phone'));
    $(pcpClass).parent().parent().find('.pcp_contact_number').val($(pcpClass).find('option:selected').data('contact_phone'));
    $(pcpClass).parent().parent().find('.pcp_speciality').val($(pcpClass).find('option:selected').data('speciality'));
    $(pcpClass).parent().parent().find('.pcp_org_name').val($(pcpClass).find('option:selected').data('org_name'));
     $(pcpClass).parent().parent().find('.pcp_state_name').val($(pcpClass).find('option:selected').data('state_name'));
     $(pcpClass).parent().parent().find('.pcp_zip_code').val($(pcpClass).find('option:selected').data('zip_code'));
     $(pcpClass).parent().parent().next().find('.pcp_email').val($(pcpClass).find('option:selected').data('email'));
     $(pcpClass).parent().parent().next().find('.pcp_fax').val($(pcpClass).find('option:selected').data('fax'));
    $(pcpClass).parent().parent().next().find('.pcp_web_address').val($(pcpClass).find('option:selected').data('web_address'));
    $(pcpClass).parent().parent().next().find('.pcp_contact_name').val($(pcpClass).find('option:selected').data('contact_name'));
    $(pcpClass).parent().parent().next().find('.pcp_contact_email').val($(pcpClass).find('option:selected').data('contact_email'));
    $(pcpClass).parent().parent().next().find('.pcp_contact_title').val($(pcpClass).find('option:selected').data('contact_title'));
    $(pcpClass).parent().parent().next().find('.pcp_contact_phone').val($(pcpClass).find('option:selected').data('contact_phone'));
     $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
    initCustomForms();
  }else{
    $(pcpClass).parent().parent().parent().find('.readonly_field').hide();
  }
}
/*
$('body').on('click', '.pagination a', function(e) {
  e.preventDefault();
  var url = window.location.href+'?page='+ $(this).text();
  var tab_name = $(this).closest(".document_notes_tabs").data('tab-name');
  var patient_id = $('.ref_patient_id').val();
  $.ajax({
    url:url,
    type:"GET",
    data:{tab_name:tab_name,id:patient_id},
    dataType: "html",
    success:function(data){
      if(tab_name == 'documents')
        $("#documents_table").html(data);
      else
        $("#notes_table").html(data);
    },
    error:function(data){
      $("#notes_table").html(data);
    }
  });
});
*/

// for all keyup,keydown, change for every input field

$('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
          $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
          $(this).removeClass('changed-input');
        }
        else {
          $(this).addClass('changed-input');
        }     
    }
    else {
        if($(this).hasClass('chosen-search-input')){

        }
        else{
          $(this).addClass('changed-input');
        }  
    }
// for radio button changes alert
   /* if($(this).attr('type') == 'radio'){
            if($(this).attr("old-data") == $(this).val()){
                $('input[name=gender]').removeClass('changed-input');
            }else{
              $(this).addClass('changed-input');
            }
    }*/
    
});


// for cancel button on every form
$('body').on('click', '.close_form', function(e) {
    e.preventDefault();
    closeForm();
});



$('body').on('click', '.reject_patient', function(e) {
        e.preventDefault();
        $('input,textarea,select').removeClass('changed-input');
        bootbox.confirm({ 
        message: "Are you sure, you want to reject this patient?", 
        callback: function(result){  
          if (result) {
            changePatientStatus(3);
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
        
});

function closeForm(){
  if ($('.changed-input').length){
      bootbox.confirm({ 
        message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
        callback: function(result){  
          if (result) {
            $('input,textarea,select').removeClass('changed-input');
            window.location.href="{{ route('patients',['page'=>$page_no]) }}";
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
  }
  else {
    window.location.href="{{ route('patients',['page'=>$page_no]) }}";

  }
}

function changePatientStatus(status){
  var patient_id = $('.ref_patient_id').val();
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $.ajax({
        url:"{{ route('patient-status') }}",
        type: 'POST',
        data: {_token: CSRF_TOKEN, patient_id:patient_id,status:status},
        dataType: 'JSON',
        success: function (data) { 
       if(data.status == 1){
         window.location.href="{{ route('patients',['page'=>$page_no]) }}";
       }
       else {
         
       }
    },
    error:function(data){
        if(data.status == 500){
          window.location.href="{{ route('patients',['page'=>$page_no]) }}"; 
        }
    }
    }); 
           
}

// for modal box close event
$(document).on('hidden.bs.modal', '.adddocumentdocuments',function () {
    $('input,textarea,select').removeClass('changed-input');
    $('.adddocumentdocuments').find('form').trigger('reset');
    $('#patient-document-form').find('select[name=category_id],input[type=file],input[name=document_name]').val("");
    $('#patient-notes-form').find('input[name=document_name],input[name=notes_area],textarea').val("");
    $("#selected_doc_name").html('No file selected');
    $("#delete_selected_doc").hide();
    $('span.error').hide().removeClass('active');
})
// for click on side bar or logout button
$(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
  if ($('.changed-input').length){
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }
});



$(document).on('change', "input[type=file][name=image]", function() {
  $('.browsebutton').find('span.error').hide().removeClass('active');
  readURL(this);
  $('.patient_pro_pic_preview span.imgcross').show();
  $('input[type=hidden][name=upload_image_or_not]').val('yes');
  $('.patient-info-pro-pic-upload').hide();
});

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#previewHolder').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

function addOldVelue(){
    $("input,textarea,select").each(function(){
        $(this).attr('old_value',$(this).val());
    })
  }
function insuranceDiv(){
  //for insurance tab 
  if ($('.is_insured').is(':checked')){
    $('.insurance_optional_section').addClass('disabled-nav-link');
    $('.insurance_optional_section').find('input').removeClass('changed-input');
    $('.insurance_optional_section').find('select').removeClass('changed-input');
    
    $('.insure-tabs .nav-pills').find('a').removeClass('active');
    $('.insure-tabs #v-pills-tabContent .tab-pane').removeClass('show active');
    

    $('#v-pills-messages').addClass('show active');
    $('#v-pills-messages-tab').addClass('active');
  }
  else
  {
    $('.insurance_optional_section').removeClass('disabled-nav-link');
  }
}

//patient profile image remove on cross click code
$(document).on('click','.patient_pro_pic_preview span.imgcross',function(){
  $('input[type=hidden][name=upload_image_or_not]').val('yes');
  $('input[type=file][name=image]').val('');
  $('.patient_pro_pic_preview img').attr('src',"{{ asset('images/noimage.jpg') }}");
  $('.patient_pro_pic_preview span.imgcross').hide();
  $('.patient-info-pro-pic-upload').show();
  $('#invalid_image_error').html('').removeClass('active');
});

$(document).on('click','.emergency_checkbox',function(){
  $(".emergency_checkbox").attr("checked", false); //uncheck all checkboxes
  $(".emergency_checkbox").parent('.jcf-checkbox').removeClass('jcf-checked');

   $(".emergency_checkbox").each(function(){
         console.log($(this));
          console.log($(this).is(":checked"))
          if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
             $(this).removeClass('changed-input');
          }
          else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
           $(this).removeClass('changed-input');
          }
          else {
           $(this).addClass('changed-input');
          } 
   });

  $(this).attr("checked", true);  //check the clicked one
});

$('#myTab2 li a.nav-link').on('click',function(e){
  if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
    $('#myTab li a.nav-link').removeClass('active');
  }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
    e.preventDefault();
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }else{
    e.preventDefault();
  }
});

$('#myTab li a.nav-link').on('click',function(e){
    if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
      $('#myTab2 li a.nav-link').removeClass('active');
    }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
    e.preventDefault();
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }else{
    e.preventDefault();
  }
});

// for tab changes
function show_second_emergency_contact(){
  $('.second_emergency_contact_section').show();
  $('.second_emergency_contact_button').hide();
}


// icd code dynamic options
$(document).ready(function(){
  icdCodeDynamic();
});



</script>
@endsection
