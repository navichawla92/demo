 <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-his" onClick="hideAllergySidebar()"><i class="fa fa-angle-left"></i> {{ trans('label.back') }}</a> {{ trans('label.allergy_history') }}</h4>
      </div>

      <div class="slide-body history-body">
          @if(!$allergy['history']->total())
              <div class="slide-section sub-part custom-single-detail">
                  <img src="{{ asset('images/no-data.png') }}" class="img img-fluid no-data">
              </div>
          @endif

          @foreach($allergy['history'] as $history)
              <div class="slide-section">

                  @php
                      $formData = $history->form_data;
                      $messageBy = str_replace("re","",@$formData['message']);
                  @endphp

                  <h4>Allergy {{ @$messageBy }} by: {{ @$formData['type_name'] }}
                      <span>{{ tzDate($history->created_at)->format('m-d-Y H:i:s') }}</span>
                  </h4>
                  
                  <div class="detail-view">
                      <div class="table-responsive care-table">
                          <table class="table">
                              <thead>
                              <tr>
                                  <th>{{ trans('label.allergy_name') }}</th>
                                  <th>{{ trans('label.start') }}</th>
                                  <th>{{ trans('label.end') }}</th>
                                  <th>{{ trans('label.type_of_reaction') }} </th>
                                  <th>{{ trans('label.severity') }} </th>
                              </tr>
                              </thead>
                              <tbody>
                              <tr>
                                  <td>{{ $formData['name'] }}</td>
                                  <td>{{ create_date_format($formData['start_date'],'Y-m-d') }}</td>
                                  <td>{{ $formData['end_date'] ? create_date_format($formData['end_date'],'Y-m-d'): '-' }}</td>
                                  <td>{{ $formData['type'] }}</td>
                                  <td>{{ $formData['severity'] }}</td>
                              </tr>
                              </tbody>
                          </table>
                      </div>
                      <div class="notebox">
                          <label>{{ trans('label.notes') }}</label>
                          <p>
                              @if( @in_array($formData['message'], ['restarted', 'discontinued']) )
                                  {{ $formData['reason'] }}
                              @else
                                  {{ $formData['comment'] }}
                              @endif
                          </p>
                      </div>
                  </div>
              </div>
          @endforeach

          <div class="allergy_history_pagination">
              {{ $allergy['history']->appends('id', encrypt_decrypt('encrypt', $allergy['detail']->id))->links() }}
          </div>
      </div>
</div>
