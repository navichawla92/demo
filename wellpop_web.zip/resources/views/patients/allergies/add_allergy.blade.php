<!-- add allergy -->
<div class="modal fade md_assessment_data" id="addAllergyModal" tabindex="-1" role="dialog" aria-labelledby="addAllergyModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         {!! Form::open(['id' => 'add_allergy_form']) !!}
            {!! Form::hidden('patient_id', encrypt_decrypt('encrypt',$patient->id))  !!}
            {!! Form::hidden('action', 'add')  !!}
            {!! Form::hidden('allergy_id', null)  !!}
         <div class="modal-header">
            <div class="headingpage"> {{ trans('label.add_allergy') }} </div>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.allergy_name') }}* </label>
                     <?php
                        $listOfValues = ['' => 'Please select', 'allergy_1' => 'Allergy 1', 'allergy_2' => 'Allergy 2'];
                     ?>
                     {!! Form::select('name', $listOfValues, null, array("class" => "customselect")) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>               
               <div class="col-md-6">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.type_of_reaction') }}*</label>
                     <?php
                        $listOfValues = ['' => 'Please select', 'reaction_1' => 'Reaction 1', 'reaction_2' => 'Reaction 2'];
                     ?>
                     {!! Form::select('type', $listOfValues, null, array("class" => "customselect")) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.start_date') }}* </label>
                     {!! Form::text('start_date',null,['class' => 'allergy_start_date form-control','placeholder' => trans('label.start_date_place_holder')]) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>               
               <div class="col-md-6">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.end_date') }}</label>
                     {!! Form::text('end_date',null,['class' => 'allergy_end_date form-control','placeholder' => trans('label.start_date_place_holder')]) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.allergy_type') }}*</label>
                     <?php
                        $listOfValues = ['' => 'Please select', '1' => 'Medicine', '0' => 'Others'];
                     ?>
                     {!! Form::select('allergy_type', $listOfValues, null, array("class" => "customselect")) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="row check-body radio-check">
                     <div class="col-xl-3 col-md-4">
                        <p class="file-p"> {{ trans('label.severity') }} </p>
                     </div>
                     <div class="col-xl-9 col-md-6">
                        <div class="checkdiv">
                           {!! Form::radio('severity', 'mild', false, ['class' => 'customradio']) !!}
                           <label>Mild</label>
                           {!! Form::radio('severity', 'severe', false, ['class' => 'customradio']) !!}
                           <label>Severe</label>

                        </div>
                         <span class="error" style="color:red"></span>
                     </div>
                  </div>
               </div>
               <div class="col-sm-12">
                  <div class="form-group">
                     <label class="labelfieldsname"> {{ trans('label.allergy_comment') }}*</label>
                     {!! Form::textarea('comment',null,array('class' => 'form-control', 'rows' => 2, 'cols' => 40)) !!}
                      <span class="error" style="color:red"></span>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <div class="buttonsbottom"> 
                <button type="button" class="next model_box_save" onClick="javascript:saveAllergy()"> {{trans('label.save')}} </button>
               <a href="#" class="close" data-dismiss="modal">{{ trans('label.cancel') }}</a> 
            </div>
         </div>
         {!! Form::close() !!}
      </div>
   </div>
</div>

@push('scripts')
<script>

   function handleAllergyFromToDate(from, to) {
        $("."+from).datepicker({
            autoclose: true,
            format: "mm-dd-yyyy",
            endDate: '-0d'
        });

        $("."+to).datepicker({
            autoclose: true,
            format: "mm-dd-yyyy",
            startDate: '-0d'
        });

        $("."+from).datepicker().on('changeDate', function (selected) {
//            var startDate = new Date(selected.date.valueOf());

            if(selected.hasOwnProperty('date')) {
             var startDate = new Date(selected.date.valueOf());
              $("."+to).datepicker('setStartDate', startDate);
              $("."+to).datepicker('setEndDate', '-0d'); 
            }
            else{
              $("."+to).datepicker('setStartDate', '-0d');
              $("."+to).datepicker('setEndDate', '-0d');
            }
          // $("."+to).datepicker('setStartDate', startDate);
           // $("."+to).datepicker('setEndDate', '-0d');
        }).on('clearDate', function (selected) {
            $("."+to).datepicker('setStartDate', '-0d');
        });

        $("."+to).datepicker().on('changeDate', function (selected) {
            if(selected.hasOwnProperty('date')) {
                var endDate = new Date(selected.date.valueOf());
                $("."+from).datepicker('setEndDate', endDate);
            }
        }).on('clearDate', function (selected) {
            $("."+from).datepicker('setEndDate', '-0d');
        });
   }
   handleAllergyFromToDate('allergy_start_date','allergy_end_date');

  function saveAllergy()
    {
      var submitURL = "{{ route('registration_md_assessment_allergy_save') }}";

      @if($type == 'case_load')
          var submitURL = caseload_save_or_upload_allergy_route;
      @endif
      var formData = new FormData($('#add_allergy_form')[0]);
      $('.model_box_save').attr("disabled", "disabled");
      $.ajax({
        url:submitURL,
        data:formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success:function(data)
        {
          $('.model_box_save').removeAttr("disabled");
          $('#allergies_listing').html(data.html);
          $('#addAllergyModal').modal('hide');
          $('#allergy_not_required').html('').removeClass('active').hide();
          $('input[name=allergy_not_required]').removeClass('changed-input');
          $('#addAllergyModal').find('input,textarea,select').removeClass('changed-input');
          applpyEllipses('allergies_section', 5, 'no');

           data.status = 'success';
           handleMessages(data, 'allergies_listing', true);
           fadeOutAlertMessages();
        },
        error:function(error){
          $('.model_box_save').removeAttr("disabled");
          $.each(error.responseJSON.errors,function(key,value){          
              $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
              $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
              $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
              if(key == 'severity')
              {
                $('input[name="'+key+'"]').parent().parent().parent().find('span.error').html(value).addClass('active').show();
              }          
          }); 
          @if($type == 'case_load')

          @else
          jQuery('html, body').animate({
              scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
          }, 500); 
          @endif    
        }
      });
    }

    //edit or view existing allergy
$('body').on('click', '.view_or_edit_allergy', function(e) {
  e.preventDefault();

  $('#addAllergyModal .headingpage').text("{{ trans('label.edit_allergy') }}");
  $('#addAllergyModal select[name=name]').val($(this).data('name')).attr("disabled", true);
  $('#addAllergyModal select[name=type]').val($(this).data('type'));
  $('#addAllergyModal select[name=allergy_type]').val($(this).data('allergy_type'));
  $('#addAllergyModal input[name=severity][value='+$(this).data('severity')+']').prop('checked', 'checked');
  // $('#addAllergyModal textarea[name=comment]').val($(this).data('comment'));

  $('#addAllergyModal input[type=hidden][name=action]').val('edit');
  $('#addAllergyModal input[type=hidden][name=allergy_id]').val($(this).data('id'));

  $(".allergy_start_date").datepicker('setDate', $(this).attr('data-start_date')).attr("disabled", true);
  $(".allergy_end_date").datepicker('setDate', $(this).attr('data-end_date')).attr("disabled", true)

   /*if($(this).attr('data-end_date') != '')
            $(".allergy_end_date").attr("disabled", true);
          else
            $(".allergy_end_date").attr("disabled", false);*/
  //$(".allergy_end_date").datepicker('setDate', $(this).attr('data-end_date'));

  initCustomForms();
  $('#addAllergyModal').modal({backdrop: 'static', keyboard: false});
});  

//add new allergy so clear modal values if any
$('body').on('click', '#add_new_allergy', function(e) {
  e.preventDefault();
    $('#addAllergyModal .headingpage').text("{{ trans('label.add_allergy') }}");
  $('#addAllergyModal select[name=name]').val('').attr("disabled", false);
  $('#addAllergyModal select[name=type]').val('');
  $('#addAllergyModal select[name=allergy_type]').val('');
  $('#addAllergyModal input[name=severity][value=mild]').prop('checked', 'checked');
  $('#addAllergyModal textarea[name=comment]').val('');

  $('#addAllergyModal input[type=hidden][name=action]').val('add');
  $('#addAllergyModal input[type=hidden][name=medication_id]').val('null');

    $('#addAllergyModal input[name=start_date]').val('').attr("disabled", false);
    $('#addAllergyModal input[name=end_date]').val('').attr("disabled", false);
    $(".allergy_start_date").trigger('clearDate');
    $(".allergy_end_date").trigger('clearDate');

  initCustomForms();

  $('#addAllergyModal').modal({backdrop: 'static', keyboard: false});
});
</script>

@endpush