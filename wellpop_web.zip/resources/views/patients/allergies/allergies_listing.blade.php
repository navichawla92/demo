<table class="table">
   <thead>
      <tr>
         <th> {{ trans('label.serial_number_short_form') }} </th>
         <th> {{ trans('label.allergy_name') }} </th>
          @if($type && $type =='case_load')
         <th>{{ trans('label.start_date') }} </th>
         <th>{{ trans('label.end_date') }} </th>
         @endif
         <th> {{ trans('label.type_of_reaction') }} </th>
         <th> {{ trans('label.severity') }} </th>
          @if($type && $type =='case_load')
          <th>{{ trans('label.status') }} </th>
          @endif
         <th>{{ trans('label.action') }} </th>
      </tr>
   </thead>
   <tbody>
      @if(count($previous_allergies))
         <?php  $index=($previous_allergies->perPage() * ($previous_allergies->currentPage()- 1))+1; ?>
         <?php  $i = 0;?>
         @foreach($previous_allergies as $allergy)
            <tr>
            <td>{{$index}}</td>
            <td>{{ $allergy->name }}</td>
            @if($type && $type =='case_load')
            <td>{{ $allergy->start_date ? $allergy->start_date : '-'  }}</td>
            <td>{{ $allergy->end_date ? $allergy->end_date : '-'  }}</td>
            @endif
            <td>{{ $allergy->type }}</td>
            <td>{{ $allergy->severity }}</td>
            @if($type && $type =='case_load')
            <td>{!! $allergy->status_badge !!}</td>
            @endif
            <td>
              @if(!$is_careplan)
               <div class="dropdown more-btn">
                  <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <span>...</span>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                     @if($type && $type =='case_load')
                          @if($allergy->status)
                              <a href="#" data-id="{{ $allergy->id }}" data-name="{{ $allergy->name }}" data-type="{{ $allergy->type }}" data-severity="{{ $allergy->severity }}" data-comment="{{ $allergy->comment }}" data-start_date="{{ $allergy->start_date }}" data-end_date="{{ $allergy->end_date }}" data-allergy_type="{{ $allergy->allergy_type }}" class="dropdown-item view_or_edit_allergy">
                                  <i class="fa fa-sync-alt"></i> {{ trans('label.update') }}
                              </a>
                              <a class="dropdown-item" data-id="{{ encrypt_decrypt('encrypt',$allergy->id) }}"  data-status="{{ $allergy->status }}" onclick="showAllergyDiscontinueModal(this)"><i class="fa fa-recycle"></i> Discontinue</a>
                          @else
                              <a class="dropdown-item" data-id="{{ encrypt_decrypt('encrypt',$allergy->id) }}"  data-status="{{ $allergy->status }}" onclick="showAllergyDiscontinueModal(this)"><i class="fa fa-recycle"></i> Start Allergy</a>

                          @endif
                     <a class="dropdown-item show-history" data-id="{{ encrypt_decrypt('encrypt',$allergy->id) }}" onclick="allergyDetail(this)" ><i class="fa fa-history"></i> View History</a>
                     @else
                     <a href="#" data-id="{{ $allergy->id }}" data-name="{{ $allergy->name }}" data-type="{{ $allergy->type }}" data-severity="{{ $allergy->severity }}" data-comment="{{ $allergy->comment }}" data-start_date="{{ $allergy->start_date }}" data-end_date="{{ $allergy->end_date }}" data-allergy_type="{{ $allergy->allergy_type }}" class="dropdown-item view_or_edit_allergy">
                       <img src="{{ asset('images/edit.png') }}"> {{ trans('label.edit') }}
                     </a>
                     @endif
                  </div>
               </div>  
                @else
                 <a class="dropdown-item show-history" data-id="{{ encrypt_decrypt('encrypt',$allergy->id) }}" onclick="allergyDetail(this)" ><i class="fa fa-history"></i> </a>
                @endif        
            </td>
         </tr>
         <?php  $index++; ?>
         @endforeach
      @else
         <tr><td>{{ trans('label.no_record_found') }}</td></tr>
      @endif
   </tbody>
</table>    
<?php echo $previous_allergies->render(); ?>