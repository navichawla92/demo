<div class="personliving">
               <div class="row">
                  <div class="col-md-6 col-6">
                     <div class="headingpage">Upload necessary notes</div>
                  </div>
                  <div class="col-md-6 col-6">
                     <div class="buttonpatient"><a href="#" data-toggle="modal" data-target="#adddocumentnotes"><i class="fas fa-plus"></i> Add Notes</a></div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="table-responsive care-table">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th>Date</th>
                           <th>Area</th>
                           <th>Subject</th>
                           <th>Added By</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td>1</td>
                           <td>Sep 20 2018</td>
                           <td>Depression</td>
                           <td>lorem ipsum lorem ipsum</td>
                           <td>Smith Kalra</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td>2</td>
                           <td>Sep 20 2018</td>
                           <td>Depression</td>
                           <td>lorem ipsum lorem ipsum</td>
                           <td>Smith Kalra</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td>3</td>
                           <td>Sep 20 2018</td>
                           <td>Depression</td>
                           <td>lorem ipsum lorem ipsum</td>
                           <td>Smith Kalra</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <ul class="pagination" role="navigation">
                  <li class="page-item disabled" aria-disabled="true" aria-label="« Previous"> <span class="page-link" aria-hidden="true">‹</span> </li>
                  <li class="page-item active" aria-current="page"><span class="page-link">1</span></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=2">2</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=3">3</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=4">4</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=5">5</a></li>
                  <li class="page-item"> <a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=2" rel="next" aria-label="Next »">›</a> </li>
               </ul>
            </div>