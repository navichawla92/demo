<div class="patient-detail personliving">
               <div class="row">
                  <div class="col md-5">
                     <div class="headingpage">Patient Functioning</div>
                     <div class="clearfix"></div>
                     <span class="smalltextunderheading checklabel">Check the ones which are applicable</span>
                     <div class="clearfix"></div>
                     <div class="row check-body">
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Independent</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Independent with DME</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Hired caregivers/IHSS</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Family able to assist</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Family unable to assist/No Resources</label>
                           </div>
                        </div>
                        <div class="col-sm-12">
                           <div class="form-group mt-10">
                              <label class="labelfieldsname">Comment</label>
                              <textarea type="text" class="form-control"></textarea>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col md-5">
                     <div class="clearfix"></div>
                     <div class="headingpage">Durable Medical Equipment</div>
                     <span class="smalltextunderheading checklabel">Check the ones which are applicable</span>
                     <div class="clearfix"></div>
                     <div class="row check-body">
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">FWW</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Wheelchair</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname"> Cane</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Bedside Commode</label>
                           </div>
                        </div>
                        <div class="col-xl-6 col-md-12">
                           <div class="checkdiv">
                              <input type="checkbox" class="customcheck">
                              <label class="labelfieldsname">Other</label>
                           </div>
                        </div>
                        <div class="col-sm-12">
                           <div class="form-group mt-10">
                              <label class="labelfieldsname">Comment</label>
                              <textarea type="text" class="form-control"></textarea>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="headingpage">Identifying Issues</div>
               <span class="smalltextunderheading checklabel ">Check the ones which are applicable</span>
               <div class="clearfix"></div>
               <div class="row check-body">
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Age with critical factors</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Homeless/Housing</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname"> Financial</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">New Major Diagnosis</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">No PCP</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Domestic Violence/Abuse</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Change in Functional Status</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Loss and Grief</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Substance Abuse</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">End of Life</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Mental Health</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Complex Placement</label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label class="labelfieldsname">Other</label>
                     </div>
                  </div>
                  <div class="col-sm-10">
                     <div class="form-group mt-10">
                        <label class="labelfieldsname">Comment</label>
                        <textarea type="text" class="form-control"></textarea>
                     </div>
                  </div>
               </div>
               <div class="buttonsbottom">
                  <button  class="next" data-toggle="modal" data-target="#exampleModal">Save & Next</button>
                  <button  class="next" data-toggle="modal" data-target="#exampleModal">Save & Close</button>
                  <a href="#" class="close">Cancel</a> 
               </div>
            </div>