@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{ trans('label.patient_registration') }}  {{ trans('label.notes') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-sm-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.notes') }}
             <span><i class="fas fa-angle-right"></i></span>{{ $patient->registration_number ? $patient->registration_number : "-" }}
             

              
         </div>
      </div>
      <div class="col-sm-6 col-6">
        <div class="buttonpatient"><a class='light_btn' href="javascript:history.back()"><i class="fas fa-arrow-left"></i> Back</a></div>
    </div>
   </div>
   <div class="tab-content">
  @include('patients.common.patient_notes_tab') 
   </div>
</div>
@endsection
@section('common_script')
  @include('patients.common.common_script')
@endsection  
