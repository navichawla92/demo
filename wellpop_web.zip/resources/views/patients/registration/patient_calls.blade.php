@extends('layouts.app')

@section('css')
<link rel="stylesheet" href="{{ asset('css/bootstrap-datepicker3.min.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css">
@endsection

@section('title')
{{trans('label.phone_call_widget')}}
@endsection

@section('content')
<div class="leftsectionpages">
	<div class="row">
		<div class="col-sm-6">
			<div class="headingpage">
				<div class="firstname"> {{trans('label.patient_registration')}}</div>
				<span><i class="fas fa-angle-right"></i></span>{{trans('label.phone_call_widget')}}
			</div>
		</div>
    <div class="col-sm-6 col-6">
        <div class="buttonpatient"><a class='light_btn' href="javascript:history.back()"><i class="fas fa-arrow-left"></i> Back</a></div>
    </div>
	</div>

<?php
$role = Auth::user()->getRoleNames();
?>

	<div class="tab-content">
		@include('patients.common.profile_status_bar')
    <input type="hidden" class="ref_patient_id" value="{{$patient->id}}" data-id="{{\Crypt::encrypt($patient->id)}}">
		<div class="clearfix"></div>
    <div id="call-table">
      @include('patients.registration.patient_calls_table')
    </div>
	  
	</div>
</div>

<!--  call-modal-->
  <div class="modal fade adddocumentdocuments" id="callModal" tabindex="-1" role="dialog" aria-labelledby="callModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="headingpage"> {{trans('label.new_contact_entry')}} </div>
        </div>
        {!! Form::model($patient,['id' => 'patient-call-form']) !!}
			<input type="hidden" name="patient_id" value="{{\Crypt::encrypt($patient->id)}}">
			<input type="hidden" name="type_id" value="{{\Crypt::encrypt(Auth::id())}}">
			<input type="hidden" name="user_type"  value="{{$role[0]}}">
        <div class="modal-body">
 			<div class="row">
				<div class="col-md-6">
					<div class="form-group date-pick">
						<label class="labelfieldsname"> {{trans('label.contact_date')}}*</label>
						<input type="text" class="form-control contact_datePicker current_date" name="contact_date" readonly="">
            <span class="error" style="color:red"></span>
						<img src="{{ asset('images/calendaradd.png') }}" alt="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="labelfieldsname"> {{trans('label.contact_time')}}*</label>
						<input type="text" class="form-control contact_timepicker" name="contact_time" readonly="">
            <span class="error" style="color:red"></span>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="form-group">
						<label class="labelfieldsname"> {{trans('label.enter_notes')}}*</label>
						<textarea type="text" class="form-control" name="comment" maxlength="10000"></textarea>
					    <span class="error" style="color:red"></span>
					</div>
				</div>
			</div>
				
			<div class="row check-body radio-check">
				<div class="col-md-6">
					 <p class="file-p"> {{trans('label.patient_agree_to_assessment')}}*</p>
				 </div>
				 <div class="col-md-6">
					<div class="checkdiv">
            <div class="yesnodiv">
  						<input type="radio" class="customradio agree_to_call" name="agree" value="yes">
  						<label>Yes</label>
            </div>
            <div class="yesnodiv">
  						<input type="radio" class="customradio agree_to_call" name="agree" value="no" checked="checked" >
  						<label>No</label>
            </div>
				    </div>
 					<span class="error" style="color:red"></span>
				 </div>
			</div>
			<div class="row agree_to_call_div" style="display:none">
				<div class="col-md-6">
					<div class="form-group date-pick">
						<label class="labelfieldsname"> {{trans('label.assessment_date')}}*</label>
						<input type="text" class="form-control assessment_datePicker" name="assessment_date" readonly="">
						<img src="{{ asset('images/calendaradd.png') }}" alt="">
						<span class="error" style="color:red"></span>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="labelfieldsname"> {{trans('label.assessment_time')}}*</label>
						<input type="text" id="timepicker" class="form-control assessment_timepicker" name="assessment_time" readonly="">
						 <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
						<span class="error" style="color:red"></span>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="form-group">
						<label class="labelfieldsname"> {{trans('label.details')}} *</label>
						<textarea type="text" class="form-control" name="location" maxlength="1000"></textarea>
						<span class="error" style="color:red"></span>
					</div>
				</div>
			</div>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom"> <a href="#" onClick="javascript:saveCallform('#patient-call-form')" class="next model_box_save"> {{trans('label.save')}} </a> <a href="#" data-dismiss="modal" aria-label="Close" class="close"> {{trans('label.cancel')}} </a> </div>
        </div>
         {!! Form::close() !!}
      </div>
    </div>
  </div>	

<!--  call view modal -->
  <div class="modal fade viewdocumentnotes" id="viewcall" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content info-modal call-info">
        <div class="modal-header">
          <h4> {{ trans('label.phone_call_details') }} </h4>
        </div>
        <div class="modal-body patient-info note-info">
    			<p style="display:none;"> {{ trans('label.added_on') }} :<span class="created_time"></span></p>
          <p style="display:none;"> {{ trans('label.contact_date_time') }} :<span class="contact_date_time"></span></p>
    			<p style="display:none;"> {{ trans('label.patient_agree_to_assessment') }} :<span class="contact_agree"></span></p>
    			<p style="display:none;"> {{ trans('label.notes') }} :<span class="comment"></span></p>
          <p style="display:none;"> {{ trans('label.assessment_date_time') }} :<span class="assessment_date_time"></span></p>
    			<p style="display:none;"> {{ trans('label.details') }} :<span class="contact_location"></span></p>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom">
          <a href="#" class="close" data-dismiss="modal" aria-label="Close"> {{ trans('label.close') }} </a> </div>
        </div>
      </div>
    </div>
         {!! Form::close() !!}
  </div>

@endsection

@section('script')
<script src="{{ asset('js/moment.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
function saveCallform(formId){
  $('span.error').hide().removeClass('active');
  var formData = new FormData($(formId)[0]);
  $.ajax({
    url:"{{ route('patient-call-add') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('input,textarea,select').removeClass('changed-input');
      var url = window.location.href;
      $.ajax({
            url:url,
            type:"GET",
            data: {id:data.patient_id},
            dataType: "html",
            success:function(data){
              $('#callModal').modal('hide');
              $("#call-table").html(data);
              $('.model_box_save').removeAttr("disabled");

              fadeOutAlertMessages();
            },
            error:function(data){
               $('#callModal').modal('hide');
               $("#call-table").html(data.data);
               fadeOutAlertMessages();
            }
        }); 

    },
    error:function(error){

      fadeOutAlertMessages();

        $('.model_box_save').removeAttr("disabled");
        $.each(error.responseJSON.errors,function(key,value){
            if(key == 'agree'){
            	$('input[name="'+key+'"]').parent().parent().parent().find('span.error').html(value).addClass('active').show();
            }
 			$('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();

        });  
    }
  });
}
 const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
$(document).on('show.bs.modal', '.adddocumentdocuments' ,function(){
      $('span.error').hide().removeClass('active');

      $('.current_time').val(new Date().toLocaleTimeString('en-US', { hour: 'numeric',  minute: 'numeric', hour12: true }));
      
});
	
$(document).ready(function(){ 

  fadeOutAlertMessages();

    $("input[name=agree]").change(function() {
        if( $(this).val() == 'yes' ){
        	$('.agree_to_call_div').show();
        }
        else {
        	$('.agree_to_call_div').hide();
        	$('.agree_to_call_div').find('span.error').html('').addClass('active').hide();
        }
    }); 
    $('.assessment_datePicker').datepicker({
    	autoclose: true,
    	format: 'mm-dd-yyyy',
      startDate: '-0d',
    })
    .datepicker("setDate", 'now')
    .on('change', function(){
      var selected_date = new Date(jQuery(this).datepicker( "getDate" ));
      var current_datetime = new Date();
      var selected_date = selected_date.setHours(0,0);
      var current_date = current_datetime.setHours(0,0);

      if(current_date == selected_date){
        $('.assessment_timepicker').data("DateTimePicker").destroy();
        setTimeout(function(){
          $('.assessment_timepicker').datetimepicker({
            format: 'LT',
            ignoreReadonly: true,
            minDate: new Date(),
            maxDate: new Date().setHours(23,59),
            icons: {
                up: 'fa fa-angle-up',
                down: ' fa fa-angle-down'
            }
          });
        },100);
      }else{
        $('.assessment_timepicker').data("DateTimePicker").destroy();
        setTimeout(function(){
          $('.assessment_timepicker').datetimepicker({
            format: 'LT',
            ignoreReadonly: true,
            icons: {
                up: 'fa fa-angle-up',
                down: ' fa fa-angle-down'
            }
          });
        },100);
      }
      
      jQuery(this).datepicker('hide');
    });


    $('.contact_datePicker').datepicker({
      autoclose: true,
      format: 'mm-dd-yyyy',
      endDate: '-0d',
    })
    .datepicker("setDate", 'now')
    .on('change', function(){
      var selected_date = new Date(jQuery(this).datepicker( "getDate" ));
      var current_datetime = new Date();
      var selected_date = selected_date.setHours(0,0);
      var current_date = current_datetime.setHours(0,0);
      if(current_date == selected_date){
        $('.contact_timepicker').data("DateTimePicker").destroy();
        setTimeout(function(){
          $('.contact_timepicker').datetimepicker({
            format: 'LT',
            ignoreReadonly: true,
            maxDate: new Date(),
            minDate: new Date().setHours(0,0),
            icons: {
                up: 'fa fa-angle-up',
                down: ' fa fa-angle-down'
            }
          });
        },100);
      }else{
        $('.contact_timepicker').data("DateTimePicker").destroy();
        setTimeout(function(){
          $('.contact_timepicker').datetimepicker({
            format: 'LT',
            ignoreReadonly: true,
            icons: {
                up: 'fa fa-angle-up',
                down: ' fa fa-angle-down'
            }
          });
        },100);
      }
      
      jQuery(this).datepicker('hide');
    });
    

    $('.contact_timepicker').datetimepicker({
        format: 'LT',
        ignoreReadonly: true,
        maxDate: new Date(),
        minDate: new Date().setHours(0,0),
        icons: {
            up: 'fa fa-angle-up',
            down: ' fa fa-angle-down'
        }
      });    

    $('.assessment_timepicker').datetimepicker({
        format: 'LT',
        ignoreReadonly: true,
        defaultDate: new Date(),
        minDate: new Date(),
        maxDate: new Date().setHours(23,59),
        icons: {
            up: 'fa fa-angle-up',
            down: ' fa fa-angle-down'
        }
      });

})

$('.adddocumentdocuments').on('hidden.bs.modal', function () {
    $(this).find('form').find('textarea').val('');
    $(this).find('form').find('input[type=radio][name=agree][value=no]').prop("checked", 'checked');
    initCustomForms();
    $('.agree_to_call_div').hide();
})


// on close view phone call

$('.viewdocumentnotes').on('hidden.bs.modal', function () {
      $('#viewcall').find('p').hide();
})

$('body').on('click', '.view_calls', function(e) {
        e.preventDefault();
        $.each($(this).data(), function(i, v) {
            $('#viewcall').find('.'+i).parent().show();
            if(i == 'comment' || i == 'contact_location'){
             // $('#viewcall').find('.'+i).text(v);  
              $('#viewcall').find('.'+i).html('<pre>'+v+'</pre>'); 
            }
            else {
              $('#viewcall').find('.'+i).text(v);  
            }
                    
         });
        $('#viewcall').modal('show');
});

// $('.table-responsive').on('show.bs.dropdown', function () {
//      $('.table-responsive').css( "overflow", "inherit" );
// });

// $('.table-responsive').on('hide.bs.dropdown', function () {
//      $('.table-responsive').css( "overflow", "auto" );
// })

</script> 
@endsection
