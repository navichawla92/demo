<div class="personliving">
               <!--                  <div class="headingpage">Patient’s Living situation/Lives with</div>-->
               <span class="headingpage">Advanced Health Care Directive</span>
               <div class="clearfix"></div>
               <div class="row check-body radio-check">
                  <div class="col-3">
                     <p class="file-p">On File? </p>
                  </div>
                  <div class="col-3">
                     <div class="checkdiv">
                        <input type="radio" class="customradio">
                        <label>Yes</label>
                        <input type="radio" class="customradio">
                        <label>No</label>
                     </div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="row check-body">
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label>Full Code</label>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label>DNR</label>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <input type="checkbox" class="customcheck">
                        <label>Limited Treatment</label>
                     </div>
                  </div>
               </div>
               <!--
                  </div>
                  
                  <div class="personliving">
                  -->
               <span class="smalltextunderheading">Durable Power of Attorney Details</span>
               <div class="clearfix"></div>
               <!--			 <br>-->
               <div class="row">
                  <div class="col-3">
                     <div class="form-group">
                        <label class="labelfieldsname">Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-3">
                     <div class="form-group">
                        <label class="labelfieldsname">Phone Number</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-3">
                     <div class="form-group">
                        <label class="labelfieldsname">Relation</label>
                        <select class="customselect">
                           <option value=""> Please select</option>
                           <option value=""> Please select</option>
                           <option value=""> Please select</option>
                        </select>
                     </div>
                  </div>
               </div>
               <!--                </div>-->
               <div class="clearfix"></div>
               <!--                <div class="personliving">-->
               <span class="headingpage mt-20">POLST</span>
               <div class="clearfix"></div>
               <div class="row check-body radio-check">
                  <div class="col-3">
                     <p class="file-p">On File? </p>
                  </div>
                  <div class="col-3">
                     <div class="checkdiv">
                        <input type="radio" class="customradio">
                        <label>Yes</label>
                        <input type="radio" class="customradio">
                        <label>No</label>
                     </div>
                  </div>
               </div>
               <div class="row check-body">
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <span class="jcf-checkbox jcf-unchecked"><span></span><input type="checkbox" class="customcheck" style="position: absolute; height: 100%; width: 100%; opacity: 0; margin: 0px;"></span>
                        <label>Full Code</label>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <span class="jcf-checkbox jcf-unchecked"><span></span><input type="checkbox" class="customcheck" style="position: absolute; height: 100%; width: 100%; opacity: 0; margin: 0px;"></span>
                        <label>DNR</label>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="checkdiv">
                        <span class="jcf-checkbox jcf-unchecked"><span></span><input type="checkbox" class="customcheck" style="position: absolute; height: 100%; width: 100%; opacity: 0; margin: 0px;"></span>
                        <label>Limited Treatment</label>
                     </div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-md-5">
                     <p class="smalltextunderheading margnbootom">PCF Information </p>
                  </div>
                  <div class="col-md-5">
                     <!--                      <div class="buttonpatient second_emergency_contact_button chw-more-btn" style=""><a href="#"><i class="fas fa-plus"></i> Add PCF</a></div>-->
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Doctor Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Email Address</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Organization Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Speciality</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">FAX</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">Phone Number</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Web Address</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Phone</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Title</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Email</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 1</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 2</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">City</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="row">
                        <div class="col-md-7">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">State</label>
                              <select class="customselect jcf-hidden" name="emergency_person1_state_id" old_value="">
                                 <option value="" selected="selected">Please select</option>
                                 <option value="1">Alabama</option>
                                 <option value="2">Alaska</option>
                                 <option value="3">Arizona</option>
                                 <option value="4">Arkansas</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-5">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">Zip Code</label>
                              <input maxlength="10" name="emergency_person1_zip" type="text" old_value="">
                              <span class="error" style="color:red"></span> 
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="personliving">
               <span class="headingpage mb-10">Home Health Provider</span>
               <!--                  <p class="smalltextunderheading margnbootom">Home Health Provider </p>-->
               <br>
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Organization Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Speciality</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">FAX</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">Phone Number</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Web Address</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Phone</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Title</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Email</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 1</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 2</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">City</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="row">
                        <div class="col-md-7">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">State</label>
                              <select class="customselect jcf-hidden" name="emergency_person1_state_id" old_value="">
                                 <option value="" selected="selected">Please select</option>
                                 <option value="1">Alabama</option>
                                 <option value="2">Alaska</option>
                                 <option value="3">Arizona</option>
                                 <option value="4">Arkansas</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-5">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">Zip Code</label>
                              <input maxlength="10" name="emergency_person1_zip" type="text" old_value="">
                              <span class="error" style="color:red"></span> 
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="personliving">
               <span class="headingpage mb-10">Hospice Provider</span>
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Organization Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Speciality</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">FAX</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">Phone Number</label>
                              <input type="text" class="form-control">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Web Address</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Name</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Phone</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Title</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Contact Email</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 1</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">Address Line 2</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="form-group">
                        <label class="labelfieldsname">City</label>
                        <input type="text" class="form-control">
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="row">
                        <div class="col-md-7">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">State</label>
                              <select class="customselect jcf-hidden" name="emergency_person1_state_id" old_value="">
                                 <option value="" selected="selected">Please select</option>
                                 <option value="1">Alabama</option>
                                 <option value="2">Alaska</option>
                                 <option value="3">Arizona</option>
                                 <option value="4">Arkansas</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-5">
                           <div class="textfieldglobal">
                              <label class="labelfieldsname">Zip Code</label>
                              <input maxlength="10" name="emergency_person1_zip" type="text" old_value="">
                              <span class="error" style="color:red"></span> 
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="buttonsbottom">
               <button  class="next" data-toggle="modal" data-target="#exampleModal">Save & Next</button>
               <button  class="next" data-toggle="modal" data-target="#exampleModal">Save & Close</button>
               <a href="#" class="close">Cancel</a> 
            </div>