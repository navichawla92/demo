<div class="modal fade" id="editPatient" tabindex="-1" role="dialog" aria-labelledby="editPatientLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg edit-patient-popup" role="document">
      {!! Form::model($patient,['id' => 'patient-info-form', 'files' => true]) !!}
      <input type="hidden" name="step_number" value="1">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="patient_id" class="ref_patient_id" value="{{ $patient->id }}" data-id="{{\Crypt::encrypt($patient->id)}}">
      <div class="modal-content">
         <div class="modal-header">
            <div class="headingpage">{{ trans('label.edit_patient_info') }}</div>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
         </div>
         <div class="modal-body ">
            <div class="clearfix"></div>
            <div class="row">
               <div class="col-4">
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.first_name') }}* </label>
                     {!! Form::text('first_name',null,array('maxlength' => 20)) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                   <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.middle_initial') }} </label>
                     {!! Form::text('middle_initial',null,array('maxlength' => 1)) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{trans('label.last_name')}}* </label>
                     {!! Form::text('last_name',null,array('maxlength' => 40)) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{trans('label.patient_alias')}} </label>
                     {!! Form::text('patient_alias',null,array('maxlength' => 50)) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.gender') }} </label>
                     {!! Form::select('gender', array('' => 'Please select') + $gender_array,null,array("class" => "customselect")) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.dob') }}* </label>
                     {!! Form::text('dob',null,['class' => 'datePicker_dob','placeholder' => trans('label.dob_place_holder')]) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.email') }} </label>
                     {!! Form::text('email',null,array('maxlength' => 45)) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
               </div>
               <div class="col-4">
                  <div class="textfieldglobal">
                     <label class="labelfieldsname" >{{ trans('label.phone') }}*</label>
                     <div class="clearfix"></div>
                     <div class="row">
                        <div class="col-md-3">
                           {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center','disabled'=>true]) !!} 
                        </div>
                        <div class="col-md-9">
                           {!! Form::text('phone',null,['class' => 'set_phone_format']) !!}
                           <span class="error" style="color:red"></span>
                        </div>
                     </div>
                     <span class="error" style="color:red"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.ssn') }}* </label>
                     {!! Form::text('ssn',null,['class'=>'ssn_format']) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.language_word') }}* </label>
                     {!! Form::select('language', $languages, null, ['class' => 'customselect']) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>

                
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.address_line_1') }}* </label>
                     {!! Form::text('address_line1',null,['maxlength'=>'100']) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.address_line_2') }} </label>
                     {!! Form::text('address_line2',null,['maxlength'=>'100']) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="textfieldglobal">
                     <label class="labelfieldsname"> {{ trans('label.city') }}* </label>
                     {!! Form::text('city',null,['maxlength'=>'50']) !!}
                     <span class="error" style="color: red; display: none;"></span>
                  </div>
                  <div class="row">
                     <div class="col-sm-7">
                        <div class="textfieldglobal">
                           <label class="labelfieldsname"> {{ trans('label.state') }}* </label>
                           <div class="clearfix"></div>
                           {!! Form::select('state_id', $states,null,['class' => 'customselect']); !!} 
                           <span class="error" style="color: red; display: none;"></span>
                        </div>
                     </div>
                     <div class="col-5">
                        <div class="textfieldglobal">
                           <label class="labelfieldsname"> {{ trans('label.zip_code') }}* </label>
                           {!! Form::text('zip_code',null,['maxlength'=>'5']) !!}
                           <span class="error" style="color: red; display: none;"></span>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-4">
                  <div class="browsebutton">
                     <div class="clearfix"></div>
                     <div class="patient_pro_pic_preview">
                        <img id="previewHolder" src="@if($patient->image) {{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }} @else {{ asset('images/noimage.jpg') }} @endif" alt="" width="150">
                        <span class="imgcross" <?php if(!$patient->image) echo 'style="display:none;"'; ?>>X</span>
                        <div class="browsebuttontext patient-info-pro-pic-upload" <?php if($patient->image) echo 'style="display:none;"'; ?>> {{ trans('label.upload_picture') }}
                           {!! Form::file('image', ['accept'=>'image/x-png,image/gif,image/jpeg'])  !!}
                           <input name="upload_image_or_not" type="hidden" value="no" old_value="no">
                        </div>
                         <span class="error" id='invalid_image_error' style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="clearfix"></div>
            <div class="modal-footer">
               <div class="buttonsbottom"> <button type="button" onClick="javascript:saveform('saveandclose','#patient-info-form','2')" class="next">{{ trans('label.save') }}</button> <a href="#" class="close" data-dismiss="modal" aria-label="Close">{{ trans('label.cancel') }}</a> </div>
            </div>
            {!! Form::close() !!}
         </div>
      </div>
   </div>
</div>
