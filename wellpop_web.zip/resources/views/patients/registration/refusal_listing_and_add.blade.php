<div class="row">
   <div class="col-sm-10">
      <div class="form-group">
         <label class="labelfieldsname">{{ trans('label.reason_for_refusal') }}</label>
         <textarea type="text" name="comment" class="form-control"></textarea>
         <span class="error" style="color:red"></span>
      </div>
   </div>
</div>

<div class="buttonsbottom">
   <button  class="next save_new_patient_refusal_reason" type="button">{{ trans('label.save') }}</button>
   <a href="{{ route('registration_patient_view', encrypt($patient_id)) }}" class="close">{{ trans('label.cancel') }}</a> 
</div>

<div class="clearfix"></div>
<p class="headingpage buttonmargin margnbootom">{{ trans('label.patient_refusel_history') }}</p>
<div class="clearfix"></div>
<div class="table-responsive care-table refusal_listing_table">
   <table class="table">
      <thead>
         <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.refuse_date') }}</th>
            <th>{{ trans('label.reason') }}</th>
            <th>{{ trans('label.added_by') }}</th>
            <th>{{ trans('label.view_reason') }}</th>
         </tr>
      </thead>
      <tbody>
         @if(count($previous_refusal))
            <?php  $index=($previous_refusal->perPage() * ($previous_refusal->currentPage()- 1))+1; ?>
            <?php  $color_array = ['name-green','name-voilet','name-red','name-light',]; $i = 0;?>
            @foreach($previous_refusal as $refusal)
            <tr>
               <td>{{$index}}</td>
               <td>{{ $refusal->created_at }}</td>
               <td>{{ $refusal->comment }}</td>
               <td>{{ $refusal->user->name }}</td>
               <td>
                  <div class="dropdown more-btn">
                     <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span>...</span>
                     </button>
                     <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                        <a href="#" data-refusal_date="{{ $refusal->created_at }}"
                        data-user_name="{{ $refusal->user->name }}" data-reason_for_refusal="{{ $refusal->comment }}" class="dropdown-item view_refusal">
                          <i class="fa fa-eye"></i> {{ trans('label.view') }}
                        </a>
                     </div>
                  </div>         
               </td>
            </tr>
            <?php  $index++; ?>
            @endforeach
            @else
               <tr><td>No record found</td></tr>
            @endif
      </tbody>
   </table>
</div>
<?php echo $previous_refusal->render(); ?>
