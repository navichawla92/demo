<div class="personliving">
               <div class="row">
                  <div class="col-md-6 col-6">
                     <div class="headingpage">Upload necessary document</div>
                  </div>
                  <div class="col-md-6 col-6">
                     <div class="buttonpatient"><a href="#" data-toggle="modal" data-target="#adddocumentdocuments"><i class="fas fa-plus"></i> Add Document</a></div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="table-responsive care-table">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th>Document Category</th>
                           <th>Name of Document</th>
                           <th>Upload Date</th>
                           <th>Uploaded By</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td>1</td>
                           <td>Category Name</td>
                           <td>Patient Medical history</td>
                           <td>Sep 20 2018</td>
                           <td>Smith</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td>2</td>
                           <td>Category Name</td>
                           <td>Patient Medical history</td>
                           <td>Sep 20 2018</td>
                           <td>Smith</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                        <tr>
                           <td>3</td>
                           <td>Category Name</td>
                           <td>Patient Medical history</td>
                           <td>Sep 20 2018</td>
                           <td>Smith</td>
                           <td>
                              <div class="dropdown more-btn dropup">
                                 <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <span>...</span>
                                 </button>
                                 <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                                    <a class="dropdown-item"><i class="fa fa-eye"></i> View</a>
                                 </div>
                              </div>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <ul class="pagination" role="navigation">
                  <li class="page-item disabled" aria-disabled="true" aria-label="« Previous"> <span class="page-link" aria-hidden="true">‹</span> </li>
                  <li class="page-item active" aria-current="page"><span class="page-link">1</span></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=2">2</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=3">3</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=4">4</a></li>
                  <li class="page-item"><a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=5">5</a></li>
                  <li class="page-item"> <a class="page-link" href="http://wellpop.debutinfotech.com/casemanager/patients?page=2" rel="next" aria-label="Next »">›</a> </li>
               </ul>
            </div>