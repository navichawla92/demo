<div class="modal fade assignment" id="assignment_modal" tabindex="-1" role="dialog" aria-labelledby="assignmentModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			{!! Form::open(['id' => 'registration_assignment_form']) !!}
			{!! Form::hidden('patient_id')  !!}
			<div class="modal-header">
				<div class="headingpage">Assign Care Team</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
			</div>
			<div class="modal-body">	
				<div class="fullmainpop">
					<div class="popdatafull">
						<div class="popdata50">
							<label class="poplabel">Referral ID</label>
						</div>
						<div class="popdata50"> <span class="labelvaluepop assignment_referral_number">WPR001</span> </div>
					</div>
					<div class="popdatafull">
						<div class="popdata50">
							<label class="poplabel">Patient Name</label>
						</div>
						<div class="popdata50"> <span class="labelvaluepop assignment_patient_name">John Smith</span> </div>
					</div>
					<div class="popdatafull">
						<div class="popdata50">
							<label class="poplabel">Gender</label>
						</div>
						<div class="popdata50"> <span class="labelvaluepop assignment_patient_gender">Male</span> </div>
					</div>
					<div class="popdatafull">
						<div class="popdata50">
							<label class="poplabel">Age</label>
						</div>
						<div class="popdata50"> <span class="labelvaluepop assignment_patient_age">32</span> </div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<label>Community Health Worker</label>
							{!! Form::select('assigned_chw', $chw_users, null, ['placeholder' => 'Select CHW', 'class' => 'customselect assigned_chw']) !!}
							<span class="error" style="color:red"></span>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label>Case Manager</label>
							{!! Form::select('assigned_cm', $cm_users, null, ['placeholder' => 'Select CM', 'class' => 'customselect assigned_cm']) !!}
							<span class="error" style="color:red"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">
							<label>Mediacal Director</label>
							{!! Form::select('assigned_md', $md_users, null, ['placeholder' => 'Select MD', 'class' => 'customselect assigned_md']) !!}
							<span class="error" style="color:red"></span>
						</div>
					</div>		
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="modal-footer">
				<div class="buttonsbottom"> <a href="javascript:assignments()" class="next">Save</a> <a href="#" class="close" data-dismiss="modal">Cancel</a> </div>
			</div>
			{!! Form::close() !!}
		</div>
	</div>
</div>