<?php
$enrollment_status = enrollment_status_for_registration();
?>

<div class="modal fade" id="enrollment_modal" tabindex="-1" role="dialog" aria-labelledby="enrollment_modalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
        {!! Form::open(['id' => 'enrollment_modal_form']) !!}
        {!! Form::hidden('patient_id')  !!}
         <div class="modal-header">
            <div class="headingpage">{{ trans('label.patient_enrollment') }}</div>
         </div>
         <div class="modal-body">
            <div class="">
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-12">
                      <div class="alert alert-warning text-center" role="alert">{{ trans('label.patient_enrollment_message') }}</div>
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Status * </label>
                        {!! Form::select('enrollment_status', array('' => 'Please select') + $enrollment_status, null, ['class' => 'customselect']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <div class="buttonsbottom"> <a href="javascript:move_to_enrollment()" class="next">{{ trans('label.enroll') }}</a>
               <a href="#" class="close" data-dismiss="modal" aria-label="Close">Cancel</a>
            </div>
         </div>
         {!! Form::close() !!}
      </div>
   </div>
</div>