<div class="modal fade" id="editAssignment" tabindex="-1" role="dialog" aria-labelledby="editAssignmentLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
        {!! Form::open(['id' => 'edit_assignments_form']) !!}
        {!! Form::hidden('patient_id', encrypt($patient->id))  !!}
         <div class="modal-header">
            <div class="headingpage">{{ trans('label.edit_patient_assignments') }}</div>
         </div>
         <div class="modal-body">
            <div class="">
               <div class="clearfix"></div>
               <div class="row">
                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Community Health Worker* </label>
                        {!! Form::select('assigned_chw', $chw_users, $patient->assigned_chw, ['class' => 'customselect assigned_chw']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Case Manager * </label>
                        {!! Form::select('assigned_cm', $cm_users, $patient->assigned_cm, ['class' => 'customselect assigned_cm']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Mediacal Director * </label>
                        {!! Form::select('assigned_md', $md_users, $patient->assigned_md, ['class' => 'customselect assigned_md']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <div class="buttonsbottom"> <a href="javascript:assignments()" class="next">Save</a> <a href="#" class="close" data-dismiss="modal" aria-label="Close">Cancel</a> </div>
         </div>
         {!! Form::close() !!}
      </div>
   </div>
</div>