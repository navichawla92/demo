@extends('layouts.app')

@section('css')
   <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
@endsection

@section('title')
   View Patient
@endsection

@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ $patient->registration_number ? $patient->registration_number : "-" }}
         </div>
      </div>
   </div>
   @if(session()->has('message.level'))
       <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         {!! session('message.content') !!}
       </div>
   @endif
   <div class="patient-view pat-show">
      <div class="row">
         <div class="col-sm-3">
            <div class="patient-img-box">
               <img src="@if($patient->image) {{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }} @else {{ asset('images/noimage.jpg') }} @endif" class="img img-fluid"> 
            </div>
         </div>
         <div class="col-sm-9">
            <div class="patient-head">
               <div class="row">
                  <div class="col-sm-8">
                     <h4><strong>{{ trans('label.patient_details') }}:</strong></h4>
                  </div>
                  <div class="col-sm-4">
                     <div class="head-btn"> <a class="btn btn-primary cancel editPatient"  data-toggle="modal" ><i class="fa fa-pencil-alt"></i> {{ trans('label.edit') }}</a> </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.reference_number_short_form') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->case_number }}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.reg_no') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->registration_number ? $patient->registration_number : "-" }}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.patient_name') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->first_name ? $patient->first_name : "-"}} {{ $patient->middle_initial ? $patient->middle_initial.'. ' : ""}}{{ $patient->last_name ? $patient->last_name : ""}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.ssn') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>
                              <?php
                                  $strring = substr($patient->ssn, 7);
                                  echo '*****'.$strring;
                              ?>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.alias') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->patient_alias ? $patient->patient_alias : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.language') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->language_value ? $patient->language_value->name : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.gender') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->gender ? $patient->gender : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.address_line_1') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->address_line1 ? $patient->address_line1 : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.dob') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <?php
                                $dob = explode('-',$patient->dob);
                                $dob = $dob[1].'-'.$dob[0].'-'.$dob[2];
                           ?>
                           <p>{{ $patient->dob ?  \Carbon\Carbon::parse($dob)->format('m-d-Y') : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
              <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">
                     {{ trans('label.address_line_2') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->address_line2 ? $patient->address_line2 : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>

              
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.age') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>
                           <?php
                              echo get_dob_in_years($patient->dob);
                           ?>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.city') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->city ? $patient->city : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.email') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->email ? $patient->email : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>

               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.state') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->state_name ? $patient->state_name : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.phone_no') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>
                           <?= $patient->phone? "+1 ".$patient->phone:'-' ?>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-sm-6 field-box">
                  <div class="form-group">
                     <label class="control-label" for="pwd">{{ trans('label.zip_code') }}:</label>
                     <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                           <p>{{ $patient->zip_code ? $patient->zip_code : "-"}}</p>
                        </div>
                     </div>
                  </div>
               </div>  

            </div>
         </div>
      </div>
      <div class="assignment-box">
         <div class="assignment-head">
            <div class="row">
               <div class="col-sm-4 offset-4">
                  <h4>{{ trans('label.assignments') }}</h4>
               </div>
               <div class="col-sm-4">
                  <div class="head-btn"> <a class="btn btn-primary cancel edit_assignment" data-toggle="modal"  data-chw="{{ $patient->assignedChw ? $patient->assignedChw->type_id : "" }}" data-md="{{ $patient->assignedMd ? $patient->assignedMd->type_id : '' }}" data-cm="{{ $patient->assignedCm ? $patient->assignedCm->type_id : '' }}"  ><i class="fa fa-pencil-alt"></i> {{ trans('label.edit') }}</a> </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-sm-4">
               <div class="form-group">
                  <label>{{ trans('label.community_health_worker') }}</label>
                  {!! Form::select('assigned_chw', $chw_users, $patient->assignedChw ? $patient->assignedChw->type_id : '', ['class' => 'customselect assigned_chw', 'disabled' => 'disabled']) !!}
               </div>
            </div>
            <div class="col-sm-4">
               <div class="form-group">
                  <label>{{ trans('label.case_manager') }}</label>
                  {!! Form::select('assigned_cm', $cm_users, $patient->assignedCm ? $patient->assignedCm->type_id : '', ['class' => 'customselect assigned_cm', 'disabled' => 'disabled']) !!}
               </div>
            </div>
            <div class="col-sm-4">
               <div class="form-group">
                  <label>{{ trans('label.mediacal_director') }}</label>
                  {!! Form::select('assigned_md', $md_users, $patient->assignedCm ? $patient->assignedMd->type_id : '', ['class' => 'customselect assigned_md', 'disabled' => 'disabled']) !!}
               </div>
            </div>
         </div>
      </div>
      <div class="assign-box">
         <div class="row">
            <div class="col-md-6 col-xl-4">
               <h4>{{ trans('label.patient_assessment') }}</h4>
               <h5 class="asign-a">
                  <span class="circle-box">{{ trans('label.chw') }}</span>
                  <p title="{{ $patient->chw_name ? $patient->chw_name : '-'}}">{{ $patient->assignedChw ? ( strlen($patient->assignedChw->user->name) > 15 ? substr($patient->assignedChw->user->name,0,15)."..." : $patient->assignedChw->user->name ) : "-"}} &nbsp;<span>({{ trans('label.community_health_worker') }})</span></p>
                  
                  {!! $patient->chw_assessment_case_status_badge !!}
               </h5>
               <h5 class="asign-b">
                  <span class="circle-box cm-circle">{{ trans('label.cm') }}</span>
                  <p title="{{ $patient->assignedCm ? $patient->assignedCm->user->name : '-'}}">{{ $patient->assignedCm ? ( strlen($patient->assignedCm->user->name) > 15 ? substr($patient->assignedCm->user->name,0,15)."..." : $patient->assignedCm->user->name ) : "-"}} &nbsp;<span>({{ trans('label.case_manager') }})</span></p>
                  @if($patient->assignedCm)
                  <a href="{{ route('registration_cm_assessment', encrypt($patient->id)) }}">{{ trans('label.assess') }}</a>
                  @else
                   <a href="javascript:void(0)" title="{{ trans('message.assign_care_message') }}">{{ trans('label.assess') }}</a>
                  @endif 
                  {!! $patient->cm_assessment_case_status_badge !!}
               </h5>
               <h5 class="asign-c">
                  <span class="circle-box md-circle">{{ trans('label.md') }}</span>
                  <p title="{{ $patient->assignedMd ? $patient->assignedMd->user->name : '-'}}">{{ $patient->assignedMd ? ( strlen($patient->assignedMd->user->name) > 15 ? substr($patient->assignedMd->user->name,0,15)."..." : $patient->assignedMd->user->name ) : "-"}} &nbsp;<span>({{ trans('label.mediacal_director') }})</span></p>
                  {!! $patient->md_assessment_case_status_badge !!}
               </h5>
            </div>
            <div class="col-md-6 col-xl-4 ">
               <h4>{{ trans('label.patient_consent') }}</h4>
               <div class="concent-box conc-area">
                  <img src="{{ asset('images/form.png') }}">
                  <h3>{{ trans('label.patient_consent') }}</h3>
                  {!! $patient->cm_consent_form_status_badge !!}
                  @if($patient->cm_name != '-')
                     @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                        <a href="{{ route('registration_cm_patient_enroll', encrypt($patient->id)) }}">{{ trans('label.view_consent_form') }}</a>
                     @else
                        <a href="{{ route('registration_cm_patient_enroll', encrypt($patient->id)) }}">{{ trans('label.sign_consent_form') }}</a>
                     @endif
                  @else
                     <a title="{{ trans('message.assign_care_message') }}" href="javascript:void(0)">{{ trans('label.sign_consent_form') }}</a>
                  @endif 
               </div>
            </div>
            <div class="col-md-6 col-xl-4">
               <h4>{{ trans('label.actions') }}</h4>
               <div class="concent-box">
                   @if($patient->cm_name != '-')
                  <ul>
                     <a href="{{ route('patient-calls',[\Crypt::encrypt($patient->id)]) }}">
                        <li><img src="{{ asset('images/call.png') }}">{{ trans('label.call') }} </li>
                     </a>
                     <a href="{{ route('registration_patient_documents', [Auth::user()->roles->pluck('name')[0],encrypt($patient->id)]) }}" >
                        <li><img src="{{ asset('images/clip.png') }}"> {{ trans('label.documents') }}</li>
                     </a>
                     <a href="{{ route('registration_patient_notes', [Auth::user()->roles->pluck('name')[0],encrypt($patient->id)]) }}">
                        <li><img src="{{ asset('images/noty.png') }}"> {{ trans('label.notes') }}</li>
                     </a>
                     <a href="javascript:void(0)" class="{{ $patient->registration_status != 2 ? 'enroll_section_disable':'- move_to_enrollment' }}">
                        <li><img src="{{ asset('images/enroll.png') }}"> {{ trans('label.enroll') }}</li>
                     </a>
                  </ul>
                  @else
                    <ul>
                     <a href="javascript:void(0)" >
                        <li title="{{ trans('message.assign_care_message') }}"><img src="{{ asset('images/call.png') }}">{{ trans('label.call') }} </li>
                     </a>
                     <a href="javascript:void(0)" >
                        <li title="{{ trans('message.assign_care_message') }}"><img src="{{ asset('images/clip.png') }}"> {{ trans('label.documents') }}</li>
                     </a>
                     <a href="javascript:void(0)">
                        <li title="{{ trans('message.assign_care_message') }}"><img src="{{ asset('images/noty.png') }}"> {{ trans('label.notes') }}</li>
                     </a>
                     <a href="javascript:void(0)">
                        <li title="{{ trans('message.assign_care_message') }}"><img src="{{ asset('images/enroll.png') }}"> {{ trans('label.enroll') }}</li>
                     </a>
                  </ul>

                  @endif 

               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@include('patients.registration.edit_patient_info_modal')
@include('patients.registration.edit_patient_assignments_modal')
@include('patients.registration.enrollment_modal')
@endsection

@section('script')
<script type="text/javascript">
   $( document ).ready(function() {

    //  console.log("welcome");
      
      fadeOutAlertMessages();
      //initialize input masks fields
      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
      $(".ssn_format").inputmask("999-99-9999",{showMaskOnFocus : false, showMaskOnHover : false});

      $('.datePicker_dob').datepicker({
         autoclose: true,
         format: 'mm-dd-yyyy',
         endDate: '-10y',
         startDate: '-100y',
      });

      $(document).on('change', "input[type=file][name=image]", function() {
        $('.browsebutton').find('span.error').hide().removeClass('active');
        readURL(this);
        $('.patient_pro_pic_preview span.imgcross').show();
        $('.patient-info-pro-pic-upload').hide();
        $('input[type=hidden][name=upload_image_or_not]').val('yes');
      });

      function readURL(input) {
        if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            $('#previewHolder').attr('src', e.target.result);
          }

          reader.readAsDataURL(input.files[0]);
        }
      }

      $(document).on('change','input[type=file][name=uploaded_document]',function(e){
          $('.upload_document_error').hide().removeClass('active');
          $("#selected_doc_name").html(e.target.files[0].name);
          $("#delete_selected_doc").show();
      });

      $(document).on('click','#delete_selected_doc',function(e){
          $('.upload_document_error').hide().removeClass('active');
          $('#patient-document-form').find('input[type=file]').val("");
          $("#selected_doc_name").html('No file selected');
          $("#delete_selected_doc").hide();
      });

      //patient profile image remove on cross click code
      $(document).on('click','.patient_pro_pic_preview span.imgcross',function(){
        $('input[type=hidden][name=upload_image_or_not]').val('yes');
        $('input[type=file][name=image]').val('');
        $('.patient_pro_pic_preview img').attr('src',"{{ asset('images/noimage.jpg') }}");
        $('.patient_pro_pic_preview span.imgcross').hide();
        $('.patient-info-pro-pic-upload').show();
        $('#invalid_image_error').html('').removeClass('active');
      });
      $(document).on('click','.edit_assignment',function(e){
         jQuery(".assigned_cm").val($(this).data('cm'));
         jQuery(".assigned_chw").val($(this).data('chw'));
         jQuery(".assigned_md").val($(this).data('md'));
         initCustomForms();
         $('#editAssignment').modal('show');
      });
      $(document).on('click','.editPatient',function(e){
        document.getElementById("patient-info-form").reset();
        $('#editPatient').modal('show');
      });
      $(document).on('click','.move_to_enrollment',function(e){
         document.getElementById("enrollment_modal_form").reset();
         $('#enrollment_modal input[type=hidden][name=patient_id]').val('{{encrypt($patient->id)}}');
         $('#enrollment_modal').modal('show');
      });

   });
   
   //Fill values in Assignment Modal before it fully opens
   function assignments(){
     var formData = new FormData($('#edit_assignments_form')[0]);
     $.ajax({
       url:"{{ route('registration_assignment') }}",
       data:formData,
       processData: false,
       contentType: false,
       dataType: "json",
       success:function(data){
         $('#editAssignment').modal('hide');
         window.location.reload();
       },
       error:function(error){      
         if(error.responseJSON.errors){
            $.each(error.responseJSON.errors,function(key,value){
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();

            }); 
         }else{
            window.location.reload();
         }
                      
       }
     });
   }

   //Fill values in Assignment Modal before it fully opens
   function move_to_enrollment(){
     var formData = new FormData($('#enrollment_modal_form')[0]);
     
     $.ajax({
       url:"{{ route('patient_enrolled') }}",
       data:formData,
       processData: false,
       contentType: false,
       dataType: "json",
       success:function(data){
         $('#editAssignment').modal('hide');
         //window.location.reload();
         window.location.href="{{ route('patient-caseload') }}";
       },
       error:function(error){      
         if(error.responseJSON.errors){
            $.each(error.responseJSON.errors,function(key,value){
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();

            }); 
         }else{
            window.location.reload();
         }
                      
       }
     });
   }

   function saveform(button_pressed,formId,tab){
  
      $('.model_box_save').attr("disabled", "disabled");
      $('span.error').hide().removeClass('active');

      //unmask value of phone number fields
      $(".set_phone_format").inputmask('remove');

      $(".set_phone_format").inputmask('remove');
      var formData = new FormData($(formId)[0]);
      formData.append( 'assignment_modal',1);

      $.ajax({
         url:"{{ route('patient-add') }}",
         data:formData,
         processData: false,
         contentType: false,
         dataType: "json",
         success:function(data){
            $('.model_box_save').removeAttr("disabled");
            $('input,textarea,select').removeClass('changed-input');
            window.location.reload();
         },
         error:function(error){
            $('.model_box_save').removeAttr("disabled");
            $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
            $.each(error.responseJSON.errors,function(key,value){
               if(key == 'image'){
                   $('#invalid_image_error').html(value).addClass('active').show();
               }
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            }); 
         }
      });
   }


</script>
@endsection