<table class="table">
	<thead>
		<th> {{trans('label.patient_name')}} </th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.referral_number')}}">{{trans('label.ref_no')}}</th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.registration_number')}}"> {{trans('label.reg_no')}} </th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.registration_date')}}">{{trans('label.reg_date')}} </th>
		<th>{{trans('label.gender')}}</th>
		<th>{{trans('label.age')}}</th>
		<th>{{trans('label.list_phone')}}</th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.community_health_worker')}}"> {{trans('label.chw')}} </th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.case_manager')}}"> {{trans('label.cm')}} </th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.mediacal_director')}}"> {{trans('label.md')}} </th>
		<th data-toggle="tooltip" data-placement="top" title="{{trans('label.registration_status')}}">{{trans('label.reg_status')}} </th>
		<th>Action</th>
	</thead>
	<tbody>
		@if(count($patients))
		<?php  $color_array = ['name-green','name-voilet','name-red','name-light',]; $i = 0;?>
		@foreach($patients as $patient)
		<tr>
			<?php
			$patient->calc($patient->random_key);
			$name = '';
			$name .= $patient->first_name ? ucfirst($patient->first_name) : '-';
			$name .= ' ';
			$name .= $patient->last_name ? ucfirst($patient->last_name) : '-';
			?>


			<td title="{{ $name }}"><a href="{{ route('registration_patient_view', encrypt($patient->id))  }}"><span class="name-circle <?php echo "status_color_".$patient->registration_status; ?>">{{ $patient->first_name ? substr($patient->first_name,0,1) : "-"}}{{ $patient->last_name ? substr($patient->last_name,0,1) : ""}}</span> {{ strlen($name) > 110000 ? substr($name,0,100000)."..." : $name }} </a></td>
			<td>{{ $patient->case_number }}</td>
			<td>{{ $patient->registration_number ? $patient->registration_number : "-" }}</td>
			<td>{{ $patient->registered_at }}</td>
			<td>{{ $patient->gender }}</td>
			<td>
				<?php
				$final_age = get_dob_in_years($patient->dob);
				echo $final_age;
				?>
			</td>
			<td>{{ $patient->phone ? $patient->phone : "-"}}</td>
			<td title="{{ $patient->assignedChw ? $patient->assignedChw->user->name : '-' }}" >{{ $patient->assignedChw ? $patient->assignedChw->user->name : "-"}}</td>
			<td title="{{ $patient->assignedCm ? $patient->assignedCm->user->name : '-' }}" >{{ $patient->assignedCm ? $patient->assignedCm->user->name : "-"}}</td>
			<td title="{{ $patient->assignedMd ? $patient->assignedMd->user->name : '-' }}">{{ $patient->assignedMd ? $patient->assignedMd->user->name: "-"}}</td>
			<td>{!! $patient->registration_status_badge !!}</td>
			<td>
				<div class="dropdown more-btn">
					<button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<span>...</span>
					</button>
					<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
						<a href="javascript:void(0)" class="dropdown-item assignment_action_btn" data-assigned_chw="{{ $patient->assignedChw ? $patient->assignedChw->type_id : '' }}" data-assigned_cm="{{ $patient->assignedCm ? $patient->assignedCm->type_id : '' }}" data-assigned_md="{{ $patient->assignedMd ? $patient->assignedMd->type_id : '' }}" data-patient_id="{{ encrypt($patient->id) }}" data-assignment_referral_number="{{ $patient->case_number }}" data-assignment_patient_name="{{ $patient->first_name ? $patient->first_name : "-"}} {{ $patient->last_name ? $patient->last_name : ""}}" data-assignment_patient_gender="{{ $patient->gender }}" data-assignment_patient_age="{!! $final_age !!}" ><img src="{{ asset('images/assign.png') }}" alt=""> {{trans('label.assign')}} </a>
						<a href="{{ route('registration_patient_view', encrypt($patient->id)) }}" class="dropdown-item"><img src="{{ asset('images/edit.png') }}" alt=""/>{{trans('label.edit')}}</a> 
						@php
						if($patient->chw_name !='-'){
						@endphp
						<a  href="{{ route('patient-calls',[\Crypt::encrypt($patient->id)]) }}" class="dropdown-item"><img src="{{ asset('images/call.png') }}" alt=""> {{trans('label.call')}} </a>
						<a href="{{ route('registration_patient_notes', [Auth::user()->roles->pluck('name')[0],encrypt($patient->id)]) }}" class="dropdown-item"><img src="{{ asset('images/comment.png') }}" alt=""/> {{trans('label.notes')}} </a> 
						<a href="{{ route('registration_patient_documents', [Auth::user()->roles->pluck('name')[0],encrypt($patient->id)]) }}" class="dropdown-item"><img src="{{ asset('images/file.png') }}" alt="">{{trans('label.documents')}} </a>
                       
                         @if($patient->registration_status =='2')
                         <a href="javascript:void(0)" class="dropdown-item enroll_action_btn" data-id="{{ encrypt($patient->id)}}">
                         <img src="{{ asset('images/enroll.png') }}" alt="">	{{trans('label.enrollment')}}
                         </a> 
                         @else
                         <button class="dropdown-item" disabled><img src="{{ asset('images/enroll.png') }}" alt=""> {{trans('label.enrollment')}} </button>	
                         @endif

						
						
						@php
						}
						else{
						@endphp
						<button class="dropdown-item" title="{{ trans('message.assign_care_message') }}" disabled><img src="{{ asset('images/call.png') }}" alt="" > {{trans('label.call')}} </button>
						<button  title="{{ trans('message.assign_care_message') }}" class="dropdown-item" disabled><img src="{{ asset('images/comment.png') }}" alt=""/> {{trans('label.notes')}} </button> 
						<button title="{{ trans('message.assign_care_message') }}" class="dropdown-item" disabled><img src="{{ asset('images/file.png') }}" alt="">{{trans('label.documents')}} </button>
			

						 @if($patient->registration_status =='2')
                         <a href="javascript:void(0)" class="dropdown-item enroll_action_btn" data-id="{{ encrypt($patient->id)}}">
                         	<img src="{{ asset('images/enroll.png') }}" alt="">{{trans('label.enrollment')}}
                         </a> 
                         @else
                        <button title="{{ trans('message.assign_care_message') }}" class="dropdown-item" disabled><img src="{{ asset('images/enroll.png') }}" alt=""> {{trans('label.enrollment')}} </button>
                         @endif
						@php
						}
						if($i <= 3) $i++; else $i = 0;
						@endphp
					</div>
				</div>			
			</td>
		</tr>
		@endforeach
		@else
		<tr><td colspan="12">No record found</td></tr>
		@endif
	</tbody>
</table>
<?php echo $patients->render(); ?>

