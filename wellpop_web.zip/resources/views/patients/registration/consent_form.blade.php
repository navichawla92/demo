@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{trans('label.patient_registration')}}
@endsection
 {{ App::setLocale($lang) }}
@section('content')
<div class="leftsectionpages">
   <div class="row non-print">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.consent_form') }}
            <span><i class="fas fa-angle-right"></i></span>{{$patient->registration_number}}
         </div>
      </div>
   </div>
   {!! Form::model($patient_form,['id' => 'save_consent_form']) !!}
   <input name="patient_id" type="hidden" value="{{ encrypt($patient_id) }}">
   <div class="tab-content">
      <div class="cons-form-box">
         <div class="lang-box non-print">
            <div class="row">
               <div class="col-md-10">
                  @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                  <div class="form-group">
                     <label>Choose Language</label>
                     {!! Form::select('consent_form_language', ['eng'=>'English','es'=>'Spanish','fr'=>'Farcy','vit'=>'Vietnamese'], $lang, ['class' => 'status_filter customselect langauge_changed']) !!}
                  </div>
                  @endif
               </div>
               <div class="col-md-2">
                  <ul class="action-box">
                     <li onclick="printDiv('print_form')"><i class="fa fa-print"></i><span>Print</span></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="print_form">
         @if(session()->has('message.level'))
          <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {!! session('message.content') !!}
          </div>
         @endif 
         <h4> {{ trans('consent_form.address_field_1') }}<br>
            {{ trans('consent_form.address_field_2') }}<br>
            {{ trans('consent_form.address_field_3') }}
         </h4>
         <h2>{{ trans('consent_form.informed_consent') }}</h2>
         <p class="consent_sign_date"> {{ trans('consent_form.patient_name') }}*:
            <!-- <input type="text" value='' readonly="">  -->
            <b>{{ $patient->first_name ? $patient->first_name : "-"}} {{ $patient->last_name ? $patient->last_name : ""}}</b>
            <button class="btn btn-primary basic-btn open_signature_modal non-print" data-type="signature_setup" <?php if($patient->consent_form_signature_setup) echo 'style="display:none;"'; ?>>{{ trans('consent_form.setup_signature') }}</button>
            <span class="signature-view signature_setup_preview non-print" <?php if(!$patient->consent_form_signature_setup) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('consent_form_signature_setup')  !!}
               @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                 <i class="fa fa-pencil-alt open_signature_modal non-print" data-type="signature_setup" data-save_type="edit"></i>
               @endif
            </span>
            <span class="fa-pull-right">{{ trans('consent_form.date') }}:
              @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                  <b>{{ @$patient_form_data['consent_form_date'] ? date_format_change(@$patient_form_data['consent_form_date']):"-" }}</b>
              @else
                <b class="consent_form_date"></b>
                <span class="error" style="color:red"></span>
              @endif
            </span>
          </p>
         <br/>

         <!-- First Acknowledge -->
         <p class="big">{{ trans('consent_form.receive_services') }} </p>
        <div class="signature-setup ack-signature-view" style="float: right;">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="receive_services" <?php if($patient->consent_form_signature_setup) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview receive_services_preview" <?php if(!$patient->consent_form_signature_setup) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('acknowledge_receive_services', 0)  !!}
               @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                 <i class="fa fa-times unacknowledge non-print" data-type="receive_services"></i>
               @endif
            </span>
         </div>
         <p> {{ trans('consent_form.authorize_paragraph') }} </p>

         <!-- Second Signature paragraph -->
         <p class="big"> {{ trans('consent_form.authorization_paragraph') }}</p>
         <div class="signature-setup ack-signature-view" style="float: right;">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="emergency_medical_services" <?php if(@$patient_form_data['acknowledge_emergency_medical_services']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview emergency_medical_services_preview" <?php if(!@$patient_form_data['acknowledge_emergency_medical_services']) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('acknowledge_emergency_medical_services', 0)  !!}
               @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                 <i class="fa fa-times unacknowledge non-print" data-type="emergency_medical_services"></i>
               @endif
            </span>
         </div>
         <p> {{ trans('consent_form.receiving_services_paragraphp') }}</p>

         <!-- Third Signature paragraph -->
         <p class="big"> {{ trans('consent_form.medical_records') }}</p>
         <div class="signature-setup ack-signature-view">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="release_medical_records" <?php if(@$patient_form_data['acknowledge_release_medical_records']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview release_medical_records_preview" <?php if(!@$patient_form_data['acknowledge_release_medical_records']) echo 'style="display:none;"'; ?>>
              <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
              {!! Form::hidden('acknowledge_release_medical_records', 0)  !!}
              @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                <i class="fa fa-times unacknowledge non-print" data-type="release_medical_records"></i>
              @endif
            </span>
         </div>
         <p> {{ trans('consent_form.medical_records_paragraph') }}  </p>
         <p> {{ trans('consent_form.release_copies_medical_services_paragraph') }} </p>
         

         <!-- Fourth Signature paragraph -->
         <p class="big">{{ trans('consent_form.vehicle_release') }} </p>
         <div class="signature-setup ack-signature-view">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="release_vehicle" <?php if(@$patient_form_data['acknowledge_release_vehicle']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview release_vehicle_preview" <?php if(!@$patient_form_data['acknowledge_release_vehicle']) echo 'style="display:none;"'; ?>>
              <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
              {!! Form::hidden('acknowledge_release_vehicle', 0)  !!}
              @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                <i class="fa fa-times unacknowledge non-print" data-type="release_vehicle"></i>
              @endif
            </span>
         </div>
         <p>{{ trans('consent_form.vehicle_release_paragraph') }} </p>
         

         <!-- Fifth Signature paragraph -->
         <p class="big">{{ trans('consent_form.patient_bill_right') }} </p>
         <div class="signature-setup ack-signature-view">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="patient_bill_of_rights" <?php if(@$patient_form_data['acknowledge_patient_bill_of_rights']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview patient_bill_of_rights_preview" <?php if(!@$patient_form_data['acknowledge_patient_bill_of_rights']) echo 'style="display:none;"'; ?>>
              <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
              {!! Form::hidden('acknowledge_patient_bill_of_rights', 0)  !!}
              @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                <i class="fa fa-times unacknowledge non-print " data-type="patient_bill_of_rights"></i>
              @endif
            </span>
         </div>
         <p> {{ trans('consent_form.patient_bill_right_paragraph') }}</p>
         <p class="big">{{ trans('consent_form.patient_rights_checkbox') }} </p>
         <p class="form_radio">{{ trans('consent_form.i_certify') }} &nbsp; {{ Form::radio('consent_form_living_will_executed', 'yes', @$patient_form_data['consent_form_living_will_executed'] == "yes" ? true : false,['class'=>'customradio']) }} {{ trans('consent_form.have_executed') }} &nbsp; {{ Form::radio('consent_form_living_will_executed', 'no',@$patient_form_data['consent_form_living_will_executed'] == "no" ? true : false,['class'=>'customradio']) }} {{ trans('consent_form.living_will') }} </p>
          <span class="error" style="color:red"></span>
         <p class="form_radio">{{ trans('consent_form.i_certify') }} &nbsp; {{ Form::radio('consent_form_dpoa_executed', 'yes', @$patient_form_data['consent_form_dpoa_executed'] == "yes" ? true : false,['class'=>'customradio']) }} {{ trans('consent_form.have_executed') }} &nbsp;
          {{ Form::radio('consent_form_dpoa_executed', 'no', @$patient_form_data['consent_form_dpoa_executed'] == "no" ? true : false,['class'=>'customradio']) }}
          {{ trans('consent_form.power_of_attorney') }} 
          </p>
         <span class="error" style="color:red"></span>
         <p> {{ trans('consent_form.DPOA_name') }}*:&nbsp;
           
              @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                 {!! Form::text('consent_form_dpoa_name', @$patient_form_data['consent_form_dpoa_name'],['readonly'=>true]) !!}
              @else
                 {!! Form::text('consent_form_dpoa_name', $patient->advance_healthcare_attorney_name,['class' => '']) !!}
            @endif
          </p>
         <p>{{ trans('consent_form.phone_number') }}*:

           @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                 {!! Form::text('consent_form_dpoa_phone_number', @$patient_form_data['consent_form_dpoa_phone_number'],['class' => 'set_phone_format','readonly'=>true]) !!}
              @else
                 {!! Form::text('consent_form_dpoa_phone_number', $patient->advance_healthcare_attorney_phone,['class' => 'set_phone_format']) !!}
            @endif
          </p>
          {!! Form::hidden('consent_form_signature_date',@$patient_form_data['consent_form_signature_date'],['class' => 'consent_form_date']) !!}
          {!! Form::hidden('consent_form_date', @$patient_form_data['consent_form_date'],['class' => 'consent_form_date']) !!}
         <p>{{ trans('consent_form.located_at_paragraph') }}
          @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
            * <input name="consent_form_documents_located_at_with" type="text" value="{{ @$patient_form_data['consent_form_documents_located_at_with'] }}">
          @else
            &nbsp;<b><i>{{  @$patient_form_data['consent_form_documents_located_at_with'] ? @$patient_form_data['consent_form_documents_located_at_with']:"-" }}</i></b>
          @endif
         </p>
         <span class="error" style="color:red"></span>
         
         <p>{{ trans('consent_form.advance_directives_paragraph') }} </p>
         <p class="big">{{ trans('consent_form.assistance_with_medications') }} </p>
         <p>{{ trans('consent_form.unlicensed_person_paragraph') }} </p>
         <div class="row patient-client-initial">
            <div class="col-md-4 col-xl-6">
               <p>{{ trans('consent_form.signature') }}*:</p>
               <div class="signature-setup">
                  <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="signature" <?php if(@$patient_form_data['acknowledge_signature']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
                  <span class="error" style="color:red"></span>
                  <span class="signature-view acknowledgement_preview signature_preview" <?php if(!@$patient_form_data['acknowledge_signature']) echo 'style="display:none;"'; ?>>
                  <img src="{{ $patient->consent_form_signature_setup }}" class="sign-img">
                  {!! Form::hidden('acknowledge_signature', 0)  !!}
                  @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                    <i class="fa fa-times unacknowledge non-print " data-type="signature"></i>
                  @endif
                  </span>
               </div>
            </div>
            <div class="col-md-8 col-xl-6">
              
              <p class="fa-pull-right">{{ trans('consent_form.date') }}:
                @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                  <b>{{ @$patient_form_data['consent_form_signature_date'] ? date_format_change(@$patient_form_data['consent_form_signature_date']) :"-" }}</b>
                @else
                  <b class="consent_form_date"></b>
                  <span class="error" style="color:red"></span>
                @endif
              </p>
              
              <div class="clearfix"></div>
              
              <p class="fa-pull-right">{{ trans('consent_form.patient_client_initials') }}
                @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
                  *: <input name="consent_form_patient_initials" type="text" value="{{  @$patient_form_data['consent_form_patient_initials'] }}" maxlength="10">
                  <span class="error" style="color:red"></span>
                @else
                  :&nbsp;<b>{{ @$patient_form_data['consent_form_patient_initials'] ? @$patient_form_data['consent_form_patient_initials']:"-" }}</b>
                @endif
              </p>
            </div>
         </div>
       </div>  
         <div class="personliving non-print">
            <div class="buttonsbottom">
              @if($patient->consent_form_signature_setup != null && $patient->consent_form_signature_setup != '')
                <a href="{{ route('registration_patient_view', encrypt($patient->id)) }}"  class="close">{{ trans('label.close') }}</a> 
              @else
                <button  class="next" type="button" onClick="javascript:save_consent_form()" data-toggle="modal" data-target="#exampleModal">{{ trans('label.save') }}</button>
                <a href="{{ route('registration_patient_view', encrypt($patient->id)) }}"  class="close">{{ trans('label.cancel') }}</a>
              @endif
            </div>
         </div>
      </div>
   </div>
 
   {!! Form::close() !!}
</div>



<!-- signModal -->
@if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
  <div class="modal fade" id="signModal" tabindex="-1" role="dialog" aria-labelledby="signModalLabel" aria-hidden="true">
   <input type="hidden" value="" name="signature_type">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <div class="headingpage">{{ trans('consent_form.patient_digital_signature') }}</div>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
       </div>
       <div class="modal-body">
           <div class="row">
              <div class="col-sm-12">
                 <label>{{ trans('consent_form.patient_sign_in_box') }}</label>
                 <div class="sign-box">       
                    <canvas style="touch-action: none;" width="500px" height="100px"></canvas>
                 </div>
                 <span class="updating_signature_notice" style="font-size:12px;display:none;">{{ trans('consent_form.updating_signature_notice') }}</span>
                 <span class="error" style="color:red;display:none;"></span>
               </div>
           </div>
        </div>
       <div class="modal-footer">
         <div class="buttonsbottom"> 
           <a href="#" class="next add_signature_btn">{{ trans('consent_form.add_signature') }}</a> 
           <a href="#" data-dismiss="modal"  class="close">{{ trans('label.cancel') }}</a> </div>
           <a href="#" class="btn btn-info clear_signature">{{ trans('consent_form.clear') }}</a> </div>
       </div>
     </div>
   </div>
@endif

<!-- Acknowledge Modal -->
@if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
  <div class="modal fade" id="acknowledgeModal" tabindex="-1" role="dialog" aria-labelledby="signModalLabel" aria-hidden="true">
   <input type="hidden" value="" name="signature_type">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <div class="headingpage">{{ trans('consent_form.patient_digital_signature') }}</div>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
       </div>
       <div class="modal-body">
           <div class="row">
              <div class="col-sm-12">
                 <label>{{ trans('consent_form.patient_sign_in_box') }}</label>
                 <div class="sign-box">       
                    <canvas style="touch-action: none;" width="500px" height="100px"></canvas>
                 </div>
                 <span style="font-size:12px;">{{ trans('consent_form.acknowledge_signature_notice') }}</span>
               </div>
           </div>
        </div>
       <div class="modal-footer">
          <div class="buttonsbottom"> 
           <a href="#" class="next acknowledge_signature_btn">{{ trans('consent_form.acknowledge') }}</a> 
           <a href="#" data-dismiss="modal"  class="close">{{ trans('label.cancel') }}</a> 
          </div>
        </div>
      </div>
    </div>
  </div>
@endif

@endsection

@section('script')
<script src="{{ asset('js/signature.js') }}" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){ 
   $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
   var signatureCanvas = document.querySelector("#signModal canvas");
   var acknowledgeCanvas = document.querySelector("#acknowledgeModal canvas");

   var signaturePad = new SignaturePad(signatureCanvas, {
      backgroundColor : "rgba(255, 255, 255, 0)"
   });   

   var acknowledgePad = new SignaturePad(acknowledgeCanvas, {
      backgroundColor : "rgba(255, 255, 255, 0)"
   });

   const monthNumbers = ["01", "02", "03", "04", "05", "06",
           "07", "08", "09", "10", "11", "12"
  ];

   var currentdate = new Date(); 
   var current_date = monthNumbers[currentdate.getMonth()] + "-"
                + ("0" + currentdate.getDate()).slice(-2) + "-" 
                + currentdate.getFullYear();
  $('.consent_form_date').text(current_date);
  $('input.consent_form_date').val(current_date);
   //signaturePad.fromDataURL("{{ $patient->consent_form_signature_setup }}");
      
   //save signature
  $('body').on('click', '.add_signature_btn', function(e) {
    e.preventDefault();
    if(signaturePad.isEmpty()){
      $("#signModal span.error").html('Please do signature first.').show();
    }else{
    // $.ajax({
    //      url:"{{ route('save_consent_form_signature') }}",
    //      type:"POST",
    //      data:{patient_id:"{{ encrypt($patient_id) }}", signature_setup : signaturePad.toDataURL()},
    //      dataType: "json",
    //      success:function(data){
    //         if($(".setup_signature_preview").is(':visible'))
    //            $('.setup_signature_preview').find('img').attr('src', signaturePad.toDataURL());
    //        $("#signModal").modal('hide');
    //      },
    //      error:function(data){
    //        alert('error');
    //      }
    //   });
        var sig_type = $("#signModal input[type=hidden]").val();

        $("."+sig_type+"_preview").parent().find('button.open_signature_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(signaturePad.toDataURL());
        $("."+sig_type+"_preview").show();
        
        //unacknowledge all acknowledgements if any
        $('button.open_acknowledge_modal').show();
        $("span.acknowledgement_preview").find('img').attr('src', '');
        $("span.acknowledgement_preview").find('input[type=hidden]').val(0);
        $("span.acknowledgement_preview").hide();

        $("#signModal").modal('hide');
    }
   });    

   //save signature
  $('body').on('click', '.acknowledge_signature_btn', function(e) {
    e.preventDefault();
    if(acknowledgePad.isEmpty()){
      $("#acknowledgeModal span.error").html('Please do signature first.').show();
    }else{

        var sig_type = $("#acknowledgeModal input[type=hidden]").val();
        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(1);
        $("."+sig_type+"_preview").show();
        
        $("#acknowledgeModal").modal('hide');
    }
   });      

   //clear signature
   $('body').on('click', '.clear_signature', function(e) {
      e.preventDefault();
      signaturePad.clear();
   });   

   //open signature modal
   $('body').on('click', '.open_signature_modal', function(e) {
      e.preventDefault();
      $("#signModal span.error").html('').hide();
      signaturePad.clear();

      if($('.signature_setup_preview').is(':visible'))
        signaturePad.fromDataURL($('.signature_setup_preview').find('img').attr('src'));

      if($(this).data('save_type') && $(this).data('save_type') == 'edit'){
          $("#signModal").find('.headingpage').text('Edit signature'); 
          $("#signModal").find('.add_signature_btn').text('Update signature'); 
          $("#signModal").find('span.updating_signature_notice').show(); 
      }
      else {
        $("#signModal").find('span.updating_signature_notice').hide(); 
        $("#signModal").find('.headingpage').text('{{trans("consent_form.patient_digital_signature")}}'); 
        $("#signModal").find('.add_signature_btn').text('{{trans("consent_form.add_signature")}}'); 
      }

      $("#signModal input[type=hidden]").val($(this).data('type'));
      $("#signModal").modal({backdrop: 'static', keyboard: false});


   });   

   //open achnowledge modal
   $('body').on('click', '.open_acknowledge_modal', function(e) {
      e.preventDefault();
      acknowledgePad.off();
      acknowledgePad.clear();

      if(signaturePad.isEmpty()){
        bootbox.alert("{{ trans('consent_form.add_setup_signature') }}");
      }
      else
      {
        // commented code to dont show the modal box to confirm the signature acknowledge
      /*  acknowledgePad.fromDataURL($('.signature_setup_preview').find('img').attr('src'));
        $("#acknowledgeModal input[type=hidden]").val($(this).data('type'));
        $("#acknowledgeModal").modal({backdrop: 'static', keyboard: false}); */


        var sig_type = $(this).data('type');
        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(1);
        $("."+sig_type+"_preview").show();

      }
   }); 

   //open signature modal
   @if($patient->consent_form_signature_setup == null || $patient->consent_form_signature_setup == '')
     $('body').on('click', '.unacknowledge', function(e) {
        var sig_type = $(this).data('type');

        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').show();
        $("."+sig_type+"_preview").find('img').attr('src', '');
        $("."+sig_type+"_preview").find('input[type=hidden]').val(0);
        $("."+sig_type+"_preview").hide();
     });
   @endif
});

function save_consent_form(){
  $("span.error").html('').hide();
  $(".set_phone_format").inputmask('remove');
  var formData = new FormData($('#save_consent_form')[0]);
  $.ajax({
     url:"{{ route('registration_cm_patient_consent_save') }}",
     type:"POST",
     data:formData,
     processData: false,
     contentType: false,
     dataType: "json",
     success:function(data){
        window.location.href="{{ route('registration_patient_view', encrypt($patient->id)) }}";
     },
     error:function(error){
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        var errorHtml= '<div class="alert alert-danger alert-dismissible"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>';
        $.each(error.responseJSON.errors,function(key,value){
          errorHtml+='<li>'+value+'</li>';
          /*if(key == 'consent_form_signature_setup' || key == 'consent_form_signature_for_authorization' || key == 'consent_form_signature_for_release' || key == 'consent_form_signature_for_vehicle' || key == 'consent_form_signature')
          {
            $('input[name="'+key+'"]').parent().parent().find('span.error').html(value).addClass('active').show();
          }
          else if(key == 'consent_form_dpoa_executed' || key == 'consent_form_living_will_executed' || key == 'consent_form_documents_located_at_with')
          {
            $('input[name="'+key+'"]').parent().next('span.error').html(value).addClass('active').show();
          }
          else
          {
            $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
          }*/

        });
        errorHtml+='</div>';
        $('#print_form').prepend(errorHtml);
       // console.log(errorHtml);

        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('#print_form').parent().offset().top
        }, 500);

        fadeOutAlertMessages();

      }
  });
}

$('form#save_consent_form input').bind("change", function() {
    var val = $(this).val();
    $(this).attr('value',val);
});


function printDiv(divName) {
  $(".set_phone_format").inputmask('remove');
  jcf.destroyAll();
  // $('input[name=consent_form_dpos_phone_number]').val('xcfxfzsdsdsdsd')

  //    var printContents = document.getElementById(divName).innerHTML;
  //    var originalContents = document.body.innerHTML;

  //    document.body.innerHTML = printContents;

     window.print();

  //    document.body.innerHTML = originalContents;

  // var DocumentContainer = document.getElementById('print_form');
  //   var WindowObject = window.open('', "PrintWindow", "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
  //   WindowObject.document.writeln(DocumentContainer.innerHTML);
  //   WindowObject.document.close();
  //   WindowObject.focus();
  //   WindowObject.print();
  //   WindowObject.close();
   initCustomForms();
}

 $(".langauge_changed").on("change", function() { 
    
    var url = new URL(window.location.href);
    var query_string = url.search;
    var search_params = new URLSearchParams(query_string); 
    search_params.set('lang', this.value);
    url.search = search_params.toString();
    var new_url = url.toString();
    window.location.href = new_url;
      
  });
</script>
@endsection