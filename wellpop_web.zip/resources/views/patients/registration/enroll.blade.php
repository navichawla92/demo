@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{trans('label.patient_registration')}}
@endsection

@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.enrolment_decision') }}
         </div>
      </div>
   </div>
   <div class="tab-content">
      <div class="patient-detail">
         <div class="subdataofpatient">
            <div class="width50ofname">
               <label>{{ trans('label.registration_number') }}:</label>
               <span class="namelabel">{{$patient->registration_number}}</span>
            </div>
         </div>
      </div>
      <div class="clearfix"></div>
      <div class="personliving">
         @if ($errors->any())
            <div class="alert alert-danger alert-dismissible">
               <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <ul>
                  @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                  @endforeach
              </ul>
            </div>
         @endif

         {!! Form::open(array('route' => array('registration_cm_patient_enroll_consent', encrypt($patient->id)),'method' => 'GET','id' => 'registration_cm_patient_enroll_consent')) !!}
         <input type="hidden" name="patient_id" value="{{ encrypt($patient->id) }}">
         <p class="headingpage buttonmargin margnbootom">{{ trans('label.patient_decision') }} </p>
         <div class="clearfix"></div>
         <div class="row check-body refuse-margin">
            <div class="col-md-3 col-xl-2">
               <div class="checkdiv">
                  <input type="radio" name="accept_or_refused_patient_decision" class="customradio" value="yes">
                  <label>{{ trans('label.agreed') }}</label>
               </div>
            </div>
            <div class="col-md-3 col-xl-2">
               <div class="checkdiv">
                  <input type="radio" name="accept_or_refused_patient_decision" class="customradio" value="refused">
                  <label>{{ trans('label.refused') }}</label>
               </div>
            </div>
         </div>
         <div class="row accept_btn_section">
            <div class="col-sm-10">
               <div class="buttonsbottom">
                  <button type="submit" class="next patient_accept_continue">{{ trans('label.continue') }}</button>
                  <a href="{{ route('registration_patient_view', encrypt($patient->id)) }}" class="close">{{ trans('label.cancel') }}</a> 
               </div>
            </div>
         </div>
         {!! Form::close() !!}
      </div>
      <div class="personliving refusal_section">
         <!-- dynamically field will added here if user selects refused -->
         <div class="clearfix"></div>
          <p class="headingpage buttonmargin margnbootom">{{ trans('label.patient_refusel_history') }}</p>
          <div class="clearfix"></div>
          <div class="table-responsive care-table refusal_listing_table">
             <table class="table">
                <thead>
                   <tr>
                      <th>{{ trans('label.serial_number_short_form') }}</th>
                      <th>{{ trans('label.refuse_date') }}</th>
                      <th>{{ trans('label.reason') }}</th>
                      <th>{{ trans('label.added_by') }}</th>
                      <th>{{ trans('label.view_reason') }}</th>
                   </tr>
                </thead>
                <tbody>
                   @if(count($previous_refusal))
                      <?php  $index=($previous_refusal->perPage() * ($previous_refusal->currentPage()- 1))+1; ?>
                      <?php  $color_array = ['name-green','name-voilet','name-red','name-light',]; $i = 0;?>
                      @foreach($previous_refusal as $refusal)
                      <tr>
                         <td>{{$index}}</td>
                         <td>{{ $refusal->created_at }}</td>
                         <td>{{ $refusal->comment }}</td>
                         <td>{{ $refusal->user->name }}</td>
                         <td>
                            <div class="dropdown more-btn">
                               <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <span>...</span>
                               </button>
                               <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                  <a href="#" data-refusal_date="{{ $refusal->created_at }}"
                                  data-user_name="{{ $refusal->user->name }}" data-reason_for_refusal="{{ $refusal->comment }}" class="dropdown-item view_refusal">
                                    <i class="fa fa-eye"></i> {{ trans('label.view') }}
                                  </a>
                               </div>
                            </div>         
                         </td>
                      </tr>
                      <?php  $index++; ?>
                      @endforeach
                      @else
                         <tr><td>No record found</td></tr>
                      @endif
                </tbody>
             </table>
          </div>
          <?php echo $previous_refusal->render(); ?>
      </div>
   </div>
</div>

<div class="modal fade" id="refuselModal" tabindex="-1" role="dialog" aria-labelledby="refuselModalLabel" style="display: none;">
   <div class="modal-dialog" role="document">
      <div class="modal-content info-modal refuse-modal">
        <div class="modal-header">
          <h4>{{ trans('label.view_reason_for_refusal') }}</h4>
        </div>
        <div class="modal-body patient-info">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <p>{{ trans('label.refuse_date') }}:<span class="refusal_date">02 July 2018</span></p>
                <p>{{ trans('label.added_by') }}:<span class="user_name">John Smith </span></p>
              <hr>
                <p>{{ trans('label.reason_for_refusal') }}:<span class="refuse-reason reason_for_refusal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus scelerisque porttitor velit. Phasellus sed dolor nec eros semper accumsan. Etiam sit amet elit eget nunc sollicitudin porttitor sed quis justo. Nulla urna tellus, pretium in justo nec, auctor iaculis tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nulla finibus quam quis dictum egestas. Cras est erat, consectetur aliquam nisi vel, efficitur gravida enim.</span></p>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom"><a href="#" class="close" data-dismiss="modal" aria-label="Close">{{ trans('label.close') }}</a> </div>
        </div>
      </div>
   </div>
</div>

@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function(){ 
  applpyEllipses('care-table', 3, 'no');  
  fadeOutAlertMessages();
  
   $(document).on('click', '.save_new_patient_refusal_reason', function() {
      $(this).attr("disabled", "disabled");
      //get previous refusal listing from another view and append here
      $.ajax({
         url:"{{ route('add_new_refused_entry') }}",
         type:"POST",
         data: {patient_id:$('input[type=hidden][name=patient_id]').val(), comment : $('textarea[name=comment]').val()},
         dataType: "json",
         success:function(data){
           // changes to move to edit profile screen after save a refusal
         //  $(".refusal_section").html(data.html); 
           window.location.href="{{ route('registration_patient_view', encrypt($patient->id)) }}";
           applpyEllipses('care-table', 3, 'no');             
         },
         error:function(error){
             $('.save_new_patient_refusal_reason').attr("disabled", false);
            //console.log(error.responseText);
            // console.log(error.responseJSON);
            $('body').waitMe('hide');

            $.each(error.responseJSON.errors,function(key,value){
               $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            }); 
         }
     }); 
   });   

   //when user click on view refusal history record the open pop-up and fill values
   $(document).on('click', '.view_refusal', function(e) {
      e.preventDefault();
      $('#refuselModal').modal('show');
      $('.refusal_date').text($(this).data('refusal_date'));
      $('.user_name').text($(this).data('user_name'));
      $('.reason_for_refusal').html('<pre>'+$(this).data('reason_for_refusal')+'</pre>'); 
     // $('.reason_for_refusal').text($(this).data('reason_for_refusal'));  
   });

   //enable listing
   $('body').on('click', '.pagination a', function(e) {
      e.preventDefault();
      var url = "{{ route('get_previous_refused_listing', [encrypt($patient->id)]) }}"+'?page='+ $(this).text();
      var patient_id = $('input[type=hidden][name=patient_id]').val();
      $.ajax({
          url:url,
          type:"GET",
          data:{patient_id:patient_id},
          dataType: "json",
              success:function(data){
                $(".refusal_section").html(data.html);
              },
              error:function(data){
                alert('error');
                 }
         });
   });


   // changes for countinue button click for sign consent form flow changes
   $(document).on('click', '.patient_accept_continue', function(e) {
      e.preventDefault();
      if($("input[name=accept_or_refused_patient_decision]:checked").val() == 'refused'){
         //hide continue btn which is only for accept option
         $('.accept_btn_section').hide();
         $('.alert-danger').hide();
         $('input[name=accept_or_refused_patient_decision]').attr('disabled', true);
         //get previous refusal listing from another view and append here
         $.ajax({
            url:"{{ route('get_previous_refused_listing', encrypt($patient->id)) }}",
            type:"GET",
            data: {patient_id:$('input[type=hidden][name=patient_id]').val()},
            dataType: "json",
            success:function(data){
              $(".refusal_section").html(data.html);       
              applpyEllipses('care-table', 3, 'no');       
            },
            error:function(data){
               alert("Oops! Some error!!");
            }
        }); 
      }
      else {
        $('form#registration_cm_patient_enroll_consent').submit(); 
      }
      
      
   });


 });
</script>
@endsection
