@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{ trans('label.patient_registration') }}
@endsection

@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>Patient Assessment
         </div>
      </div>
   </div>
   <div class="tabsmain">
      <div class="row">
         <div class="col-md-8">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
               <li class="nav-item"> <a class="nav-link" id="patientinfo-tab" href="#patientinfo" role="tab" aria-controls="home" aria-selected="true">Advanced Directive</a> </li>
               <li class="nav-item"> <a class="nav-link" id="concern-tab" data-toggle="tab" href="#concern" role="tab" aria-controls="profile" aria-selected="false">Home Safety Evaluation</a> </li>
               <li class="nav-item"> <a class="nav-link" id="assessment-tab" data-toggle="tab" href="#assessment" role="tab" aria-controls="assessment" aria-selected="false">CM Assessment</a> </li>
            </ul>
         </div>
         <div class="col-md-4 smalltextunderheading paddingbtm15">
            <div class="document-notetabs">
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'document')?'active':'' }}" id="document-tab" href="#document" role="tab" data-toggle="tab" aria-controls="contact" aria-selected="false">Documents</a> </li>
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'note')?'active':'' }}" id="note" data-toggle="tab" href="#notes" role="tab" aria-controls="contact" aria-selected="false">Notes</a> </li>
               </ul>
            </div>
         </div>
      </div>
      <div class="tab-content" id="myTabContent">
         <div class="patient-detail">
            <div class="subdataofpatient">
               <div class="width50ofname">
                  <label>{{ trans('label.registration_number') }}:</label>
                  <span class="namelabel">{{$patient->registration_number}}</span>
                  <div class="addnewdetail"><a data-toggle="modal" data-target="#detailModal" class="viewDetail" data-mod>{{ trans('label.view_detail') }}</a></div>
               </div>
            </div>
         </div>
         <div class="tab-pane fade" id="patientinfo" role="tabpanel" aria-labelledby="home-tab">
            @include('patients.registration.advanced_directive_tab')
         </div>
         <!--	second tab	-->
         <div class="tab-pane fade" id="concern" role="tabpanel" aria-labelledby="profile-tab">
            @include('patients.registration.home_safety_evaluation_tab')
         </div>
         <!--fourth tab-->
         <div class="tab-pane fade" id="assessment" role="tabpanel" aria-labelledby="contact-tab">
            @include('patients.registration.assessment_comments_tab')
         </div>
         <!--document	-->
         <div class="tab-pane fade {{ ($active_tab == 'document')?'active show':'' }}" id="document" role="tabpanel" aria-labelledby="contact-tab">
            @include('patients.common.patient_documents_tab')
         </div>
         <!--notes	-->
         <div class="tab-pane fade {{ ($active_tab == 'note')?'active show':'' }}" id="notes" role="tabpanel" aria-labelledby="contact-tab">
             @include('patients.common.patient_notes_tab')
         </div>
      </div>
   </div>
</div>
@endsection

@section('common_script')
  @include('patients.common.common_script')
@endsection  
