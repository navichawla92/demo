@extends('layouts.app')

@section('css')
<link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
@endsection

@section('title')
 {{trans('label.patient_registration')}}
@endsection

@section('content')
<div class="leftsectionpages">
	<div class="row">
		<div class="col-md-6 col-4">
			<div class="headingpage"> {{trans('label.patient_registration')}} </div>
		</div>
	</div>



	<div class="top-search register-search">
		<form method="POST" id="patient-filter-form" action="{{ route('patient-filter') }}">	
			@csrf
			<ul>
				<li><input type="text" placeholder="{{trans('label.search_patients')}}" class="refernce_number" name="refernce_number" disabled=""></li>
				<li>
					{!! Form::select('status', [''=>'Status','0'=>'New','1'=>'Incomplete','2'=>'Complete','3'=>'Rejected'], $filter_status, ['class' => 'status_filter customselect']) !!}
				</li>
				<li title="{{ trans('label.community_health_worker') }}"> 
					{!! Form::select('selected_chw', $chw_users, $selected_chw, ['placeholder' => 'CHW', 'class' => 'role_filter customselect']) !!}
				</li>
				<li title="{{trans('label.case_manager')}}">
					{!! Form::select('selected_cm', $cm_users, $selected_cm, ['placeholder' => 'CM', 'class' => 'role_filter customselect']) !!}
				</li>
				<li title="{{trans('label.mediacal_director')}}">
					{!! Form::select('selected_md', $md_users, $selected_md, ['placeholder' => 'MD', 'class' => 'role_filter customselect']) !!}
				</li>
				<li class="date-box">
					<input type="text" placeholder="{{trans('label.reg_from')}}" name="from_date" class="from_date" value="{{ $filter_from_date }}" readonly>
					<img src="{{ asset('images/calendaradd.png') }}" alt="">
				</li>
				<li class="date-box">
					<input type="text" placeholder="{{trans('label.reg_to')}}" name="to_date" class="to_date" value="{{ $filter_to_date }}" readonly>
					<img src="{{ asset('images/calendaradd.png') }}" alt="">
				</li>
				<li>
					<button href="#" class="btn btn-primary basic-btn" disabled=""><b> {{trans('label.search')}} </b></button>
					<a href="#" class="reset_all_filter"><b> {{trans('label.reset')}} </b></a>
				</li>
			</ul>
		</form>
	</div>
	

	<div class="table-responsive register-table referral_table {!! count($patients) < 4 ? 'fix_table_height' : '' !!}">
		@if(session()->has('message.level'))
		    <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		    	{!! session('message.content') !!}
		    </div>
		@endif  
		@include('patients.registration.registration_table')
	</div>	
	
</div>

</div>
@include('patients.registration.assignment_modal')
@include('patients.registration.enrollment_modal')
@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function(){

	//call common function to put ellipses
	applpyEllipses('register-table', 10, 'yes');

	fadeOutAlertMessages();

	$(".from_date").datepicker({
		autoclose: true,
		format: "mm-dd-yyyy",
		endDate: '-0d'
	}).on("changeDate", function (selected) {
		var minDate = new Date(selected.date.valueOf());
		$(".to_date").datepicker("setStartDate", minDate);
		ajaxListTable();
	});
	$(".to_date").datepicker({
		autoclose: true,
		format: "mm-dd-yyyy",
		endDate: '-0d'
	})
	.on("changeDate", function (selected) {
		var minDate = new Date(selected.date.valueOf());
		$(".from_date").datepicker("setEndDate", minDate);
		ajaxListTable();
	});
	$("select[name=status]").on("change", function() {
		ajaxListTable();
	});
	$(".role_filter").on("change", function() {
		ajaxListTable();
	});
	$(".searchstatus").on("keyup", ".refernce_number",function () {
		searchword = $(this).val();
		if ((searchword.length) >= 3) {
			ajaxListTable();
		}
	});

	$('body').on('click', '.pagination a', function(e) {
		e.preventDefault();
		var url = $(this).attr('href');  
		var data = $("#patient-filter-form").serialize();
		getPatients(url,data);
	});
	$('body').on('click', '.reset_all_filter', function(e) {
		e.preventDefault();
		$('.refernce_number').val('');
		$('.status_filter').val('');
		$('.role_filter').val('');
		$('.from_date').val('');
		$('.to_date').val('');
		initCustomForms();
		var url = "{{ route('registrations') }}";  
		var data = '';
		getPatients(url,data);
	});
	
}); 
var ajaxReq = null;
function ajaxListTable(){
	if (ajaxReq != null) ajaxReq.abort();
	var formData = new FormData($("#patient-filter-form")[0]);
	ajaxReq = $.ajax({
		url:"{{ route('registrations') }}",
		data:$("#patient-filter-form").serialize(),
		type:"GET",
		processData: false,
		contentType: false,
		dataType: "html",
		success:function(data){
			$(".referral_table").html(data);
			applpyEllipses('register-table', 10, 'yes');
			table_load();
		},
		error:function(data){
			$(".referral_table").html(data);
			applpyEllipses('register-table', 10, 'yes');
			table_load();
		}
	});
}

function getPatients(url,data) {
	$.ajax({
		url:url,
		type:"GET",
		data:data,
		processData: false,
		contentType: false,
		dataType: "html",
		success:function(data){
			$(".referral_table").html(data);
			applpyEllipses('register-table', 10, 'yes');
			table_load();
		    // $(".buttonpatient").attr('href',"{{ route('addPatient',['create',$patients->currentPage()]) }}")
		},
		error:function(data){
			$(".referral_table").html(data);
			applpyEllipses('register-table', 10, 'yes');
			table_load();
		}
	});
}

//Fill values in Assignment Modal before it fully opens
$(document).on('click', '.assignment_action_btn', function (e) {

	//set values of selected patient in assignment pop-up
	$.each($(this).data(), function(i, v) {
		if(i != 'assigned_chw' && i != 'assigned_cm' && i != 'assigned_md')
			$('#assignment_modal').find('.'+i).html(v);
		else
			$('#assignment_modal').find('.'+i).val(v);
	});

	//update jcf to show latest values
	initCustomForms();
	
	//set patient id in pop-up hidden field
	$('#registration_assignment_form input[type=hidden][name=patient_id]').val($(this).data('patient_id'));

   //now values are set so open the pop-up
   $('#assignment_modal').modal('show');
});

//Send request to save assignments
function assignments(){
  var formData = new FormData($('#registration_assignment_form')[0]);
  $.ajax({
    url:"{{ route('registration_assignment') }}",
    data:formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success:function(data){
      $('#assignment_modal').modal('hide');
      window.location.reload();
    },
    error:function(error){      
    	if(error.responseJSON.errors){
    		$.each(error.responseJSON.errors,function(key,value){
	            if(key == 'patient_concern')
	                $('#patient_concern_error').html(value).addClass('active').show();     
	            else
	            {
	               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
	               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
	           }
	        });	
    	}else{
    		window.location.reload();
    	}
                   
    }
  });
}


   //Fill values in Assignment Modal before it fully opens
function move_to_enrollment(){
     var formData = new FormData($('#enrollment_modal_form')[0]);
     
     $.ajax({
       url:"{{ route('patient_enrolled') }}",
       data:formData,
       processData: false,
       contentType: false,
       dataType: "json",
       success:function(data){
         $('#editAssignment').modal('hide');
         //window.location.reload();
         window.location.href="{{ route('patient-caseload') }}";
       },
       error:function(error){      
         if(error.responseJSON.errors){
            $.each(error.responseJSON.errors,function(key,value){
               $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
               $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();

            }); 
         }else{
            window.location.reload();
         }
                      
       }
     });
   }

   //Fill values in Assignment Modal before it fully opens
$(document).on('click', '.enroll_action_btn', function (e) {

	$('#enrollment_modal input[type=hidden][name=patient_id]').val($(this).data('id'));

    $('#enrollment_modal').modal('show');
});
</script> 
@endsection
