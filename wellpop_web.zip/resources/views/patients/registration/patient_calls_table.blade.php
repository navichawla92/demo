
<div class="personliving">
	 @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
	<p class="headingpage buttonmargin margnbootom"> {{trans('label.phone_call_widget')}}    <button class="btn btn-primary basic-btn" data-toggle="modal" data-target="#callModal"> {{trans('label.add_new_contact_entry')}} </button></p>
	<div class="clearfix"></div>
	<div class="table-responsive">

		<table class="table">
			<thead>
				<tr>
					<th>{{ trans('label.serial_number_short_form') }}</th>
					<th> {{ trans('label.contact_date_time') }} </th>
					<th> {{ trans('label.patient_agreement') }} </th>
					<th> {{ trans('label.assessment_date_time') }} </th>
					<th> {{ trans('label.action') }} </th>
				</tr>
			</thead>
			<tbody>
				@if(count($patient_calls))
				<?php  $index=($patient_calls->perPage() * ($patient_calls->currentPage()- 1))+1; ?>
				@foreach($patient_calls as $patient_call)
				<tr>
					<td>{{$index}}</td>
					<td>{{ $patient_call->contact_date ? $patient_call->contact_date . ' '. $patient_call->contact_time  : 'N/A' }}</td>
					<td>{{ ucfirst($patient_call->agree) }}</td>
					<td>{{ $patient_call->assessment_date ? $patient_call->assessment_date . ' '. $patient_call->assessment_time  : 'N/A' }}</td>

					<td>
						<div class="dropdown more-btn dropup">
							<button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<span>...</span>
							</button>
							<div class="dropdown-menu" aria-labelledby="dropdownMenu2" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -2px, 0px); top: 0px; left: 0px; will-change: transform;">
								@if($patient_call->agree == 'yes')
									<a href="#" data-id="{{$patient_call->id}}"
										data-created_time="{{ $patient_call->created_time }}" data-contact_agree="{{ ucfirst($patient_call->agree)}}" data-comment="{{$patient_call->comment}}" data-contact_date_time="{{ $patient_call->contact_date ? $patient_call->contact_date . ' '. $patient_call->contact_time  : '-' }}" data-assessment_date_time="{{ $patient_call->assessment_date ? $patient_call->assessment_date . ' '. $patient_call->assessment_time  : '-' }}" data-contact_location="{{$patient_call->location ? $patient_call->location : '-'}}" class="dropdown-item view_calls">
										<i class="fa fa-eye"></i> {{ trans('label.view') }}
									</a>
								@else
									<a href="#" data-id="{{$patient_call->id}}"
										data-created_time="{{ $patient_call->created_time }}" data-contact_agree="{{ ucfirst($patient_call->agree)}}" data-comment="{{$patient_call->comment}}" data-comment="{{$patient_call->comment}}" data-contact_date_time="{{ $patient_call->contact_date ? $patient_call->contact_date . ' '. $patient_call->contact_time  : '-' }}"  class="dropdown-item view_calls">
										<i class="fa fa-eye"></i> {{ trans('label.view') }}
									</a>
								@endif
							</div>
						</div>
					</td>

				</tr>
				<?php  $index++; ?>
				@endforeach
				@else
				<tr> <td>{{ trans('label.no_record_found') }} </td></tr>
				@endif
			</tbody>
		</table>
	</div>
</div>



<?php echo $patient_calls->render(); ?>

