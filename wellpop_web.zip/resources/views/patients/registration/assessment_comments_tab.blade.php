<div class="personliving">
               <div class="row">
                  <div class="col-md-6 col-6">
                     <div class="headingpage">Add Assessment</div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="qa-message-list" id="wallmessages">
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="message-head clearfix">
                           <div class="avatar fa-pull-left"><a href="./index.php?qa=user&qa_1=amiya"><img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a></div>
                           <div class="user-detail">
                              <h5 class="handle">amiya <span class="qa-message-when-data">Nov 24, 2013</span></h5>
                              <div class="qa-message-content">
                                 Integer vitae arcu vitae ligula Cras vestibulum suscipit odio ac dapibus. In hac habitasse platea dictumst. Cras pulvinar erat et nunc fringilla, quis molestie
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="message-head clearfix">
                           <div class="avatar fa-pull-left"><a href="./index.php?qa=user&qa_1=amiya"><img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a></div>
                           <div class="user-detail">
                              <h5 class="handle">amiya <span class="qa-message-when-data">Nov 24, 2013</span></h5>
                              <div class="qa-message-content">
                                 Nice theme . Excellent one .
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="message-head clearfix">
                           <div class="avatar fa-pull-left"><a href="./index.php?qa=user&qa_1=amiya"><img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a></div>
                           <div class="user-detail">
                              <h5 class="handle">amiya <span class="qa-message-when-data">Nov 24, 2013</span></h5>
                              <div class="qa-message-content">
                                 Nulla dui ante, pulvinar ac auctor vitae, sollicitudin et tortor. Cras vestibulum suscipit odio ac dapibus. In hac habitasse platea dictumst. Cras pulvinar erat et nunc fringilla, quis molestie diam pulvinar.
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="message-head clearfix">
                           <div class="avatar fa-pull-left"><a href="./index.php?qa=user&qa_1=amiya"><img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a></div>
                           <div class="user-detail">
                              <h5 class="handle">amiya <span class="qa-message-when-data">Nov 24, 2013</span></h5>
                              <div class="qa-message-content">
                                 Integer vitae arcu vitae ligula Cras vestibulum suscipit odio ac dapibus. In hac habitasse platea dictumst. Cras pulvinar erat et nunc fringilla, quis molestie
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="message-head clearfix">
                           <div class="avatar fa-pull-left"><a href="./index.php?qa=user&qa_1=amiya"><img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a></div>
                           <div class="user-detail">
                              <h5 class="handle">amiya <span class="qa-message-when-data">Nov 24, 2013</span></h5>
                              <div class="qa-message-content">
                                 Nice theme . Excellent one .
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="message-item" id="m9">
                     <div class="message-inner">
                        <div class="comment-box">
                           <div class="form-group">
                              <label>Add new Assessment</label>
                              <textarea class="form-control"></textarea>
                           </div>
                           <button class="btn btn-success" >Add Assessment</button>
                        </div>
                     </div>
                  </div>
               </div>
               <!--				list-end	-->
            </div>
            <div class="buttonsbottom comment-btn">
               <button class="next" >Save & Close</button>
               <button class="movetable" >Complete Assessment</button>
               <button type="button" class="reject reject_patient">Reject</button>
            </div>