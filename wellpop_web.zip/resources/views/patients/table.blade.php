<table class="table">
  <thead>
    <th> {{trans('label.patient_name')}} </th>
    <th data-toggle="tooltip" data-placement="top" title="{{trans('label.referral_number')}}"> {{trans('label.ref_no')}} </th>
    <th data-toggle="tooltip" data-placement="top" title="{{trans('label.referral_date')}}"> {{trans('label.ref_date')}} </th>
    <th> {{trans('label.source')}} </th>
    <th> {{trans('label.list_phone')}} </th>
    <th> {{trans('label.encounters')}} </th>
    <th> {{trans('label.status')}} </th>
    <th> {{trans('label.action')}} </th>
  </thead>
  <tbody>
    @if(count($patients))
    <?php  $color_array = ['name-green','name-voilet','name-red','name-light',]; $i = 0;?>
          @foreach($patients as $patient)
    <tr>
      <?php
      $patient->calc($patient->random_key);      
      $name = '';
      $name .= $patient->first_name ? ucfirst($patient->first_name) : '-';
      $name .= ' ';
      $name .= $patient->last_name ? ucfirst($patient->last_name) : '-';
      ?>      
      <td title="{{ $name }}"><a href="{{ $patient->casestatusvalue != 3 ? route('addPatient',['edit',$patients->currentPage(),\Crypt::encrypt($patient->id)]) : 'javascript:;'}}"> <span class="name-circle <?php echo "referral_status_color_".$patient->case_status_value; ?>">{{ $patient->first_name ? substr($patient->first_name,0,1) : "-"}}{{ $patient->last_name ? substr($patient->last_name,0,1) : ""}}</span>{{ $name }} </a></td>
      <td>{{ $patient->case_number }}</td>
      <td>{{ $patient->created_at }}</td>
      <td>{{ $patient->refernce->org_name ? $patient->refernce->org_name : "-" }}</td>
      <td>{{ $patient->phone ? $patient->phone : "-"}}</td>
      <td style="padding-left: 20px;">1</td>
      <td>{!! $patient->case_status_badge !!}</td>
      <td>
        <div class="dropdown more-btn">
          <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span>...</span>
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            <?php
              if($patient->casestatusvalue == 3){
                ?>
                <a href="#" class="dropdown-item"><i class="far fa-eye"></i> {{trans('label.view')}} </a> 
                <a href="#" class="dropdown-item"><i class="fas fa-sync-alt"></i> {{trans('label.restore')}} </a>
              <?php 
              }
              else{

              ?>
               <a href="{{ route('addPatient',['edit',$patients->currentPage(),\Crypt::encrypt($patient->id)]) }}" href="#" class="dropdown-item"><img src="{{ asset('images/edit.png') }}" alt=""/> {{trans('label.edit')}} </a> 
               <a href="{{ route('addPatient',['edit',$patients->currentPage(),\Crypt::encrypt($patient->id),'notes']) }}" class="dropdown-item"><img src="{{ asset('images/comment.png') }}" alt=""/>{{trans('label.notes')}} </a> 
               <a href="{{ route('addPatient',['edit',$patients->currentPage(),\Crypt::encrypt($patient->id),'document']) }}" class="dropdown-item"><img src="{{ asset('images/file.png') }}" alt=""> {{trans('label.documents')}} </a>
               <?php
               if($i <= 3) $i++; else $i = 0;
              }
            ?>
          </div>
        </div>      
      </td>
    </tr>
          @endforeach
        @else
          <tr><td colspan="8">No record found</td></tr>
      @endif
    </tbody>
</table>
<?php echo $patients->render(); ?>
