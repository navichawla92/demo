@extends('layouts.app')

@section('css')
  <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
  <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection

@section('title')
   {{ $patient->id ? trans('label.edit_referral') : trans('label.add_new_referral')}}
@endsection

@section('content')
<div class="leftsectionpages">
  <div class="row">
    <div class="col-md-6">
      <div class="headingpage">
        <div class="firstname"><a href="{{ route('patients') }}"> {{ trans('label.patient_referrals') }} </a></div>
        <span><i class="fas fa-angle-right"></i></span>{{ $patient->id ? trans('label.edit_referral') : trans('label.add_new_referral')}}
        </div>
      </div>
  </div>
	<div class="tabsmain">
    <div class="row">
      <div class="col-8">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'patient_info')?'active':'' }}" id="patientinfo-tab" data-toggle="tab" href="#patientinfo" role="tab" aria-controls="home" aria-selected="true">{{ trans('label.patient_information') }} </a> </li>
          <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'healthcare')?'active':'' }}" data-toggle="{{ ($active_step == 'healthcare' || $active_step == 'insurance')?'tab':'' }}" id="concern-tab" href="#concern" role="tab" aria-controls="profile" aria-selected="false"> {{ trans('label.healthcare') }} </a> </li>
          <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'insurance')?'active':'' }}" data-toggle="{{ ($active_step == 'insurance')?'tab':'' }}" id="otherinfo-tab" href="#otherinfo" role="tab" aria-controls="contact" aria-selected="false"> {{ trans('label.insurance_payer') }} </a> </li>
        </ul>
      </div>
      <div class="col-4 smalltextunderheading paddingbtm15">
        <div class="document-notetabs">
          <ul class="nav nav-tabs" id="myTab2" role="tablist">
            <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'document')?'active':'' }}" data-toggle="{{ ($active_step == 'healthcare' || $active_step == 'insurance')?'tab':'' }}" id="document-tab" href="#document" role="tab" aria-controls="contact" aria-selected="false">{{ trans('label.documents') }} </a> </li>
            <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'notes')?'active':'' }}" data-toggle="{{ ($active_step == 'healthcare' || $active_step == 'insurance')?'tab':'' }}" id="note-tab" href="#notes" role="tab" aria-controls="contact" aria-selected="false">{{ trans('label.notes') }}</a> </li>
          </ul>
        </div>  
      </div>
    </div>


    <div class="tab-content" id="myTabContent">
         @include('patients.patient_info_tab')    
         @include('patients.add_referral_source')
         @include('patients.add_pcp_info')		

          <div class="tab-pane fade {{ ($active_tab == 'healthcare')?'show active':'' }}" id="concern" role="tabpanel" aria-labelledby="profile-tab">
            @if($action == 'edit' && ($patient->step_number==1 || $patient->step_number==2 || $patient->step_number==3))
  				    @include('patients.patient_healthcare_tab')		
            @endif
          </div>
					
          <div class="tab-pane fade {{ ($active_tab == 'insurance')?'show active':'' }}" id="otherinfo" role="tabpanel" aria-labelledby="contact-tab">
            @if($action == 'edit' && ($patient->step_number==2 || $patient->step_number==3))
              @include('patients.patient_insurance_tab')
            @endif
          </div>

          <div class="tab-pane fade {{ ($active_tab == 'document')?'show active':'' }}" id="document" role="tabpanel" aria-labelledby="contact-tab">
  					@if($action == 'edit' && ($patient->step_number==1 || $patient->step_number==2 || $patient->step_number==3))   
					@include('patients.common.patient_documents_tab')
					@endif
          </div>

          <div class="tab-pane fade {{ ($active_tab == 'notes')?'show active':'' }}" id="notes" role="tabpanel" aria-labelledby="contact-tab">
  					@if($action == 'edit' && ($patient->step_number==1 || $patient->step_number==2 || $patient->step_number==3))
              @include('patients.common.patient_notes_tab')
            @endif
          </div>
    </div>
  </div>
</div>
@endsection
@section('common_script')
  @include('patients.common.common_script')
@endsection
