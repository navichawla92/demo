 <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-his" onClick="hideMedicationSidebar()"><i class="fa fa-angle-left"></i> {{ trans('label.back') }}</a> {{ trans('label.medication_history') }} </h4>
      </div>

      <div class="slide-body history-body">


          @if(!$medication['history']->total())
              <div class="slide-section sub-part custom-single-detail">
                  <img src="{{ asset('images/no-data.png') }}" class="img img-fluid no-data">
              </div>
          @endif

          @foreach($medication['history'] as $history)

              @php
                $formData = $history->form_data;
                $messageBy = str_replace("re","",@$formData['message']);
              @endphp
              <div class="slide-section">

                  @if($formData['status'])
                  @else
                  @endif

                  <h4>Medication {{ @$messageBy }} by: {{ @$formData['type_name'] }}
                      <span>{{ tzDate($history->created_at)->format('m-d-Y H:i:s') }}</span>
                  </h4>
                  <div class="detail-view">
                      <div class="table-responsive care-table">
                          <table class="table">
                              <thead>
                              <tr>
                                  <th>{{ trans('label.medication_name') }}</th>
                                  <th>{{ trans('label.start') }}</th>
                                  <th>{{ trans('label.end') }}</th>
                                  <th>{{ trans('label.frequency') }} </th>
                                  <th>{{ trans('label.dosage') }} </th>
                                  <th>{{ trans('label.unit') }} </th>
                              </tr>
                              </thead>
                              <tbody>
                              <tr>
                                  <td>{{ $formData['name'] }}</td>
                                  <td>{{ create_date_format($formData['start_date'],'Y-m-d') }}</td>
                                  <td>{{ $formData['end_date'] ? create_date_format($formData['end_date'],'Y-m-d'): '-' }}</td>
                                  <td>{{ $formData['frequency'] }}</td>
                                  <td>{{ $formData['dosage'] }}</td>
                                  <td>{{ $formData['units'] }}</td>
                              </tr>
                              </tbody>
                          </table>
                      </div>
                      <div class="notebox">
                          <label>Notes</label>
                          <p>
                              @if( @in_array($formData['message'], ['restarted', 'discontinued']) )
                                  {{ $formData['reason'] }}
                              @else
                                  {{ $formData['comment'] }}
                              @endif
                          </p>
                      </div>
                  </div>
              </div>
          @endforeach

          <div class="medication_history_pagination">
              {{ $medication['history']->appends('id', encrypt_decrypt('encrypt', $medication['detail']->id))->links() }}
          </div>
      </div>
</div>
