<table class="table" id="medication_listing">
   <thead>
      <tr>
         <th>{{ trans('label.serial_number_short_form') }}</th>
         <th>{{ trans('label.medication_name') }} </th>
         @if($type && $type =='case_load')
         <th>{{ trans('label.start_date') }} </th>
         <th>{{ trans('label.end_date') }} </th>
         @endif
         <th>{{ trans('label.frequency') }} </th>
         <th>{{ trans('label.dosage') }} </th>
         <th>{{ trans('label.unit') }} </th>
          @if($type && $type =='case_load')
          <th>{{ trans('label.status') }} </th>
          @endif
         <th>{{ trans('label.action') }} </th>
      </tr>
   </thead>
   <tbody>
      @if(count($previous_medications))
         <?php  $index=($previous_medications->perPage() * ($previous_medications->currentPage()- 1))+1; ?>
         <?php  $i = 0;?>
         @foreach($previous_medications as $medication)
            <tr>
            <td>{{$index}}</td>
            <td>{{ $medication->name }}</td>
            @if($type && $type =='case_load')
            <td>{{ $medication->start_date ? $medication->start_date : '-'  }}</td>
            <td>{{ $medication->end_date ? $medication->end_date : '-'  }}</td>
            @endif
            <td>{{ $medication->frequency }}</td>
            <td>{{ $medication->dosage }}</td>
            <td>{{ $medication->units }}</td>
            @if($type && $type =='case_load')
            <td>{!! $medication->status_badge !!}</td>
            @endif
            <td>
               @if(!$is_careplan)
               <div class="dropdown more-btn">
                  <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <span>...</span>
                  </button>
                  
                  <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                     @if($type && $type =='case_load')
                     @if($medication->status)
                          <a href="#" data-id="{{ $medication->id }}" data-name="{{ $medication->name }}" data-frequency="{{ $medication->frequency }}" data-dosage="{{ $medication->dosage }}" data-units="{{ $medication->units }}" data-comment="{{ $medication->comment }}" data-start_date="{{ $medication->start_date }}" data-end_date="{{ $medication->end_date }}" class="dropdown-item view_or_edit_medication"><i class="fa fa-sync-alt"></i> {{ trans('label.update') }}</a>
                          <a class="dropdown-item"  data-id="{{ encrypt_decrypt('encrypt',$medication->id) }}" data-status="{{ $medication->status }}" onclick="showMedicationDiscontinueModal(this)"><i class="fa fa-recycle"></i> Discontinue</a>
                     @else
                          <a class="dropdown-item"  data-id="{{ encrypt_decrypt('encrypt',$medication->id) }}" data-status="{{ $medication->status }}" onclick="showMedicationDiscontinueModal(this)"><i class="fa fa-recycle"></i> Start Medication</a>
                     @endif
                     <a class="dropdown-item show-history get_medication_history" data-id="{{ encrypt_decrypt('encrypt',$medication->id) }}" onclick="medicationDetail(this)" ><i class="fa fa-history"></i>View History</a>
                     @else
                     <a href="#" data-id="{{ $medication->id }}" data-name="{{ $medication->name }}" data-frequency="{{ $medication->frequency }}" data-dosage="{{ $medication->dosage }}" data-units="{{ $medication->units }}" data-comment="{{ $medication->comment }}" data-start_date="{{ $medication->start_date }}" data-end_date="{{ $medication->end_date }}" class="dropdown-item view_or_edit_medication">
                       <img src="{{ asset('images/edit.png') }}"> {{ trans('label.edit') }}
                     </a>
                     @endif
                  </div>
               </div>
               @else
                <a class="dropdown-item show-history get_medication_history" data-id="{{ encrypt_decrypt('encrypt',$medication->id) }}" onclick="medicationDetail(this)" ><i class="fa fa-history"></i></a>
                @endif         
            </td>
         </tr>
         <?php  $index++; ?>
         @endforeach
      @else
         <tr><td>{{ trans('label.no_record_found') }} </td></tr>
      @endif
   </tbody>
</table>
<?php echo $previous_medications->render(); ?>