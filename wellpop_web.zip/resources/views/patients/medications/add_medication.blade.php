<!-- add medication -->
<div class="modal fade md_assessment_data" id="addMedicationModal" tabindex="-1" role="dialog" aria-labelledby="addMedicationLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         {!! Form::open(['id' => 'add_medication_form']) !!}
            {!! Form::hidden('patient_id', encrypt_decrypt('encrypt',$patient->id))  !!}
            {!! Form::hidden('action', 'add')  !!}
            {!! Form::hidden('medication_id', null)  !!}
            <div class="modal-header">
               <div class="headingpage"> {{ trans('label.add_medication') }} </div>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div class="modal-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.medication_name') }} </label>
                        <?php
                           $listOfValues = ['' => 'Please select', 'medicine_1' => 'Med 1', 'medicine_2' => 'Med 2'];
                           $listOfUnits  = ['' => 'Please select', 'unit_1' => 'Unit 1', 'unit_2' => 'Unit 2'];
                        ?>
                        {!! Form::select('name', $listOfValues, null, array("class" => "customselect")) !!}
                         <span class="error" style="color:red"></span>
                        <!-- <input type="text" class="form-control" name="name"> -->
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.frequency') }} </label>
                        {!! Form::text('frequency',null,array('class' => 'form-control')) !!}
                         <span class="error" style="color:red"></span>
                        <!-- <input type="text" class="form-control" name="frequency"> -->
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.dosage') }} </label>
                        {!! Form::text('dosage',null,array('class' => 'form-control')) !!}
                         <span class="error" style="color:red"></span>
                        <!-- <input type="text" class="form-control" name="dosage"> -->
                     </div>
                  </div>

                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.unit') }} </label>
                        {!! Form::select('units', $listOfUnits, null, array("class" => "customselect")) !!}
                        <span class="error" style="color:red"></span>
                        <!-- <input type="text" class="form-control" name="units"> -->
                     </div>
                  </div>

                  <div class="col-md-6">
                      <div class="form-group">
                          <label class="labelfieldsname"> {{ trans('label.start_date') }} </label>
                          {!! Form::text('start_date',null,['class' => 'medication_start_date form-control','placeholder' => trans('label.start_date_place_holder')]) !!}
                          <span class="error" style="color:red"></span>
                      </div>
                  </div>

                   <div class="col-md-6">
                      <div class="form-group ">
                          <label class="labelfieldsname"> {{ trans('label.end_date') }} </label>
                          {!! Form::text('end_date',null,['class' => 'medication_end_date form-control','placeholder' => trans('label.end_date_place_holder')]) !!}
                          <span class="error" style="color:red"></span>
                      </div>
                  </div>

                  <div class="col-sm-12">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.allergy_comment') }} </label>
                        {!! Form::textarea('comment',null,array('class' => 'form-control', 'rows' => 2, 'cols' => 40)) !!}
                         <span class="error" style="color:red"></span>
                        <!-- <textarea type="text" class="form-control" name="comment"></textarea> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <div class="buttonsbottom">
               <button type="button" class="next model_box_save" onClick="javascript:saveMedication()"> {{trans('label.save')}} </button>
                  <a href="#" class="close" data-dismiss="modal"> {{ trans('label.cancel') }} </a> </div>
            </div>
            {!! Form::close() !!}
      </div>
   </div>
</div>

@push('scripts')
<script>

    function handleMedicationFromToDate(from, to) {
        $("."+from).datepicker({
            autoclose: true,
            format: "mm-dd-yyyy",
            endDate: '-0d'
        });

        $("."+to).datepicker({
            autoclose: true,
            format: "mm-dd-yyyy",
            endDate: '-0d'
        });

        $("."+from).datepicker().on('changeDate', function (selected) {
            if(selected.date){
             var startDate = new Date(selected.date.valueOf());
              $("."+to).datepicker('setStartDate', startDate);
              $("."+to).datepicker('setEndDate', '-0d');
            }
            else{
              $("."+to).datepicker('setStartDate', '-0d');
              $("."+to).datepicker('setEndDate', '-0d');
            }

        }).on('clearDate', function (selected) {
            $("."+to).datepicker('setStartDate', '-0d');
        });

        $("."+to).datepicker().on('changeDate', function (selected) {
            if(selected.hasOwnProperty('date')) {
                var endDate = new Date(selected.date.valueOf());
                $("."+from).datepicker('setEndDate', endDate);
            }
        }).on('clearDate', function (selected) {
            $("."+from).datepicker('setEndDate', '-0d');
        });
    }
   handleMedicationFromToDate('medication_start_date','medication_end_date');

  //edit or view existing medication
    $('body').on('click', '.view_or_edit_medication', function(e) {
      e.preventDefault();

        $('#addMedicationModal .headingpage').text("{{ trans('label.edit_medication') }}");
        $('#addMedicationModal select[name=name]').val($(this).data('name')).attr("disabled", true);
        $('#addMedicationModal input[name=frequency]').val($(this).data('frequency'));
        $('#addMedicationModal input[name=dosage]').val($(this).data('dosage'));
        $('#addMedicationModal select[name=units]').val($(this).data('units'));
        // $('#addMedicationModal textarea[name=comment]').val($(this).data('comment'));


         $(".medication_start_date").datepicker('setDate', $(this).attr('data-start_date')).attr("disabled", true);
         $(".medication_end_date").datepicker('setDate', $(this).attr('data-end_date')).attr("disabled", true)
        /* if($(this).attr('data-end_date') != '')
            $(".medication_end_date").attr("disabled", true);
          else
            $(".medication_end_date").attr("disabled", false);*/
        $('#addMedicationModal input[type=hidden][name=action]').val('edit');
        $('#addMedicationModal input[type=hidden][name=medication_id]').val($(this).data('id'));
        initCustomForms();
        $('#addMedicationModal').modal({backdrop: 'static', keyboard: false});
     });

     //clear previous values if any before modal open
     $('body').on('click', '#add_new_medication', function(e) {
      e.preventDefault();

        $('#addMedicationModal .headingpage').text("{{ trans('label.add_medication') }}");

        $('#addMedicationModal select[name=name]').val('').attr("disabled", false);
        $('#addMedicationModal select[name=units]').val('');

        $('#addMedicationModal input[name=frequency]').val('');
        $('#addMedicationModal input[name=dosage]').val('');
        $('#addMedicationModal textarea[name=comment]').val('');

        $('#addMedicationModal input[type=hidden][name=action]').val('add');
        $('#addMedicationModal input[type=hidden][name=medication_id]').val('null');


         $('#addMedicationModal input[name=start_date]').val('').attr("disabled", false);
         $('#addMedicationModal input[name=end_date]').val('').attr("disabled", false);
         $(".medication_start_date").trigger('clearDate');
         $(".medication_end_date").trigger('clearDate');

         initCustomForms();
         $('#addMedicationModal').modal({backdrop: 'static', keyboard: false});
     });



  function saveMedication()
  {
    var formData = new FormData($('#add_medication_form')[0]);
    $('.model_box_save').attr("disabled", "disabled");

    var submitURL = "{{ route('registration_md_assessment_medication_save') }}";

    @if($type == 'case_load')
        var submitURL = caseload_save_or_upload_medication_route;
    @endif

    $.ajax({
      url:submitURL,
      data:formData,
      processData: false,
      contentType: false,
      dataType: "json",
      success:function(data)
      {
        $('.model_box_save').removeAttr("disabled");
        $('#medication_listing').html(data.html);
        $('#addMedicationModal').modal('hide');
        $('body').waitMe('hide');
        $('#medication_not_required').html('').removeClass('active').hide();
        $('input[name=medication_not_required]').removeClass('changed-input');
        $('#addMedicationModal').find('input,textarea,select').removeClass('changed-input');
        applpyEllipses('medication_section', 5, 'no');

        data.status = 'success';
        handleMessages(data, 'medication_listing', true);
        fadeOutAlertMessages();
      },
      error:function(error){
        $('.model_box_save').removeAttr("disabled");
        $.each(error.responseJSON.errors,function(key,value){
            $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
        });
        @if($type == 'case_load')

        @else
        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);
        @endif
      }
    });
  }
</script>

@endpush

