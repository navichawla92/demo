  @include('patients.common.profile_status_bar')
  {!! Form::model($patient,['id' => 'patient-concern-form']) !!}
  <input type="hidden" name="step_number" value="2">
  <input type="hidden" name="action" value="edit">
  <input type="hidden" name="message_type" value="edit">
  <input type="hidden" name="patient_id" class="ref_patient_id" value="{{$patient->id}}" data-id="{{\Crypt::encrypt($patient->id)}}">
  <div class="personliving">
    <div class="safety-box">
      <div class="headingpage">{{ trans('label.patient_concern') }} *</div>
      <span class="smalltextunderheading checklabel">{{ trans('label.check_one_which_is_applicable') }}</span>
      <div class="clearfix"></div>
      <div class="row check-body">
  		  
  	  <span class="error" id="patient_concern_error" style="color:red"></span>
          @foreach($patient_concerns as $key=>$patient_concern)
            <div class="col-md-6 col-xl-4">	
  		  <div class="checkdiv">
                <!-- <input type="checkbox" value="{{ $key }}" name="lives_with[]" class="customcheck"> -->
                {!! Form::checkbox('patient_concern[]', $key, (($patient->patient_concern) && in_array($key, $patient->patient_concern) ? true : false),['class'=>'customcheck','old-data'=>(($patient->patient_concern) && in_array($key, $patient->patient_concern))? 'jcf-checked':'jcf-unchecked']) !!}
                <label>{{ $patient_concern }}</label>
              </div>
              </div>
          @endforeach
  		 <div class="col-md-6 col-xl-4">
  			 <div class="checkdiv">
  			{!! Form::checkbox('patient_concern_other',null, (($patient->patient_concern_other) ? true : false),['class'=>'customcheck', 'placeholder'=>'Enter Patient Concern', 'old-data'=>($patient->patient_concern_other)? 'jcf-checked':'jcf-unchecked']) !!}
  			<!-- <input type="checkbox" class="customcheck" name="patient_concern_other"> -->
  			  <label>Other</label>
  			</div>
          </div>
  		 <div class="col-md-6 col-xl-4">
  			<div class="checkdiv patient_concern_is_other textfieldglobal" {!! ((!$patient->patient_concern_other) ? 'style="display:none;"' : '') !!}>
  			  {!! Form::text('patient_concern_other_text',null,array('maxlength' => 100)) !!}
  			  <!-- <input type="text" placeholder="" name="patient_concern_other_text"> -->
  			   <span class="error" id="patient_concern_other_text" style="color:red"></span>
  			</div>
          </div>
      </div>
      </div>
    </div>
    <div class="personliving">
      <div class="safety-box">

        <div class="headingpage">{{ trans('label.pcp_information') }}</div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-5">
            <div class="textfieldglobal addfieldselect">
              <label class="labelfieldsname">{{ trans('label.doctor_name') }}</label>
              <select name="pcp_id" class="pcp_informations customselect" id='pcp_information'>
                <option value=""> Please select</option>
                @foreach($pcp_informations as $key=>$pcp_information)
                 <option value="{{ $pcp_information->id }}" data-address_line1="{{ $pcp_information->address_line1 }}" data-address_line2="{{ $pcp_information->address_line2 }}" data-city="{{ $pcp_information->city }}" data-zip_code="{{ $pcp_information->zip }}" data-contact_name="{{ $pcp_information->contact_name }}" data-contact_phone="{{ $pcp_information->contact_phone }}" data-contact_email="{{ $pcp_information->contact_email }}" data-contact_title="{{ $pcp_information->contact_title }}" data-speciality="{{ $pcp_information->speciality }}" data-org_name="{{ $pcp_information->org_name }}" data-state_id="{{ $pcp_information->state_id }}" data-state_name="{{ $pcp_information->state_name }}" data-phone="{{ $pcp_information->phone_number }}" data-fax="{{ $pcp_information->fax }}" data-email="{{ $pcp_information->email }}" data-web_address="{{ $pcp_information->web_address }}"

                    @if ($pcp_information->id === $patient->pcp_id) selected @endif
                  >{{$pcp_information->name}} </option>
                @endforeach
              </select>
              <div class="addreferalplus"><a href="#" data-toggle="modal" data-target="#add_pcp_info"><i class="fas fa-plus" data-toggle="tooltip" data-placement="top" title="{{trans('label.add_new_pcp')}}" ></i></a></div>
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.org_name') }}</label>
              <input placeholder="" type="text" class="pcp_org_name" disabled="">
            </div>

            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.speciality') }}</label>
              <input placeholder="" type="text" class="pcp_speciality" disabled="">
            </div>

            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.phone_number') }}</label>
              <input placeholder="" type="text"  class="pcp_phone set_phone_format" disabled="">
            </div>

            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.address_line_1') }}</label>
              <input placeholder="" type="text" class="pcp_address_line_1" disabled="">
              
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.address_line_2') }}</label>
              <input placeholder="" type="text" class="pcp_address_line2" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.city') }}</label>
              <input placeholder="" type="text" class="pcp_city" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <div class="row">
                 <div class="col-md-7">
                   <label class="labelfieldsname">{{ trans('label.state') }}</label>
                   <input placeholder="" type="text" class="pcp_state_name" disabled="">
                 </div>
                  <div class="col-md-5">
                     <label class="labelfieldsname">{{ trans('label.zip_code') }}</label>
                     <input placeholder="" type="text" class="pcp_zip_code" disabled="">
                  </div>

              </div>
             
            </div>
           
          </div>
          <div class="col-md-5">
           
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.email_address') }}</label>
              <input placeholder="" type="text" class="pcp_email" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.fax') }}</label>
              <input placeholder="" type="text" class="pcp_fax" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.web_address') }}</label>
              <input placeholder="" type="text" class="pcp_web_address" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.contact_name') }}</label>
              <input placeholder="" type="text" class="pcp_contact_name" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.contact_phone') }}</label>
              <input placeholder="" type="text" class="pcp_contact_phone set_phone_format" disabled="">
            </div>
             <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.contact_title') }}</label>
              <input placeholder="" type="text" class="pcp_contact_title" disabled="">
            </div>
            <div class="textfieldglobal readonly_field">
              <label class="labelfieldsname">{{ trans('label.contact_email') }}</label>
              <input placeholder="" type="text" class="pcp_contact_email" disabled="">
            </div>
          </div>
        </div>
    </div>
  </div>
  <div class="personliving">
    <div class="safety-box">
      <div class="row">
        <div class="col-md-5 col-4">
          <div class="headingpage">{{ trans('label.icd_code') }}</div>
        </div>
      </div>
      <div class="clearfix"></div>
      <?php
        $listOfValues = ['1' => 'ICD1', '2' => 'ICD2','3' => 'ICD3', '4' => 'ICD4'];
      ?>
      <div class="row">
        <div class="col-md-7 col-4">
          {!! Form::select('icd_code[]', $icd_codes,null,array("class" => "Icd_class",'id'=>"icdCode",'multiple')) !!}  
          <span class="error" id="icd_code" style="color:red"></span>
        </div>
      </div>
      </div>
  </div>
  <div class="buttonsbottom">
    <button type="button" class="next" onClick="javascript:saveform('saveandnext','#patient-concern-form','3')">{{ trans('label.save_and_next') }}</button>
     <button type="button" class="next" onClick="javascript:saveform('saveandclose','#patient-concern-form','3')">{{ trans('label.save_and_close') }}</button>
    <a href="#" class="close close_form">{{ trans('label.cancel') }}</a> </div>
     {!! Form::close() !!}

