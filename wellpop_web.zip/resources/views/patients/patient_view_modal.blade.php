
    <div class="modal-dialog" role="document">
      <div class="modal-content info-modal">
        <div class="modal-header">
			<h4>{{ trans('label.patient_information') }}</h4>
        </div>
        <div class="modal-body patient-info">
			
			<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3">
					<div class="profileimg">
            <img src="@if($patient->image) {{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }} @else {{ asset('images/noimage.jpg') }} @endif" alt="">
          </div>
					<span class="badge badge-info"><?= $patient->case_number ?></span>
				</div>	
				<div class="col-sm-9">
					<p>{{ trans('label.name') }} :<span><?= $patient->first_name?$patient->first_name:'-' ?> <?= $patient->middle_initial?$patient->middle_initial.'.':'-' ?> <?= $patient->last_name?$patient->last_name:'-' ?> &nbsp;(<?php
            $dob = explode('-',$patient->dob);
            $dob = $dob[1].'-'.$dob[0].'-'.$dob[2];             
            echo get_dob_in_years($patient->dob);
      ?>)</span></p>
					<p>SSN:<span><?php
                $strring = substr($patient->ssn, 7);
                echo '*****'.$strring;
                ?> </span></p>
					<p> {{ trans('label.alias') }}:<span><?= $patient->patient_alias?$patient->patient_alias:'-' ?></span></p>
					<p> {{ trans('label.email') }}:<span><?= $patient->email?$patient->email:'-' ?></span></p>
					<p> {{ trans('label.gender') }}:<span><?= $patient->gender?$patient->gender:'-' ?></span></p>
					<p> {{ trans('label.phone_no') }}:<span><?= $patient->phone? "+1 ".$patient->phone:'-' ?></span></p>
					<p> {{ trans('label.dob_word') }}:<span><?= $patient->dob? \Carbon\Carbon::parse($dob)->format('m-d-Y'):'-' ?></span></p>
          <p> {{ trans('label.language_word') }}:<span><?= $patient->language_value?$patient->language_value->name:'-' ?></span></p>
          <p> {{ trans('label.address_word') }}:<span><?= $patient->address_line1?$patient->address_line1:'' ?> <?= $patient->address_line2? $patient->address_line2:'' ?> 
          </span>
          <span>
          <?= $patient->city? $patient->city.' ,':'' ?> <?= $patient->state_name? $patient->state_name.' ':'' ?></span>
          <span>  <?= $patient->zip_code? $patient->zip_code:'' ?> </span></p>
				</div>
			</div>
			</div>
        </div>
        <div class="modal-footer">
          <div class="buttonsbottom"><a href="#" class="close" data-dismiss="modal" aria-label="Close"> {{ trans('label.close') }}</a> </div>
        </div>
      </div>
    </div>
  </div>
