 <div class="nav flex-column nav-pills left-bar" id="v-pills-tab" data-type="team" role="tablist" aria-orientation="vertical"> 
   <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" data-type="purpose" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
      {{ trans('label.purpose') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-messages-tab" data-toggle="pill"  data-type="content_discussed" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
      {{ trans('label.content_discussed') }}*  <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Intervention-tab" data-toggle="pill" data-type="intervention" href="#v-pills-Intervention" role="tab" aria-controls="v-pills-Intervention" aria-selected="false">
      {{ trans('label.intervention') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
</div>