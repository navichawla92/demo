@extends('layouts.app')
@section('css')
   <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
   <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection
@section('title')
{{ trans('label.add_new_checkpoint') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-7 col-lg-8">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.care_plan') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.add_new_checkpoint') }}
         </div>
      </div>
      <div class="col-md-5 col-lg-4">
         <div class="buttonsbottom">
             <a href="javascript:;" class="next save_btn" onClick="saveCheckpointData();" >{{ trans('label.save_and_confirm') }}</a>
             <a href="javascript:;" class="close close_form">{{ trans('label.cancel') }}</a>
         </div>
      </div>
   </div>
   <div class="">
      <div class="patient-view pat-show case-main-wrap">
        @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
         <input type="hidden" name="patient_id" value="{{ encrypt_decrypt('encrypt',$patient['patient_info']->id) }}">
         <input type="hidden" name="careplan_id" value="0">
         <input type="hidden" name="checkpoint_id" value="0">
         <input type="hidden" name="intervention_id" value="0">
         <input type="hidden" name="is_save" value="0">
         <div class="assess-main">
            <div class="row">
              @if($activeCarePlan)
               <div class="col-md-3 col-lg-2">
                 @include('patients.caseload.checkpoint.sidebar')  
               </div>
               <div class="col-md-9 col-lg-10">
                  <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                     @include('patients.caseload.checkpoint.purpose') 
                  </div>
               </div>
                @else
         
               <h5> No active care plan </h5>
              
               @endif
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@section('modal_box')
<!--sidebox  -->


<!--view-tools -->
<div class="sidebox-overlay" id="toolsOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-barrier"><i class="fa fa-angle-left"></i> Back</a>View Tools</h4>
      </div>
      <div class="slide-body">
         <div class="slide-tools">
            <div class="barrier-search">
               <div class="textfieldglobal">
                  <input type="text" placeholder="Search by Tool Title or Tool ID" name='search_tool'>
                  <button class="btn btn-primary basic-btn search_tool">Search</button>
               </div>
            </div>
            <div class="table-responsive care-table div_load" id='tool_list'>
               
            </div>
         </div>
      </div>
   </div>
</div>

<div class="sidebox-overlay" id="viewOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-tool-detail"><i class="fa fa-angle-left"></i> Back</a>Tool Details</h4>
         </div>
         <div class="slide-body">
              <div class="slide-section">
               <h4>Basic Details</h4>
              <div class="detail-view">
                  <div class="row tool_detail_data">
                      <div class="col-md-12">
                          <p class="tool_id"><span>Tool ID:</span> TO!O!O </p>
                      </div>
                      <div class="col-md-12">
                          <p class="tool_desc"><span>Tool Descrption:</span> ssas </p>
                      </div>
                      <div class="col-md-12">
                          <p class="tool_type"><span>Tool Type:</span> sas</p>
                      </div>
                  </div>
              </div>
             </div>
         </div>
   </div>   
</div>

@endsection

@section('script')
@include('layouts.route_name')
<script src="{{ asset('js/caseloads/care_plan.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/caseloads/case_load.js') }}" type="text/javascript"></script> 

<script type="text/javascript">

  const monthNumbers = ["01", "02", "03", "04", "05", "06",
         "07", "08", "09", "10", "11", "12"
    ];

    var currentdate = new Date();
    var hour    = currentdate.getHours();
    var minute  = currentdate.getMinutes();
    var second  = currentdate.getSeconds();
    if(hour.toString().length == 1) {
             hour = '0'+hour;
        }
        if(minute.toString().length == 1) {
             minute = '0'+minute;
        }
        if(second.toString().length == 1) {
             second = '0'+second;
        }    
    var current_date = monthNumbers[currentdate.getMonth()] + "-"
            +("0" + currentdate.getDate()).slice(-2) + "-" 
            + currentdate.getFullYear()+ ' ('+hour + ":"  
                + minute + ":" 
                + second+' )';

    /*  var current_date = monthNumbers[currentdate.getMonth()] + "-"
            +("0" + currentdate.getDate()).slice(-2) + "-" 
            + currentdate.getFullYear();*/
    $('.date_time').html(current_date);
$.ajaxSetup({
  type:"POST",
  headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
  beforeSend:function(){
      $('.loader_div').waitMe();
  },
  complete:function(){
      $('.loader_div').waitMe('hide');
      
  },
  error:function(error){
  }
});
 

// function to click on side bar to load the relative tab
$('body').on('click', '.assess-main .nav-link', function(e) {
     e.preventDefault();
        closeFormTab();
        if($('.changed-input').length != 0) {
             return false;
        }
        var type = $(this).data('type');
        var checkpointId = $('[name="checkpoint_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var patientId = $('[name="patient_id"]').val();
        var interventionId = $('[name="intervention_id"]').val();

         $.ajax({
            url:"{{ route('patient_checkpoint_detail_tab', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}",
            type: "GET",
            dataType: "json",
            data: {tab:$(this).data('type'),checkpoint_id:checkpointId, careplan_id:careplanId, patient_id:patientId,intervention_id:interventionId},
            success:function(response){
              $('#v-pills-tabContent').html(response.data.html);
              initCustomForms();
              addOldVelue();
           },error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else if(error.status == 404){
                        $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
                    }
                    else if(error.status == 403){
                        $('#v-pills-tab a').not(':first').removeClass('active');
                        $('#v-pills-tab a:first').addClass('active');
                    }
                }
        });
   
});
  
function saveCheckpointData(){
     bootbox.confirm({
            message: "Are you sure you want to save this checkpoint?",
            callback: function(result){
                if (result) {
                      var tab_name = $('[name="tab_name"]').val();
                          if(tab_name == "purpose"){
                              savePurpose(1);
                           }
                            if(tab_name == "content_discussed"){
                              saveContentDiscussed(1);
                            }
                            if(tab_name == "intervention"){
                              saveIntervention(1);
                            }
                }
                else {
                    bootbox.hideAll();
                    return false;
                }
            }
        })
}  

function saveCheckpoint() {
  $.ajaxSetup({
  type:"POST",
  headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
  beforeSend:function(){
    //  $('.loader_div').waitMe();
  },
  complete:function(){
      $('.loader_div').waitMe('hide');
      
  },
  error:function(error){
  }
  });
  var patientId = $('[name="patient_id"]').val();
  var careplanId = $('[name="careplan_id"]').val();
  var checkpointId = $('[name="checkpoint_id"]').val();
  var interventionId = $('[name="intervention_id"]').val();
  var tab_name = $('[name="tab_name"]').val();
  var formData = new FormData($('#purposeForm')[0]);
  if(tab_name =='purpose'){
    var formData = new FormData($('#purposeForm')[0]);
  }
  else if(tab_name =='content_discussed'){
    var formData = new FormData($('#contentDiscussed')[0]);
  }
  else if(tab_name =='intervention'){
    var formData = new FormData($('#intervention_form')[0]);
  }

  formData.append('patient_id', patientId)
  formData.append('careplan_id', careplanId);
  formData.append('checkpoint_id', checkpointId);
  formData.append('intervention_id', interventionId);
  formData.append('tab_name', tab_name);
   $.ajax({
                        url: '{{ route('patient_checkpoint_save') }}',
                        data: formData,
                        dataType:'JSON',
                        contentType: false,
                        processData: false,
                        success: function(response) {
                           $('[name="is_save"]').val(0);
                            window.location = "{{ route('caseload_patient_view', encrypt_decrypt('encrypt', $patient['patient_info']->id)) }}/#checkpoint";
                            fadeOutAlertMessages();
                        },
                        error: function(errors) {
                            $.each(errors.responseJSON.errors,function(key,value){
                                $('#v-pills-tab a[data-type="'+key+'"]').addClass('text-red');
                            });
                        }
                    });
}

function addOldVelue(){
    $("input,textarea,select").each(function(){
        $(this).attr('old_value',$(this).val());
    })
}

$('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
            $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
            $(this).removeClass('changed-input');
        }
        else {
            $(this).addClass('changed-input');
        }
    }
    else {
        if($(this).hasClass('chosen-search-input')){

        }
        else{
            $(this).addClass('changed-input');
        }
    }
});

function closeForm() {
    if ($('.changed-input').length || $('[name="is_save"]').val()=='1') {
        bootbox.confirm({
            message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?",
            callback: function(result){
                if (result) {
                    $('input,textarea,select').removeClass('changed-input');
                    $('[name="is_save"]').val('');
                    window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#checkpoint']) }}";
                }
                else {
                    bootbox.hideAll();
                    return false;
                }
            }
        })
    }
    else {
    window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#checkpoint']) }}";

  }
}


function closeFormTab() {
    if($('.changed-input').length) {
        bootbox.alert("{{ trans('message.unsaved_error_message') }}");
        return false;
    }
}

addOldVelue();

// for cancel button on every form
$('body').on('click', '.close_form', function(e) {
    e.preventDefault();
    closeForm();
});

// for click on side bar or logout button
$(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
  if ($('.changed-input').length || $('[name="is_save"]').val()=='1'){
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }
});


$(".close-side-tool-detail").click(function () {
        $('#viewOverlay').find(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $("#viewOverlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $('#viewOverlay').find(".inner-slide").removeClass("slideOutRight");

        }, 1000);
    });
/* */


 //  check if input changed and unsaved before reload
    window.onbeforeunload = function() {
      /*
      ==if auto-logout functionality causing page-reload then allow it don't show any alert 
      ==no matter data changed and un;-saved
      */
      if (($('.changed-input').length || $('[name="is_save"]').val()=='1') && !$('div.ui-dialog[aria-describedby="sessionTimeout-dialog"]').is(':visible')){
             return "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page.";
      }
      else {
      }      
    }

     $(".close-side-barrier").click(function () {
        $(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $(".sidebox-overlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $('.barrier-search').find('input').removeClass('changed-input');
            $(".inner-slide").removeClass("slideOutRight");
        }, 1000);
    });
</script>
@endsection