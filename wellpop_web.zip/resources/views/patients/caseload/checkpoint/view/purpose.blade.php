<div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <h4 class="assess-head">{{ trans('label.purpose') }}</h4>
    <div class="care-box">
        {!! Form::model($assessment,['id' => 'purposeForm', 'files' => true]) !!}
        <div class="row">
            <div class="col-md-4">
                <div class="form-group edit_select">
                    <label>{{ trans('label.purpose') }}</label>
                    {!! Form::select('purpose', get_manageable_fields('careplan_assessment_purpose'), $assessment->purpose, ['class' => 'status_filter customselect ','disabled' => true]) !!}
                    <span class="error" style="color: red; display: none;"></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group edit_select">
                    <label>{{ trans('label.via') }}</label>
                    {!! Form::select('via', get_manageable_fields('careplan_assessment_via'), $assessment->via, ['class' => 'status_filter customselect edit_select','disabled' => true]) !!}
                    <span class="error" style="color: red; display: none;"></span>
                </div>
            </div>
             <div class="col-md-4">
                @if($assessment->assessment_date_time)
                <p class="show-time">{{ $assessment->assessment_date_time }}</p>
                @endif
            </div>
        </div>
        {!! Form::close() !!}
    </div>
    <div class="asess-btnbox">
       <button class="btn btn-primary basic-btn" onClick="savePurpose();">{{ trans('label.next') }}</button>
    </div>
</div>

<script>
    function savePurpose() {
        $('#v-pills-tab a[data-type="content_discussed"]').click();
    }
</script>