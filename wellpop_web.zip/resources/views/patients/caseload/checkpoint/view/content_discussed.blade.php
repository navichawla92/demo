<div class="tab-pane fade active show" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
   <h4 class="assess-head">{{ trans('label.content_discussed') }} <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn tool-detail">{{ trans('label.view_tools') }}</button></span></h4>
   <div class="care-box">
      {!! Form::model($assessment,['id' => 'contentDiscussed']) !!}
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">{{ trans('label.checkpoint_content') }}</label>

                  {!! Form::select('visit_content[]', $content_discussed,null,array("class" => "content_discussed",'id'=>"icdCode",'multiple','disabled' => true)) !!}
                  
                  <span class="error" id='visit_content' style="color:red"></span> 
               </div>
            </div>
         </div>
      </div>
      <div class="other-notes">
         <div class="row">
            <div class="col-lg-2 col-md-3">
               <label>{{ trans('label.other_notes') }}</label>
            </div>
            <div class="col-lg-10 col-md-9">
                <p> {{ $assessment->other_notes ?? ''}}</p>
               <span class="error" style="color:red"></span> 
            </div>
         </div>
        
      </div>
      <input type="hidden" name="tab_name" value="content_discussed">
       {!! Form::close() !!}
   </div>

  <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="saveContentDiscussed();">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right"  onClick="previousTab();">{{ trans('label.previous') }}</button>
  </div>

</div>

<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">
$(".tool-detail").click(function () {
   handleToolListing();
   $("#toolsOverlay").addClass("show-overlay");
});



function handleToolListing(current_page = '',SearchText='')
   {

      if(current_page === '') {
         current_page = $("#allergies_listing .pagination").find('.active').text();
      }
      var url = "{{ route('patient_tool_list') }}"+'?page='+ current_page;
      $.ajax({
         url:url,
         type:"GET",
         data:{name:SearchText},
         dataType: "json",
         success:function(data){
             $('#tool_list').html(data.html);
             applpyEllipses('div_load', 5, 'no');
         },
         error:function(data){
             alert('error');
         }
      });
}

$('body').on('click', '#tool_list .pagination a', function(e) {
  e.preventDefault();
  page = getURLParameter($(this).attr('href'), 'page');

  name = $('input[name=search_tool]').val();

  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
         //applpyEllipses('div_load', 5, 'no');
     },
     error:function(error){
     }
   });
  handleToolListing(page,name);
});


$('body').on('click', '.search_tool', function(e) {
  e.preventDefault();
  name = $('input[name=search_tool]').val();

  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
        // applpyEllipses('div_load', 5, 'no');
     },
     error:function(error){
     }
   });
  handleToolListing('',name);
});


$('body').on('click', '.show-detail', function(e) {
   $('.tool_id').html('<span>{{ trans("label.tool_id") }}:</span> '+$(this).data('tool_id'));
   $('.tool_desc').html('<span>{{ trans("label.tool_desc") }}:</span> <b class="more_info"> '+$(this).data('tool_desc')+'</b>');
   $('.tool_type').html('<span>{{ trans("label.tool_type") }}:</span> '+$(this).data('tool_type'));
   $("#viewOverlay").addClass("show-overlay");
   $("body").addClass("hideout");
   handleMoreInfo()
});

$(".content_discussed").chosen({ width:'100%' });


function saveContentDiscussed() {
  $('#v-pills-tab a[data-type="intervention"]').click();
}

function previousTab(){
   $('#v-pills-tab a[data-type="purpose"]').click();
}


</script>