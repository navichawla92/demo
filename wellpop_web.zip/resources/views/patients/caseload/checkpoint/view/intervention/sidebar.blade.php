 <div class="nav flex-column nav-pills left-bar" id="v-pills-tab" data-type="team" role="tablist" aria-orientation="vertical"> 
   <a class="nav-link1" id="v-pills-Intervention-tab" data-toggle="pill" data-type="intervention" href="#v-pills-Intervention" role="tab" aria-controls="v-pills-Intervention" aria-selected="false">{{ trans('label.intervention') }}</a>
</div>
