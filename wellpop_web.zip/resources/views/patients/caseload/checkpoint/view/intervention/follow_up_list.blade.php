<table class="table">
   <thead>
      <tr>
         <th>{{ trans('label.serial_number_short_form') }}</th>
         <th>{{ trans('label.date_added') }}</th>
         <th>{{ trans('label.follow_up_date') }}</th>
         <th>{{ trans('label.follow_up_item') }} </th>
         <th>{{ trans('label.complete') }} </th>
      </tr>
   </thead>
   <tbody>
       @if(count($interventionFollowUps))
        <?php  $index=($interventionFollowUps->perPage() * ($interventionFollowUps->currentPage()- 1))+1; ?>
         <?php  $i = 0;?>
         @foreach($interventionFollowUps as $interventionFollowUp)
      <tr>
         <td>{{ $index }}</td>
         <td>{{ $interventionFollowUp->added_date }}</td>
         <td>{{ $interventionFollowUp->follow_up_date }}</td>
         <td>{{ $interventionFollowUp->follow_up_item }}</td>
         <td> <input type="checkbox" disabled class="customcheck followup_chkbox" {{ $interventionFollowUp->is_completed ? "checked" : "" }} value="{{ encrypt_decrypt('encrypt',$interventionFollowUp->id) }}" >
            
         </td>
      </tr>
      <?php  $index++; ?>
         @endforeach
       @else
         <tr><td>{{ trans('label.no_record_found') }}</td></tr>
      @endif
   </tbody>
</table>
<?php echo $interventionFollowUps->render(); ?>

<script type="text/javascript">
    initCustomForms();
</script>