@extends('layouts.app')
@section('css')
   <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
   <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection
@section('title')
{{ trans('label.view_intervention') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-7 col-lg-9">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
             <span><i class="fas fa-angle-right"></i></span>{{ trans('label.care_plan') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.view_intervention') }}
         </div>
      </div>

       <div class="col-md-3">
           <div class="buttonsbottom view-plan-btn "> <a href="{{ Request::server('HTTP_REFERER') }}/#intervention" class="next backi"><i class="fa fa-angle-left"> </i>&nbsp; Back</a> </div>
        </div>
     
   </div>
  
   <div class="">
      <div class="patient-view pat-show case-main-wrap">
        @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
         <div class="assess-main">
            <div class="row">
               
               <div class="col-md-12 col-lg-12">
                  <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                     @include('patients.caseload.checkpoint.view.intervention.index',['intervention'=>$intervention]) 
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection

@section('script')
@include('layouts.route_name')

 <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">
 $(".assigned_users").chosen({ width:'100%' });
applpyEllipses('care-table', 4, 'no');

</script>
@endsection
