<div class="tab-pane fade active show" id="v-pills-Intervention" role="tabpanel" aria-labelledby="v-pills-Intervention-tab">
   <h4 class="assess-head">Intervention</h4>
   <div class="care-box">

    {!! Form::model($intervention,['id' => 'intervention_form']) !!}

    @php
    $intervention_action = intervention_action();
    @endphp
    @if($careTeam)
    @php
      $userList = $careTeam;
     /* $caseManager = $careTeam->cmUser;
      $commonHealthWorker = $careTeam->chwUser;
      $medicalDirector = $careTeam->mdUser;
      $userList[$careTeam->cmUser->id] = $careTeam->cmUser->name .'(CM)';
      $userList[$careTeam->chwUser->id] = $careTeam->chwUser->name .'(CHW)';
      $userList[$careTeam->mdUser->id] = $careTeam->mdUser->name .'(MD)';*/
    @endphp

    @endif
      <div class="inter-action">
         <div class="other-notes">
         <div class="row">
            <div class="col-lg-2 col-md-3">
               <label>{{ trans('label.action') }}</label>
            </div>
            <div class="col-md-3 edit_select">
               {!! Form::select('action', array('' => 'Select an action') + $intervention_action,null,array("class" => "customselect edit_select",'disabled' => true)) !!}

               <span class="error" style="color:red"></span> 
            </div>
            <div class="col-md-3">
               <div class="flag-box inter-flag">
                  <i class="fas fa-flag show-flag {{ $intervention->flag ?? ''}}-flag " ></i>
                  <div class="select-flag"> <a class="flag_name" data-flag="red"><i class="fas fa-flag red-flag"></i></a> <a class="flag_name" data-flag="yellow"><i class="fas fa-flag yellow-flag"></i></a> <a class="flag_name" data-flag="green"><i class="fas fa-flag green-flag"></i></a> </div>
               </div>
               <input name="flag" type="hidden" class='selected_flag_name' value="{{ $intervention->flag ?? ''}}">

               <input name="type" type="hidden" value="{{$type}}">
               <span class="error" style="color:red"></span> 
            </div>
         </div>
         </div>
         <br>
         <div class="other-notes">
         <div class="row">
            <div class="col-lg-2 col-md-3">
               <label>{{ trans('label.notes') }}</label>
            </div>
            <div class="col-lg-10 col-md-9">
               <p >{{ $intervention->summary ?? ''}}</p>
               <span class="error" style="color:red"></span> 
            </div>
         </div>
         </div>
      </div>
      <hr>
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">Notify</label>
                 {!! Form::select('assigned_users[]', $userList,null,array("class" => "assigned_users",'id'=>"icdCode",'multiple','disabled' => true)) !!}
                  <span class="error" style="color:red" id='assigned_users'></span> 
               </div>
            </div>
         </div>
      </div>
      <input type="hidden" name="tab_name" value="intervention">
      {!! Form::close() !!}

      <h4 class="assess-head fs-16">Follow Up Actions <span class="head-btn main-head-box"></span></h4>

      <span class="error" style="color:red" id='followup_id'></span> 
      <div class="table-responsive care-table" id='follow_up_list'>
        @include('patients.caseload.checkpoint.view.intervention.follow_up_list',['interventionFollowUps' =>$interventionFollowUps])  
      </div>
   </div>

    
</div>

 <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">


$(".assigned_users").chosen({ width:'100%' });
$('body').on('click', '#follow_up_list .pagination a', function(e) {
  e.preventDefault();
  page = getURLParameter($(this).attr('href'), 'page');


  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
        // applpyEllipses('div_load', 5, 'no');
     },
     error:function(error){
     }
   });
  handleFollowUpListing(page);
});


function handleFollowUpListing(current_page = '',SearchText='')
   {

      if(current_page === '') {
         current_page = $("#follow_up_list .pagination").find('.active').text();
      }
      var checkpointId = $('[name="checkpoint_id"]').val();
      var url = "{{ route('patient_followup_list') }}"+'?page='+ current_page;
      console.log(url);
      $.ajax({
         url:url,
         type:"GET",
         data:{id:checkpointId},
         dataType: "json",
         success:function(data){
             $('#follow_up_list').html(data.html);
              applpyEllipses('care-table', 5, 'no');
         },
         error:function(data){
             alert('error');
         }
      });
  }

  applpyEllipses('care-table', 4, 'no');
  function previousTab(){
    $('#v-pills-tab a[data-type="content_discussed"]').click();
  }
</script>
