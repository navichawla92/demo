@extends('layouts.app')
@section('css')
   <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
   <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection
@section('title')
{{ trans('label.view_checkpoint') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-7 col-lg-9">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.care_plan') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.view_checkpoint') }} 
         </div>
      </div>

        <div class="col-md-3">
           <div class="buttonsbottom view-plan-btn "> <a href="{{ Request::server('HTTP_REFERER') }}/#checkpoint" class="next backi"><i class="fa fa-angle-left"> </i>&nbsp; Back</a> </div>
        </div>
     
   </div>
  
   <div class="">
      <div class="patient-view pat-show case-main-wrap">
        @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
         <input type="hidden" name="patient_id" value="{{ encrypt_decrypt('encrypt',$patient['patient_info']->id) }}">
         <input type="hidden" name="careplan_id" value="{{encrypt_decrypt('encrypt',$checkpointDetail->careplan_id)}}">
         <input type="hidden" name="checkpoint_id" value="{{encrypt_decrypt('encrypt',$checkpointDetail->id)}}">
         <input type="hidden" name="intervention_id" value="{{encrypt_decrypt('encrypt',$checkpointDetail->intervention->id)}}">
         <div class="assess-main">
            <div class="row">
               <div class="col-md-3 col-lg-2">
                 @include('patients.caseload.checkpoint.view.sidebar')  
               </div>
               <div class="col-md-9 col-lg-10">
                  <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                     @include('patients.caseload.checkpoint.view.purpose',['assessment'=>$checkpointDetail]) 
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@section('modal_box')
<!--sidebox  -->
<!--view-tools -->
<div class="sidebox-overlay" id="toolsOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-barrier"><i class="fa fa-angle-left"></i> Back</a>{{ trans('label.view_tools') }}</h4>
      </div>
      <div class="slide-body">
         <div class="slide-tools">
            <div class="barrier-search">
               <div class="textfieldglobal">
                  <input type="text" placeholder="Search by Tool Title or Tool ID" disabled="" name='search_tool'>
                  <button class="btn btn-primary basic-btn search_tool" disabled="">Search</button>
               </div>
            </div>
            <div class="table-responsive care-table div_load" id='tool_list'>
               
            </div>
         </div>
      </div>
   </div>
</div>




<div class="sidebox-overlay" id="viewOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-tool-detail"><i class="fa fa-angle-left"></i> Back</a>Tool Details</h4>
         </div>
         <div class="slide-body">
              <div class="slide-section">
               <h4>Basic Details</h4>
              <div class="detail-view">
                  <div class="row tool_detail_data">
                      <div class="col-md-12">
                          <p class="tool_id"><span>Tool ID:</span> TO!O!O </p>
                      </div>
                      <div class="col-md-12">
                          <p class="tool_desc"><span>Tool Descrption:</span> ssas </p>
                      </div>
                      <div class="col-md-12">
                          <p class="tool_type"><span>Tool Type:</span> sas</p>
                      </div>
                  </div>
              </div>
             </div>
         </div>
   </div>   
</div>
@endsection
@section('script')
@include('layouts.route_name')
<script src="{{ asset('js/caseloads/care_plan.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/caseloads/case_load.js') }}" type="text/javascript"></script> 

<script type="text/javascript">
  $.ajaxSetup({
    type:"POST",
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
    beforeSend:function(){
        $('.loader_div').waitMe();
    },
    complete:function(){
        $('.loader_div').waitMe('hide');
        applpyEllipses('dataTable', 5, 'no');
    },
    error:function(error){
    }
  });
 

// function to click on side bar to load the relative tab
$('body').on('click', '.assess-main .nav-link', function(e) {
     e.preventDefault();
        var type = $(this).data('type');
        var checkpointId = $('[name="checkpoint_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var patientId = $('[name="patient_id"]').val();
        var interventionId = $('[name="intervention_id"]').val();

         $.ajax({
            url:"{{ route('patient_checkpoint_detail_tab', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}",
            type: "GET",
            dataType: "json",
            data: {tab:$(this).data('type'),checkpoint_id:checkpointId, careplan_id:careplanId, patient_id:patientId,intervention_id:interventionId,is_view:1},
            success:function(response){
              $('#v-pills-tabContent').html(response.data.html);
              initCustomForms();
           },error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else if(error.status == 404){
                        $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
                    }
                    else if(error.status == 403){
                        $('#v-pills-tab a').not(':first').removeClass('active');
                        $('#v-pills-tab a:first').addClass('active');
                    }
                }
        });
   
});


    $(".close-side-tool-detail").click(function () {
        $('#viewOverlay').find(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $("#viewOverlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
             $('.barrier-search').find('input').removeClass('changed-input');
            $('#viewOverlay').find(".inner-slide").removeClass("slideOutRight");

        }, 1000);
    });
</script>
@endsection