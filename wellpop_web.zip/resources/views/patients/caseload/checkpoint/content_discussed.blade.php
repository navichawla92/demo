<div class="tab-pane fade active show" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
   <h4 class="assess-head">{{ trans('label.content_discussed') }} <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn tool-detail">{{ trans('label.view_tools') }} </button></span></h4>
   <div class="care-box">
      @if(!@$assessment)
            @inject('assessment', 'App\Models\CareplanCheckpoint')
        @endif
        {!! Form::model($assessment,['id' => 'contentDiscussed']) !!}
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">{{ trans('label.checkpoint_content') }}</label>
                  {!! Form::select('visit_content[]', $content_discussed,null,array("class" => "content_discussed",'id'=>"icdCode",'multiple')) !!}
                  <span class="error" id='visit_content' style="color:red"></span> 
               </div>
            </div>
         </div>
      </div>
      <div class="other-notes1">
         <label class="labelfieldsname">{{ trans('label.other_notes') }}</label>
         <textarea class="form-control" name='other_notes' placeholder="{{ trans('label.enter_your_notes_here') }}" value="{{ $assessment->other_notes ?? ''}}"> {{ $assessment->other_notes ?? ''}}</textarea>
          <span class="error" style="color:red"></span> 
      </div>
      <input type="hidden" name="tab_name" value="content_discussed">
       {!! Form::close() !!}
   </div>
   <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="saveContentDiscussed(0);">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right" onClick="saveContentDiscussed(2);">{{ trans('label.save') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right"  onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
</div>

<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">

$(".tool-detail").click(function () {
   handleToolListing();
   $("#toolsOverlay").addClass("show-overlay");
});

function handleToolListing(current_page = '',SearchText='')
{
      if(current_page === '') {
         current_page = $("#tool_list .pagination").find('.active').text();
      }
      var url = "{{ route('patient_tool_list') }}"+'?page='+ current_page;
      $.ajax({
         url:url,
         type:"GET",
         data:{name:SearchText},
         dataType: "json",
         success:function(data){
             $('#tool_list').html(data.html);
             applpyEllipses('div_load', 4, 'no');
         },
         error:function(data){
             alert('error');
         }
      });
}

$('body').on('click', '#tool_list .pagination a', function(e) {
  e.preventDefault();
  page = getURLParameter($(this).attr('href'), 'page');

  name = $('input[name=search_tool]').val();

  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
     },
     error:function(error){
     }
   });
  handleToolListing(page,name);
});


$('body').on('click', '.search_tool', function(e) {
  e.preventDefault();
  name = $('input[name=search_tool]').val();

  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
     },
     error:function(error){
     }
   });
  handleToolListing('',name);
});


$('body').on('click', '.show-detail', function(e) {
   $('.tool_id').html('<span>{{ trans("label.tool_id") }}:</span> '+$(this).data('tool_id'));
   $('.tool_desc').html('<span>{{ trans("label.tool_desc") }}:</span> <b class="more_info"> '+$(this).data('tool_desc')+'</b>');
   $('.tool_type').html('<span>{{ trans("label.tool_type") }}:</span> '+$(this).data('tool_type'));
   $("#viewOverlay").addClass("show-overlay");
   $("body").addClass("hideout");
   handleMoreInfo()
});


$(".content_discussed").chosen({ width:'100%' });
function icdCodeDynamic() {
   //setup before functions
    var typingTimer;                //timer identifier
    var xhr = {abort: function () {  }};  //time in ms (2 seconds)
    var selectID = 'icdCode';    //Hold select id
    var selectData = [];           // data for unique id array

    $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
        minLength:1,
        delay: 300,
        source: function( request, response ) {
          $('#' + selectID + '_chosen .no-results').hide();
           var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
            $.ajax({
                url:"{{ route('content_discussed_list') }}",
                data: {data: inputData,selected_code : $('#' + selectID).val()},
                type:'POST',
                dataType: "json",
                beforeSend: function(){

                },
                success: function( data ) {

                  $('#' + selectID ).find('option').not(':selected').remove();
                  $.map( data.html, function( item ) {
                    if($.inArray(item.id,selectData) == -1){
                      $('#' + selectID ).append('<option value="'+item.id+'" data-id = "'+item.id+'">' + item.code + '- '+ item.title+ '</option>');
                    }
                  });
                  var inputData1 = $('#' + selectID + '_chosen .chosen-choices input').val();
                  $('#' + selectID ).trigger("chosen:updated");
                  $('.chosen-search-input' ).val(inputData1);
                }
            });
        }
    });

    $('#' + selectID ).on('change', function() {
      var domArray = $('#' + selectID ).find('option:selected');
      selectData = [];
      for (var i = 0, length = domArray.length; i < length; i++ ){
        selectData.push( $(domArray[i]).data('id') );
      }

      $('#' + selectID ).html(domArray);
      $('#' + selectID ).trigger("chosen:updated");

      });

}

icdCodeDynamic();


function saveContentDiscussed(is_save) {

       if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="intervention"]').click();
           return false;
       }

        if(is_save == '1'){
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
          $.ajaxSetup({
            type:"POST",
            headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend:function(){
                $('.loader_div').waitMe();
            },
            complete:function(){
                $('.loader_div').waitMe('hide');                
            },
            error:function(error){
            }
          });

        }
  var patientId = $('[name="patient_id"]').val();
  var careplanId = $('[name="careplan_id"]').val();
  var checkpointId = $('[name="checkpoint_id"]').val();

  var formData = new FormData($('#contentDiscussed')[0]);
  formData.append('patient_id', patientId)
  formData.append('careplan_id', careplanId);
  formData.append('checkpoint_id', checkpointId);

  $.ajax({
      url: '{{ route('patient_checkpoint_content_discussed_save') }}',
      data: formData,
      dataType:'JSON',
      contentType: false,
      processData: false,
      success: function(response) {
          $('input,textarea,select').removeClass('changed-input');
          $('#v-pills-tab a[data-type="content_discussed"]').removeClass('text-red');
          $('#v-pills-tab a[data-type="content_discussed"]').find('i').removeClass('chk-hide');
         // $('#v-pills-tab a[data-type="intervention"]').click();
          $('[name="is_save"]').val(1);
          if(is_save == '1'){
            saveCheckpoint();
          }
          if(is_save == '0'){
            $('#v-pills-tab a[data-type="intervention"]').click();
          }
      },
      error: function(errors) {
          $.each(errors.responseJSON.errors,function(key,value){
              if(key == 'visit_content'){
                $('#'+key).html(value).addClass('active').show()
              }
              else {
                $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
              }
          });
          if(is_save == '1'){
            saveCheckpoint();
          }
      }
  });
}

function previousTab(){
   $('#v-pills-tab a[data-type="purpose"]').click();
}


</script>