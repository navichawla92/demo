<table class="table">
   <thead>
      <tr>
         <th> {{ trans('label.serial_number_short_form') }}</th>
         <th> {{ trans('label.tool_id') }} </th>
         <th> {{ trans('label.view_tool_title') }} </th>
         <th> {{ trans('label.tool_type') }} </th>
         <th> {{ trans('label.action') }} </th>
      </tr>
   </thead>
   <tbody>
      @if(count($tools))
      <?php  $index=($tools->perPage() * ($tools->currentPage()- 1))+1; ?>
         <?php  $i = 0;?>
         @foreach($tools as $tool)
      <tr>
         <td>{{ $index }}</td>
         <td>{{ $tool->code }}</td>
         <td>{{ $tool->description }}</td>
         <td>{{ $tool->type }}</td>
         <td><a class="show-detail" data-tool_id="{{$tool->code}}"
         data-tool_desc="{{$tool->description}}" data-tool_type="{{$tool->type}}"><i class="fa fa-eye"></i></a></td>
      </tr>
      
      <?php  $index++; ?>
         @endforeach
      @else
         <tr><td>{{ trans('label.no_record_found') }}</td></tr>
      @endif
   </tbody>
</table>
<?php echo $tools->render(); ?>