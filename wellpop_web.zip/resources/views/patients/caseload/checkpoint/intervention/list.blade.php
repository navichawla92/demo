<table class="table">
            <thead>
               <tr>
                  <th>{{ trans('label.serial_number_short_form') }}</th>
                  <th>{{ trans('label.intervention_date') }} </th>
                  @if(!$is_careplan)
                    <th>{{ trans('label.care_plan_id') }} </th>
                  @endif
                  <th>{{ trans('label.assessment_checkpoint_id') }} </th>
                  <th>{{ trans('label.added_by') }} </th>
                  <th>{{ trans('label.role') }} </th>
                  <th>{{ trans('label.action') }} </th>
               </tr>
            </thead>
            <tbody>
                @if(count($interventionList))
               <?php  $index=($interventionList->perPage() * ($interventionList->currentPage()- 1))+1; ?>
               <?php  $i = 0;?>
                @foreach($interventionList as $intervention)
                 <tr>
                  <td>{{ $index }}</td>
                  <td>{{ $intervention->added_date }}</td>
                  @if(!$is_careplan)
                  <td>{{ $intervention->careplan->code }}</td>
                  @endif
                  @if($intervention->type == 1)
                  <td>
                       @if($intervention->checkpoint)
                          {{ $intervention->checkpoint->code }}
                      @else
                          -
                      @endif
                  </td>
                  @else
                  <td>
                      @if($intervention->assessment)
                          {{ $intervention->assessment->code }}
                      @else
                          -
                      @endif
                  </td>
                  @endif

                  <td>{{ $intervention->user->name }}</td>
                  <td>{{ $intervention->userRole->name }}</td>
                  <td><a class="show-detail" href="{{ route('patient_intervention_view', [encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', $intervention->id)]) }}"><i class="fa fa-eye"></i></a></td>
                   </tr>

                <?php  $index++; ?>
               @endforeach

                @else
               <tr><td>{{ trans('label.no_record_found') }}</td></tr>
               @endif
            </tbody>
</table>
<?php echo $interventionList->render(); ?>
