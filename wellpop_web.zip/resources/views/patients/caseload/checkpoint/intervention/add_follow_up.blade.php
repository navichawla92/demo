<div class="modal fade adddocumentdocuments" id="addFollowModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <div class="headingpage">{{ trans('label.add_follow_up') }}</div>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
         </div>
         <form action="javascript:;" id="follow_up_item">
         <div class="modal-body">
            <div class="form-group">
               <label>{{ trans('label.follow_up_date') }} </label>
               <input type="text" name="follow_up_date" class="form-control datePicker" placeholder="{{ trans('label.enter_follow_up_date') }}">
               <span class="error" id='visit_content' style="color:red"></span> 
            </div>
            <div class="form-group">
               <label>{{ trans('label.follow_up_item') }} </label>
               <input type="text" name="follow_up_item" class="form-control "  placeholder="{{ trans('label.enter_follow_up_item') }}">
               <span class="error" id='visit_content' style="color:red"></span> 
            </div>
         </div>
         <div class="modal-footer">
            <div class="buttonsbottom"> 
              <a href="javascript:;" class="next" onClick="saveFollowUp();">{{ trans('label.save') }}</a> 
              <a href="javascript:;" data-dismiss="modal" class="close">{{ trans('label.cancel') }}</a> 
            </div>
         </div>
         </form>
      </div>
   </div>
</div>

<script type="text/javascript">
   
  function saveFollowUp(){
      $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.modal-content').waitMe();
              },
              complete:function(){
                  $('.modal-content').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
      var patientId = $('[name="patient_id"]').val();
      var careplanId = $('[name="careplan_id"]').val();
      var checkpointId = $('[name="checkpoint_id"]').val();

      var formData = new FormData($('#follow_up_item')[0]);
      formData.append('patient_id', patientId)
      formData.append('careplan_id', careplanId);
      formData.append('id', checkpointId);
      
      $.ajax({
         url: '{{ route('patient_checkpoint_followup_save') }}',
         data: formData,
         dataType:'JSON',
         contentType: false,
         processData: false,
         success: function(response) {
             $('#addFollowModal').modal('hide');
             $('#follow_up_list').html(response.html);
              handleMessages(response, 'save_intervention_followup', false);
              fadeOutAlertMessages();
              $('[name="is_save"]').addClass('changed-input');
              applpyEllipses('care-table', 4, 'no');
         },
         error: function(errors) {
             $.each(errors.responseJSON.errors,function(key,value){
                 if(key == 'visit_content'){
                  $('#'+key).html(value).addClass('active').show()
                 }
                 else {
                  $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                 }
             });

            jQuery('html, body').animate({
                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
            }, 500);
         }
      });
   }
  function datep(){
     $('.datePicker').datepicker({
      autoclose: true,
      format: 'mm-dd-yyyy',
      startDate: '-0d',
     });
  }


   // for modal box close event
  $(document).on('hidden.bs.modal', '.adddocumentdocuments',function () {
      $('#addFollowModal').find('input,textarea,select').removeClass('changed-input');
      $('#follow_up_item').trigger('reset');
      $('span.error').hide().removeClass('active');
  })
</script>