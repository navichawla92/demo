<div class="tab-pane fade active show" id="v-pills-Intervention" role="tabpanel" aria-labelledby="v-pills-Intervention-tab">
   <h4 class="assess-head">{{ trans('label.intervention') }}</h4>
    <div id="save_interventions">
                <div class="alert alert-danger hide">
                    <div class="alert-message"></div>
                </div>
    </div>

   <div class="care-box">

    {!! Form::model($intervention,['id' => 'intervention_form']) !!}

    @php
    $intervention_action = intervention_action();
    @endphp
    @if($careTeam)
    @php
      $userList = [];
      $caseManager = $careTeam->cmUser;
      $commonHealthWorker = $careTeam->chwUser;
      $medicalDirector = $careTeam->mdUser;
      $userList[$careTeam->cmUser->id] = $careTeam->cmUser->name .'(CM)';
      $userList[$careTeam->chwUser->id] = $careTeam->chwUser->name .'(CHW)';
      $userList[$careTeam->mdUser->id] = $careTeam->mdUser->name .'(MD)';
    @endphp

    @endif
      <div class="inter-action">
         <div class="row">
            <div class="col-lg-1 col-md-2">
               <label>{{ trans('label.action') }}</label>
            </div>
            <div class="col-md-3">
               {!! Form::select('action', array('' => 'Select an action') + $intervention_action,null,array("class" => "customselect")) !!}

               <span class="error" style="color:red"></span> 
            </div>
            <div class="col-md-3">
               <div class="flag-box inter-flag">
                  <i class="fas fa-flag show-flag {{ $intervention->flag ?? ''}}-flag " ></i>
                  <div class="select-flag"> 

                    @foreach($flags as $flag)
                    <a class="flag_name" data-flag="{{$flag}}"><i class="fas fa-flag {{$flag}}-flag"></i></a> 
                    
                    @endforeach
                  <!--  <a class="flag_name" data-flag="red"><i class="fas fa-flag red-flag"></i></a> 
                    <a class="flag_name" data-flag="yellow"><i class="fas fa-flag yellow-flag"></i></a> 
                    <a class="flag_name" data-flag="green"><i class="fas fa-flag green-flag"></i></a> -->

                  </div>
               </div>
               <input name="flag" type="hidden" class='selected_flag_name' value="{{ $intervention->flag ?? ''}}" old_value="{{ $intervention->flag ?? ''}}">

               <input name="type" type="hidden" value="{{$type}}">
               <span class="error" style="color:red"></span> 
            </div>
         </div>
         <br>
         <div class="row">
            <div class="col-lg-1 col-md-2">
               <label>{{ trans('label.notes') }}</label>
            </div>
            <div class="col-md-8">
               <textarea class="form-control" name='summary' maxlength="1000" placeholder="{{ trans('label.enter_your_notes_here') }}" value="{{ $intervention->summary ?? ''}}">{{ $intervention->summary ?? ''}}</textarea>
               <span class="error" style="color:red"></span> 
            </div>
         </div>
      </div>
      <hr>
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">{{ trans('label.notify') }}</label>
                 {!! Form::select('assigned_users[]', $userList,null,array("class" => "assigned_users",'id'=>"icdCode",'multiple')) !!}
                  <span class="error" style="color:red" id='assigned_users'></span> 
               </div>
            </div>
         </div>
      </div>
      <input type="hidden" name="tab_name" value="intervention">
      {!! Form::close() !!}

      <h4 class="assess-head fs-16">{{ trans('label.follow_up_actions') }} <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn addFollowModal" ><i class="fa fa-plus new-add"></i> {{ trans('label.new') }}</button></span></h4>

      <span class="error" style="color:red" id='followup_id'></span> 
      <div id="save_intervention_followup">
                <div class="alert alert-danger hide">
                    <div class="alert-message"></div>
                </div>
     </div>
      <div class="table-responsive care-table" id='follow_up_list'>
        @include('patients.caseload.checkpoint.intervention.follow_up_list',['interventionFollowUps' =>$interventionFollowUps])  
      </div>
   </div>
   <div class="asess-btnbox">

      <button class="btn btn-primary basic-btn" onClick="saveIntervention(0);">{{ trans('label.save') }}</button>
      <button class="btn btn-primary basic-btn" style="margin-right:10px;" onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
</div>

@include('patients.caseload.checkpoint.intervention.add_follow_up') 
 <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">
  var followup_id=[];
  applpyEllipses('care-table', 5, 'no');
  function saveIntervention(is_save) {
        if(is_save == '1'){
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                ///  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{

            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }
  var patientId = $('[name="patient_id"]').val();
  var careplanId = $('[name="careplan_id"]').val();
  var checkpointId = $('[name="checkpoint_id"]').val();
  var interventionId = $('[name="intervention_id"]').val();

  var formData = new FormData($('#intervention_form')[0]);
  formData.append('patient_id', patientId)
  formData.append('careplan_id', careplanId);
  formData.append('id', checkpointId);
  formData.append('intervention_id', interventionId);
  formData.append('followup_id', followup_id);

  $('span.error').text('').hide();
  $.ajax({
      url: '{{ route('patient_checkpoint_intervention_save') }}',
      data: formData,
      dataType:'JSON',
      contentType: false,
      processData: false,
      success: function(response) {
          $('input,textarea,select').removeClass('changed-input');
          $('[name="is_save"]').val(1);
          $('#v-pills-tab a[data-type="intervention"]').removeClass('text-red');
          $('#v-pills-tab a[data-type="intervention"]').find('i').removeClass('chk-hide');
          $('[name="intervention_id"]').val(response.intervention_id);
          handleMessages(response, 'save_interventions', false);
          fadeOutAlertMessages();
          if(is_save == '1'){
                    saveCheckpoint();
                }
      },
      error: function(errors) {
          $.each(errors.responseJSON.errors,function(key,value){
              if(key == 'assigned_users' || key == 'followup_id'){
               $('#'+key).html(value).addClass('active').show()
              }
              else {
               $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
              }
          });
          if(is_save == '1'){
                    saveCheckpoint();
                }
      }
  });
}
   $('.show-flag').click(function() {
      $('.select-flag').fadeToggle();
   })


$('body').on('click', '.addFollowModal', function(e) {
  $('#addFollowModal').modal({backdrop: 'static', keyboard: false});
  datep();
});
function previousTab(){
  $('#v-pills-tab a[data-type="content_discussed"]').click();
}

$(".assigned_users").chosen({ width:'100%' });
$('.flag_name').click(function() {

  if($(this).data('flag').toString() != $('.selected_flag_name').attr('old_value').toString()){
        $('.selected_flag_name').addClass('changed-input');
      }
      else {
        $('.selected_flag_name').removeClass('changed-input');
      }
  $('.show-flag').removeClass($('.selected_flag_name').val()+'-flag');
  $('.selected_flag_name').val($(this).data('flag'));
  $('.show-flag').addClass($(this).data('flag')+'-flag');
  $('.select-flag').fadeToggle();
  $('.selected_flag_name').parent().find('span.error').hide().removeClass('active');
})


$('body').on('click', '#follow_up_list .pagination a', function(e) {
  e.preventDefault();
  page = getURLParameter($(this).attr('href'), 'page');


  $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.div_load').waitMe();
     },
     complete:function(){
         $('.div_load').waitMe('hide');
         applpyEllipses('div_load', 5, 'no');
     },
     error:function(error){
     }
   });
  handleFollowUpListing(page);
});


function handleFollowUpListing(current_page = '',SearchText='')
   {

      if(current_page === '') {
         current_page = $("#follow_up_list .pagination").find('.active').text();
      }
      var checkpointId = $('[name="checkpoint_id"]').val();
      var url = "{{ route('patient_followup_list') }}"+'?page='+ current_page;
      console.log(url);
      $.ajax({
         url:url,
         type:"GET",
         data:{id:checkpointId},
         dataType: "json",
         success:function(data){
             $('#follow_up_list').html(data.html);
             handleMessages(data, 'save_intervention_followup', false);
             fadeOutAlertMessages();
             applpyEllipses('care-table', 4, 'no');
         },
         error:function(data){
             alert('error');
         }
      });
  }
  

$('body').on('click', '.followup_chkbox', function(e) {
    if($(this).is(':checked')){
      $(this).parent().parent().find('.checklabel').text('Completed');
    }
    else{
      $(this).parent().parent().find('.checklabel').text('Un-Completed');
    }
});
</script>