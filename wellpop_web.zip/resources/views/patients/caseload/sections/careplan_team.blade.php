<div class="row">
    <div class="col-lg-4 col-md-6">
        <div class="manage-box">
            <h4 class="mini-title">{{ trans('label.case_manager') }} </h4>
            @if($patient->assignedCareplanCm)
                @php
                    $caseManager = $patient->assignedCareplanCm->user;
                @endphp
                <div class="man-box"> <img src="@if($caseManager->image) {{ config('filesystems.s3_user_images_full_path').$caseManager->id.'/'.$caseManager->image }} @else {{ asset('images/noimage.jpg') }} @endif"> </div>
                <p><span>{{ ucwords($caseManager->name) }}</span>
                <span>{{ $caseManager->phone ? "+1 " .phone_number_format($caseManager->phone):  ""  }}</span></p>
            @endif
        </div>
    </div>
    <div class="col-lg-4 col-md-6">
        <div class="manage-box">
            <h4 class="mini-title">{{ trans('label.community_health_worker') }} </h4>

            @if($patient->assignedCareplanChw)
                @php
                    $commonHealthWorker = $patient->assignedCareplanChw->user;
                @endphp
                <div class="man-box"> <img src="@if($commonHealthWorker->image) {{ config('filesystems.s3_user_images_full_path').$commonHealthWorker->id.'/'.$commonHealthWorker->image }} @else {{ asset('images/noimage.jpg') }} @endif"> </div>
                <p><span>{{ ucwords($commonHealthWorker->name) }}</span>
                <span>{{ $commonHealthWorker->phone ? "+1 " .phone_number_format($commonHealthWorker->phone):  ""  }}</span></p>
            @endif

        </div>
    </div>
    <div class="col-lg-4 col-md-6">
        <div class="manage-box">
            <h4 class="mini-title">{{ trans('label.mediacal_director') }} </h4>
            @if($patient->assignedCareplanMd)
                @php
                    $medicalDirector = $patient->assignedCareplanMd->user;
                @endphp
                <div class="man-box"> <img src="@if($medicalDirector->image) {{ config('filesystems.s3_user_images_full_path').$medicalDirector->id.'/'.$medicalDirector->image }} @else {{ asset('images/noimage.jpg') }} @endif"> </div>
                <p><span>{{ ucwords($medicalDirector->name) }}</span>
                 <span>{{ $medicalDirector->phone ? "+1 " .phone_number_format($medicalDirector->phone):  ""  }}</span></p>
            @endif
        </div>
    </div>
</div>