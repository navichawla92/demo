<div class="main-section">
   <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSubThree" aria-expanded="true" aria-controls="collapseSubThree">
      <i class="fa fa-minus-square"></i>
      </button>
      {{ trans('label.insurance_payer') }}
   </div>
   <div class="main-section-inner collapse show" id="collapseSubThree"  aria-labelledby="headingOne">
      <ul class="nav nav-tabs" id="myTab" role="tablist">
         @if($insurance['primaryInsurance'])
         <li class="nav-item"> <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">{{ trans('label.primary_insurance') }}</a> </li>
         @endif
        @if($insurance['secondaryInsurance'])
         <li class="nav-item"> <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile2" role="tab" aria-controls="profile2" aria-selected="false">{{ trans('label.secondary_insurance') }}</a> </li>
        @endif
        @if($insurance['contractPayer'])
         <li class="nav-item"> <a class="nav-link {{ $patient->is_insured ? 'active' : ''}}" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">{{ trans('label.contracted_payer') }}</a> </li>
          @endif
      </ul>
      <div class="tab-content" id="myTabContent">
         @if($insurance['primaryInsurance'])
         @php
         $insurance['primaryInsurance']->calc($patient->random_key);
         $primaryInsurance = $insurance['primaryInsurance']->insurance;
         @endphp
         <div class="tab-pane fade {{ !$patient->is_insured ? 'show active' : ''}}" id="home" role="tabpanel" aria-labelledby="home-tab">
            <div class="insure-data">
               <div class="clearfix"></div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.org_name') }}:</span>{{ $primaryInsurance->org_name??'-' }}</p>
                  <p><span>{{ trans('label.code') }}:</span>{{ $primaryInsurance->code??'-' }}</p>
                  <p><span>{{ trans('label.address_line_1') }}:</span>{{ $primaryInsurance->address_line1??'-' }}</p>
                  <p><span>{{ trans('label.address_line_2') }}:</span>{{ $primaryInsurance->address_line2??'-' }}</p>
                  <p><span>{{ trans('label.city') }}:</span>{{ $primaryInsurance->city??'-' }}</p>
                  <p class="wid-50"><span>{{ trans('label.state') }}:</span>{{ $primaryInsurance->state->full_name??'-' }}</p>
                  <p  class="wid-50"><span>{{ trans('label.zip_code') }}:</span>{{ $primaryInsurance->zip??'-' }}</p>
                  <p><span>{{ trans('label.phone_number') }}:</span>{{ $primaryInsurance->phone_number??'-' }}</p>
                  <p><span>{{ trans('label.fax') }}:</span>{{ $primaryInsurance->fax??'-' }}</p>
                  <p><span>{{ trans('label.web_address') }}:</span>{{ $primaryInsurance->web_address??'-' }}</p>
               </div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.contact_name') }}:</span>{{ $primaryInsurance->contact_name??'-' }}</p>
                  <p><span>{{ trans('label.contact_title') }}:</span>{{ $primaryInsurance->contact_title??'-' }} </p>
                  <p><span>{{ trans('label.contact_phone') }}:</span>{{ $primaryInsurance->contact_phone??'-' }}</p>
                  <p><span>{{ trans('label.contact_email') }}:</span>{{ $primaryInsurance->contact_email??'-' }}</p>
                  <p><span>{{ trans('label.policy') }}:</span>{{ $insurance['primaryInsurance']->policy??'-' }}</p>
                  <p><span>{{ trans('label.group') }}:</span>{{ $insurance['primaryInsurance']->group??'-' }}</p>
                  <p><span>{{ trans('label.authorized_by') }}:</span>{{ $insurance['primaryInsurance']->authorized_by??'-' }}</p>
                  <p><span>{{ trans('label.authorization') }}:</span>{{ $insurance['primaryInsurance']->authorization??'-' }}</p>
                  <p><span>{{ trans('label.effective_date') }}:</span>{{ $insurance['primaryInsurance']->effective_date??'-' }}</p>
                  <p><span>{{ trans('label.expiration_date') }}:</span>{{ $insurance['primaryInsurance']->expiration_date??'-' }}</p>
               </div>
            </div>
         </div>
         @endif
         @if($insurance['secondaryInsurance'])
         @php
         $insurance['secondaryInsurance']->calc($patient->random_key);
         $secondaryInsurance = $insurance['secondaryInsurance']->insurance;
         @endphp
         <div class="tab-pane fade" id="profile2" role="tabpanel" aria-labelledby="profile-tab">
            <div class="insure-data">
               <div class="clearfix"></div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.org_name') }}:</span>{{ $secondaryInsurance->org_name??'-' }}</p>
                  <p><span>{{ trans('label.code') }}:</span>#{{ $secondaryInsurance->code??'-' }}</p>
                  <p><span>{{ trans('label.address_line_1') }}:</span>{{ $secondaryInsurance->address_line1??'-' }}</p>
                  <p><span>{{ trans('label.address_line_2') }}:</span>{{ $secondaryInsurance->address_line2??'-' }}</p>
                  <p><span>{{ trans('label.city') }}:</span>{{ $secondaryInsurance->city??'-' }}</p>
                  <p class="wid-50"><span>{{ trans('label.state') }}:</span>{{ $secondaryInsurance->state->full_name??'-' }}</p>
                  <p  class="wid-50"><span>{{ trans('label.zip') }}:</span>{{ $secondaryInsurance->zip??'-' }}</p>
                  <p><span>{{ trans('label.phone_number') }}:</span>{{ $secondaryInsurance->phone_number??'-' }}</p>
                  <p><span>{{ trans('label.fax') }}:</span>{{ $secondaryInsurance->fax??'-' }}</p>
                  <p><span>{{ trans('label.web_address') }}:</span>{{ $secondaryInsurance->web_address??'-' }}</p>
               </div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.contact_name') }}:</span>{{ $secondaryInsurance->contact_name??'-' }}</p>
                  <p><span>{{ trans('label.contact_title') }}:</span>{{ $secondaryInsurance->contact_title??'-' }} </p>
                  <p><span>{{ trans('label.contact_phone') }}:</span>{{ $secondaryInsurance->contact_phone??'-' }}</p>
                  <p><span>{{ trans('label.contact_email') }}:</span>{{ $secondaryInsurance->contact_email??'-' }}</p>
                  <p><span>{{ trans('label.policy') }}:</span>{{ $insurance['secondaryInsurance']->policy??'-' }}</p>
                  <p><span>{{ trans('label.group') }}:</span>{{ $insurance['secondaryInsurance']->group??'-' }}</p>
                  <p><span>{{ trans('label.authorized_by') }}:</span>{{ $insurance['secondaryInsurance']->authorized_by??'-' }}</p>
                  <p><span>{{ trans('label.authorization') }}:</span>{{ $insurance['secondaryInsurance']->authorization??'-' }}</p>
                  <p><span>{{ trans('label.effective_date') }}:</span>{{ $insurance['secondaryInsurance']->effective_date??'-' }}</p>
                  <p><span>{{ trans('label.expiration_date') }}:</span>{{ $insurance['secondaryInsurance']->expiration_date??'-' }}</p>
               </div>
            </div>
         </div>
         @endif
         @if($insurance['contractPayer'])
         @php
         $contractPayer = $insurance['contractPayer'];
         @endphp
         <div class="tab-pane fade {{ $patient->is_insured ? 'show active' : ''}} " id="contact" role="tabpanel" aria-labelledby="contact-tab">
            <div class="insure-data">
               <div class="clearfix"></div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.contracted_payer') }}:</span>{{  $contractPayer->name??'-' }}</p>
                  <p><span>{{ trans('label.org_name') }}:</span>{{ $contractPayer->org_name??'-' }}</p>
                  <p><span>{{ trans('label.code') }}:</span>#{{ $contractPayer->code??'-' }}</p>
                  <p><span>{{ trans('label.address_line_1') }}:</span>{{ $contractPayer->address_line1??'-' }}</p>
                  <p><span>{{ trans('label.address_line_2') }}:</span>{{ $contractPayer->address_line2??'-' }}</p>
                  <p><span>{{ trans('label.city') }}:</span>{{ $contractPayer->city??'-' }}</p>
                  <p class="wid-50"><span>{{ trans('label.state') }}:</span>{{ $contractPayer->state->full_name??'-' }}</p>
                  <p  class="wid-50"><span>{{ trans('label.zip_code') }}:</span>{{ $contractPayer->zip??'-' }}</p>
                  <p><span>{{ trans('label.effective_start_date') }}:</span>{{ $contractPayer->effective_start_date??'-' }}</p>
                  <p><span>{{ trans('label.effective_end_date') }}:</span>{{ $contractPayer->effective_end_date??'-' }}</p>
                  <p><span>{{ trans('label.authorization_code') }}:</span>{{ $patient->authorization_code??'-'   }}</p>
               </div>
               <div class="insure-sub">
                  <p><span>{{ trans('label.confirmation') }}:</span>{{ $contractPayer->auth_confirmation??'-' }}</p>
                  <p><span>{{ trans('label.phone_number') }}:</span>{{ $contractPayer->phone_number??'-' }}</p>
                  <p><span>{{ trans('label.email') }}:</span>{{ $contractPayer->email??'-' }}</p>
                  <p><span>{{ trans('label.fax') }}:</span>{{ $contractPayer->fax??'-' }}</p>
                  <p><span>{{ trans('label.web_address') }}:</span>{{ $contractPayer->web_address??'-' }}</p>
                  <p><span>{{ trans('label.contact_name') }}:</span>{{ $contractPayer->contact_name??'-' }}</p>
                  <p><span>{{ trans('label.contact_title') }}:</span>{{ $contractPayer->contact_title??'-' }}</p>
                  <p><span>{{ trans('label.contact_phone') }}:</span>{{ $contractPayer->contact_phone??'-' }}</p>
                  <p><span>{{ trans('label.contact_email') }}:</span>{{ $contractPayer->contact_email??'-' }}</p>
                  <p><span>{{ trans('label.contact_fax') }}:</span>{{ $contractPayer->contact_fax??'-' }}</p>
               </div>
            </div>
         </div>
         @endif
      </div>
   </div>
</div>