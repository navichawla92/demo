@extends('layouts.app')
@section('css')
@endsection
@section('title')
{{ trans('label.initial_home_assessment') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-9">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.patient_overview') }} <span><i class="fas fa-angle-right"></i></span>{{ trans('label.initial_home_assessment') }}
         </div>
      </div>
   </div>
   <div class="tab-content">
      <div class="patient-view pat-show case-main-wrap">
         @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
      </div>
      <div class="assess-main">
         <div class="accordion" id="accordionExample">
            <div class="card">
               <div class="card-header" id="headingOne">
                  <h5 class="mb-0">
                     <button class="btn btn-link" type="button" > {{ trans('label.in_home_assessment') }}- {{ return_user_type($assessments['user_type']) }}</button>
                  </h5>
               </div>
               <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">
                     <div class="qa-message-list" id="wallmessages">
                        @foreach($assessments['assessments'] as $assessment)
                        <div class="message-item" id="m9">
                           <div class="message-inner">
                              <div class="message-head clearfix">
                                 <div class="avatar fa-pull-left"><a><img src="@if($assessment->user->image) {{ config('filesystems.s3_user_images_full_path').$assessment->user->id.'/'.$assessment->user->image }} @else {{ asset('images/dummy_user.png') }} @endif"></a></div>
                                 <div class="user-detail">
                                    <h5 class="handle">{{ $assessment->user->name }} <span class="qa-message-when-data">{{ $assessment->assessment_date_with_time }}</span>
{!! $assessment->comment_type == 'assessment_rejection' ? "<span class='badge badge-danger'>{{ trans('label.rejected') }}</span>" : "" !!}   
                                    </h5>
                                    <div class="qa-message-content">
                                       <pre>
                                          {{ $assessment->comment }}
                                       </pre>
                                  </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        @endforeach
                       
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

@endsection