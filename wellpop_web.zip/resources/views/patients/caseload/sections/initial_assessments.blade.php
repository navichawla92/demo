<div class="main-section">
	<div class="headingpage">
	   <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
		  <i class="fa fa-minus-square"></i>
	   </button>  {{ trans('label.initial_home_assessment') }} 
	</div>
	<div class="main-section-inner collapse show" id="collapseFour"  aria-labelledby="headingOne">
	   <div class="row assign-box">
		  <div class="col-lg-4 col-md-6">
			 <h5 class="asign-a">
				<span class="circle-box">{{ trans('label.chw') }}</span>
				<p> {{ trans('label.community_health_worker') }} </span></p>
					<a href="{{ route('caseload_patient_assessments', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', COMMUNITYHEALTHWORKER)]) }}" > {{ trans('label.view_assessment') }}</a> <span class="date-text">{{ trans('label.completed_on') }}
			    {{$patient->md_complete_assessment_at}}
				</span>
			 </h5>
		  </div>
		  <div class="col-lg-4 col-md-6">
			 <h5 class="asign-b">
				<span class="circle-box cm-circle">{{ trans('label.cm') }}</span>
				<p>{{ trans('label.case_manager') }} </span></p>
					<a href="{{ route('caseload_patient_assessments', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', CASEMANAGER)]) }}" > {{ trans('label.view_assessment') }}</a><span class="date-text">{{ trans('label.completed_on') }} {{$patient->cm_complete_assessment_at}}</span>
			 </h5>
		  </div>
		  <div class="col-lg-4 col-md-6">
			 <h5 class="asign-c">
				<span class="circle-box md-circle">{{ trans('label.md') }}</span>
				<p>{{ trans('label.mediacal_director') }} </span></p>
				<a href="{{ route('caseload_patient_assessments', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', MANAGERDIRECTOR)]) }}" > {{ trans('label.view_assessment') }} </a><span class="date-text">{{ trans('label.completed_on') }} {{$patient->md_complete_assessment_at}}</span>
			 </h5>
		  </div>
	   </div>
	</div>
</div>
