<div class="table-responsive care-table sub-table">
   <table class="table">
      <thead>
         <tr>
            <th>{{ trans('label.contact_type') }} </th>
            <th>{{ trans('label.name') }} </th>
            <th>{{ trans('label.phone_number') }} </th>
            <th>{{ trans('label.relationship') }} </th>
         </tr>
      </thead>
      <tbody>
         @if($patient->emergency_person1_name && $patient->emergency_person1_phone && $patient->emergency_person1_relation)
         <tr>
            <td>
               {{ ($patient->emergency_person1_checkbox)?'Emergency':'Family' }} Contact
            </td>
            <td>{{ title_case($patient->emergency_person1_name) }}</td>
            <td>{{ phone_number_format($patient->emergency_person1_phone) }}</td>
            <td>{{ title_case($patient->emergency_person1_relation) }}</td>
         </tr>
         @endif
         @if($patient->emergency_person2_name && $patient->emergency_person2_phone && $patient->emergency_person2_relation)
         <tr>
            <td>
               {{ ($patient->emergency_person2_checkbox)?'Emergency':'Family' }} Contact
            </td>
            <td>{{ title_case($patient->emergency_person2_name) }}</td>
            <td>{{ phone_number_format($patient->emergency_person2_phone) }}</td>
            <td>{{ title_case($patient->emergency_person2_relation) }}</td>
         </tr>
         @endif
      </tbody>
   </table>
</div>