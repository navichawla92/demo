<div class="main-section">
   <div class="headingpage">
      <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
      <i class="fa fa-minus-square"></i>
      </button>
      {{ trans('label.care_plan') }}
      <span class="head-btn main-head-box">
         <!--                            <a class="btn btn-primary basic-btn">Create New Plan</a>-->
         <a class="btn btn-primary basic-btn" href="{{ route('patient_care_plan', encrypt_decrypt('encrypt', $patient->id)) }}" ><i class="fa fa-plus new-add"></i> {{ trans('label.new') }} </a>
      </span>
   </div>
   <div class="main-section-inner collapse show" id="collapseFive"  aria-labelledby="headingOne">
      <div class="clearfix"></div>
      @if(session()->has('message.care-level'))
        <div class="alert alert-{{ session('message.care-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
      <div class="alert dismissible hide">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
           <div class="alert-message"></div>
       </div>
      <div class="table-responsive care-table" id="care_plan_list">
         @include('patients.caseload.care_plan.care_plan_list')
      </div>
   </div>
   @include('patients.caseload.care_plan.update_status')
</div>


@push('scripts')
<script>

function handleCarePlanListing(current_page = '')
  {
   var onlyActiveRecords = 0;

   if(current_page === '') {
       current_page = $("#care_plan_list .pagination").find('.active').text();
   }
  var url = "{{ route('caseload_careplan_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
   var patient_id = $('input[type=hidden][name=patient_id]').val();
   $.ajax({
       url:url,
       type:"GET",
       data:{patient_id:patient_id},
       dataType: "json",
       success:function(data){
           $('#care_plan_list').html(data.html);
           initCustomForms();
       },
       error:function(data){
           alert('error');
       }
   });
  }


$('body').on('click', '#care_plan_list .pagination a', function(e) {
   e.preventDefault();
   page = getURLParameter($(this).attr('href'), 'page');
   handleCarePlanListing(page);
});
</script>

@endpush