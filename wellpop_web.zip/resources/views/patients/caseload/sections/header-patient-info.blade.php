<div class="row">
    <div class="col-sm-2">
        <div class="patient-img-box">
            @if($patient->image)

            <img src="{{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }}" class="img img-fluid">
            @else
            <img src="{{ asset('images/noimage.jpg') }}" class="img img-fluid placeholder-img">
            @endif
        </div>
    </div>
    <div class="col-sm-10 message_data">
        <div class="patient-head">
            <div class="row">
                <div class="col-sm-8">
                    <h4><strong>{{ trans('label.patient_overview') }}:</strong></h4>
                </div>
                <div class="col-sm-4">
                    @if(!$is_form)
                    <div class="head-btn"> <a class="btn btn-primary editPatient" data-toggle="modal" data-target="#editPatient"><i class="fa fa-pencil-alt"></i> Edit</a> </div>
                    @endif
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.patient_name') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ ucfirst($patient->first_name.' '.$patient->last_name) }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.status') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->enrollment_status_name }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.phone_no') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p><?= $patient->phone? "+1 ".$patient->phone:'-' ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.wpn') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->registration_number ? $patient->registration_number : "-" }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.language') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->language_value ? $patient->language_value->name : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.age') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ get_dob_in_years($patient->dob) }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="fix-info">
    <img src="@if($patient->image) {{ config('filesystems.s3_patient_images_full_path').$patient->id.'/'.$patient->image }} @else {{ asset('images/noimage.jpg') }} @endif" class="img img-fluid">
    <div class="info-patient-inner">
        <p>{{ ucfirst($patient->first_name.' '.$patient->last_name) }} ({{ get_dob_in_years($patient->dob) }})</p>
        <p>{{ $patient->registration_number ? $patient->registration_number : "-" }} | {{ $patient->enrollment_status_name }}</p>
        <p><?= $patient->phone? "+1 ".$patient->phone:'' ?></p>
    </div>
</div>