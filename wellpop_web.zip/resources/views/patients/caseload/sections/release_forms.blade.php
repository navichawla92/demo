<div class="main-section">
   <div class="headingpage">
      <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree" >
      <i class="fa fa-minus-square"></i>
      </button>{{ trans('label.release_forms') }}
   </div>
   <div class="main-section-inner  collapse show" id="collapseThree"  aria-labelledby="headingOne" >

         @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
      <div class="clearfix"></div>
      <div class="table-responsive care-table">
         <table class="table">
            <thead>
               <tr>
                  <th>{{ trans('label.serial_number_short_form') }} </th>
                  <th>{{ trans('label.name_of_document') }} </th>
                  <th>{{ trans('label.signed_date') }}</th>
                  <th>{{ trans('label.authorized_by') }} </th>
                  <th>{{ trans('label.action') }} </th>
               </tr>
            </thead>
            <tbody>
              
               <tr>
                  <td>1</td>
                  <td>{{ trans('label.consent_form') }}</td>
                  <td>{{ @$patientConsentForm['consent_form_signature_date'] ? date_format_change(@$patientConsentForm['consent_form_signature_date']) : '-'}}</td>
                  <td>{{ @$patientConsentForm['authorize_by'] }}</td>
                  <td>
                     <div class="dropdown more-btn dropup">
                        <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>...</span> </button>
                        <div class="dropdown-menu " aria-labelledby="dropdownMenu2"> 
                           @if(@$patientConsentForm['signature'] && $patientConsentForm['signature'] != null && $patientConsentForm['signature'] != '')
                           <a class="dropdown-item" href="{{ route('caseload_patient_forms', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt','consent')]) }}" ><i class="fa fa-file"></i> {{ trans('label.view') }}</a> 
                           @else
                           <a class="dropdown-item"href="{{ route('caseload_patient_forms', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt','consent')]) }}" ><i class="fa fa-file"></i> {{ trans('label.sign_form') }}</a> 
                           @endif
                     </div>
                  </td>
               </tr>
               <tr>
                  <td>2</td>
                  <td>HIPPA Authorization Form</td>
                  <td>{{ @$patientHippaForm['hippa_form_signature_date'] ? date_format_change(@$patientHippaForm['hippa_form_signature_date']) : '-'}}</td>
                  <td>{{ @$patientHippaForm['authorize_by'] }}</td>
                  <td>
                      <div class="dropdown more-btn dropup">
                        <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>...</span> </button>
                        <div class="dropdown-menu " aria-labelledby="dropdownMenu2"> 
                          @if(@$patientHippaForm['signature'] && $patientHippaForm['signature'] != null && $patientHippaForm['signature'] != '')
                           <a class="dropdown-item" href="{{ route('caseload_patient_forms', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt','hippa')]) }}" ><i class="fa fa-file"></i> {{ trans('label.view') }}</a> 
                           @else
                           <a class="dropdown-item"href="{{ route('caseload_patient_forms', [ encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt','hippa')]) }}" ><i class="fa fa-file"></i> {{ trans('label.sign_form') }}</a> 
                           @endif
                     </div>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
   </div>
</div>
