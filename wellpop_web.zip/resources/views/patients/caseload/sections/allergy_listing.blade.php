<div class="main-section">
   <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
      <i class="fa fa-minus-square"></i>
      </button>
      {{ trans('label.allergies') }} <span class="head-btn main-head-box">
      <button class="btn btn-primary basic-btn" id="add_new_allergy"><i class="fa fa-plus new-add"></i> New</button>
      </span>
   </div>
   <div class="main-section-inner collapse show" id="collapseSeven"  aria-labelledby="headingOne">

       <div class="alert dismissible hide">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
           <div class="alert-message"></div>
       </div>

      <div class="table-responsive care-table" id="allergies_listing">
       @include('patients.allergies.allergies_listing',['type'=>'case_load','is_careplan'=>0])
      </div>
   </div>
   @include('patients.allergies.add_allergy',['type'=>'case_load'])
</div>


<!--  discountinueMedication-->
<div class="modal fade md_assessment_data" id="discontinueAllergyModal" tabindex="-1" role="dialog" aria-labelledby="discontinueAllergyModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="headingpage">{{ trans('label.discontinue_allergy') }}</div>
            </div>
            <form action="javascript:;" id="allergyDiscontinueForm">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-warning text-center" role="alert"></div>
                            <div class="textfieldglobal">
                                <label class="labelfieldsname"> Enter Reason* </label>
                                <textarea name="reason" type="text" old_value="" placeholder="Enter reason"></textarea>
                                <span class="error" style="color: red; display: none;"></span>
                                <input type="hidden" name="id">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="buttonsbottom">
                        <button type="submit" class="next">Complete</button>
                        <a href="javascript:;" class="close" data-dismiss="modal" aria-label="Close">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


@push('scripts')
<script>

    function showAllergyDiscontinueModal(target) {

        if($(target).attr('data-status') == 1) {
            $('#discontinueAllergyModal .headingpage').text("{{ trans('label.discontinue_allergy') }}")
            $('#discontinueAllergyModal .alert-warning').text("{{ trans('message.discontinue_allergy') }}")
        } else {
            $('#discontinueAllergyModal .headingpage').text("{{ trans('label.start_allergy') }}")
            $('#discontinueAllergyModal .alert-warning').text("{{ trans('message.start_allergy') }}")
        }

        $('#discontinueAllergyModal').modal('show');
        $('#allergyDiscontinueForm input[name="id"]').val($(target).attr('data-id'));
    }


    function handleAllergyDiscontinueForm()
    {
        var form = $('#allergyDiscontinueForm');

        form.submit(function(){
            $.ajax({
                url:UPDATE_ALLERGY_STATUS_ROUTE,
                data:form.serialize(),
                dataType: "json",
                success:function(data) {
                    handleAllergyListing();
                    $('#discontinueAllergyModal').modal('hide');
                    form[0].reset();

                    handleMessages(data, 'allergies_listing', true);
                    fadeOutAlertMessages();
                },
                error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else{
                        $.each(error.responseJSON.errors,function(key,value){
                            $('textarea[name="'+key+'"]').parent().find('span.error').html(value).show();
                        });
                    }
                }
            });
        });

        return false;
    }


    function handleAllergyListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#allergies_listing .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_allergy_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
        var patient_id = $('input[type=hidden][name=patient_id]').val();
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id},
            dataType: "json",
            success:function(data){
                $('#allergies_listing').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#allergies_listing .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleAllergyListing(page);
    });


    function allergyDetail(target, submitURL = '')
    {
        if(target) {
            var submitURL = "{{ route('caseload_allergy_detail',[encrypt_decrypt('encrypt',$patient->id)]) }}";
            var id = $(target).attr('data-id');
        } else {
            var id = getURLParameter(submitURL, 'id');
        }

        $.ajax({
            url:submitURL,
            data:{id:id},
            type:"GET",
            dataType: "json",
            success:function(data)
            {
                $("#allergyHistoryOverlay").html(data.html);
                if(target) {
                    $("#allergyHistoryOverlay").addClass("show-overlay");
                    $("body").addClass("hideout");
                }
                handleAllergyHistoryPagination();
            },
            error:function(error){
                if(error.status == 500){
                    $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    // window.location.reload();
                }
                if(error.status == 404){
                    window.location.reload();
                }
            }
        });
    }


    function handleAllergyHistoryPagination()
    {
        $('.allergy_history_pagination .pagination a').on('click', function(){
            allergyDetail(false,$(this).attr('href'));
            return false;
        });
    }

    function hideAllergySidebar() {
        $("#allergyHistoryOverlay").removeClass("show-overlay");
        $("body").removeClass("hideout");
    }

    handleAllergyDiscontinueForm();
</script>

@endpush