<div class="main-section">
   <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTen">
      <i class="fa fa-minus-square"></i>
      </button>
     {{ trans('label.interventions') }} 
   </div>
   <div class="main-section-inner collapse show" id="collapseTen"  aria-labelledby="headingOne">
      <div class="table-responsive care-table" id="intervention_list">
          @include('patients.caseload.checkpoint.intervention.list',['interventionList'=>$interventionList,'is_careplan'=>0])
      </div>
   </div>
</div>


@push('scripts')
<script type="text/javascript">
   
   function handleInterventionListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#intervention_list .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_intervention_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
        var patient_id = $('input[type=hidden][name=patient_id]').val();
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id},
            dataType: "json",
            success:function(data){
                $('#intervention_list').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#intervention_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleInterventionListing(page);
    });


</script>
@endpush