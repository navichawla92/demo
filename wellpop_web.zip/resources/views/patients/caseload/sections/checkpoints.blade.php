<div class="main-section">
   <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseNine">
      <i class="fa fa-minus-square"></i>
      </button>
      {{ trans('label.checkpoints') }} <span class="head-btn main-head-box">
        @if($activeCarePlan)
      <a class="btn btn-primary basic-btn active_add_btn" href="{{ route('patient_checkpoint', encrypt_decrypt('encrypt', $patient->id)) }}"><i class="fa fa-plus new-add"></i> {{ trans('label.new') }} </a>
      @endif
      </span>
   </div>
   <div class="main-section-inner collapse show" id="collapseNine"  aria-labelledby="headingOne">
        @if(session()->has('message.checkpoint-level'))
          <div class="alert alert-{{ session('message.checkpoint-level') }} alert-dismissible"> 
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {!! session('message.content') !!}
        </div>
        @endif 
      <div class="table-responsive care-table" id="checkpoint_list">
        @include('patients.caseload.checkpoint.list',['checkpointList'=>$checkpointList,'is_careplan'=>0])
      </div>
   </div>
</div>
@push('scripts')
<script type="text/javascript">
   
   function handleCheckpointListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#checkpoint_list .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_checkpoint_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;

        console.log(url);
        var patient_id = $('input[type=hidden][name=patient_id]').val();
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id},
            dataType: "json",
            success:function(data){
                $('#checkpoint_list').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#checkpoint_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleCheckpointListing(page);
    });


</script>
@endpush