<div class="table-responsive care-table sub-table">
   <table class="table">
      <thead>
         <tr>
            <th>{{ trans('label.contact_type') }} </th>
            <th>{{ trans('label.organization') }} </th>
            <th>{{ trans('label.phone_number') }} </th>
            <th>{{ trans('label.name') }} </th>
         </tr>
      </thead>
      <tbody>
         @if($otherContacts->count())
         @foreach($otherContacts as $contact)
         <tr>
            <td>{{ get_registry_type($contact->type) }}</td>
            <td>{{ $contact->org_name }}</td>
            <td>{{ $contact->phone_number }}</td>
            @if($contact->type == 'pcp_informations' || $contact->type == 'specialities')
               <td>{{ $contact->name ? title_case($contact->name) : '-' }}</td>
            @else
               <td>{{ $contact->contact_name ? title_case($contact->contact_name) : '-' }}</td>
            @endif
         </tr>
         @endforeach
         @else
         <tr>
            <td colspan="4">{{ trans('label.no_record_found') }}</td>
         </tr>
         @endif
      </tbody>
   </table>
</div>