<section id="team">
    <div class="main-section ">
        <div class="headingpage">
            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="fa fa-minus-square"></i>
            </button>
           {{ trans('label.wellpop_care_team') }} 
            <span class="head-btn main-head-box">
                <button class="btn btn-primary edit_assignment basic-btn" data-toggle="modal" data-target="#editAssignment"  data-chw="{{ $patient->assignedCareplanChw ? $patient->assignedCareplanChw->type_id : "" }}" data-md="{{ $patient->assignedCareplanMd ? $patient->assignedCareplanMd->type_id : '' }}" data-cm="{{ $patient->assignedCareplanCm ? $patient->assignedCareplanCm->type_id : '' }}" >
             {{ trans('label.change_care_team') }}
                </button>
            </span>
        </div>
        <div class="main-section-inner collapse show sub-main-new" id="collapseTwo"  aria-labelledby="headingOne">
            <div class='wellpop_team_section'>
                @include('patients.caseload.sections.careplan_team')
            </div>
            <!--inner-->
            <div class="main-section">
                <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSubOne" aria-expanded="true" aria-controls="collapseSubOne">
                        <i class="fa fa-minus-square"></i>
                    </button>
                   {{ trans('label.other_contacts') }}   
                </div>
                <div class="main-section-inner collapse show" id="collapseSubOne"  aria-labelledby="headingOne">
                     @include('patients.caseload.sections.other_contact')
                </div>
            </div>
            <div class="main-section">
                <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSubTwo" aria-expanded="true" aria-controls="collapseSubTwo">
                        <i class="fa fa-minus-square"></i>
                    </button>
                    {{ trans('label.emergency_contacts') }}   
                </div>
                <div class="main-section-inner collapse show" id="collapseSubTwo"  aria-labelledby="headingOne">

                    @include('patients.caseload.sections.emergency_contact')
                    
                </div>
            </div>
            <!--inner-->
        </div>
    </div>
</section>