
<div class="main-section">
    <div class="headingpage">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <i class="fa fa-minus-square"></i>
        </button>
        {{ trans('label.patient_details') }}
    </div>
    <div class="main-section-inner collapse show" id="collapseOne"  aria-labelledby="headingOne">
        <div class="row">
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.alias') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->patient_alias ? $patient->patient_alias : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.address_line_1') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->address_line1 ? $patient->address_line1 : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.dob') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                          
                            <p>{{ $patient->dob ?  $patient->dob : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.address_line_2') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->address_line2 ? $patient->address_line2 : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.ssn') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>
                                <?php
                                    $strring = substr($patient->ssn, 7);
                                    echo '*****'.$strring;
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.city') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->city ? $patient->city : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.email') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->email ? $patient->email : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.state') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->state_name ? $patient->state_name : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.gender') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->gender ? $patient->gender : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-md-6 field-box">
                <div class="form-group">
                    <label class="control-label" for="pwd">{{ trans('label.zip_code') }}:</label>
                    <div class="control-field col-xl-7 col-md-6">
                        <div class="row">
                            <p>{{ $patient->zip_code ? $patient->zip_code : "-"}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
