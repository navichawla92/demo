<div class="table-responsive care-table">
    <table class="table diag-table">
        <thead>
        <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.date_added') }} </th>
            <th>{{ trans('label.priority') }} </th>
            <th>{{ trans('label.diagnosis') }} </th>
            @if(!$is_careplan_detail)
            <th>{{ trans('label.action') }} </th>
            @endif
        </tr>
        </thead>
        <tbody>

        @foreach($diagnosisList as $key => $diagnosis)
            @php
                $i = $key + 1;
            @endphp
            <tr>
                <td>{{ $i }}</td>
                <td>{{ $diagnosis->created_at }}</td>
                <td>{{ $diagnosis->priority }}</td>
                <td >
                     <span class="accordion table-accord" id="accordionExample2">
                        <div class="card">
                           <div class="card-header" id="headingOne">
                              <h5 class="mb-0">
                                 <button class="btn btn-link collapsed"
                                         type="button"
                                         data-toggle="collapse"
                                         data-target="#dropi-{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}"
                                         data-diagnosisId='{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}'
                                         onclick="loadDiagnosisGoal(this)"
                                         aria-expanded="true"
                                         aria-controls="dropi">
                                     {{ $diagnosis->diagnosis->title }}
                                     <span class="goal-count">{{ $diagnosis->goal_count }} {{ str_plural('Goal',$diagnosis->goal_count) }}
                                         <i class="fa fa-angle-down"></i>
                                     </span>
                                 </button>
                              </h5>
                           </div>
                           <div id="dropi-{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}" class="collapse" aria-labelledby="headingOne">

                           </div>
                        </div>
                     </span>
                </td>
                 @if(!$is_careplan_detail)
                <td>
                    <div class="dropdown more-btn dropup">
                        <button class="btn dropdown-toggle" type="button" id="dropdownMenu2"
                                data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                            <span>...</span>
                        </button>
                        <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                            <a href="javascript:;"
                               onclick="editDiagnosis(this)"
                               data-diagnosis_id="{{ $diagnosis->diagnosis_id }}"
                               data-diagnosis_version="{{ $diagnosis->diagnosis_version }}"
                               class="dropdown-item edit-detail">
                               <i class="fa fa-pencil-alt"></i>{{ trans('label.manage_goals') }}
                            </a>

                            <a class="dropdown-item " data-id="{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}"  onclick="removeDiagnosis(this)">
                                <i class="fa fa-trash"></i> {{ trans('label.remove_diagnosis') }} 
                            </a>
                        </div>
                    </div>
                </td>
                @endif
            </tr>
        @endforeach


        @if($diagnosisList->total() == 0)
            <tr>
                <td colspan="4">{{ trans('label.no_record_found') }}.</td>
            </tr>
        @endif

        </tbody>
    </table>
</div>

<div class="careplan_diagnosis_list">
    {{ $diagnosisList->links() }}
</div>