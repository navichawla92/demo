@extends('layouts.app')
@section('title')
{{ trans('label.view_care_plan') }}
@endsection
@section('content')
<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-9">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span> {{ trans('label.view_care_plan') }} 
         </div>
      </div>
      
         <div class="col-md-3">
           <div class="buttonsbottom view-plan-btn "> <a href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#plan']) }}" class="next backi"><i class="fa fa-angle-left"> </i>&nbsp; Back</a> </div>
         </div>
         
   </div>
   <div class="tab-content">
    @if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      {!! session('message.content') !!}
    </div>
    @endif
      <div class="patient-view pat-show case-main-wrap">
         @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
      </div>
   
      <!--
         <div class="expandy-accord">
           <a class="closeall btn btn-main" accordion-id="#accordionExample">Collapse All</a>
         <a class="openall btn btn-main" accordion-id="#accordionExample">Expand All</a>
         </div>  
         -->
      <div class="care-view-box">
         <ul>
            <li><span class="in-view">{{ trans('label.care_plan_id') }}:</span>{{ $carePlanDetail->code }}</li>
            <li><span class="in-view">{{ trans('label.start_date') }}:</span>{{ $carePlanDetail->start_date }} </li>
            <li><span class="in-view">{{ trans('label.end_date') }}:</span>{{ $carePlanDetail->end_date ?? ""}}</li>
            <li><span class="in-view">{{ trans('label.status') }}:</span>{!! $carePlanDetail->status_badge !!}</li>
         </ul>
         @if($carePlanDetail->is_base_line)
         <b class="next baseline-btn"> {{ trans('label.baselined') }} </b> 
         @else
          @if($carePlanDetail->status == 1)
         <a href="#" class="next baseline-btn is_baseline">{{ trans('label.baseline_this_care_plan') }}</a>  
         @endif
         @endif
      </div>
      <div class="assess-main">
         <div class="row">
            <div class="col-md-3 col-lg-2">
               <div class="nav flex-column nav-pills left-bar" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                  <a class="nav-link active" id="v-pills-home-tab" data-type="team" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">{{ trans('label.wellpop_care_team') }}</a>
                  <a class="nav-link" id="v-pills-profile-tab" data-type="otherinfo" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">{{ trans('label.other_contacts') }} </a>
                  <a class="nav-link" id="v-pills-messages-tab" data-type="emergency_contact" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">{{ trans('label.emergency_contacts') }} </a>
                  <p class="tab-sub">{{ trans('label.care_plan') }} </p>
                  <a class="nav-link" id="v-pills-settings-tab" data-type="diagnosis_goals" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false"> {{ trans('label.diagnosis_goals') }} </a>
                  <a class="nav-link" id="v-pills-Barriers-tab" data-type="medication" data-toggle="pill" href="#v-pills-Barriers" role="tab" aria-controls="v-pills-Barriers" aria-selected="false">{{ trans('label.medication') }} </a> 
                  <a class="nav-link" id="v-pills-allergy-tab" data-type="allergy" data-toggle="pill" href="#v-pills-allergy" role="tab" aria-controls="v-pills-allergy" aria-selected="false">{{ trans('label.allergies_list') }} </a>
                  <a class="nav-link" id="v-pills-vitals-tab" data-type="vital" data-toggle="pill" href="#v-pills-vitals" role="tab" aria-controls="v-pills-vitals" aria-selected="false">{{ trans('label.vitals') }} </a>
                  <p class="tab-sub">{{ trans('label.monitoring') }} </p>
                  <a class="nav-link" id="v-pills-assess-tab" data-type="assessments" data-toggle="pill" href="#v-pills-assess" role="tab" aria-controls="v-pills-assess" aria-selected="false">{{ trans('label.assessments') }} </a> 
                  <a class="nav-link" id="v-pills-check-tab" data-type="checkpoints" data-toggle="pill" href="#v-pills-check" role="tab" aria-controls="v-pills-check" aria-selected="false">{{ trans('label.checkpoints') }} </a> 
                  <a class="nav-link" id="v-pills-solution-tab" data-type="barriers" data-toggle="pill" href="#v-pills-solution" role="tab" aria-controls="v-pills-solution" aria-selected="false">{{ trans('label.barriers_solutions') }} </a>
                  <a class="nav-link" id="v-pills-Intervention-tab" data-type="intervention" data-toggle="pill" href="#v-pills-Intervention" role="tab" aria-controls="v-pills-Intervention" aria-selected="false">{{ trans('label.interventions') }} </a> 
                   <a class="nav-link" id="v-pills-note-tab" data-type="notes" data-toggle="pill" href="#v-pills-note" role="tab" aria-controls="v-pills-note" aria-selected="false">{{ trans('label.notes') }} </a> 
               </div>
            </div>
            <div class="col-md-9 col-lg-10">
               <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                    @include('patients.caseload.care_plan.careteam_tab')
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@section('modal_box')
<div class="sidebox-overlay" id="viewOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side"><i class="fa fa-angle-left"></i> Back</a>Goal Details</h4>
      </div>
      <div class="slide-body">
         <div class="slide-section">
            <h4>Basic Details</h4>
            <div class="detail-view">
               <div class="row">
                  <div class="col-md-5">
                     <p><span>Goal ID:</span> GID001</p>
                  </div>
                  <div class="col-md-6">
                     <p><span>Goal Title:</span> Commit Patient to Therapy </p>
                  </div>
                  <div class="col-md-5">
                     <p><span>Goal Type:</span> Quantitative</p>
                  </div>
                  <div class="col-md-6">
                     <p><span>Goal Metric: </span> Binary</p>
                  </div>
                  <div class="col-md-5">
                     <p><span>Flag: </span> Yes</p>
                  </div>
               </div>
            </div>
         </div>
         <div class="slide-section sub-part custom-single-detail">
            <h4>Sub Goals (2)</h4>
            <div class="detail-view sub-detail">
               <p><span>Sub Goal Description:</span> lorem ipsum dolor sit omet, consectetur odipisicing elit, sed do eiusmod tempor incididunt ut lobore et dolore mag no oliquo. Ut enim ad minim veniom, quis 
                  nostrud exerci,totion ullomco loboris nisi ut oliquip ex ea commodo consequot. Duis oute irure dolor in reprehenderit in voluptote velit esse cilium dolore eu 
                  fugiot nullo poriotur. Excepteur sint occoecot cupidotot non proident, sunt in culpa qui officio deserunt mollit onim id est loborum. 
               </p>
               <p><span>Assigned To (Role): </span> CM,CHW,MD </p>
            </div>
            <div class="detail-view sub-detail">
               <p><span>Sub Goal Description:</span> lorem ipsum dolor sit omet, consectetur odipisicing elit, sed do eiusmod tempor incididunt ut lobore et dolore mag no oliquo. Ut enim ad minim veniom, quis 
                  nostrud exerci,totion ullomco loboris nisi ut oliquip ex ea commodo consequot. Duis oute irure dolor in reprehenderit in voluptote velit esse cilium dolore eu 
                  fugiot nullo poriotur. Excepteur sint occoecot cupidotot non proident, sunt in culpa qui officio deserunt mollit onim id est loborum. 
               </p>
               <p><span>Assigned To (Role): </span> CM,CHW,MD </p>
            </div>
         </div>
         <div class="slide-section sub-part custom-single-detail">
            <h4>Questions (2)</h4>
            <div class="detail-view sub-detail">
               <p><span>Question: </span> Did you toke your Medicine? </p>
               <p><span>Assigned To (Role): </span> CM,CHW,MD </p>
               <p><span>Metric: </span> Binary </p>
            </div>
            <div class="detail-view sub-detail">
               <p><span>Question: </span> Did you toke your Medicine? </p>
               <p><span>Assigned To (Role): </span> CM,CHW,MD </p>
               <p><span>Metric: </span> Binary </p>
            </div>
         </div>
      </div>
   </div>
</div>
 <!--historysidebox  -->
<div class="sidebox-overlay" id="medicationHistoryOverlay"></div>
<div class="sidebox-overlay" id="allergyHistoryOverlay"></div>
<div class="sidebox-overlay" id="goal_detail_sidebar">
        <div class="inner-slide animated slideInRight fast">
            <div class="slide-head">
                <h4><a class="close-side close_goal_detail_sidebar"><i class="fa fa-angle-left"></i> Back</a>Goal Details</h4>
            </div>
             <div id="goal_detail_body"></div>
            </div>
        </div>
</div>
@endsection
@section('script')

<script type="text/javascript">
$.ajaxSetup({
  type:"POST",
  headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
  beforeSend:function(){
      $('.loader_div').waitMe();
  },
  complete:function(){
      $('.loader_div').waitMe('hide');
      applpyEllipses('dataTable', 5, 'no');
  },
  error:function(error){
  }
});
 

// function to click on side bar to load the relative tab      
$('body').on('click', '.assess-main .nav-link', function(e) {
        e.preventDefault();
        var type = $(this).data('type');
         $.ajax({  
            url:"{{ route('patient_care_plan_detail-tab', [encrypt_decrypt('encrypt',$patient['patient_info']->id),encrypt_decrypt('encrypt',$carePlanDetail->id)]) }}",
            type: "GET",
            dataType: "html",
            data: {tab:$(this).data('type'),id:'{{ encrypt_decrypt('encrypt',$carePlanDetail->id) }}'},
            success:function(data){
              var success = $.parseJSON(data);
              $('#v-pills-tabContent').html(success.html.data);
              if(type == 'diagnosis_goals'){
                initializeCareplanDiagnosisPagination();
              }
              applpyEllipses('care-table', 4, 'no');

           },error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else if(error.status == 404){
                        $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
                    }
                    else{
                        
                    }
                }
        });
   
});

// function to handle medication listing      

  function handleMedicationListing(current_page = '')
   {
       
       if(current_page === '') {
           current_page = $("#medication_listing .pagination").find('.active').text();
       }
       var url = "{{ route('caseload_meditation_list', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}"+'?page='+ current_page;
       var patient_id = $('input[type=hidden][name=patient_id]').val();
       $.ajax({
           url:url,
           type:"GET",
           data:{patient_id:patient_id, is_careplan: 1},
           dataType: "json",
           success:function(data){
               $('#medication_listing').html(data.html);
           },
           error:function(data){
               alert('error');
           }
       });
   }
// function to handle medication listing paginations 
   $('body').on('click', '#medication_listing .pagination a', function(e) {
       e.preventDefault();
       page = getURLParameter($(this).attr('href'), 'page');
       handleMedicationListing(page);
   });

// function to handle medication detail 
   function medicationDetail(target, submitURL = '')
      {
        if(target) {
            var submitURL = "{{ route('caseload_meditation_detail',[encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}";
            var id = $(target).attr('data-id');
        } else {
            var id = getURLParameter(submitURL, 'id');
        }

        $.ajax({
          url:submitURL,
          data:{id:id},
          type:"GET",
          dataType: "json",
          success:function(data)
          {
              $("#medicationHistoryOverlay").html(data.html);
              if(target) {
                  $("#medicationHistoryOverlay").addClass("show-overlay");
                  $("body").addClass("hideout");
              }
              handleMedicationHistoryPagination();
          },
          error:function(error){
           if(error.status == 500){
              $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
             // window.location.reload();
           }
           if(error.status == 404){
              window.location.reload();
           }   
          }
        });
      }

// function to handle medication history listing paginations 
function handleMedicationHistoryPagination()
    {
      $('.medication_history_pagination .pagination a').on('click', function(){
          medicationDetail(false,$(this).attr('href'));
          return false;
      });
    }

function hideMedicationSidebar() {
   $("#medicationHistoryOverlay").removeClass("show-overlay");
   $("body").removeClass("hideout");
}
/* allergy js   */

// function to handle allergy listing  
function handleAllergyListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#allergies_listing .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_allergy_list', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}"+'?page='+ current_page;
        var patient_id = $('input[type=hidden][name=patient_id]').val();
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id, is_careplan: 1},
            dataType: "json",
            success:function(data){
                $('#allergies_listing').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }
// function to handle allergy listing paginations 
    $('body').on('click', '#allergies_listing .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleAllergyListing(page);
    });

// function to handle allergy detail 
    function allergyDetail(target, submitURL = '')
    {
        if(target) {
            var submitURL = "{{ route('caseload_allergy_detail',[encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}";
            var id = $(target).attr('data-id');
        } else {
            var id = getURLParameter(submitURL, 'id');
        }

        $.ajax({
            url:submitURL,
            data:{id:id},
            type:"GET",
            dataType: "json",
            success:function(data)
            {
                $("#allergyHistoryOverlay").html(data.html);
                if(target) {
                    $("#allergyHistoryOverlay").addClass("show-overlay");
                    $("body").addClass("hideout");
                }
                handleAllergyHistoryPagination();
            },
            error:function(error){
                if(error.status == 500){
                    $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    // window.location.reload();
                }
                if(error.status == 404){
                    window.location.reload();
                }
            }
        });
    }

// function to handle allergy  history listing paginations 
    function handleAllergyHistoryPagination()
    {
        $('.allergy_history_pagination .pagination a').on('click', function(){
            allergyDetail(false,$(this).attr('href'));
            return false;
        });
    }

    function hideAllergySidebar() {
        $("#allergyHistoryOverlay").removeClass("show-overlay");
        $("body").removeClass("hideout");
    }

// function to handle is base line button 

    $('body').on('click', '.is_baseline', function(e) {
        var id = "{{ encrypt_decrypt('encrypt',$carePlanDetail->id) }}";
        e.preventDefault();
        bootbox.confirm({ 
        message: "{{ trans('message.baseline_alert_message') }}", 
        callback: function(result){  
          if (result) {

            $.ajax({
             url:"{{ route('caseload_update_careplan_status') }}",
             data:{id:id, is_base_line: 1},
             dataType: "json",
             success:function(data) {
                 window.location.reload();
             },
             error:function(error) {
                 if(error.status == 500){
                     $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                 }
                 else{
                     $.each(error.responseJSON.errors,function(key,value){
                         $('textarea[name="'+key+'"]').parent().find('span.error').html(value).show();
                     });
                 }
             }
            });

            $('input,textarea,select').removeClass('changed-input');
            
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
    });


fadeOutAlertMessages();


function loadDiagnosisGoal(target) {
    var diagnosisId = $(target).attr('data-diagnosisId');
    var careplanId = "{{ encrypt_decrypt('encrypt',$carePlanDetail->id) }}";
    if($(target).hasClass('collapsed') && $.trim($('#dropi-'+diagnosisId).text()).length < 5) {
        var url = '{{ route('careplan_diagnosis_goal_list') }}?careplan_id='+careplanId+'&diagnosis_id='+diagnosisId;
        $.get(url, function(response){
            $('#dropi-'+diagnosisId).html(response.html);
            initializeDiagnosisGoalsPagination(diagnosisId);
        },'json');
    }
}

function initializeDiagnosisGoalsPagination(diagnosisId)
{
    $('#dropi-'+diagnosisId+' .careplan_diagnosis_goal_list .pagination a').click(function(){
        $.get($(this).attr('href'), function(response){
             $('#dropi-'+diagnosisId).html(response.html);
            initializeDiagnosisGoalsPagination(diagnosisId);
        },'json');
        return false;
    });
}

function getGoalDetails(target)
  {
      var goalId = $(target).attr('data-goal_id');
      var goalVersion = $(target).attr('data-goal_version');

      var url = '{{ route('careplan_diagnosis_goal_detail') }}?goal_version='+goalVersion+'&goal_id='+goalId;
      $.get(url, function(response){
          $("#goal_detail_sidebar").addClass("show-overlay");
          $('#goal_detail_body').html(response.html);
          $("body").addClass("hideout");

          handleGoalDetailPagination();
      },'json');
  }


function handleGoalDetailPagination()
{   
    $.ajaxSetup({
      type:"POST",
      headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
      beforeSend:function(){
          $('.inner-slide').waitMe();
      },
      complete:function(){
          $('.inner-slide').waitMe('hide');
          applpyEllipses('dataTable', 5, 'no');
      },
      error:function(error){
      }
    });
    $('.careplan_subgoal_pagination .pagination a').click(function(){
        $.get($(this).attr('href'), function(response){
            $('.careplan_subgoal_list').html(response.html);
            $("body").addClass("hideout");
            handleGoalDetailPagination();
        },'json');

        return false;
    });

    $('.careplan_question_pagination .pagination a').click(function(){
        $.get($(this).attr('href'), function(response){
            $('.careplan_question_list').html(response.html);
            $("body").addClass("hideout");
            handleGoalDetailPagination();
        },'json');

        return false;
    });

}

$('.close_goal_detail_sidebar').click(function(){
            $(".inner-slide").addClass("slideOutRight");
            setTimeout(function () {
                $("#goal_detail_sidebar").removeClass("show-overlay");
                //    $(".sidebox-overlay").removeClass("show-overlay");
                $("body").removeClass("hideout");
                $(".inner-slide").removeClass("slideOutRight");

            }, 1000);
});

function initializeCareplanDiagnosisPagination()
        {
            $('.careplan_diagnosis_list .pagination a').click(function(){
                $.get($(this).attr('href'), function(response){
                    if(response.hasOwnProperty('diagnosis_html')) {
                        $('#careplan_diagnosis_list').html(response.diagnosis_html);
                        initializeCareplanDiagnosisPagination();
                    }
                }, 'json')

                return false;
            });
        }
if(window.location.href.indexOf('#intervention') !='-1'){
   $('#v-pills-tab').find('.nav-link').removeClass('active show');
   $('#v-pills-tab a[data-type="intervention"]').click();
   $('#v-pills-tab a[data-type="intervention"]').addClass('active show');
}

if(window.location.href.indexOf('#assessment') !='-1'){
   $('#v-pills-tab').find('.nav-link').removeClass('active show');
   $('#v-pills-tab a[data-type="assessments"]').click();
   $('#v-pills-tab a[data-type="assessments"]').addClass('active show');
}
if(window.location.href.indexOf('#checkpoint') !='-1'){
   $('#v-pills-tab').find('.nav-link').removeClass('active show');
   $('#v-pills-tab a[data-type="checkpoints"]').click();
   $('#v-pills-tab a[data-type="checkpoints"]').addClass('active show');
}

</script>
@endsection