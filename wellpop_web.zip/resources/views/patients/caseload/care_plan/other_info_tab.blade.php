<div class="tab-pane fade active show" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
<h4 class="assess-head">{{ trans('label.other_contacts') }}</h4>
	<div class="care-box">
	   @include('patients.caseload.sections.other_contact')
	</div>
	<div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>

<script type="text/javascript">
	
	function previousTab(){
        $('#v-pills-tab a[data-type="team"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="emergency_contact"]').click();
    }
</script>
