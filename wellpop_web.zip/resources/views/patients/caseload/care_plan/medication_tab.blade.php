<div class="tab-pane fade active show" id="v-pills-Barriers" role="tabpanel" aria-labelledby="v-pills-Barriers-tab">
   <h4 class="assess-head">{{ trans('label.medication') }}</h4>
   <div class="care-box">
      <div class="table-responsive care-table" id="medication_listing">
         @include('patients.medications.medication_listing',['type'=>'case_load','is_careplan'=>1])
      </div>
   </div>
   <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>


<script type="text/javascript">
	
	function previousTab(){
        $('#v-pills-tab a[data-type="diagnosis_goals"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="allergy"]').click();
    }
</script>