<div class="tab-pane fade active show" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
   <h4 class="assess-head">{{ trans('label.diagnosis_goals') }}</h4>
   <div class="care-box" id="careplan_diagnosis_list">
      @include('patients.caseload.care_plan.careplan_diagnosis_list',['diagnosisList'=>$diagnosisList,'is_careplan_detail'=>1])
   </div>
   <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>


<script type="text/javascript">
	
	function previousTab(){
        $('#v-pills-tab a[data-type="emergency_contact"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="medication"]').click();
    }
</script>