<div class="tab-pane fade active show" id="v-pills-check" role="tabpanel" aria-labelledby="v-pills-check-tab">
<h4 class="assess-head">{{ trans('label.checkpoints') }}</h4>
   <div class="care-box">
      <div class="table-responsive care-table" id="checkpoint_list">
        @include('patients.caseload.checkpoint.list',['checkpointList'=>$checkpointList,'is_careplan'=>1])
      </div>
   </div>
     <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>



<script type="text/javascript">
   
   function handleCheckpointListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#allergies_listing .pagination").find('.active').text();
        }
        var url = "{{ route('caseload_checkpoint_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
        var patient_id = "{{ encrypt_decrypt('encrypt',$patient->id) }}";
        var careplan_id = "{{ encrypt_decrypt('encrypt',$id) }}";
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id,careplan_id:careplan_id, is_careplan: 1},
            dataType: "json",
            success:function(data){
                $('#checkpoint_list').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#checkpoint_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleCheckpointListing(page);
    });

    function previousTab(){
        $('#v-pills-tab a[data-type="assessments"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="barriers"]').click();
    }

</script>
