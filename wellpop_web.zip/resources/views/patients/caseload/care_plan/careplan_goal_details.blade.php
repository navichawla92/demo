<div class="slide-body">
    <div class="slide-section">
        <h4>{{ trans('label.basic_details') }} </h4>
        <div class="detail-view">
            <div class="row">
                 <div class="col-md-12">
                     <p class='careplan_goal_title'><span>{{ trans('label.goal_title') }}:</span> <b class="more_info"> {{ $goal->title }} </b></p>
                </div>
                <div class="col-md-5">
                    <p><span>{{ trans('label.goal_id') }}:</span> {{ $goal->code }}</p>
                </div>
                <div class="col-md-6">
                    <p><span>{{ trans('label.goal_type') }}:</span> {{ $goal->getTypeText() }}</p>
                </div>
                <div class="col-md-5">
                     <p><span>{{ trans('label.flag') }}: </span> {{ $goal->getFlagText() }}</p>
                </div>
                <div class="col-md-6">
                    <p><span>{{ trans('label.goal_metric') }}: </span> {{ $goal->getMatrixText() }}</p>
                </div>
               

            </div>
        </div>
    </div>

    <div class="slide-section careplan_goal_subgoal sub-part custom-single-detail">
        <h4>{{ str_plural('Sub Goal',$subgoals->total()) }} ({{ $subgoals->total() }})</h4>

        <div class="careplan_subgoal_list">
            @include('patients.caseload.care_plan.careplan_subgoal_list', compact('subgoals'))
        </div>
    </div>

    <div style="clear: both;"></div>
    <div class="slide-section sub-part custom-single-detail">
        <h4>{{ str_plural('Question',$questions->total()) }} ({{ $questions->total() }})</h4>

        <div class="careplan_question_list">
            @include('patients.caseload.care_plan.careplan_question_list', compact('questions'))
        </div>
    </div>
</div>

<script type="text/javascript">
    handleMoreInfo();
</script>