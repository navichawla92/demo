<div class="tab-pane fade active show" id="v-pills-vitals" role="tabpanel" aria-labelledby="v-pills-vitals-tab">
   <h4 class="assess-head">{{ trans('label.vitals') }} </h4>
   <div class="care-box">
       <div class="table-responsive care-table vital_list">
         @include('patients.caseload.assessment.vital_list', ['vitals' => $vitalList])
      </div>
   </div>
    <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>

<script>
function handleVitalPagination() {
        $('.vital_pagination .pagination a').click(function(){
            var url = $(this).attr('href')
            $.get(url, function(response){
                $('.vital_list').html(response.html);
                handleVitalPagination();
            },'json');
            return false;
        })
    }

    handleVitalPagination();

   function previousTab(){
        $('#v-pills-tab a[data-type="allergy"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="assessments"]').click();
    }
</script>