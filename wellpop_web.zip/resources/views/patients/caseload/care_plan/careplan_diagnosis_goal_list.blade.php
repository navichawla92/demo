<div class="card-body">
    @foreach($careplanGoals as $careplanGoal)
         <div class="row">
            <div class="col-md-8">
        <p>{{ $careplanGoal->title }}
        </p>
          </div>
          <div class="col-md-4">
            <a href="javascript:;"
               data-goal_version="{{ $careplanGoal->goal_version }}"
               data-goal_id="{{ encrypt_decrypt('encrypt',$careplanGoal->goal_id) }}"
               onclick="getGoalDetails(this)"
               class="show-detail">Goal Details </a>
          </div>
        </div>
    @endforeach

     <div class="careplan_diagnosis_goal_list">
         {{$careplanGoals->links()}}
     </div>
</div>