<div class="tab-pane fade active show" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">

   <div class="main-section note-tab">
     <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSubOne" aria-expanded="true" aria-controls="collapseSubOne">
               <i class="fa fa-minus-square"></i>
           </button>
          {{ trans('label.careplan_notes') }}   
       </div>
       <div class="main-section-inner collapse show positioning" id="collapseSubOne" aria-labelledby="headingOne">
         <p>{{ $carePlanDetail->notes}}</p>
      </div>
   </div> 

   @if($carePlanDetail->reason != '')
   <div class="main-section note-tab">
     <div class="headingpage">  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSubTwo" aria-expanded="true" aria-controls="collapseSubTwo">
               <i class="fa fa-minus-square"></i>
           </button>
          @if($carePlanDetail->status == '2')
          {{ trans('label.careplan_reason_discountinue') }}   
          @elseif($carePlanDetail->status == '3')
          {{ trans('label.careplan_reason_complete') }}   
          @endif
       </div>
       <div class="main-section-inner collapse show positioning" id="collapseSubTwo" aria-labelledby="headingOne">
         <p>{{ $carePlanDetail->reason }}</p>
      </div>
   </div>  
   @endif  

    <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>           
</div>

<script type="text/javascript">
  function previousTab(){
        $('#v-pills-tab a[data-type="intervention"]').click();
    }
</script>