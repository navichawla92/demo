 <div class="tab-pane fade active show" id="v-pills-Intervention" role="tabpanel" aria-labelledby="v-pills-Intervention-tab">
 <h4 class="assess-head"> {{ trans('label.interventions') }} </h4>
   <div class="care-box">
      <div class="table-responsive care-table" id="intervention_list">
         @include('patients.caseload.checkpoint.intervention.list',['interventionList'=>$interventionList,'is_careplan'=>1])
      </div>
   </div>
    <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>


<script type="text/javascript">
   
   function handleInterventionListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#intervention_list .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_intervention_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
        var patient_id = "{{ encrypt_decrypt('encrypt',$patient->id) }}";
        var careplan_id = "{{ encrypt_decrypt('encrypt',$id) }}";
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id, is_careplan: 1},
            dataType: "json",
            success:function(data){
                $('#intervention_list').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#intervention_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleInterventionListing(page);
    });

    function previousTab(){
        $('#v-pills-tab a[data-type="barriers"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="notes"]').click();
    }
</script>