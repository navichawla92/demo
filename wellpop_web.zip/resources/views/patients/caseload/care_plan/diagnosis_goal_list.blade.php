<div class="slide-section sub-part">
    @if(@$careplanId)
     <h4>{{ trans('message.goal_selected_for_care_plan') }}: </h4>
    <span class="check-text">{{ trans('message.goal_checked_for_care_plans') }}  </span>
    @else
     <h4>{{ trans('message.select_goal_for_care_plan') }}: </h4>
    @endif
    <div class="detail-view sub-detail">
        <span class="error" style="color:red"></span>
        <div class="table-responsive care-table">

            <table class="table">
                <thead>
                <tr>
                    <th>
                        <input type="checkbox" class="customcheck goal_chbox" id="selectallgoals" value="0">
                        <label>{{ trans('label.goal_id') }} </label>
                    </th>
                    <th>{{ trans('label.goal_title') }} </th>
                    <th>{{ trans('label.view_detail') }} </th>
                </tr>
                </thead>
                <tbody>

                @foreach($goals as $goal)
                    <tr>
                        <td>
                            <input type="checkbox" name="goal_id[]" class="customcheck goal_chbox" value="{{ encrypt_decrypt('encrypt', $goal['goal_id']) }}-{{ $goal['goal_version'] }}">
                            <label>{{ $goal['code'] }}</label>
                        </td>
                        <td>{{ $goal['title'] }}</td>
                        <td><a class="show-detail"
                               href="javascript:;"
                               data-goal_version="{{ $goal['goal_version'] }}"
                               data-goal_id="{{ encrypt_decrypt('encrypt',$goal['goal_id'] ) }}"
                               onclick="getGoalDetails(this)">
                                <i class="fa fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        </div>

        <div class="buttonsbottom">
            <a href="javascript:;" onclick="saveDiagnosis()" class="next">{{ trans('label.save') }}</a>
            <a href="#" class="close close_form_back">{{ trans('label.cancel') }}</a>
        </div>
    </div>

</div>

<script type="text/javascript">
    applpyEllipses('care-table', 4, 'no');
</script>