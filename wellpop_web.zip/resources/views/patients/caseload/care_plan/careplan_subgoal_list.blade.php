@foreach($subgoals as $subgoal)
    <div class="detail-view sub-detail">
        <p><span>{{ trans('label.sub_goal_description') }}:</span> <b class="more_info"> {{ $subgoal->subgoal->description }} </b> </p>
        <p><span>{{ trans('label.assigned_to_role') }}: </span> {{ $subgoal->subgoal->getRoles() }}  </p>
    </div>
@endforeach
<div class="careplan_subgoal_pagination">
    {{ $subgoals->links() }}
</div>