 <div class="tab-pane fade active show" id="v-pills-solution" role="tabpanel" aria-labelledby="v-pills-solution-tab">
 <h4 class="assess-head">{{ trans('label.barriers_solutions') }} </h4>
   <div class="care-box">
      <div class="table-responsive care-table barrier_list">
      @include('patients.caseload.assessment.barriers_list', ['assessmentBarriers' => $barrierList,'is_careplan'=>true])
      </div>
   </div>
     <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
   </div>

<!--barrier-detail -->
<div class="sidebox-overlay assessment_barrier_sidebar" id="barrierOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-barrier" onclick="closeBarrierDetailSidebar()"><i class="fa fa-angle-left"></i> Back</a>{{ trans('label.barrier_details') }}</h4>
      </div>
      <div class="slide-body">
         <div class="slide-section custom-single-detail">
            <div class="detail-view barrier-view">

            </div>
         </div>
      </div>
   </div>
</div>

<script type="text/javascript">
 function viewBarrier(target)
    {
        var barrierId = $(target).attr('data-id');
        $.get('{{ route("assessment_barrier_by_id") }}?id='+barrierId, function(response){
            $('#barrierOverlay .barrier-view').html(response.html)
            $('#barrierOverlay').addClass('show-overlay');
        },'json');
    }

    function closeBarrierDetailSidebar() {
        $(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $(".sidebox-overlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $(".inner-slide").removeClass("slideOutRight");
        }, 1000);
    }


    function handleBarrierPagination() {
        $('.barrier_pagination .pagination a').click(function(){
            var url = $(this).attr('href')
            loadBarrierListing(url);

            return false;
        })
    }

    function loadBarrierListing(url)
    {
        $.get(url, function(response){
            $('.barrier_list').html(response.html);
            handleBarrierPagination();
        },'json')
    }
    handleBarrierPagination();

    function previousTab(){
        $('#v-pills-tab a[data-type="checkpoints"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="intervention"]').click();
    }
</script>