@extends('layouts.app')
@section('css')
    <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection

@section('title')
    {{trans('label.case_loads')}}
@endsection
@section('content')

    <div class="leftsectionpages">
        <div class="bread-head">
            <div class="row">
                <div class="col-lg-8 col-md-7">
                    <div class="headingpage">
                        <div class="firstname">{{ trans('label.case_loads') }}</div>
                        <span><i class="fas fa-angle-right"></i></span>{{ trans('label.new_care_plan') }}
                    </div>
                </div>
                <div class="col-md-5 col-lg-4">


                    <div class="buttonsbottom"><a onClick="javascript:save_care_plan()" class="next" style="padding: 0 13px;">{{ trans('label.verify_and_confirm') }} </a> <a href="#" class="close close_form">{{ trans('label.cancel') }} </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-content">
            <div class="patient-view pat-show case-main-wrap">
                @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
            </div>
            <?php
                $patient = $patient['patient_info'];
            ?>


            <div id="diagnosis_created_status">
                <div class="alert alert-error dismissible hide">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <div class="alert-message"></div>
                </div>
            </div>

            <div class="">
                <span class="error" id='careplan_id' style="color:red"></span>
                <div class="identify-box">
                    <div class="personliving custom-medical-box">
                        <p class="headingpage buttonmargin margnbootom">{{ trans('label.identified_diagnosis') }}  <a class="btn btn-primary basic-btn add_diagnosis_btn edit-detail">{{ trans('label.add_new_diagnosis') }} </a></p>
                        <div class="clearfix"></div>
                        <div class="notdiag">

                            <div id="careplan_diagnosis_list">
                                <div class="table-responsive care-table">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>{{ trans('label.serial_number_short_form') }} </th>
                                            <th>{{ trans('label.date_added') }} </th>
                                            <th>{{ trans('label.priority') }} </th>
                                            <th>{{ trans('label.diagnosis') }} </th>
                                            <th>{{ trans('label.action') }} </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td colspan="5">{{ trans('label.no_record_found') }}.</td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>


                             {!! Form::model($patient,['id' => 'save_care_plan']) !!}
                               {!! Form::hidden('patient_id', encrypt_decrypt('encrypt', $patient->id)) !!}
                               {!! Form::hidden('careplan_id', 0) !!}
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group mt-20">
                                        <p class="headingpage buttonmargin margnbootom">{{ trans('label.enter_notes') }}</p>
                                        <textarea type="text" name="notes" class="form-control"></textarea>
                                        <span class="error" style="color:red"></span>
                                    </div>
                                </div>
                            </div>

                             {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name='is_anything_change' id='is_anything_change' value="" >

@endsection

@section('modal_box')

    <div class="sidebox-overlay" id="diagnosis_sidebar">
        <div class="inner-slide animated slideInRight fast">
            <div class="slide-head">
                <h4><a class="close_diagnosis_sidebar "><i class="fa fa-angle-left"></i> {{ trans('label.back') }}  </a> {{ trans('label.diagnosis_details') }} </h4>
            </div>
            <div class="slide-body">
                {!! Form::open(['id' => 'save_diagnosis_care_plan']) !!}
                {{ Form::hidden('goal_ids') }}
                {{ Form::hidden('edit_diagnosis_id') }}
                {{ Form::hidden('diagnosis_version') }}
                    <div class="slide-section sub-part custom-single-detail diagnosis_fields">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>{{ trans('label.add_diagnosis_from_registry') }}</label>
                                    {!! Form::select('diagnosis_id',[],null,array("class" => "form-control multi_select_chosen",'id'=>"select_chosen_diagnosis",'multiple','data-type'=>'diagnosis','data-placeholder' => trans('label.search_by_diagnosis'))) !!}
                                    <span class="error" style="color:red"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>{{ trans('label.set_priority') }}  </label>
                                    <input type="text" class="form-control" name="priority" placeholder="{{ trans('label.set_priority_placeholder') }}">
                                    <span class="error" style="color:red"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                {!! Form::close() !!}

                <div class="diagnosis_detail"> 
                    <div class="slide-section sub-part custom-single-detail">      
                        <img src="{{ asset('images/no-data.png') }}" class="img img-fluid no-data">         
                    </div>
                </div>
                <div class="diagnosis_goal_list"> 
                  <!--  <div class="slide-section sub-part">
                        {{--<img src="{{ asset('images/no-data.png') }}" class="img img-fluid no-data">--}}
                    </div>-->
                </div>
            </div>
        </div>
    </div>


    <div class="sidebox-overlay" id="goal_detail_sidebar">
        <div class="inner-slide animated slideInRight fast">
            <div class="slide-head">
                <h4><a class="close-side close_goal_detail_sidebar"><i class="fa fa-angle-left"></i> {{ trans('label.back') }} </a> {{ trans('label.goal_details') }} </h4>
            </div>
             <div id="goal_detail_body"></div>
            </div>
        </div>
    </div>



@endsection

@section('script')
    <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>

    <script type="text/javascript">
        $(".show-detail").click(function () {
            $("#viewOverlay").addClass("show-overlay");
            $("body").addClass("hideout");
        });

        $(".add_diagnosis_btn").click(function () {
            $("#diagnosis_sidebar").addClass("show-overlay");
            $("body").addClass("hideout");

            $('[name="goal_ids"]').val('');
            $('[name="edit_careplan_id"]').val('');
            $('[name="edit_diagnosis_id"]').val('');
            $('[name="diagnosis_version"]').val('');
            $('.diagnosis_fields').show();

            $('#diagnosis_sidebar .error').text('');

        });

       
       
        $(document).on("click", '.close_diagnosis_sidebar,.close_form_back', function(event) { 
            backForm();
        });

        $(".close-edit-side").click(function () {
            $(".inner-slide").addClass("slideOutRight");
            setTimeout(function () {
                $("#editOverlay").removeClass("show-overlay");
                //    $(".sidebox-overlay").removeClass("show-overlay");
                $("body").removeClass("hideout");
                $(".inner-slide").removeClass("slideOutRight");

            }, 1000);
        });

        $('.close_goal_detail_sidebar').click(function(){
            $(".inner-slide").addClass("slideOutRight");
            setTimeout(function () {
                $("#goal_detail_sidebar").removeClass("show-overlay");
                //		$(".sidebox-overlay").removeClass("show-overlay");
                $("body").removeClass("hideout");
                $(".inner-slide").removeClass("slideOutRight");

            }, 1000);
        });


        $(document).ready(function () {
            $(".multi_select_chosen").chosen({width: '100%', max_selected_options: 1});

            addOldVelue();
            chosenDropDown('select_chosen_diagnosis');
        });

        function chosenDropDown(selectID) {

            var xhr = {
                abort: function () {
                }
            };
            var selectData = [];           // data for unique id array
            var type = $('#' + selectID).data('type');
            $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
                minLength: 1,
                source: function (request, response) {
                    $('#' + selectID + '_chosen .no-results').hide();
                    var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
                    var careplanId = $('[name="careplan_id"]').val();
                    $.ajax({
                        url: "{{ route('diagnosis_list') }}",
                        data: {data: inputData, careplanId: careplanId},
                        type: 'POST',
                        dataType: "json",
                        beforeSend: function () {

                        },
                        success: function (data) {
                            $('#' + selectID).find('option').not(':selected').remove();
                            $.map(data.html, function (item) {
                                if ($.inArray(item.id, selectData) == -1) {
                                    $('#' + selectID).append('<option value="' + item.id + '" data-id = "' + item.id + '">' + item.code + '- ' + item.title + '</option>')
                                }
                            });

                            $('#' + selectID).trigger("chosen:updated");
                            $('.chosen-search-input').val(inputData);
                        }
                    });
                }
            });

            // Chosen event listen on input change eg: after select data / deselect this function will be trigger
            $('#' + selectID).on('change', function () {
                var domArray = $('#' + selectID).find('option:selected');
                selectData = [];

                if(domArray.length == 0){
                    $('ul.chosen-choices li.search-field').show();
                    $('.diagnosis_detail').html('<div class="slide-section sub-part custom-single-detail"><img src="{{ asset("images/no-data.png") }}" class="img img-fluid no-data"></div>');
                    $('.diagnosis_goal_list').html('');
                    $('[name="goal_ids"]').val('');
                }
                else{
                    $('ul.chosen-choices li.search-field').hide();
                    for (var i = 0, length = domArray.length; i < length; i++) {
                        selectData.push($(domArray[i]).data('id'));
                    }

                    $('#' + selectID).html(domArray);
                    $('#' + selectID).trigger("chosen:updated");

                    var selectedId = domArray[0].value;
                    url = '{{ route('get_diagnosis_detail') }}?diagnosis_id='+selectedId

                    loadGoalList(url);

                }

            });

        }

        function handleGoalPagination()
        {
            $('.goal_pagination .pagination a').click(function(){
                loadGoalList($(this).attr('href'));
                return false;
            });
        }

        function loadGoalList(url) {
            $.get(url, function(response) {

                if(response.hasOwnProperty('goal_ids') && response.goal_ids !== '') {
                    $('[name="goal_ids"]').val(response.goal_ids)
                }

                if(response.diagnosis_detail) {
                    $('.diagnosis_detail').html(response.diagnosis_detail);
                    handleReadMore();
                }
                $('.diagnosis_goal_list').html(response.goal_list);

                handleGoalPagination();
                handleCheckbox();

                var goalIds = [];
                if($('[name="goal_ids"]').val() != '') {
                    goalIds = $('[name="goal_ids"]').val().split(',');
                }

                if(goalIds.length > 0) {
                    $.each(goalIds, function(key, value){
                        $('[name="goal_id[]"][value="'+value+'"]').attr("checked","true")
                    });
                }

                if($('[name="goal_id[]"]').length == $('[name="goal_id[]"]:checked').length) {
                    $('#selectallgoals').prop('checked', true);
                } else {
                    $('#selectallgoals').prop('checked', false);
                }

                initCustomForms();

            },'json');
        }

        function handleReadMore() {
            $('.read_more_content').click(function(){

                if($(this).hasClass('more')){
                    $(this).text('read less');
                    $('.diagnosis_full_desc').css('display', 'inline');
                    $(this).removeClass('more').addClass('less');
                } else {
                    $(this).text('read more...');
                    $('.diagnosis_full_desc').css('display', 'none');
                    $(this).removeClass('less').addClass('more');
                }

            })
        }

        function handleCheckbox()
        {
            $('.goal_chbox').change(function() {
                var goalIds = [];
                if($('[name="goal_ids"]').val() != '') {
                    goalIds = $('[name="goal_ids"]').val().split(',');
                }

                if ($(this).prop('checked')) {
                    if($(this).val() == 0) {
                        $('.goal_chbox').prop('checked', true);
                        $('[name="goal_id[]"]').each(function(key, chbox){
                            goalIds.push($(chbox).val());
                        });
                    } else {
                        goalIds.push($(this).val());
                    }
                }
                else {
                    if($(this).val() == 0) {
                        $('.goal_chbox').prop('checked', false);
                        $('[name="goal_id[]"]').each(function(key, chbox){
                            removeItem = $(chbox).val();

                            goalIds = $.grep(goalIds, function(value) {
                                return value != removeItem;
                            });

                        });
                    } else {
                        removeItem = $(this).val();
                        goalIds = $.grep(goalIds, function(value) {
                            return value != removeItem;
                        });
                        $('#selectallgoals').prop('checked', false);
                    }
                }

                goalIds = jQuery.unique(goalIds);
                $('[name="goal_ids"]').val(goalIds.join(','));

                if($('[name="goal_id[]"]').length == $('[name="goal_id[]"]:checked').length) {
                    $('#selectallgoals').prop('checked', true);
                } else {
                    $('#selectallgoals').prop('checked', false);
                }

                initCustomForms();
            });
        }

        function saveDiagnosis()
        {
            $("span.error").html('').hide();
            var formData = new FormData($('#save_diagnosis_care_plan')[0]);
            formData.append('careplan_id', $('[name="careplan_id"]').val());
            formData.append('patient_id', $('[name="patient_id"]').val());

            $.ajax({
                url:"{{ route('save_diagnosis_care_plan') }}",
                type:"POST",
                data:formData,
                processData: false,
                contentType: false,
                dataType: "json",
                success:function(data) {
                    resetDiagnosisForm();
                    $(".close_diagnosis_sidebar").trigger('click');
                    handleMessages(data, 'diagnosis_created_status', true);
                    $('[name="careplan_id"]').val(data.careplan_id)
                    fadeOutAlertMessages();

                    if(data.hasOwnProperty('diagnosis_html')) {
                        $('#careplan_diagnosis_list').html(data.diagnosis_html);
                        initializeCareplanDiagnosisPagination();
                    }
                    $('input,textarea,select').removeClass('changed-input');
                    $('#is_anything_change').val(1);

                    //$('.diagnosis_fields').show();
                },
                error:function(error){
                    $.each(error.responseJSON.errors,function(key,value){
                        if(key === 'goal_ids') {
                            $('.sub-detail').find('span.error').html(value).addClass('active').show();
                        } else {
                            $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();

                            if(key === 'priority') {
                                jQuery('.slide-body').animate({scrollTop: 0}, 500);
                            }
                        }


                    });
                }
            });
        }


        function initializeCareplanDiagnosisPagination()
        {
            $('.careplan_diagnosis_list .pagination a').click(function(){
                $.get($(this).attr('href'), function(response){
                    if(response.hasOwnProperty('diagnosis_html')) {
                        $('#careplan_diagnosis_list').html(response.diagnosis_html);
                        initializeCareplanDiagnosisPagination();
                    }
                }, 'json')

                return false;
            });
        }

        function resetDiagnosisForm() {
            $('.diagnosis_detail').html('');
            $('.diagnosis_goal_list').html('');
            $('[name="goal_ids"]').val('');
            $('#save_diagnosis_care_plan')[0].reset();
            $('#select_chosen_diagnosis').find('option').not(':selected').remove();

            $('#select_chosen_diagnosis').trigger('change');
            $('#select_chosen_diagnosis').trigger("chosen:updated");

            $('input,textarea,select').removeClass('changed-input');
           // $('#is_anything_change').val(1);
        }


        function loadDiagnosisGoal(target) {
            var diagnosisId = $(target).attr('data-diagnosisId');
            var careplanId = $('[name="careplan_id"]').val();

            if($(target).hasClass('collapsed') && $.trim($('#dropi-'+diagnosisId).text()).length < 5) {
                var url = '{{ route('careplan_diagnosis_goal_list') }}?careplan_id='+careplanId+'&diagnosis_id='+diagnosisId;
                $.get(url, function(response){
                    $('#dropi-'+diagnosisId).html(response.html);
                    initializeDiagnosisGoalsPagination(diagnosisId);
                },'json');
            }
        }

        function initializeDiagnosisGoalsPagination(diagnosisId)
        {
            $('#dropi-'+diagnosisId+' .careplan_diagnosis_goal_list .pagination a').click(function(){
                $.get($(this).attr('href'), function(response){
                     $('#dropi-'+diagnosisId).html(response.html);
                    initializeDiagnosisGoalsPagination(diagnosisId);
                },'json');
                return false;
            });
        }

        function getGoalDetails(target)
        {
            var goalId = $(target).attr('data-goal_id');
            var goalVersion = $(target).attr('data-goal_version');

            var url = '{{ route('careplan_diagnosis_goal_detail') }}?goal_version='+goalVersion+'&goal_id='+goalId;
            $.get(url, function(response){
                $("#goal_detail_sidebar").addClass("show-overlay");
                $('#goal_detail_body').html(response.html);
                $("body").addClass("hideout");

                handleGoalDetailPagination();
            },'json');
        }


        function handleGoalDetailPagination()
        {
            $('.careplan_subgoal_pagination .pagination a').click(function(){
                $.get($(this).attr('href'), function(response){
                    $('.careplan_subgoal_list').html(response.html);
                    $("body").addClass("hideout");
                    handleGoalDetailPagination();
                },'json');

                return false;
            });

            $('.careplan_question_pagination .pagination a').click(function(){
                $.get($(this).attr('href'), function(response){
                    $('.careplan_question_list').html(response.html);
                    $("body").addClass("hideout");
                    handleGoalDetailPagination();
                },'json');

                return false;
            });
        }

        function editDiagnosis(target)
        {
            var diagnosisId = $(target).attr('data-diagnosis_id');
            var diagnosis_version = $(target).attr('data-diagnosis_version');
            $('.diagnosis_fields').hide();

            var careplanId = $('[name="careplan_id"]').val();
            $('[name="edit_diagnosis_id"]').val(diagnosisId);
            $('[name="diagnosis_version"]').val(diagnosis_version);

            var url = '{{ route('get_diagnosis_detail') }}?diagnosis_id='+diagnosisId+'&careplan_id='+careplanId+'&goal_ids=1';
            loadGoalList(url);

            $("#diagnosis_sidebar").addClass("show-overlay");
            $('#diagnosis_sidebar .error').text('');

            $("body").addClass("hideout");
        }
    </script>



    <script type="text/javascript">

        function save_care_plan(){

            bootbox.confirm('Are you sure you have added and verified all the Diagnosis and Goals required for this Care Plan. Once created, Care Plan cannot be edited.', function(result){

                if(result) {
                    $("span.error").html('').hide();
                    var formData = new FormData($('#save_care_plan')[0]);
                    $.ajax({
                        url:"{{ route('save_patient_care_plan') }}",
                        type:"POST",
                        data:formData,
                        processData: false,
                        contentType: false,
                        dataType: "json",
                        success:function(data){
                            $('input,textarea,select').removeClass('changed-input');
                            $('#is_anything_change').val('');
                            handleMessages(data, 'diagnosis_created_status', true);
                            window.location = "{{ route('caseload_patient_view', encrypt_decrypt('encrypt', $patient->id)) }}/#plan";
                            fadeOutAlertMessages();
                        },
                        error:function(error){

                            $.each(error.responseJSON.errors,function(key,value){

                                if(key == 'careplan_id'){
                                    $('#'+key).html(value).addClass('active').show();

                                }else{
                                    $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                                    $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                                    $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                                }

                            });

                            jQuery('html, body').animate({
                                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
                            }, 500);
                            fadeOutAlertMessages();
                        }
                    });
                }
            });
        }


    function closeForm(){
      if ($('.changed-input').length || $('#is_anything_change').val()){
          bootbox.confirm({ 
            message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
            callback: function(result){  
              if (result) {
                $('input,textarea,select').removeClass('changed-input');
                 $('#is_anything_change').val('');
                window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient->id),'#plan']) }}";
              }
              else {
                bootbox.hideAll();
                return false;
              }
            }
          })
      }
      else {
        window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient->id),'#plan']) }}";

      }
    }


    function backForm(){
        if ($('.changed-input').length){
                bootbox.confirm({ 
                message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
                callback: function(result){  
                  if (result) {
                   // $('input,textarea,select').removeClass('changed-input');
                      $(".inner-slide").addClass("slideOutRight");

                        $("#diagnosis_sidebar").removeClass("show-overlay");
                        $("body").removeClass("hideout");
                        $(".inner-slide").removeClass("slideOutRight");
                        resetDiagnosisForm();
                  }
                  else {
                    bootbox.hideAll();
                    return false;
                  }
                }
              })
          }
          else {
               // $('input,textarea,select').removeClass('changed-input');
                $(".inner-slide").addClass("slideOutRight");

                $("#diagnosis_sidebar").removeClass("show-overlay");
                $("body").removeClass("hideout");
                $(".inner-slide").removeClass("slideOutRight");
                resetDiagnosisForm();

          }
    }

       // for cancel button on every form
        $('body').on('click', '.close_form', function(e) {
            e.preventDefault();
            closeForm();
        });

        // for click on side bar or logout button
        $(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
          if ($('.changed-input').length || $('#is_anything_change').val()){
            bootbox.alert("{{ trans('message.unsaved_error_message') }}");
            return false;
          }
        });
      // for all keyup,keydown, change for every input field


$('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
          $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
          $(this).removeClass('changed-input');
        }
        else {
          $(this).addClass('changed-input');
        }     
    }
    else {
        if($(this).hasClass('chosen-search-input')){

        }
        else{
          $(this).addClass('changed-input');
        }  
    }
});
  function addOldVelue(){
    $("input,textarea,select").each(function(){
        $(this).attr('old_value',$(this).val());
    })
  }

  //  check if input changed and unsaved before reload
    window.onbeforeunload = function() {
      /*
      ==if auto-logout functionality causing page-reload then allow it don't show any alert 
      ==no matter data changed and un;-saved
      */
      if (($('.changed-input').length || $('#is_anything_change').val())&& !$('div.ui-dialog[aria-describedby="sessionTimeout-dialog"]').is(':visible')){
             return "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page.";
      }
      else {
      }      
    }

    function removeDiagnosis(target){

        //target.preventDefault();
        bootbox.confirm({ 
        message: "{{ trans('message.remove_diagnosis_warning') }}",
        buttons: {
        confirm: {
            label: 'Yes',
            className: 'btn-primary'
        },
        cancel: {
            label: 'No',
            className: 'btn-default'
        }
        },
        callback: function(result){  
          if (result) {
            var diagnosisId = $(target).attr('data-id');
            var careplanId = $('[name="careplan_id"]').val();
            $.ajax({
             url:"{{ route('caseload_remove_careplan_diasnosis') }}",
             data:{diagnosisId:diagnosisId, careplanId: careplanId},
             dataType: "json",
             success:function(data) {
                    handleMessages(data, 'diagnosis_created_status', true);
                    fadeOutAlertMessages();
                    if(data.hasOwnProperty('diagnosis_html')) {
                        $('#careplan_diagnosis_list').html(data.diagnosis_html);
                        initializeCareplanDiagnosisPagination();
                    }

                    if($('#careplan_diagnosis_list table tbody tr').length > 0){
    
                    }
                    else{
                        $('#is_anything_change').val('');
                    }
               //  window.location.reload();
             },
             error:function(error) {
                 if(error.status == 500){
                     $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                 }
                 else{
                     
                 }
             }
            });
            
          //  $('input,textarea,select').removeClass('changed-input');
            
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
        
    }

    </script>


@endsection