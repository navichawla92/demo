@foreach($questions as $question)
    <div class="detail-view sub-detail">
        <p><span>{{ trans('label.question') }}: </span> <b class="more_info"> {{ $question->question->description }} </b> </p>
        <p><span>{{ trans('label.assigned_to_role') }}: </span> {{ $question->question->getRoles() }}  </p>
        <p><span>{{ trans('label.metric') }}:  </span> {{ $question->question->metric->name }}  </p>
    </div>
@endforeach
<div class="careplan_question_pagination">
    {{ $questions->links() }}
</div>