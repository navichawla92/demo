<div class="tab-pane fade active show" id="v-pills-assess" role="tabpanel" aria-labelledby="v-pills-assess-tab">
   <h4 class="assess-head">{{ trans('label.assessments') }}</h4>
   <div class="care-box">
      <div class="table-responsive care-table" id="assessment_list">
        @include('patients.caseload.assessment.list',['assessmentList'=>$assessmentList,'is_careplan'=>1,'activeCarePlan'=> 0])
      </div>
   </div>
   <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>


<script type="text/javascript">
   
  
   function handleAssessmentListing(current_page = '')
    {

        if(current_page === '') {
            current_page = $("#assessment_list .pagination").find('.active').text();
        }

        var url = "{{ route('caseload_assessment_list', [encrypt_decrypt('encrypt',$patient->id)]) }}"+'?page='+ current_page;
        var patient_id = "{{ encrypt_decrypt('encrypt',$patient->id) }}";
        var careplan_id = "{{ encrypt_decrypt('encrypt',$id) }}";
        $.ajax({
            url:url,
            type:"GET",
            data:{patient_id:patient_id, is_careplan: 1,careplan_id:careplan_id},
            dataType: "json",
            success:function(data){
                $('#assessment_list').html(data.html);
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#assessment_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');
        handleAssessmentListing(page);
    });

    function previousTab(){
        $('#v-pills-tab a[data-type="vital"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="checkpoints"]').click();
    }


</script>