<div class="tab-pane fade active show" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
<h4 class="assess-head">{{ trans('label.emergency_contacts') }}</h4>
<div class="care-box">
   @include('patients.caseload.sections.emergency_contact')
</div>
	<div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
    </div>
</div>

<script type="text/javascript">
	
	function previousTab(){
        $('#v-pills-tab a[data-type="otherinfo"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="diagnosis_goals"]').click();
    }
</script>