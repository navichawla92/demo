<table class="table">
   <thead>
      <tr>
         <th>{{ trans('label.serial_number_short_form') }} </th>
         <th>{{ trans('label.care_plan_id') }} </th>
         <th>{{ trans('label.active_from') }} </th>
         <th>{{ trans('label.active_till') }} </th>
         <th>{{ trans('label.status') }} </th>
         <th>{{ trans('label.baseline') }} </th>
         <th>{{ trans('label.added_by') }} </th>
         <th>{{ trans('label.role') }} </th>
         <th>{{ trans('label.action') }} </th>
      </tr>
   </thead>
   <tbody>
      @if(count($carePlanList))
      <?php  $index=($carePlanList->perPage() * ($carePlanList->currentPage()- 1))+1; ?>
      <?php  $i = 0;?>
      @foreach($carePlanList as $carePlan)
      <tr>
         <td>{{ $index }}</td>
         <td>{{ $carePlan->code }}</td>
         <td>{{ $carePlan->start_date }}</td>
         <td>{{ $carePlan->end_date ?? "-" }}</td>
         <td>{!! $carePlan->status_badge !!}</td>
         <td><input type="checkbox" class="customcheck" {{ $carePlan->is_base_line ? "checked" : '' }} disabled=""><label></label></td>
         <td>{{ $carePlan->user->name ?? "-" }}</td>
         <td>{{ $carePlan->userRole->name ?? "-" }}</td>
         <td>
            <div class="dropdown more-btn dropup">
               <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>...</span> </button>
               <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                  <a class="dropdown-item"  href="{{ route('patient_care_plan_detail', [encrypt_decrypt('encrypt',$patient->id),encrypt_decrypt('encrypt',$carePlan->id)]) }}"><i class="fa fa-eye"></i> View Care Plan</a>
                  @if($carePlan->status == 1)
                  <a class="dropdown-item" 
                  data-id="{{ encrypt_decrypt('encrypt',$carePlan->id) }}" data-status="completed" onclick="showUpdateStatusModal(this)"
                  ><i class="fa fa-check"></i> Mark as Completed</a>
                  <a class="dropdown-item"  data-id="{{ encrypt_decrypt('encrypt',$carePlan->id) }}" data-status="discontinue" onclick="showUpdateStatusModal(this)"><i class="fa fa-recycle"></i> Discontinue Care Plan</a>
                  @endif
                <!--  <a class="dropdown-item"><i class="fa fa-filter"></i> Refine Care Plan</a>-->
               </div>
            </div>
         </td>
      </tr>
      <?php  $index++; ?>
      @endforeach
      @else
      <tr>
         <td>{{ trans('label.no_record_found') }} </td>
      </tr>
      @endif
   </tbody>
</table>
<?php echo $carePlanList->render(); ?>