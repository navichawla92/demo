    <!--  completePlan-->
      <div class="modal fade" id="completePlan" tabindex="-1" role="dialog" aria-labelledby="completePlanLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
			      <form action="javascript:;" id="careplan_update_form">
            {!! Form::hidden('patient_id', encrypt_decrypt('encrypt',$patient->id))  !!}
            {!! Form::hidden('status', null)  !!}
            {!! Form::hidden('id', null)  !!}
				
               <div class="modal-header">
                  <div class="headingpage">{{ trans('label.complete_care_plan') }} </div>
               </div>
               <div class="modal-body">
                  <div class="row">
                     <div class="col-12">
                        <div class="textfieldglobal">
                           <label class="labelfieldsname"> {{ trans('label.enter_notes') }}* </label>
                           <textarea name="reason" type="text" old_value="" placeholder="{{ trans('label.enter_your_notes_here') }}"></textarea>
                           <span class="error" style="color: red; display: none;"></span> 
                        </div>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <div class="buttonsbottom"> 
					  <button type="submit" class="next model_box_save"> Complete Care Plan </button>
					  
					  <a href="#" class="close" data-dismiss="modal" aria-label="Close">Cancel</a> </div>
               </div>
             </form>
            </div>
         </div>
      </div>

@push('scripts')
<script>



function showUpdateStatusModal(target) {
          $("span.error").html('').hide();
           if($(target).attr('data-status') == 'discontinue') {
               $('#completePlan .headingpage').text("{{ trans('label.discontinue_care_plan') }}");
               $('#completePlan .model_box_save').text("{{ trans('label.discontinue_care_plan') }}");
                $('#completePlan input[name="status"]').val(2);
           } 
           if($(target).attr('data-status') == 'completed') {
              $('#completePlan .headingpage').text("{{ trans('label.complete_care_plan') }}");
              $('#completePlan .model_box_save').text("{{ trans('label.complete_care_plan') }}");
              $('#completePlan input[name="status"]').val(3);
               
           }

           $('#completePlan').modal('show');
           $('#completePlan input[name="id"]').val($(target).attr('data-id'));
}
   
function handleUpdateForm()
 {
     
     $("span.error").html('').hide();
     var form = $('#careplan_update_form');
     form.submit(function(){
         $.ajax({
             url:UPDATE_CAREPLAN_STATUS_ROUTE,
             data:form.serialize(),
             dataType: "json",
             success:function(data) {
                  if(!data.activeCarePlan){
                    $('.active_add_btn').remove();
                  }
                 handleCarePlanListing();
                 $('#completePlan').modal('hide');
                 form[0].reset();
                 $('.model_box_save').removeAttr("disabled");
                 handleMessages(data, 'care_plan_list', true);
                 fadeOutAlertMessages();
                 handleAssessmentListing();
             },
             error:function(error) {
                 if(error.status == 500){
                     $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                 }
                 else{
                     $.each(error.responseJSON.errors,function(key,value){
                         $('textarea[name="'+key+'"]').parent().find('span.error').html(value).show();
                     });
                 }
             }
         });
     });

     return false;
 }
handleUpdateForm();
</script>

@endpush

