<div class="tab-pane fade active show" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
  <h4 class="assess-head">{{ trans('label.wellpop_care_team') }}</h4>
                     <div class="active-main-box">

                       
                         @if($carePlanDetail->carePlanTeam)
                        <div class="row">
                           <div class="col-lg-4 col-md-6">
                              @php
                                 $caseManager = $carePlanDetail->carePlanTeam->cmUser;
                                 $commonHealthWorker = $carePlanDetail->carePlanTeam->chwUser;
                                 $medicalDirector = $carePlanDetail->carePlanTeam->mdUser;
                              @endphp
                              <div class="manage-box">
                                 <h4 class="mini-title">{{ trans('label.case_manager') }} </h4>
                                 <div class="man-box"> <img src="@if($caseManager->image) {{ config('filesystems.s3_user_images_full_path').$caseManager->id.'/'.$caseManager->image }} @else {{ asset('images/noimage.jpg') }} @endif">   </div>
                                 <p>{{ ucwords($caseManager->name) }} <span>{{ $caseManager->phone ? "+1 " .phone_number_format($caseManager->phone):  ""  }}</span> </p>
                              </div>
                             
                           </div>
                           <div class="col-lg-4 col-md-6">
                              <div class="manage-box">
                                 <h4 class="mini-title">{{ trans('label.community_health_worker') }}</h4>
                                 <div class="man-box">  <img src="@if($commonHealthWorker->image) {{ config('filesystems.s3_user_images_full_path').$commonHealthWorker->id.'/'.$commonHealthWorker->image }} @else {{ asset('images/noimage.jpg') }} @endif">  </div>
                                 <p>{{ ucwords($commonHealthWorker->name) }}  <span>{{ $commonHealthWorker->phone ? "+1 " .phone_number_format($commonHealthWorker->phone):  ""  }}</span> </p>
                              </div>
                           </div>
                           <div class="col-lg-4 col-md-6">
                              <div class="manage-box">
                                 <h4 class="mini-title">{{ trans('label.mediacal_director') }} </h4>
                                 <div class="man-box">  <img src="@if($medicalDirector->image) {{ config('filesystems.s3_user_images_full_path').$medicalDirector->id.'/'.$medicalDirector->image }} @else {{ asset('images/noimage.jpg') }} @endif">  </div>
                                 <p>{{ ucwords($medicalDirector->name) }}  <span>{{ $medicalDirector->phone ? "+1 " .phone_number_format($medicalDirector->phone):  ""  }}</span> </p>
                              </div>
                           </div>
                        </div>
                        @endif
                     </div>
                     <div class="asess-btnbox">
                        <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
                     </div>
</div>

<script type="text/javascript">
   function nextTab() {
        $('#v-pills-tab a[data-type="otherinfo"]').click();
    }

</script>