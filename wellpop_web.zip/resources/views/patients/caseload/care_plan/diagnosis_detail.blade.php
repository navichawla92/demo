<div class="slide-section sub-part custom-single-detail">
    <h4>{{ trans('label.diagnosis_details') }}: </h4>
    <div class="detail-view ">
        @if($diagnosis['detail']->priority)
            <p><span>{{ trans('label.diagnosis_id')  }}: </span> {{ $diagnosis['detail']->code }} </p>
            <p><span>{{ trans('label.diagnosis_title') }}: </span> {{ $diagnosis['detail']->title }} </p>
            <p><span>{{ trans('label.priority') }}: </span> {{ $diagnosis['detail']->priority }} </p>
        @endif

        <p>
            <span class="read-data">{{ trans('label.diagnosis_description') }}: </span>
            <b class="more_info"> {{ $diagnosis['detail']->description }} </b>

           
        </p>
        <p>
            <span>{{ trans('label.ICD_10_Codes') }}: </span>
             <b class="more_info">
            @foreach($diagnosis['icdCodes'] as $diagnosisIcdCode)
                @if($diagnosisIcdCode->icdCodes)
                    {{ $diagnosisIcdCode->icdCodes->code }} -
                    {{ $diagnosisIcdCode->icdCodes->name }} <br>
                @endif
            @endforeach
            </b>
        </p>
    </div>
</div>

<script type="text/javascript">
    handleMoreInfo();
</script>