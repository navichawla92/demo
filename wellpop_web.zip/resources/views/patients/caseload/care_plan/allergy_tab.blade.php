<div class="tab-pane fade active show" id="v-pills-allergy" role="tabpanel" aria-labelledby="v-pills-allergy-tab">
	<h4 class="assess-head">{{ trans('label.allergies_list') }}</h4>
     <div class="care-box">
        <div class="table-responsive care-table" id="allergies_listing">
           @include('patients.allergies.allergies_listing',['type'=>'case_load','is_careplan'=>1])
        </div>
     </div>
     <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
      </div>
</div>

<script type="text/javascript">
	function previousTab(){
        $('#v-pills-tab a[data-type="medication"]').click();
    }


    function nextTab() {
        $('#v-pills-tab a[data-type="vital"]').click();
    }
</script>