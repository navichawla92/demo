<script src="{{ asset('js/signature.js') }}" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){ 
   $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
   var signatureCanvas = document.querySelector("#signModal canvas");
   var acknowledgeCanvas = document.querySelector("#acknowledgeModal canvas");

   var signaturePad = new SignaturePad(signatureCanvas, {
      backgroundColor : "rgba(255, 255, 255, 0)"
   });   

   var acknowledgePad = new SignaturePad(acknowledgeCanvas, {
      backgroundColor : "rgba(255, 255, 255, 0)"
   });

   const monthNumbers = ["01", "02", "03", "04", "05", "06",
           "07", "08", "09", "10", "11", "12"
  ];

   var currentdate = new Date(); 
   var current_date = monthNumbers[currentdate.getMonth()] + "-"
                + ("0" + currentdate.getDate()).slice(-2) + "-" 
                + currentdate.getFullYear();
  $('.consent_form_date').text(current_date);
  $('input.consent_form_date').val(current_date);
   //signaturePad.fromDataURL("{{ $patient->hippa_form_signature_setup }}");
      
   //save signature
  $('body').on('click', '.add_signature_btn', function(e) {
    e.preventDefault();
    if(signaturePad.isEmpty()){
      $("#signModal span.error").html('Please do signature first.').show();
    }else{
        var sig_type = $("#signModal input[type=hidden]").val();

        $("."+sig_type+"_preview").parent().find('button.open_signature_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(signaturePad.toDataURL());
        $("."+sig_type+"_preview").show();
        
        //unacknowledge all acknowledgements if any
        $('button.open_acknowledge_modal').show();
        $("span.acknowledgement_preview").find('img').attr('src', '');
        $("span.acknowledgement_preview").find('input[type=hidden]').val(0);
        $("span.acknowledgement_preview").hide();

        $("#signModal").modal('hide');
    }
   });    

   //save signature
  $('body').on('click', '.acknowledge_signature_btn', function(e) {
    e.preventDefault();
    if(acknowledgePad.isEmpty()){
      $("#acknowledgeModal span.error").html('Please do signature first.').show();
    }else{

        var sig_type = $("#acknowledgeModal input[type=hidden]").val();
        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(1);
        $("."+sig_type+"_preview").show();
        
        $("#acknowledgeModal").modal('hide');
    }
   });      

   //clear signature
   $('body').on('click', '.clear_signature', function(e) {
      e.preventDefault();
      signaturePad.clear();
   });   

   //open signature modal
   $('body').on('click', '.open_signature_modal', function(e) {
      e.preventDefault();
      $("#signModal span.error").html('').hide();
      signaturePad.clear();

      if($('.signature_setup_preview').is(':visible'))
        signaturePad.fromDataURL($('.signature_setup_preview').find('img').attr('src'));

      if($(this).data('save_type') && $(this).data('save_type') == 'edit'){
          $("#signModal").find('.headingpage').text('Edit signature'); 
          $("#signModal").find('.add_signature_btn').text('Update signature'); 
          $("#signModal").find('span.updating_signature_notice').show(); 
      }
      else {
        $("#signModal").find('span.updating_signature_notice').hide(); 
        $("#signModal").find('.headingpage').text('{{trans("consent_form.patient_digital_signature")}}'); 
        $("#signModal").find('.add_signature_btn').text('{{trans("consent_form.add_signature")}}'); 
      }

      $("#signModal input[type=hidden]").val($(this).data('type'));
      $("#signModal").modal({backdrop: 'static', keyboard: false});


   });   

   //open achnowledge modal
   $('body').on('click', '.open_acknowledge_modal', function(e) {
      e.preventDefault();
      acknowledgePad.off();
      acknowledgePad.clear();

      if(signaturePad.isEmpty()){
        bootbox.alert("{{ trans('consent_form.add_setup_signature') }}");
      }
      else
      {
        var sig_type = $(this).data('type');
        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').hide();
        $("."+sig_type+"_preview").find('img').attr('src', signaturePad.toDataURL());
        $("."+sig_type+"_preview").find('input[type=hidden]').val(1);
        $("."+sig_type+"_preview").show();

      }
   }); 

   //open signature modal
   @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
     $('body').on('click', '.unacknowledge', function(e) {
        var sig_type = $(this).data('type');

        $("."+sig_type+"_preview").parent().find('button.open_acknowledge_modal').show();
        $("."+sig_type+"_preview").find('img').attr('src', '');
        $("."+sig_type+"_preview").find('input[type=hidden]').val(0);
        $("."+sig_type+"_preview").hide();
     });
   @endif
});

function save_release_form(){
  $("span.error").html('').hide();
  $(".set_phone_format").inputmask('remove');
  var formData = new FormData($('#save_release_form')[0]);
  $.ajax({
     url:"{{ route('patient_release_form_save') }}",
     type:"POST",
     data:formData,
     processData: false,
     contentType: false,
     dataType: "json",
     success:function(data){ 
        window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient->id),'#release']) }}";
     },
     error:function(error){
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
        var errorHtml= '<div class="alert alert-danger alert-dismissible"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>';
        $.each(error.responseJSON.errors,function(key,value){
          errorHtml+='<li>'+value+'</li>';

        });
        errorHtml+='</div>';
        $('#print_form').prepend(errorHtml);
       // console.log(errorHtml);

        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('#print_form').parent().offset().top
        }, 500);

        fadeOutAlertMessages();

      }
  });
}

$('form#save_consent_form input').bind("change", function() {
    var val = $(this).val();
    $(this).attr('value',val);
});


function printDiv(divName) {
  $(".set_phone_format").inputmask('remove');
  //$('.signature-view').css("border",'none');
  jcf.destroyAll();
  window.print();
  initCustomForms();


}

 $(".langauge_changed").on("change", function() { 
    
    var url = new URL(window.location.href);
    var query_string = url.search;
    var search_params = new URLSearchParams(query_string); 
    search_params.set('lang', this.value);
    url.search = search_params.toString();
    var new_url = url.toString();
    window.location.href = new_url;
      
  });
</script>