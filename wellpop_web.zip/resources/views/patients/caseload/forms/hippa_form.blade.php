@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{trans('label.case_loads')}}
@endsection
 {{ App::setLocale($lang) }}
@section('content')
<div class="leftsectionpages">
   <div class="row non-print">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.patient_overview') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.hippa_form') }}
         </div>
      </div>
   </div>
     <div class="tab-content">
  <div class="patient-view pat-show case-main-wrap non-print">
      @include('patients.caseload.sections.header-patient-info', ['patient' => $patient,'is_form'=>true])
  </div>
   {!! Form::model($patient,['id' => 'save_release_form']) !!}
   <input name="patient_id" type="hidden" value="{{ encrypt($patient_id) }}">
 
      <div class="cons-form-box auth-form">
         <div class="lang-box non-print">
            <div class="row">
               <div class="col-md-10">
                  @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                  <div class="form-group">
                     <label>Choose Language</label>
                     {!! Form::select('hippa_form_language', ['eng'=>'English','es'=>'Spanish','fr'=>'Farcy','vit'=>'Vietnamese'], $lang, ['class' => 'status_filter customselect langauge_changed']) !!}
                  </div>
                  @endif
               </div>
               <div class="col-md-2">
                  <ul class="action-box">
                     <li onclick="printDiv('print_form')"><i class="fa fa-print"></i><span>Print</span></li>
                  </ul>
               </div>
            </div>
         </div>
         <div id="print_form">
         @if(session()->has('message.level'))
          <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {!! session('message.content') !!}
          </div>
         @endif 
         <h4> {{ trans('hippa_form.address_field_1') }}<br>
            {{ trans('hippa_form.address_field_2') }}<br>
            {{ trans('hippa_form.address_field_3') }}
         </h4>
         <h2>{{ trans('hippa_form.informed_hippa') }}</h2>
         <p class="consent_sign_date"> {{ trans('hippa_form.patient_name') }}*:
            <!-- <input type="text" value='' readonly="">  -->
            <b>{{ $patient->first_name ? $patient->first_name : "-"}} {{ $patient->last_name ? $patient->last_name : ""}}</b>
            <button class="btn btn-primary basic-btn open_signature_modal non-print" data-type="signature_setup" <?php if($patient->hippa_form_signature_setup) echo 'style="display:none;"'; ?>>{{ trans('consent_form.setup_signature') }}</button>
            <span class="signature-view signature_setup_preview non-print" <?php if(!$patient->hippa_form_signature_setup) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('hippa_form_signature_setup')  !!}
               @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                 <i class="fa fa-pencil-alt open_signature_modal non-print" data-type="signature_setup" data-save_type="edit"></i>
               @endif
            </span>
            <span class="fa-pull-right">{{ trans('consent_form.date') }}:
              @if($patient->hippa_form_signature_setup != null && $patient->hippa_form_signature_setup != '')
                  <b>{{ @$patient_form_data['hippa_form_date'] ? date_format_change(@$patient_form_data['hippa_form_date']):"-" }}</b>
              @else
                <b class="consent_form_date"></b>
                <span class="error" style="color:red"></span>
              @endif
            </span>
          </p>
         <br/>

         <!-- First Acknowledge -->
         <p class="big">{{ trans('hippa_form.authorize_process') }} </p>
        <div class="signature-setup ack-signature-view" style="float: right;">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="receive_services" <?php if($patient->hippa_form_signature_setup) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview receive_services_preview" <?php if(!$patient->hippa_form_signature_setup) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('acknowledge_authorize_person', 0)  !!}
               @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                 <i class="fa fa-times unacknowledge non-print" data-type="receive_services"></i>
               @endif
            </span>
         </div>
         <p> {{ trans('hippa_form.authorize_paragraph') }} </p>
         <p>{{ trans('hippa_form.authorize_disclose_permission') }}</p>

         <!-- Second Signature paragraph -->
         <p class="big"> {{ trans('hippa_form.description_heading') }}</p>
         <div class="signature-setup ack-signature-view" style="float: right;">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="emergency_medical_services" <?php if(@$patient_form_data['acknowledge_description_of_info']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview emergency_medical_services_preview" <?php if(!@$patient_form_data['acknowledge_description_of_info']) echo 'style="display:none;"'; ?>>
               <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
               {!! Form::hidden('acknowledge_description_of_info', 0)  !!}
               @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                 <i class="fa fa-times unacknowledge non-print" data-type="emergency_medical_services"></i>
               @endif
            </span>
         </div>
          <p> {{ trans('hippa_form.health_info') }} </p>
            <ul>
               <li>{{ trans('hippa_form.medical_records') }} </li>
               <li>{{ trans('hippa_form.alcohol_drug_abuse') }} </li>
               <li>{{ trans('hippa_form.mental_health_record') }} </li>
               <li>{{ trans('hippa_form.all_treatment_record') }} </li>
            </ul>
            <p>{{ trans('hippa_form.all_past_info') }} </p>

         <!-- Third Signature paragraph -->
         <p class="big"> {{ trans('hippa_form.purpose_heading') }} </p>
         <div class="signature-setup ack-signature-view">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="release_medical_records" <?php if(@$patient_form_data['acknowledge_purpose_to_use']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview release_medical_records_preview" <?php if(!@$patient_form_data['acknowledge_purpose_to_use']) echo 'style="display:none;"'; ?>>
              <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
              {!! Form::hidden('acknowledge_purpose_to_use', 0)  !!}
              @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                <i class="fa fa-times unacknowledge non-print" data-type="release_medical_records"></i>
              @endif
            </span>
         </div>
         <p> {{ trans('hippa_form.purpose_paragraph') }} </p>
         

         <!-- Fourth Signature paragraph -->
         <p class="big">{{ trans('hippa_form.validity_heading') }} </p>
         <div class="signature-setup ack-signature-view">
            <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="release_vehicle" <?php if(@$patient_form_data['acknowledge_validity_of_form']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
            <span class="error" style="color:red"></span>
            <span class="signature-view acknowledgement_preview release_vehicle_preview" <?php if(!@$patient_form_data['acknowledge_validity_of_form']) echo 'style="display:none;"'; ?>>
              <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
              {!! Form::hidden('acknowledge_validity_of_form', 0)  !!}
              @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                <i class="fa fa-times unacknowledge non-print" data-type="release_vehicle"></i>
              @endif
            </span>
         </div>
          <p class="consent_form_by">{{ trans('hippa_form.validity_para') }} @if($patient->hippa_form_signature_setup != null && $patient->hippa_form_signature_setup != '')<b class="" style="margin: 0px 10px;">{{ @$patient_form_data['hippa_validation_date'] ? date_format_change(@$patient_form_data['hippa_validation_date']) :"-" }}</b> @else <b class="consent_form_date " style="margin: 0px 10px;" ></b> @endif {{ trans('hippa_form.validity_paragraph') }}</p>
            <p class="big">{{ trans('hippa_form.ACKNOWLEDGMENT') }} </p>
            <p>{{ trans('hippa_form.acknowledgment_para') }}</p>
            <p>{{ trans('hippa_form.acknowledgment_paragraph') }} </p>
         
          {!! Form::hidden('hippa_form_signature_date', $patient->hippa_form_signature_date,['class' => 'consent_form_date']) !!}
          {!! Form::hidden('hippa_validation_date', $patient->hippa_validation_date,['class' => 'consent_form_date']) !!}
          {!! Form::hidden('hippa_form_date', $patient->hippa_form_date,['class' => 'consent_form_date']) !!}
         <div class="row patient-client-initial">
            <div class="col-md-4 col-xl-6">
               <p>By*: 
                  @if($patient->hippa_form_signature_setup != null && $patient->hippa_form_signature_setup != '')
                     <b>{{ @$patient_form_data['authorize_by'] ? @$patient_form_data['authorize_by'] :"-" }}</b>
                @else
                       <b class="">{{ Auth::user()->name}}</b>
                @endif

               </p>
               <p>{{ trans('consent_form.signature') }}*:</p>
               <div class="signature-setup">
                  <button class="btn btn-primary basic-btn open_acknowledge_modal non-print" data-type="signature" <?php if(@$patient_form_data['acknowledge_signature']) echo 'style="display:none;"'; ?>>{{ trans('consent_form.acknowledge') }}</button>
                  <span class="error" style="color:red"></span>
                  <span class="signature-view acknowledgement_preview signature_preview" <?php if(!@$patient_form_data['acknowledge_signature']) echo 'style="display:none;"'; ?>>
                  <img src="{{ $patient->hippa_form_signature_setup }}" class="sign-img">
                  {!! Form::hidden('acknowledge_signature', 0)  !!}
                  @if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
                    <i class="fa fa-times unacknowledge non-print " data-type="signature"></i>
                  @endif
                  </span>
               </div>
            </div>
            <div class="col-md-8 col-xl-6">
              {!! Form::hidden('form_type', $type)  !!}
              <p class="fa-pull-right">{{ trans('consent_form.date') }}:
                @if($patient->hippa_form_signature_setup != null && $patient->hippa_form_signature_setup != '')
                 
                  <b>{{ @$patient_form_data['hippa_form_signature_date'] ? date_format_change(@$patient_form_data['hippa_form_signature_date']) :"-" }}</b>
                @else
                  <b class="consent_form_date"></b>
                  <span class="error" style="color:red"></span>
                @endif
              </p>
              
              <div class="clearfix"></div>
            </div>
         </div>
       </div>  
         <div class="personliving non-print">
            <div class="buttonsbottom">
              @if($patient->hippa_form_signature_setup != null && $patient->hippa_form_signature_setup != '')
                <a href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient->id),'#release']) }}"  class="close">{{ trans('label.close') }}</a> 
              @else
                <button  class="next" type="button" onClick="javascript:save_release_form()" data-toggle="modal" data-target="#exampleModal">{{ trans('label.save') }}</button>
                <a href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient->id),'#release']) }}"  class="close">{{ trans('label.cancel') }}</a>
              @endif
            </div>
         </div>
      </div>
   </div>
 
   {!! Form::close() !!}
</div>



<!-- signModal -->
@if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
  <div class="modal fade" id="signModal" tabindex="-1" role="dialog" aria-labelledby="signModalLabel" aria-hidden="true">
   <input type="hidden" value="" name="signature_type">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <div class="headingpage">{{ trans('consent_form.patient_digital_signature') }}</div>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
       </div>
       <div class="modal-body">
           <div class="row">
              <div class="col-sm-12">
                 <label>{{ trans('consent_form.patient_sign_in_box') }}</label>
                 <div class="sign-box">       
                    <canvas style="touch-action: none;" width="500px" height="100px"></canvas>
                 </div>
                 <span class="updating_signature_notice" style="font-size:12px;display:none;">{{ trans('consent_form.updating_signature_notice') }}</span>
                 <span class="error" style="color:red;display:none;"></span>
               </div>
           </div>
        </div>
       <div class="modal-footer">
         <div class="buttonsbottom"> 
           <a href="#" class="next add_signature_btn">{{ trans('consent_form.add_signature') }}</a> 
           <a href="#" data-dismiss="modal"  class="close">{{ trans('label.cancel') }}</a> </div>
           <a href="#" class="btn btn-info clear_signature">{{ trans('consent_form.clear') }}</a> </div>
       </div>
     </div>
   </div>
@endif

<!-- Acknowledge Modal -->
@if($patient->hippa_form_signature_setup == null || $patient->hippa_form_signature_setup == '')
  <div class="modal fade" id="acknowledgeModal" tabindex="-1" role="dialog" aria-labelledby="signModalLabel" aria-hidden="true">
   <input type="hidden" value="" name="signature_type">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <div class="headingpage">{{ trans('consent_form.patient_digital_signature') }}</div>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
       </div>
       <div class="modal-body">
           <div class="row">
              <div class="col-sm-12">
                 <label>{{ trans('consent_form.patient_sign_in_box') }}</label>
                 <div class="sign-box">       
                    <canvas style="touch-action: none;" width="500px" height="100px"></canvas>
                 </div>
                 <span style="font-size:12px;">{{ trans('consent_form.acknowledge_signature_notice') }}</span>
               </div>
           </div>
        </div>
       <div class="modal-footer">
          <div class="buttonsbottom"> 
           <a href="#" class="next acknowledge_signature_btn">{{ trans('consent_form.acknowledge') }}</a> 
           <a href="#" data-dismiss="modal"  class="close">{{ trans('label.cancel') }}</a> 
          </div>
        </div>
      </div>
    </div>
  </div>
@endif

@endsection

@section('script')
  @include('patients.caseload.forms.release_form_js')
@endsection