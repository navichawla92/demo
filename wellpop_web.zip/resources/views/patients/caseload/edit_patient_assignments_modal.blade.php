
<div class="modal fade" id="editAssignment" tabindex="-1" role="dialog" aria-labelledby="editAssignmentLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
        {!! Form::open(['id' => 'edit_care_team_form']) !!}
        {!! Form::hidden('patient_id',  encrypt_decrypt('encrypt', $patient->id))  !!}
        {!! Form::hidden('is_care_team', 1)  !!}

         <div class="modal-header">
            <div class="headingpage">{{ trans('label.edit_wellpop_team') }}</div>
         </div>
         <div class="modal-body">
            <div class="">
               <div class="clearfix"></div>
               <div class="row">

                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Case Manager * </label>
                        {!! Form::select('assigned_cm', $careTeam['cm_users'], ($patient->assignedCareplanCm)?$patient->assignedCareplanCm->type_id:0, ['class' => 'customselect assigned_cm']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Community Health Worker* </label>
                        {!! Form::select('assigned_chw', $careTeam['chw_users'], ($patient->assignedCareplanChw)?$patient->assignedCareplanChw->type_id:0, ['class' => 'customselect assigned_chw']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> Mediacal Director * </label>
                        {!! Form::select('assigned_md', $careTeam['md_users'], ($patient->assignedCareplanMd)?$patient->assignedCareplanMd->type_id:0, ['class' => 'customselect assigned_md']) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <div class="buttonsbottom">
               <button type="button" onClick="javascript:edit_care_plan_team()" class="next model_box_save">{{ trans('label.save') }}</button>

              <a href="#" class="close" data-dismiss="modal" aria-label="Close">Cancel</a> </div>
         </div>
         {!! Form::close() !!}
      </div>
   </div>
</div>