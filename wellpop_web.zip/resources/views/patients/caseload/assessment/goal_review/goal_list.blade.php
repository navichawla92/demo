<div class="card-body">

    @foreach($careplanGoals as $careplanGoal)


        @php
            $hasQuestionByRole = $careplanGoal->questions()->count();
        @endphp
        <div class="row @if(!$hasQuestionByRole) disable_goal_text @endif">
            <div class="col-md-7">
                <?php
                    $role = Auth::user()->getRoleNames();
                    $roleName = '';
                    if($role){
                        $roleName = $role[0];
                    }
                    
                ?>
                <p>{{ $careplanGoal->title }} @if(!$hasQuestionByRole) <b class="not_available">({{ trans('label.no_question_available_or_assigned_to') }} {{$roleName}})</b> @endif </p>
            </div>
            <div class="col-md-5">
                <a href="javascript:;"
                   data-goal_version="{{ $careplanGoal->goal_version }}"
                   data-goal_id="{{ encrypt_decrypt('encrypt',$careplanGoal->goal_id) }}"
                   onclick="getGoalDetails(this)"
                   class="show-detail">
                    {{ trans('label.goal_details') }}
                </a>
                <span class="checky">
                    @if($hasQuestionByRole)
                        <input type="checkbox"
                        name="diagnosis[{{$careplanGoal->diagnosis_id}}][]"
                        class="goal_chbox customcheck"
                        value="{{ encrypt_decrypt('encrypt',$careplanGoal->goal_id) }}-{{ $careplanGoal->goal_version }}">
                    @else
                        <input type="checkbox" class="goal_chbox customcheck" disabled readonly>
                    @endif
                </span>
                <span class="goal-updated-date">{{ $careplanGoal->getUpdatedDate() }} </span>
                
                
            </div>
        </div>
    @endforeach
    <div class="goalreview_diagnosis_goal_list">
        {{$careplanGoals->links()}}
    </div>
</div>

