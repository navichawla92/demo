<div class="table-responsive care-table loadDivData">
    <table class="table diag-table">
        <thead>
        <tr>
            <th>{{ trans('label.diagnosis') }} </th>
            <th>{{ trans('label.priority') }} </th>
            <th>{{ trans('label.goals') }} </th>
            <th style="text-align:right; padding-right:30px;">{{ trans('label.last_updated') }} </th>
        </tr>
        </thead>
        <tbody>

        @if($diagnosisList->total())
            @foreach($diagnosisList as $diagnosis)
                <tr>
                    <td>{{ ucfirst($diagnosis->title) }}</td>
                    <td>{{ $diagnosis->priority }}</td>
                    <td colspan="2">
                        <span class="accordion table-accord" id="accordionExample3">
                           <div class="card">
                              <div class="card-header" id="headingOne">
                                 <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#dropi-{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}"
                                            data-diagnosisId="{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}"
                                            data-diagnosis_version="{{$diagnosis->version }}"
                                            onclick="loadDiagnosisGoal(this)"
                                            aria-expanded="true" aria-controls="dropi3">
                                        {{ $diagnosis->goal_count }} available {{ str_plural('Goal',$diagnosis->goal_count) }}
                                        <span class="goal-count">Select <i class="fa fa-angle-down"></i></span>
                                    </button>
                                 </h5>
                              </div>
                              <input type="hidden" name="diagnosis-version[{{ $diagnosis->diagnosis_id }}]" value="{{ $diagnosis->version }}">
                               <div id="dropi-{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}" data-type="diagnosis" data-version="{{ $diagnosis->version }}" data-id="{{ encrypt_decrypt('encrypt',$diagnosis->diagnosis_id) }}" class="collapse" aria-labelledby="headingOne">

                               </div>
                           </div>
                        </span>
                    </td>
                </tr>
            @endforeach
        @else
            <tr>
                <td colspan="4">{{ trans('label.no_record_found') }}.</td>
            </tr>
        @endif
        </tbody>
    </table>
</div>
<div class="careplan_diagnosis_list">
    {{ $diagnosisList->links() }}
</div>


<div class="sidebox-overlay" id="goal_detail_sidebar">
    <div class="inner-slide animated slideInRight fast">
        <div class="slide-head">
            <h4><a class="close-side close_goal_detail_sidebar"><i class="fa fa-angle-left"></i> {{ trans('label.back') }} </a> {{ trans('label.goal_details') }} </h4>
        </div>
        <div id="goal_detail_body"></div>
    </div>
</div>
</div>

<script>
    /* */

    $.ajaxSetup({
        type:"POST",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend:function(){
            $('.loadDivData').waitMe();
        },
        complete:function(){
            $('.loadDivData').waitMe('hide');
            applpyEllipses('loadDivData', 3, 'no');
        },
        error:function(error){
            if(error.status == 500){
                $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
            }
            else if(error.status == 404){
                $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
            }
        }
    });

    function loadDiagnosisGoal(target) {
        var diagnosisId = $(target).attr('data-diagnosisId');
        var diagnosisVersion = $(target).attr('data-diagnosis_version');
        var careplanId = $('[name="careplan_id"]').val();

        if($(target).hasClass('collapsed') && $.trim($('#dropi-'+diagnosisId).text()).length < 5) {
            var url = '{{ route('goalreview_diagnosis_goal_list') }}?careplan_id='+careplanId+'&diagnosis_id='+diagnosisId;
            $.get(url, function(response){
                $('#dropi-'+diagnosisId).html(response.html);
                initCustomForms();
                initializeDiagnosisGoalsPagination(diagnosisId);

                handleCheckbox();


                if(typeof window.diagnosis_list !== 'undefined') {
                    $.each(window.diagnosis_list, function(key,value){
                        if(value['diagnosis_id'] == diagnosisId && value['diagnosis_version'] == diagnosisVersion) {
                            diagnosisContainer = $('[data-id="' + diagnosisId + '"][data-version="' + diagnosisVersion + '"]');
                            if(typeof  value['final_goal_ids'] != 'undefined') {
                                value['goalids'] = value['final_goal_ids'];
                                goalIds = value['goalids'].split(',');
                                $.each(goalIds, function(i,id){
                                    $('input[value="'+id+'"]', diagnosisContainer).prop('checked',true);
                                })
                            }
                        }
                    });

                    initCustomForms();
                }

            },'json');
        }
    }

    function initializeDiagnosisGoalsPagination(diagnosisId)
    {
        console.log('#dropi-' + diagnosisId);
        $('#dropi-'+diagnosisId+' .goalreview_diagnosis_goal_list .pagination a').click(function(){
            $.get($(this).attr('href'), function(response){
                $('#dropi-'+diagnosisId).html(response.html);

                if(typeof window.diagnosis_list !== 'undefined') {
                    $.each(window.diagnosis_list, function(key,value) {
                        if(value['diagnosis_id'] == diagnosisId) {
                            diagnosisContainer = $('[data-id="' + diagnosisId + '"]');
                            goalIds = value['goalids'].split(',');
                            $.each(goalIds, function(i,id){
                                $('input[value="'+id+'"]', diagnosisContainer).prop('checked',true);
                            })
                        }
                    });

                    initCustomForms();
                }

                initializeDiagnosisGoalsPagination(diagnosisId);
                initCustomForms();
                handleCheckbox();
            },'json');
            return false;
        });
    }

    function getGoalDetails(target)
    {
        var goalId = $(target).attr('data-goal_id');
        var goalVersion = $(target).attr('data-goal_version');

        var url = '{{ route('careplan_diagnosis_goal_detail') }}?goal_version='+goalVersion+'&goal_id='+goalId;
        $.get(url, function(response){
            $("#goal_detail_sidebar").addClass("show-overlay");
            $('#goal_detail_body').html(response.html);
            $("body").addClass("hideout");
            handleGoalDetailPagination();
        },'json');
    }


    function handleGoalDetailPagination()
    {
        $('.careplan_subgoal_pagination .pagination a').click(function(){
            $.get($(this).attr('href'), function(response){
                $('.careplan_subgoal_list').html(response.html);
                $("body").addClass("hideout");
                handleGoalDetailPagination();
            },'json');

            return false;
        });

        $('.careplan_question_pagination .pagination a').click(function(){
            $.get($(this).attr('href'), function(response){
                $('.careplan_question_list').html(response.html);
                $("body").addClass("hideout");
                handleGoalDetailPagination();
            },'json');

            return false;
        });
    }

    $('.close_goal_detail_sidebar').click(function(){
        $('#goal_detail_sidebar').find(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $("#goal_detail_sidebar").removeClass("show-overlay");
            //    $(".sidebox-overlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $(".inner-slide").removeClass("slideOutRight");

        }, 1000);
    });


    function handleCheckbox()
    {
        $('.goal_chbox').change(function() {
            if(typeof window.diagnosis_list == 'undefined') {
                window.diagnosis_list = [];
            }

            var goalId = $(this).val();
            var diagnosisData = $(this).closest("[data-type='diagnosis']");
            var diagnosisId = diagnosisData.attr('data-id');
            var diagnosisVersion = diagnosisData.attr('data-version');

            if($(this).prop('checked')) {
                var flag = true;
                $.each(window.diagnosis_list, function(key,value){
                    if(value['diagnosis_id'] == diagnosisId && value['diagnosis_version'] == diagnosisVersion) {
                        goalIds = value['goalids'].split(',');
                        goalIds.push(goalId);
                        goalIds = jQuery.unique(goalIds);
                        value['goalids'] = goalIds.join(',')

                        flag = false;
                    }
                });

                if(flag) {
                    window.diagnosis_list.push({
                        diagnosis_id:diagnosisData.attr('data-id'),
                        diagnosis_version: diagnosisData.attr('data-version'),
                        goalids: $(this).val()
                    });
                }
            } else {
                removeItem = $(this).val();
                $.each(window.diagnosis_list, function(key,value){
                    if(value['diagnosis_id'] == diagnosisId && value['diagnosis_version'] == diagnosisVersion) {
                        goalIds = value['goalids'].split(',');

                        goalIds = $.grep(goalIds, function(value) {
                            return value != removeItem;
                        });

                        goalIds = jQuery.unique(goalIds);
                        value['goalids'] = goalIds.join(',');
                    }
                });
            }


            initCustomForms();
        });
    }


    function initializeCareplanDiagnosisPagination(current_page = '')
    {
        $('.careplan_diagnosis_list .pagination a').click(function(){

            if(current_page === '') {
                current_page = getURLParameter($(this).attr('href'), 'page');
            }
            console.log();
            var assessmentId = $('[name="assessment_id"]').val();
            $.get('{{ route('goalreview_diagnosis_list') }}?assessment_id=' + assessmentId+'&page='+ current_page, function (response) {
                $('.diagnosis_list').html(response.html);
            }, 'json');

            return false;
        });
    }

    initializeCareplanDiagnosisPagination();


</script>

