<div class="care-box">
 <form action="javascript:;" id="goal_review_data">
    <div id="goal_deleted_success">
                <div class="alert alert-danger hide">
                    <div class="alert-message"></div>
                </div>
    </div>
    @foreach($assessmentGoalReview as $goalReview)
    <div class="main-section goal-main-list">
        <div class="headingpage">
          <div class="row">
            <div class="col-lg-6 col-md-12">
               <button class="btn btn-link collapsed goal_review_btn" type="button" data-toggle="collapse" data-target="#goalreview-{{ encrypt_decrypt('encrypt', $goalReview->diagnosis_id) }}" aria-expanded="false" aria-controls="collapseGoalInnerOne">
                <i class="fa fa-minus-square"></i>
            </button>
            Diagnosis: {{ $goalReview->title }}
            </div>
            <div class="col-lg-6 col-md-12">

            <span class="opty-box">
                <ul class="two-opt @if($goalReview->metric->name == 'Level') {{'five_opt'}} @endif" >
                    @foreach($goalReview->metric->getValueArray() as $key => $value)
                      <li>
                         <input type="radio" class="diagnosis_metric_radio" id="diagnosis_{{$goalReview->diagnosis_id}}_{{ $goalReview->diagnosis_version }}_{{$key}}" name="diagnosis[{{$goalReview->diagnosis_id}}][{{ $goalReview->diagnosis_version }}][metric]" @if($goalReview->metric_value == $value) checked="checked" @endif value="{{ $value }}">
                         <label for="diagnosis_{{$goalReview->diagnosis_id}}_{{ $goalReview->diagnosis_version }}_{{$key}}">{{ $value }}</label>
                      </li>
                    @endforeach
                </ul>

                <ul class="flag-box">
                   @php
                    $flagColor = '';
                    $flagId = '';
                   @endphp
                   @foreach($flags as $id =>$flag)
                        @if($id == $goalReview->flag_id)
                            @php
                                $flagColor = $flag.'-flag';
                                $flagId = $id;
                            @endphp
                        @endif
                   @endforeach

                   <i class="fas fa-flag show-flag {{ $flagColor }}"></i>
                    <div class="select-flag">
                        @foreach($flags as $id =>$flag)
                        <a class="flag_name" data-flag="{{$flag}}" data-id="{{$id}}"><i class="fas fa-flag {{$flag}}-flag"></i></a>
                        @endforeach

                    </div>
                    <input name="diagnosis[{{$goalReview->diagnosis_id}}][{{ $goalReview->diagnosis_version }}][flag]" type="hidden" class='selected_flag_name' value="{{$flagId}}" old_value="{{$flagId}}">
                </ul>

                <a href="javascript:;" onclick="deleteDiagnosis(this)" data-diagnosis_id="{{ encrypt_decrypt('encrypt',$goalReview->diagnosis_id) }}" data-diagnosis_version="{{ $goalReview->diagnosis_version }}"> <i class="fa fa-trash-alt"></i> </a>
            </span>
             <input type="hidden" name="diagnosis[{{$goalReview->diagnosis_id}}][{{ $goalReview->diagnosis_version }}][metric_id]" value="{{ $goalReview->metric->id }}">
            </div>
          </div>
 
        </div>
        <div class="main-section-inner positioning collapse" id="goalreview-{{ encrypt_decrypt('encrypt', $goalReview->diagnosis_id) }}" aria-labelledby="headingOne" style="">
            <div class="goal-body">

                <div class="row">

                    <div class="col-md-12">


                        <div class="error_alert alert alert-danger alert-dismissible fade hide" role="alert">
                           <span class="diagnosis_flag_error" id="diagnosis_{{$goalReview->diagnosis_id}}_flag"></span>
                        </div>
                        <div class="error_alert alert alert-danger alert-dismissible fade hide" role="alert">
                            <span class=" diagnosis_metric_error" id="diagnosis_{{$goalReview->diagnosis_id}}_metric"></span>
                        </div>

                    </div>
                    @php
                    $roleId = 0;
                    if(auth()->user()->hasAnyRole(Spatie\Permission\Models\Role::all())) {
                        $roleId = auth()->user()->roles->pluck('id')[0];
                    }
                    @endphp
                    <div class="col-sm-10">
                        
                         @if(app('request')->input('is_view',0))
                             <div class="other-notes">
                             <div class="row">
                                <div class="col-lg-2 col-md-3">
                                   <label>Summary</label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                   <p >{{ $goalReview->summary ?? ''}}</p>
                                   <span class="error" style="color:red"></span> 
                                </div>
                             </div>
                             </div>
                         @else
                        <div class="form-group">
                            <label class="labelfieldsname">Summary</label>
                            <textarea type="text" class="form-control diagnosis_summary" name="diagnosis[{{$goalReview->diagnosis_id}}][{{ $goalReview->diagnosis_version }}][summary]" placeholder="Enter Summary about the Progress of the patient ">{{ $goalReview->summary }}</textarea>
                        </div>
                        @endif
                         <div class="error_alert alert alert-danger alert-dismissible fade hide" role="alert">
                             <span class=""  id="diagnosis_{{$goalReview->diagnosis_id}}_summary"></span>
                        </div>
                    </div>
                </div>
                @php
                    $assessmentGoals = $goalReview->getAssessmentGoal();
                @endphp
                                        <div class="error_alert alert alert-danger alert-dismissible fade hide" role="alert">
                            <span class="diagnosis_select_error"  id="dia_{{$goalReview->diagnosis_id}}"></span>
                        </div>
                @foreach($assessmentGoals as $assessmentGoal)
                    <div class="goal-box">
                       <div class="goal-heady">
                         <div class="row">
                          <div class="col-lg-9 col-md-7">
                             <h4>Goal: <span>{{ ucfirst($assessmentGoal->title) }}</span>
                              </h4>
                          </div> 
                           <div class="col-lg-3 col-md-5">
                           <a class="view_assessment_goal_btn"
                                 onClick="deleteGoalData(this);"
                                 data-goal_id="{{ encrypt_decrypt('encrypt',$assessmentGoal->goal_id) }}"
                                 data-goal_version="{{ $assessmentGoal->goal_version }}"
                                 data-diagnosis_id="{{ encrypt_decrypt('encrypt',$goalReview->diagnosis_id) }}"
                                 data-diagnosis_version="{{ $goalReview->diagnosis_version }}"
                                 data-assessment_id="{{ encrypt_decrypt('encrypt',$goalReview->assessment_id) }}">
                                  <i class="fa fa-trash-alt" ></i>
                              </a>
                              <a class="clear view_assessment_goal_btn" onClick="clearGoalData(this);">Clear</a>
                          </div> 
                         </div> 
                       </div> 
                        @php
                            $goalAssignments = $assessmentGoal->getGoalAssignments();
                            $questionCount = 1;
                        @endphp
                        @foreach($goalAssignments as $goalAssignment)

                        @if(in_array($roleId ,$goalAssignment->question->assigned_roles))

                            <div class="qus-box">
                                <div class="row">
                                    <div class="col-md-12 col-lg-6">
                                        <p><span class="ques">Ques.{{ $questionCount }}</span><b class="more_info"> {{ $goalAssignment->question->description }} </b></p>
                                    </div>
                                    <div class="col-md-12 col-lg-6 inner-option">
                                        @php
                                            $name = "diagnosis[$goalReview->diagnosis_id][$goalReview->diagnosis_version][goal][$assessmentGoal->goal_id][{$goalAssignment->question->id}]";
                                        @endphp

                                        @if($goalAssignment->question->metric->name == 'Scale' || $goalAssignment->question->metric->name == 'Level' || $goalAssignment->question->metric->name == 'Binary')
                                        <ul class="two-opt @if($goalAssignment->question->metric->name == 'Level') {{'five_opt'}} @endif">
                                            @foreach($goalAssignment->question->metric->getValueArray() as $key => $value )
                                                @php
                                                    $labelId = "diagnosis_{$goalReview->diagnosis_id}_{$goalReview->diagnosis_version}_{$assessmentGoal->goal_id}_{$key}_{$goalAssignment->question->id}";
                                                @endphp
                                                <li>
                                                    <input type="radio" id="{{ $labelId }}" name="{{$name}}[answer]" value="{{ $value }}"
<?php
    if(isset($dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id])  && $dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id]['answer'] == $value )
    {
        echo "checked";
    }
    ?>
>
                                                    <label for="{{ $labelId }}">{{ $value }}</label>
                                                </li>
                                            @endforeach
                                        </ul>
                                        @php
                                        $questionCount++;
                                        @endphp
                                        @endif

                                        @if($goalAssignment->question->metric->name == 'Note')
                                        <?php
                                            $datavalue = '';
                                            if(isset($dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id]))
                                            {
                                                $datavalue = $dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id]['answer'];
                                            }
                                        ?>

                                            <div class="textfieldglobal" style="width: 87%;">
                                            <input name="{{$name}}[answer]" maxlength="1000" type="text" value="{{$datavalue}}" >
                                                 <span class="error" style="color:red"></span>
                                            </div>
                                        @endif


                                         <input type="hidden"  name="{{$name}}[metric_id]" value="{{ $goalAssignment->question->metric->id }}">
                                        @if(1)
                                        @php
                                        $flagColor = '';
                                        $flagId = '';
                                       @endphp
                                       @foreach($flags as $id =>$flag)
                                       @if(isset($dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id])  && $dataSaved['diagnosis_'.$goalReview->diagnosis_id.'_'.$goalReview->diagnosis_version.'_'.$assessmentGoal->goal_id.'_'.$goalAssignment->question->id]['flag'] == $id )
                                          
                                                @php
                                                    $flagColor = $flag.'-flag';
                                                    $flagId = $id;
                                                @endphp
                                            @endif
                                       @endforeach

                                        <ul class="flag-box">
                                            <i class="fas fa-flag show-flag {{ $flagColor }}"></i>
                                            <div class="select-flag"> 
                                                 @foreach($flags as $id => $flag)
                                                    <a class="flag_name" data-flag="{{$flag}}" data-id="{{$id}}"><i class="fas fa-flag {{$flag}}-flag"></i></a> 
                                                 @endforeach
                                              
                                            </div>
                                            <input  name="{{$name}}[flag]" type="hidden" class='selected_flag_name' value="{{$flagId}}" old_value="{{$flagId}}">
                                        </ul>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    @endforeach

     <input type="hidden" name="tab_name" value="goal_review">

</div>
</form>
    @if(app('request')->input('is_view',0))
        <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn " onClick="nextTab();">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">{{ trans('label.previous') }}</button>
        </div>
        @else
        <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn " onClick="saveGoalReview(0);">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="saveGoalReview(2);">{{ trans('label.save') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">{{ trans('label.previous') }}</button>
        </div>
    @endif

<script type="text/javascript">
    $('.show-flag').click(function() {
       $(this).parent().find('.select-flag').fadeToggle();
    });

    $('.flag_name').click(function() {

      if($(this).data('id').toString() != $(this).parent().parent().find('.selected_flag_name').attr('old_value').toString()){
        $(this).parent().parent().find('.selected_flag_name').addClass('changed-input');
      }
      else {
        $(this).parent().parent().find('.selected_flag_name').removeClass('changed-input');
      }
      $(this).parent().parent().parent().parent().parent().find('.diagnosis_flag_error').text('').hide();
      $(this).parent().parent().find('.show-flag').attr('class', 'fas fa-flag show-flag');
      $(this).parent().parent().find('.show-flag').removeClass($('.selected_flag_name').data('flag')+'-flag');
      $(this).parent().parent().find('.selected_flag_name').val($(this).data('id'));
      $(this).parent().parent().find('.selected_flag_name').attr('data-flag', $(this).data('flag'));
      $(this).parent().parent().parent().find('.show-flag').addClass($(this).data('flag')+'-flag');
      $(this).parent().parent().find('.select-flag').fadeToggle();

      $(this).parent().parent().find('.selected_flag_name').parent().find('span.error').hide().removeClass('active');
      $(this).closest('.goal-main-list').find('.diagnosis_flag_error').parent().removeClass('show').addClass('hide').css('display','none');

    })

    function clearGoalData(target){
        var element = $(target).closest('.goal-box');

        element.find('input:text').val('');
        element.find('input:radio').each(function () { $(this).prop('checked', false); });
        element.find('.show-flag').attr('class', 'fas fa-flag show-flag');
        element.find('selected_flag_name').val('');
        element.find(':input').removeClass('changed-input');
        $('[name="is_save"]').addClass('changed-input');
        initCustomForms();
    }

    function deleteGoalData(target){
        if($(target).closest('.goal-main-list').find('.goal-box').length > 1){
            deleteGoalDataFinally(target)
        }else {
            bootbox.confirm("{{ trans('message.delete_goal_message') }}", function(result){
                if($('.goal-main-list').length == 1) {
                    deleteDiagnosisFinally(target, true);
                } else {
                    deleteDiagnosisFinally(target);
                }
            });
            return false;
        }
    }

    function deleteGoalDataFinally(target)
    {
        var goalId = $(target).attr('data-goal_id');
        var goalVersion = $(target).attr('data-goal_version');
        var diagnosisId = $(target).attr('data-diagnosis_id');
        var diagnosisVersion = $(target).attr('data-diagnosis_version');
        var assessmentId = $(target).attr('data-assessment_id');


        var removeItem = goalId+'-'+goalVersion;
        $.each(window.diagnosis_list, function(key,value){
            if(value['diagnosis_id'] == diagnosisId && value['diagnosis_version'] == diagnosisVersion) {
                goalIds = value['goalids'].split(',');
                goalIds = $.grep(goalIds, function(value) {
                    return value != removeItem;
                });
                goalIds = jQuery.unique(goalIds);
                value['goalids'] = goalIds.join(',');
            }
        });

        $.ajax({
            url:"{{ route('caseload_remove_goalreview_data') }}",
            data:{diagnosisId:diagnosisId, goalId: goalId, assessmentId:assessmentId},
            dataType: "json",
            success:function(data) {
                $('[name="is_save"]').addClass('changed-input');
                handleMessages(data, 'goal_deleted_success', false);
                fadeOutAlertMessages();
                $(target).closest('.goal-box').remove();

            },
            error:function(error) {
                if(error.status == 500){
                    $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                }
                else{

                }
            }
        });
    }

    function deleteDiagnosis(target)
    {
        if($('.goal-main-list').length == 1) {
            bootbox.confirm("{{ trans('message.delete_goal_review_diagnosis_message') }}", function(result){
                if(result) {
                    deleteDiagnosisFinally(target, true);
                }

            });
        } else {
            deleteDiagnosisFinally(target);
        }
    }

    function deleteDiagnosisFinally(target, isLastDiagnosis = false) {
        var diagnosisId = $(target).attr('data-diagnosis_id');
        var diagnosisVersion = $(target).attr('data-diagnosis_version');
        var assessmentId = $('[name="assessment_id"]').val();

        $.post('{{ route('goal_review_diagnosis_delete') }}', {
            diagnosis_id: diagnosisId,
            diagnosis_version: diagnosisVersion,
            assessment_id: assessmentId
        }, function(response){
            window.diagnosis_list = $.grep(window.diagnosis_list, function(value) {
                return !(value['diagnosis_id'] == diagnosisId && value['diagnosis_version'] == diagnosisVersion);
            });

            if(isLastDiagnosis) {
                $('#questions_list').empty();
                $('[name="is_save"]').removeClass('changed-input');
                $('.goal_review_text').show();
            } else {
                $(target).closest('.goal-main-list').remove();
                $('[name="is_save"]').addClass('changed-input');
            }

        },'json')
    }



    function saveGoalReview(is_save) {

        if(is_save == 0 && $('.changed-input').length == 0) {
            $('#v-pills-tab a[data-type="content_discussed"]').click();
            return false;
        }


        if(is_save == '1'){
            $.ajaxSetup({
                type:"POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend:function(){
                    $('.loader_div').waitMe();
                },
                complete:function(){
                    // $('.loader_div').waitMe('hide');

                },
                error:function(error){
                }
            });
        }
        else{
            $.ajaxSetup({
                type:"POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend:function(){
                    $('.loader_div').waitMe();
                },
                complete:function(){
                    $('.loader_div').waitMe('hide');

                },
                error:function(error){
                }
            });

        }


          var patientId = $('[name="patient_id"]').val();
          var careplanId = $('[name="careplan_id"]').val();
          var assessment_id = $('[name="assessment_id"]').val();

          
          var formData = new FormData($('#goal_review_data')[0]);
          formData.append('patient_id', patientId)
          formData.append('careplan_id', careplanId);
          formData.append('assessment_id', assessment_id);

          $('span.error').text('').hide();
          $.ajax({
              url: '{{ route('patient_assessment_goaldata_save') }}',
              data: formData,
              dataType:'JSON',
              contentType: false,
              processData: false,
              success: function(response) {
                  $('input,textarea,select').removeClass('changed-input');
                  $('#v-pills-tab a[data-type="goal_review"]').removeClass('text-red');
                  $('#v-pills-tab a[data-type="goal_review"]').find('i').removeClass('chk-hide');
                  $('[name="is_save"]').val(1);
                  $('.error_alert').removeClass('show');
                  $('.error_alert span').text('');

                  if(is_save == '1'){
                      saveAssessment();
                  }
                  if(is_save != 2){
                      $('#v-pills-tab a[data-type="content_discussed"]').click();
                  }



              },
              error: function(errors) {

                  $('.goal_review_btn').removeClass('collapsed');

                  $('.error_alert').addClass('hide').css('display','none');
                  $(".diagnosis_select_error").each(function() {
                      var id = $(this).attr('id');

                      if(!id.indexOf("dia_")) {
                          $('#'+id).html('').removeClass('active').hide();
                          $('#'+id).parent().addClass('hide').removeClass('show').css('display','none')
                      }
                  });

                  $.each(errors.responseJSON.errors,function(key,value){   
                      if(key == 'assigned_users' || key == 'followup_id'){
                       $('#'+key).html(value).addClass('active').show()
                      }
                      else if(!key.indexOf("diagnosis"))
                        {
                          var diagnosis = key.split('.');
                           var newkey = '';
                           if(diagnosis.length > 2) {
                               newkey = diagnosis[0]+'_'+diagnosis[1]+'_'+diagnosis[3]; 
                           }
                           $('#'+newkey).html(value).addClass('active').show();
                            console.log(newkey);
                           console.log($('#'+newkey).parent());
                           $('#'+newkey).parent().addClass('show').removeClass('hide').css('display','block');
                           $('.main-section-inner').addClass('show')
                        }
                      else {
                       $('#'+key).html(value).addClass('active').show();
                       $('#'+key).parent().addClass('show').removeClass('hide').css('display','block')
                      }
                  });
                  if(is_save == '1'){
                      saveAssessment();
                  }
                  jQuery('html, body').animate({
                    scrollTop: jQuery(document).find('.error_alert:visible').parent().offset().top-150
                  }, 500);
              }
          });
    }


    $('.diagnosis_summary').on('input', function() {
      $(this).parent().parent().find('span.error').text('').hide();
      $(this).parent().parent().find('.error_alert').removeClass('show').css('display','none');
    });

    $('.diagnosis_metric_radio').on('change', function() {

        $(this).closest('.goal-main-list').find('.diagnosis_metric_error').text('').hide();
        $(this).closest('.goal-main-list').find('.diagnosis_metric_error').parent().removeClass('show').css('display','none');

     // $(this).parent().parent().find('span.error').text('').hide();
    });
    
    handleMoreInfo();


    function previousTab()
    {
        $('#v-pills-tab a[data-type="purpose"]').click();
    }

    function nextTab()
    {
        $('#v-pills-tab a[data-type="content_discussed"]').click();
    }
</script>