<div class="tab-pane fade active show" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
   <h4 class="assess-head">{{ trans('label.goal_review') }}
      <span class="head-btn main-head-box">
         <button class="btn btn-primary basic-btn select-goal" >{{ trans('label.select_goals') }} </button>
      </span>
   </h4>
   @if(!$assessmentGoalReview->count())
      <p class="check-text goal_review_text">{{ trans('message.please_select_goals_and_provide') }} </p>
   @endif

   <div id="questions_list">
      @if($assessmentGoalReview->count())
         @include('patients.caseload.assessment.goal_review.goal_review_questions', compact($assessmentGoalReview))
      @endif
   </div>
   {{--<div class="asess-btnbox">--}}
      {{--<button class="btn btn-primary basic-btn">Save</button>--}}
   {{--</div>--}}
</div>


<!--goal-sidebox -->
<div class="sidebox-overlay" id="diagnosis_list_sidebar">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4>
            <a class="close-side-goal"><i class="fa fa-angle-left"></i> {{ trans('label.back') }}</a>
            {{ trans('label.select_goals_for_assessment') }}
         </h4>
      </div>
      <div class="slide-body">
         <div class="slide-topover">
            <div class="row">
               <div class="col-md-9 selected_goal_text">
                  <p>
                    <span>{{ trans('message.select_goal_using_checkbox') }}</span>
                    <span> {{trans('message.select_goal_using_checkbox_with_pre_select') }}
                    </span> 
                  </p>
               </div>
               <div class="col-md-3">
                  <button class="btn btn-primary basic-btn" onclick="add_to_assessment()">{{ trans('label.add_to_assessment') }}</button>
               </div>
                <div class="col-md-12">
                   <span class="error" style="color:red" id='diagnosis'></span>
                </div>
            </div>
         </div>
         <form action="javascript:;" id="save_goal_review">
           <div class="diagnosis_list">

           </div>
         </form>
      </div>
   </div>
</div>

<div class="diagnosis_data" data-value=""></div>



<script>
  var careplanId   = $('[name="careplan_id"]').val();
  var patientId    = $('[name="patient_id"]').val();
  var assessmentId = $('[name="assessment_id"]').val();

  $('.select-goal').click(function(){
     $.get('{{ route('goalreview_diagnosis_list') }}?assessment_id=' + assessmentId, function (response) {
         $('#diagnosis_list_sidebar').addClass('show-overlay');
         $('.diagnosis_list').html(response.html);

         if(typeof window.diagnosis_list == 'undefined') {
             $('.selected_goal_text span').eq(0).show();
             $('.selected_goal_text span').eq(1).hide();
         } else {
             $('.selected_goal_text span').eq(0).hide();
             $('.selected_goal_text span').eq(1).show();

             $.each(window.diagnosis_list, function(key,value){
                 if(typeof value['final_goal_ids'] != 'undefined') {
                     value['goalids'] = value['final_goal_ids'];
                 } else {
                     value['goalids'] = '';
                 }
             });
         }


     }, 'json');
  });


  $('.close-side-goal').click(function(){
     $('#diagnosis').hide().removeClass('active');
     $('#diagnosis_list_sidebar').removeClass('show-overlay');
  });

  function add_to_assessment(){
    
      var formData = new FormData($('#save_goal_review')[0]);
      var careplanId   = $('[name="careplan_id"]').val();
      var patientId    = $('[name="patient_id"]').val();
      var assessmentId = $('[name="assessment_id"]').val();

      formData.append('patient_id', patientId)
      formData.append('careplan_id', careplanId);
      formData.append('assessment_id', assessmentId);

      if (typeof window.diagnosis_list == 'undefined') {
          formData.append('diagnosis','');
      } else {
          formData.append('diagnosis', JSON.stringify(window.diagnosis_list));
      }

      $.ajax({
         url:"{{ route('goalreview_diagnosis_goal_save') }}",
         type:"POST",
         data:formData,
         processData: false,
         contentType: false,
         dataType: "json",
          success:function(data){
              $('input,textarea,select').removeClass('changed-input');
              $('#is_anything_change').val('');
              $("span.error").text('');
              $('input,textarea,select').removeClass('changed-input');
              $('[name="is_save"]').val(1);
              $('[name="is_save"]').addClass('changed-input');
              $('.close-side-goal').trigger('click');
              $('.goal_review_text').hide();
              $('#questions_list').html(data.html);
             // $('button.select-goal').hide();

              $.each(window.diagnosis_list, function(key,value){
                  value['final_goal_ids'] = value['goalids'];
              });
          },
          error:function(error) {
             $.each(error.responseJSON.errors,function(key,value){
                 if(key == 'diagnosis'){
                    $('#'+key).show().text(value);
                 }else{
                    var element = key.replace(/\./g, '_');
                    $('.'+element).find('span.error').show().text(value);
                 }
             });
          }
      });
  }




</script>