<div class="tab-pane fade active show" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
   <h4 class="assess-head">{{ trans('label.content_discussed') }} <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn tool-detail">{{ trans('label.view_tools') }}</button></span></h4>
   <div class="care-box">
      @if(!@$assessment)
         @inject('assessment', 'App\Models\CareplanAssessment')
      @endif
      {!! Form::model($assessment,['id' => 'contentDiscussed']) !!}
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">Add content form Registry(Search by Content Title or ID)</label>
                  {!! Form::select('visit_content[]', $contentDiscussed,null,array("class" => "content_discussed",'id'=>"icdCode",'multiple')) !!}
                  <span class="error" id='visit_content' style="color:red"></span>
               </div>
            </div>
         </div>
      </div>
      <div class="other-notes_data">
         <label class="labelfieldsname">Other Notes</label>
         <textarea class="form-control" name='other_notes' placeholder="Enter your notes here" value="{{ $assessment->other_notes ?? ''}}"> {{ $assessment->other_notes ?? ''}}</textarea>
         <span class="error" style="color:red"></span>
      </div>
      <input type="hidden" name="tab_name" value="content_discussed">
      {!! Form::close() !!}
   </div>
   <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="saveContentDiscussed(0);">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right" onClick="saveContentDiscussed(2);">{{ trans('label.save') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
</div>

<!--view-tools -->
<div class="sidebox-overlay" id="toolsOverlay" style="left: 0;">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-tool"><i class="fa fa-angle-left"></i> Back</a>{{ trans('label.view_tools') }}</h4>
      </div>
      <div class="slide-body">
         <div class="slide-tools">
            <div class="barrier-search">
               <div class="textfieldglobal">
                  <input type="text" placeholder="Search by Tool Title or Tool ID" name='search_tool'>
                  <button class="btn btn-primary basic-btn search_tool">Search</button>
               </div>
            </div>
            <div class="table-responsive care-table div_load" id='tool_list'>

            </div>
         </div>
      </div>
   </div>
</div>

<div class="sidebox-overlay tool_detail" id="viewOverlay" style="left: 0;">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side"><i class="fa fa-angle-left"></i> Back</a>Tool Details</h4>
      </div>
      <div class="slide-body">
         <div class="slide-section">
            <h4>Basic Details</h4>
            <div class="detail-view">
               <div class="row tool_detail_data">
                  <div class="col-md-12">
                     <p class="tool_id"><span>{{ trans('label.tool_id') }}:</span> TO!O!O </p>
                  </div>
                  <div class="col-md-12">
                     <p class="tool_desc"><span>Tool Descrption:</span> ssas </p>
                  </div>
                  <div class="col-md-12">
                     <p class="tool_type"><span>Tool Type:</span> sas</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">

    $(".tool-detail").click(function () {
        handleToolListing();
        $("#toolsOverlay").addClass("show-overlay");
    });

    function handleToolListing(current_page = '',SearchText='')
    {
        if(current_page === '') {
            current_page = $("#tool_list .pagination").find('.active').text();
        }
        var url = "{{ route('patient_tool_list') }}"+'?page='+ current_page;
        $.ajax({
            url:url,
            type:"GET",
            data:{name:SearchText},
            dataType: "json",
            success:function(data){
                $('#tool_list').html(data.html);
                applpyEllipses('div_load', 4, 'no');
            },
            error:function(data){
                alert('error');
            }
        });
    }

    $('body').on('click', '#tool_list .pagination a', function(e) {
        e.preventDefault();
        page = getURLParameter($(this).attr('href'), 'page');

        var name = $('input[name=search_tool]').val();

        $.ajaxSetup({
            type:"POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend:function(){
                $('.div_load').waitMe();
            },
            complete:function(){
                $('.div_load').waitMe('hide');
                //applpyEllipses('div_load', 5, 'no');
            },
            error:function(error){
            }
        });
        handleToolListing(page,name);
    });


    $('body').on('click', '.search_tool', function(e) {
        e.preventDefault();
        name = $('input[name=search_tool]').val();

        $.ajaxSetup({
            type:"POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend:function(){
                $('.div_load').waitMe();
            },
            complete:function(){
                $('.div_load').waitMe('hide');
              //  applpyEllipses('div_load', 5, 'no');
            },
            error:function(error){
            }
        });
        handleToolListing('',name);
    });


    $('body').on('click', '.show-detail', function(e) {
     $('.tool_id').html('<span>{{ trans("label.tool_id") }}:</span> '+$(this).data('tool_id'));
     $('.tool_desc').html('<span>{{ trans("label.tool_desc") }}:</span> <b class="more_info"> '+$(this).data('tool_desc')+'</b>');
     $('.tool_type').html('<span>{{ trans("label.tool_type") }}:</span> '+$(this).data('tool_type'));
     $("#viewOverlay").addClass("show-overlay");
     $("body").addClass("hideout");
     handleMoreInfo()
    });


    $(".content_discussed").chosen({ width:'100%' });
    function contentDiscussedList() {
        //setup before functions
        var typingTimer;                //timer identifier
        var xhr = {abort: function () {  }};  //time in ms (2 seconds)
        var selectID = 'icdCode';    //Hold select id
        var selectData = [];           // data for unique id array

        $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
            minLength:1,
            delay: 300,
            source: function( request, response ) {
                $('#' + selectID + '_chosen .no-results').hide();
                var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
                $.ajax({
                    url:"{{ route('content_discussed_list') }}",
                    data: {data: inputData,selected_code : $('#' + selectID).val()},
                    type:'POST',
                    dataType: "json",
                    beforeSend: function(){

                    },
                    success: function( data ) {

                        $('#' + selectID ).find('option').not(':selected').remove();
                        $.map( data.html, function( item ) {
                            if($.inArray(item.id,selectData) == -1){
                                $('#' + selectID ).append('<option value="'+item.id+'" data-id = "'+item.id+'">' + item.code + '- '+ item.title+ '</option>');
                            }
                        });
                        var inputData1 = $('#' + selectID + '_chosen .chosen-choices input').val();
                        $('#' + selectID ).trigger("chosen:updated");
                        $('.chosen-search-input' ).val(inputData1);
                    }
                });
            }
        });

        $('#' + selectID ).on('change', function() {
            var domArray = $('#' + selectID ).find('option:selected');
            selectData = [];
            for (var i = 0, length = domArray.length; i < length; i++ ){
                selectData.push( $(domArray[i]).data('id') );
            }

            $('#' + selectID ).html(domArray);
            $('#' + selectID ).trigger("chosen:updated");

        });

    }

    contentDiscussedList();


    function saveContentDiscussed(is_save) {
        if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="priority_alignment"]').click();
           return false;
        }

        if(is_save == '1'){
            console.log('here');
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }
        var patientId = $('[name="patient_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var assessmentId = $('[name="assessment_id"]').val();

        var formData = new FormData($('#contentDiscussed')[0]);
        formData.append('patient_id', patientId)
        formData.append('careplan_id', careplanId);
        formData.append('assessment_id', assessmentId);

        $.ajax({
            url: '{{ route('patient_assessment_content_discussed_save') }}',
            data: formData,
            dataType:'JSON',
            contentType: false,
            processData: false,
            success: function(response) {
                $('input,textarea,select').removeClass('changed-input');
                $('#v-pills-tab a[data-type="content_discussed"]').removeClass('text-red');
                
                $('[name="is_save"]').val(1);
                if(is_save == '1'){
                  saveAssessment();
                }
                if(is_save == '0'){
                  $('#v-pills-tab a[data-type="priority_alignment"]').click();
                }
            },
            error: function(errors) {
                $.each(errors.responseJSON.errors,function(key,value){
                    if(key == 'visit_content'){
                        $('#'+key).html(value).addClass('active').show()
                    }
                    else {
                        $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                    }
                });
                 if(is_save == '1'){
                    saveAssessment();
                }
            }
        });
    }

    function previousTab(){
        $('#v-pills-tab a[data-type="goal_review"]').click();
    }

    $(".close-side-tool").click(function () {
        $(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $(".sidebox-overlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $('.barrier-search').find('input').removeClass('changed-input');
            $(".inner-slide").removeClass("slideOutRight");
        }, 1000);
    });

    $(".close-side").click(function () {
        $(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $("#viewOverlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $(".inner-slide").removeClass("slideOutRight");

        }, 1000);
    });
</script>