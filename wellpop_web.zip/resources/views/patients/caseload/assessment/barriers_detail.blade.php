<p><span>{{ trans('label.id') }}:</span> {{ $barrier->code }} </p>
<p><span>{{ trans('label.title') }}:</span> {{ $barrier->title }} </p>
<p><span>{{ trans('label.description') }}:</span> {{ $barrier->description }}</p>
<p><span>{{ trans('label.suggestions_to') }} <br> {{ trans('label.overcome') }} :</span> <b class="more_info"> {{ $barrier->solution }}  </b></p> <br>