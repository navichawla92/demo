@extends('layouts.app')
@section('css')
    <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
    <style type="text/css">
        
        .headingpage .flag-box{
                padding-left: 0px !important;
        }

    </style>
@endsection
@section('title')
{{ trans('label.add_new_assessment') }}
@endsection
@section('content')

<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-7 col-lg-8">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.care_plan') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.add_new_assessment') }}
         </div>
      </div>
      <div class="col-md-5 col-lg-4">
         <div class="buttonsbottom">
             <a href="javascript:;" class="next save_btn" onclick="saveAssessmentData()">{{ trans('label.save_and_confirm') }}</a>
             <a href="#" class="close close_form">{{ trans('label.cancel') }}</a>
         </div>
      </div>
   </div>
   <div class="">
      <div class="patient-view pat-show case-main-wrap">
        @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
         <input type="hidden" name="patient_id" value="{{ encrypt_decrypt('encrypt',$patient['patient_info']->id) }}">
         <input type="hidden" name="careplan_id" value="0">
         <input type="hidden" name="assessment_id" value="0">
         <input type="hidden" name="is_save" value="0">

         <!--              <div class="expandy-accord"> <a class="closeall btn btn-main" accordion-id="#accordionExample">Collapse All</a> <a class="openall btn btn-main" accordion-id="#accordionExample">Expand All</a> </div>-->

         @if($activeCarePlan)
         <div class="assess-main">
            <div class="row">
               <div class="col-md-3 col-lg-2">
                 @include('patients.caseload.assessment.sidebar')  
               </div>
               <div class="col-md-9 col-lg-10">
                  <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                     @include('patients.caseload.assessment.purpose',['is_view' => 0])
                  </div>
               </div>
            </div>
         </div>
         @else
         <div class="assess-main">
            <div class="row">
               <h5> No active care plan </h5>
            </div>
         </div>
         @endif
            
      </div>
   </div>
</div>
@endsection

@section('script')
@include('layouts.route_name')
<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/caseloads/care_plan.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/caseloads/case_load.js') }}" type="text/javascript"></script> 

<script type="text/javascript">
    const monthNumbers = ["01", "02", "03", "04", "05", "06",
         "07", "08", "09", "10", "11", "12"
    ];

    var currentdate = new Date();
    var hour    = currentdate.getHours();
    var minute  = currentdate.getMinutes();
    var second  = currentdate.getSeconds();
    if(hour.toString().length == 1) {
             hour = '0'+hour;
        }
        if(minute.toString().length == 1) {
             minute = '0'+minute;
        }
        if(second.toString().length == 1) {
             second = '0'+second;
        }    
    var current_date = monthNumbers[currentdate.getMonth()] + "-"
            +("0" + currentdate.getDate()).slice(-2) + "-" 
            + currentdate.getFullYear()+ ' ('+hour + ":"  
                + minute + ":" 
                + second+' )';
    $('.date_time').html(current_date);


   $.ajaxSetup({
     type:"POST",
     headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         },
     beforeSend:function(){
         $('.loader_div').waitMe();
     },
     complete:function(){
         $('.loader_div').waitMe('hide');
         applpyEllipses('dataTable', 5, 'no');
     },
     error:function(error){
         if(error.status == 500){
            $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
            }
         else if(error.status == 404){
            $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
         }
     }
   });
 

// function to click on side bar to load the relative tab
$('body').on('click', '.assess-main .nav-link', function(e) {
     e.preventDefault();
         closeFormTab();
        if($(this).hasClass('active')) {
            return false;
        }
       
        if($('.changed-input').length != 0) {
             return false;
        }
        var type = $(this).data('type');
        var assessmentId = $('[name="assessment_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var patientId = $('[name="patient_id"]').val();

         $.ajax({
            url:"{{ route('patient_assessment_detail_tab', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}",
            type: "GET",
            dataType: "json",
            data: {tab:$(this).data('type'),assessment_id:assessmentId, careplan_id:careplanId, patient_id:patientId},
            success:function(response){
              $('#v-pills-tabContent').html(response.data.html);
              initCustomForms();
              addOldVelue();
           },error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else if(error.status == 404){
                        $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
                    }
                    else if(error.status == 403){
                        $('#v-pills-tab a').not(':first').removeClass('active');
                        $('#v-pills-tab a:first').addClass('active');
                    }
                }
        });
   
});


function saveAssessment() {

    $.ajaxSetup({
          type:"POST",
          headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
          beforeSend:function(){
            //  $('.loader_div').waitMe();
          },
          complete:function(){
              $('.loader_div').waitMe('hide');
              
          },
          error:function(error){
          }
    });
    var assessmentId = $('[name="assessment_id"]').val();
    var careplanId = $('[name="careplan_id"]').val();
    var patientId = $('[name="patient_id"]').val();

    var formData = new FormData();
    formData.append('patient_id', patientId)
    formData.append('careplan_id', careplanId);
    formData.append('assessment_id', assessmentId);
    $.ajax({
        url:"{{ route('patient_assessment_save') }}",
        type: "POST",
        dataType: "json",
        data: formData,
        contentType: false,
        processData: false,
        success:function(response) {
            $('input,textarea,select').removeClass('changed-input');
            $('[name="is_save"]').val(0);
            window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#assessment']) }}";
        },error:function(errors) {
            $.each(errors.responseJSON.errors,function(key,value){
                $('#v-pills-tab a[data-type="'+key+'"]').addClass('text-red');
            });
        }
    });
}

function saveAssessmentData() {
    bootbox.confirm({
        message: "Are you sure you want to save this assessment?",
        callback: function(result){
            if (result) {
                  var tab_name = $('[name="tab_name"]').val();
                    console.log(tab_name);
                      if(tab_name == "purpose"){
                          savePurpose(1);
                       }
                        if(tab_name == "goal_review"){
                            saveGoalReview(1);
                        }
                        if(tab_name == "content_discussed"){
                          saveContentDiscussed(1);
                        }
                        if(tab_name == "intervention"){
                          saveIntervention(1);
                        }
                        if(tab_name == "progress_notes"){
                          saveProgress(1);
                        }
                        if(tab_name == "risk_assessment"){
                          saveRiskAssessment(1);
                        }
                        if(tab_name == "priority_alignment"){
                          savePriorityAlignment(1);
                        }
                        if(tab_name == "barriers"){
                          saveBarriers(1);
                        }
                        if(tab_name == "vitals"){
                          saveVitals(1);
                        }
            }
            else {
                bootbox.hideAll();
                return false;
            }
        }
        })
}

function addOldVelue(){
    $("input,textarea,select").each(function(){
       // $(this).attr('old_value',$(this).val());

        if($(this).attr('type') == 'radio'){
            if ($(this).is(":checked")) {
              $(this).attr('old_value',$(this).val());
            }
        }else{
          $(this).attr('old_value',$(this).val());

        }
    })
}

$('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
            $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
            $(this).removeClass('changed-input');
        }
        else {
            $(this).addClass('changed-input');
        }
    }
    else {
        if($(this).hasClass('chosen-search-input')){

        }
        else{
            $(this).addClass('changed-input');
        }
    }

    //for radio button changes alert
    if($(this).attr('type') == 'radio'){
      if($(this).attr("old_value") == $(this).val()){
          $(this).removeClass('changed-input');
          $('input[name="'+$(this).attr("name")+'"]').removeClass('changed-input');
      }
      else{
        $(this).addClass('changed-input');
      }
    } 
});

function closeForm() {
    if ($('.changed-input').length || $('[name="is_save"]').val()=='1') {
        bootbox.confirm({
            message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?",
            callback: function(result){
                if (result) {
                    $('input,textarea,select').removeClass('changed-input');
                    $('[name="is_save"]').val('');
                    $('#is_anything_change').val('');
                    window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#assessment']) }}";
                }
                else {
                    bootbox.hideAll();
                    return false;
                }
            }
        })
    }
    else {
    window.location.href="{{ route('caseload_patient_view', [encrypt_decrypt('encrypt', $patient['patient_info']->id),'#assessment']) }}";

  }
}


function closeFormTab() {
    if($('.changed-input').length) {
        bootbox.alert("{{ trans('message.unsaved_error_message') }}");
        return false;
    }
}

addOldVelue();

// for cancel button on every form
$('body').on('click', '.close_form', function(e) {
    e.preventDefault();
    closeForm();
});

// for click on side bar or logout button
$(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
  if ($('.changed-input').length || $('[name="is_save"]').val()=='1'){
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }
});


 //  check if input changed and unsaved before reload
    window.onbeforeunload = function() {
      /*
      ==if auto-logout functionality causing page-reload then allow it don't show any alert 
      ==no matter data changed and un;-saved
      */
      if (($('.changed-input').length || $('[name="is_save"]').val()=='1') && !$('div.ui-dialog[aria-describedby="sessionTimeout-dialog"]').is(':visible')){
             return "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page.";
      }
      else {
      }      
    }

</script>
@endsection