<div class="tab-pane fade active show" id="v-pills-Vitals" role="tabpanel" aria-labelledby="v-pills-Vitals-tab">
   <h4 class="assess-head">Vitals <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn" data-toggle="modal" data-target="#addVital">Add Vitals</button>
      </span>
   </h4>
   <div class="care-box">
      <div id="vital_status">
         <div class="alert alert-error dismissible hide">
            <div class="alert-message"></div>
         </div>
      </div>

      <div class="table-responsive care-table vital_list">
         @include('patients.caseload.assessment.vital_list', ['vitals' => $vitals])
      </div>
   </div>
   <input type="hidden" name="tab_name" value="vitals">
   

   @if(app('request')->input('is_view',0))
      <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="nextTab();">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn" style="margin-right:10px;" onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
   @else
      

      <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="nextTab();">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn button_margin_right" onClick="saveVitals(2);">{{ trans('label.save') }}</button>
      <button class="btn btn-primary basic-btn" style="margin-right:10px;" onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
   @endif

</div>

<!-- addVital-->
<div class="modal fade addVitals" id="addVital" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="addVitalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <div class="headingpage">{{ trans('label.add_vital') }}</div>
         </div>
         <form action="javascript:;" method="post" id="addVitalForm">
            <div class="modal-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname">{{ trans('label.weight') }}</label>
                        <input type="text" class="form-control" name="weight" maxlength="3">
                        <span class="error" style="color:red"></span>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname">{{ trans('label.aic') }}</label>
                        <input type="text" class="form-control" name="a1c" maxlength="3">
                        <span class="error" style="color:red"></span>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="row">
                        <div class="col-lg-6 col-md-6">
                           <div class="form-group">
                              <label class="labelfieldsname">{{ trans('label.blood_pressure') }}</label>
                              <input type="text" class="form-control" name="blood_pressure_high" maxlength="3">
                              <span class="error" style="color:red"></span>
                           </div>
                        </div>
                        <div class="col-lg-1 col-md-2">
                           <div class="row">
                              <p class="over-text">{{ trans('label.over') }}</p>
                           </div>
                        </div>
                        <div class="col-lg-5 col-md-4">
                           <div class="form-group mt-20">
                              <label class="labelfieldsname"></label>
                              <input type="text" class="form-control" name="blood_pressure_low" maxlength="3">
                              <span class="error" style="color:red"></span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname">{{ trans('label.pulse') }}</label>
                        <input type="text" class="form-control" name="pulse" maxlength="3">
                        <span class="error" style="color:red"></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <div class="buttonsbottom">
                  <a href="javascript:;" onclick="saveVital()" class="next">{{ trans('label.save') }}</a>
                  <a href="javascript:;" class="close" data-dismiss="modal" aria-label="Close">{{ trans('label.cancel') }}</a>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>

<script>
    function saveVital() {

        var assessmentId = $('[name="assessment_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var patientId = $('[name="patient_id"]').val();
        var formData = new FormData($('#addVitalForm')[0]);
        $("span.error").html('').hide();
        formData.append('assessment_id',assessmentId);
        formData.append('careplan_id',careplanId);
        formData.append('patient_id',patientId);

        $.ajax({
            url: "{{ route('assessment_vital_add') }}",
            type: 'POST',
            data:formData,
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(response){
                $('span.error').text('');
                $('#addVitalForm')[0].reset();
                $('.vital_list').html(response.html);
                handleVitalPagination();
                $('input,textarea,select').removeClass('changed-input');
                $('#addVital').modal('hide');
                $('[name="is_save"]').val(1);
                handleMessages(response, 'vital_status', true);
                fadeOutAlertMessages();
            },
            error: function(error) {
                $.each(error.responseJSON.errors,function(key,value){
                    $('input[name="'+key+'"]').parent().find('span.error').show().text(value);
                });
            }
        })
    }

    function handleVitalPagination() {
        $('.vital_pagination .pagination a').click(function(){
            var url = $(this).attr('href')
            $.get(url, function(response){
                $('.vital_list').html(response.html);
                handleVitalPagination();
            },'json');
            return false;
        })
    }

    handleVitalPagination();

    function previousTab(){
        $('#v-pills-tab a[data-type="barriers"]').click();
    }

    function nextTab(){
        $('#v-pills-tab a[data-type="risk_assessment"]').click();
    }


     $(document).on('hidden.bs.modal', '.addVitals',function () {
      $('#addVitalForm').find('input,textarea,select').removeClass('changed-input');
      $('#addVitalForm').trigger('reset');
      $('span.error').hide().removeClass('active');
  })

     function saveVitals(is_save) {

         if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="progress_notes"]').click();
           return false;
          }

        if(is_save == '1'){

            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }

          if(is_save == '1'){
            saveAssessment();
          }
        
         
    }
</script>