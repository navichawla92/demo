<div class="tab-pane fade active show" id="v-pills-Intervention" role="tabpanel" aria-labelledby="v-pills-Intervention-tab">
   <h4 class="assess-head">{{ trans('label.intervention') }}</h4>
   <div class="care-box">

    {!! Form::model($intervention,['id' => 'intervention_form']) !!}

    @php
    $intervention_action = intervention_action();
     $userList = [];
    @endphp
    @if($careTeam)
        @php
		  $userList = $careTeam;
         /* $caseManager = $careTeam->cmUser;
          $commonHealthWorker = $careTeam->chwUser;
          $medicalDirector = $careTeam->mdUser;
          $userList[$careTeam->cmUser->id] = $careTeam->cmUser->name .'(CM)';
          $userList[$careTeam->chwUser->id] = $careTeam->chwUser->name .'(CHW)';
          $userList[$careTeam->mdUser->id] = $careTeam->mdUser->name .'(MD)';*/
        @endphp

    @endif
      <div class="inter-action">
         <div class="other-notes">
         <div class="row">
            <div class="col-lg-2 col-md-3">
               <label>Action</label>
            </div>
            <div class="col-md-3">
               {!! Form::select('action', array('' => 'Select an action') + $intervention_action,null,array("class" => "customselect")) !!}

               <span class="error" style="color:red"></span> 
            </div>
            <div class="col-md-3">
               <div class="flag-box inter-flag">
                  <i class="fas fa-flag {{ $intervention->flag ?? ''}}-flag show-flag" ></i>
                  <div class="select-flag"> 
                     @foreach($flags as $flag)
                    <a class="flag_name" data-flag="{{$flag}}"><i class="fas fa-flag {{$flag}}-flag"></i></a> 
                    @endforeach
                 <!--   <a class="flag_name" data-flag="red"><i class="fas fa-flag red-flag"></i></a> 
                    <a class="flag_name" data-flag="yellow"><i class="fas fa-flag yellow-flag"></i></a> 
                    <a class="flag_name" data-flag="green"><i class="fas fa-flag green-flag"></i></a> -->
                    </div>
               </div>
               <input name="flag" type="hidden" class='selected_flag_name' value="{{ $intervention->flag ?? ''}}" old_value="{{ $intervention->flag ?? ''}}">
               <input name="type" type="hidden" value="{{$type}}">
                <input type="hidden" name="intervention_id" value="{{ @$intervention->id ? encrypt_decrypt('encrypt',$intervention->id):0 }}">
               <span class="error" style="color:red"></span>
            </div>
         </div>
         </div>
         <br>
          <div class="other-notes">
         <div class="row">
            <div class="col-lg-2 col-md-3">
               <label>{{ trans('label.notes') }}</label>
            </div>
            <div class="col-lg-10 col-md-9">
               <p >{{ $intervention->summary ?? ''}}</p>
               <span class="error" style="color:red"></span> 
            </div>
         </div>
         </div>
      </div>
      <hr>
      <div class="record-visit">
         <div class="row">
            <div class="col-md-8">
               <div class="textfieldglobal">
                  <label class="labelfieldsname">{{ trans('label.notify') }}</label>
                 {!! Form::select('assigned_users[]', $userList,null,array("class" => "assigned_users",'id'=>"icdCode",'multiple','disabled' => true)) !!}
                  <span class="error" style="color:red" id='assigned_users'></span> 
               </div>
            </div>
         </div>
      </div>
      <input type="hidden" name="tab_name" value="intervention">
      {!! Form::close() !!}

      <h4 class="assess-head fs-16">{{ trans('label.follow_up_actions') }} <span class="head-btn main-head-box"><button class="btn btn-primary basic-btn addFollowModal" ><i class="fa fa-plus new-add"></i>  {{ trans('label.new') }}</button></span></h4>

      <span class="error" style="color:red" id='followup_id'></span> 

      <div id="save_intervention_followup">
                <div class="alert alert-danger hide">
                    <div class="alert-message"></div>
                </div>
      </div>
      <div class="table-responsive care-table" id='follow_up_list'>
        @include('patients.caseload.assessment.intervention.follow_up_list',compact('interventionFollowUps'))
      </div>
   </div>
   <div class="asess-btnbox">
      <button class="btn btn-primary basic-btn" onClick="nextTab();">{{ trans('label.next') }}</button>
      <button class="btn btn-primary basic-btn" style="margin-right:10px;" onClick="previousTab();">{{ trans('label.previous') }}</button>
   </div>
</div>

@include('patients.caseload.assessment.intervention.add_follow_up')
 <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">

    function saveIntervention() {
          var patientId = $('[name="patient_id"]').val();
          var careplanId = $('[name="careplan_id"]').val();
          var assessment_id = $('[name="assessment_id"]').val();
          var interventionId = $('[name="intervention_id"]').val();

          var formData = new FormData($('#intervention_form')[0]);
          formData.append('patient_id', patientId)
          formData.append('careplan_id', careplanId);
          formData.append('assessment_id', assessment_id);
          formData.append('intervention_id', interventionId);

          $('span.error').text('').hide();
          $.ajax({
              url: '{{ route('patient_assessment_intervention_save') }}',
              data: formData,
              dataType:'JSON',
              contentType: false,
              processData: false,
              success: function(response) {
                  $('input,textarea,select').removeClass('changed-input');
                  $('#v-pills-tab a[data-type="intervention"]').removeClass('text-red');
                  $('[name="intervention_id"]').val(response.intervention_id);
                  $('#v-pills-tab a[data-type="progress_notes"]').click();
                  $('#v-pills-tab a[data-type="intervention"]').removeClass('text-red');
              },
              error: function(errors) {
                  $.each(errors.responseJSON.errors,function(key,value){
                      if(key == 'assigned_users' || key == 'followup_id'){
                       $('#'+key).html(value).addClass('active').show()
                      }
                      else {
                       $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                      }
                  });
              }
          });
    }
    $('.show-flag').click(function() {
       $('.select-flag').fadeToggle();
    });


    $('body').on('click', '.addFollowModal', function(e) {

      $('span.error').text('');
      $('#addFollowModal').modal({backdrop: 'static', keyboard: false});
      datep();
    });

    function previousTab() {
      $('#v-pills-tab a[data-type="risk_assessment"]').click();
    }

    function nextTab() {
        $('#v-pills-tab a[data-type="progress_notes"]').click();
    }

    $(".assigned_users").chosen({ width:'100%' });
    $('.flag_name').click(function() {

      if($(this).data('flag').toString() != $('.selected_flag_name').attr('old_value').toString()){
        $('.selected_flag_name').addClass('changed-input');
      }
      else {
        $('.selected_flag_name').removeClass('changed-input');
      }

      $('.show-flag').removeClass($('.selected_flag_name').val()+'-flag');
      $('.selected_flag_name').val($(this).data('flag'));
      $('.show-flag').addClass($(this).data('flag')+'-flag');
      $('.select-flag').fadeToggle();
      $('.selected_flag_name').parent().find('span.error').hide().removeClass('active');
    })


    function handleFollowUpListing() {
        $('#followup_pagination .pagination a').click(function(e){
            e.preventDefault();
            page = getURLParameter($(this).attr('href'), 'page');
            getFollowUpListing(page);
        })
    }

    function getFollowUpListing(current_page = '')
    {
          if(current_page === '') {
             current_page = $("#followup_pagination .pagination").find('.active').text();
          }
          var assessmentId = $('[name="assessment_id"]').val();
          var url = "{{ route('patient_assessment_followup_list') }}"+'?page='+ current_page;
          $.ajax({
             url:url,
             type:"GET",
             data:{assessment_id:assessmentId},
             dataType: "json",
             success:function(data){
                 $('#follow_up_list').html(data.html);
                 handleFollowUpListing();
             },
             error:function(data){
                 alert('error');
             }

          });
      }

    handleFollowUpListing();

    $('body').on('click', '.followup_chkbox', function(e) {
        if($(this).is(':checked')){
            $(this).parent().parent().find('.checklabel').text('Completed');
        }
        else{
            $(this).parent().parent().find('.checklabel').text('Un-Completed');
        }
    });
    applpyEllipses('care-table', 4, 'no');
</script>
