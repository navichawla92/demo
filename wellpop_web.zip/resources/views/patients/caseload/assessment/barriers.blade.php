<div class="tab-pane fade active show" id="v-pills-Barriers" role="tabpanel" aria-labelledby="v-pills-Barriers-tab">
   <h4 class="assess-head">{{ trans('label.barriers') }}</h4>
   <div class="care-box">

       <div id="barrier_status">
           <div class="alert alert-error dismissible hide">
               <div class="alert-message"></div>
           </div>
       </div>

      <div class="barrier-search">
         <div class="row">
            <div class="col-md-6">
               <label class="labelfieldsname">{{ trans('label.add_barriers_from_registry') }}</label>
               <div class="textfieldglobal">
                  {!! Form::select('barrier_id',[],null,array("class" => "form-control multi_select_chosen",'id'=>"select_chosen_barrier",'multiple','data-type'=>'barrier','data-placeholder' => trans('label.search_by_barrier'))) !!}
                  <span class="error" style="color:red"></span>
               </div>
            </div>
            <div class="col-md-3">
               <button class="btn btn-primary basic-btn" style="margin-top: 20px;" onclick="addBarrier()">{{ trans('label.add_barrier') }}</button>
            </div>
         </div>
      </div>
       @if(app('request')->input('is_view',0))
         <div class="table-responsive care-table barrier_list">
         @include('patients.caseload.assessment.barriers_list', ['assessmentBarriers' => $assessmentBarriers,'is_careplan'=>true])
      </div>
       @else
      <div class="table-responsive care-table barrier_list">
         @include('patients.caseload.assessment.barriers_list', ['assessmentBarriers' => $assessmentBarriers,'is_careplan'=>false])
      </div>
       @endif
       <input type="hidden" name="tab_name" value="barriers">
   </div>

   @if(app('request')->input('is_view',0))
      <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
      </div>
   @else
      <div class="asess-btnbox">
         <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="saveBarriers(2);">{{ trans('label.save') }}</button>
         <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
      </div>
   @endif
</div>

<!--barrier-detail -->
<div class="sidebox-overlay assessment_barrier_sidebar" id="barrierOverlay">
   <div class="inner-slide animated slideInRight fast">
      <div class="slide-head">
         <h4><a class="close-side-barrier" onclick="closeBarrierDetailSidebar()"><i class="fa fa-angle-left"></i> Back</a>{{ trans('label.barrier_details') }}</h4>
      </div>
      <div class="slide-body">
         <div class="slide-section custom-single-detail">
            <div class="detail-view barrier-view">

            </div>
         </div>
      </div>
   </div>
</div>

<script>
    $(".multi_select_chosen").chosen({width: '100%', max_selected_options: 1});
    chosenDropDown('select_chosen_barrier');

    function chosenDropDown(selectID) {
        var xhr = { abort: function () {} };
        var selectData = [];           // data for unique id array
        $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
            minLength: 1,
            source: function (request, response) {
                $('#' + selectID + '_chosen .no-results').hide();
                var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
                var assessmentId = $('[name="assessment_id"]').val();
                $.ajax({
                    url: "{{ route('assessment_search_barriers') }}",
                    data: {query: inputData, assessment_id: assessmentId},
                    type: 'POST',
                    dataType: "json",
                    beforeSend: function () {

                    },
                    success: function (response) {
                        $('#' + selectID).find('option').not(':selected').remove();
                        $.map(response.data, function (item) {
                            if ($.inArray(item.id, selectData) == -1) {
                                $('#' + selectID).append('<option value="' + item.id + '" data-id = "' + item.id + '">' + item.code + '- ' + item.title + '</option>')
                            }
                        });

                        $('#' + selectID).trigger("chosen:updated");
                        $('.chosen-search-input').val(inputData);
                    }
                });
            }
        });

        // Chosen event listen on input change eg: after select data / deselect this function will be trigger
        $('#' + selectID).on('change', function () {
            var domArray = $('#' + selectID).find('option:selected');
            if(domArray.length == 0){
                $('ul.chosen-choices li.search-field').show();
            }
            else{
                $('ul.chosen-choices li.search-field').hide();

            }
        });
    }

    function addBarrier()
    {
        var assessmentId = $('[name="assessment_id"]').val();
        var barrierId = $('[name="barrier_id"]').val();
        var patientId = $('[name="patient_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();

        $.ajax({
            url: "{{ route('assessment_barrier_add') }}",
            data: {barrier_id: barrierId[0], assessment_id: assessmentId, patient_id: patientId, careplan_id: careplanId},
            type: 'POST',
            dataType: "json",
            success: function(response){
                $('.barrier_list').html(response.html);
                applpyEllipses('barrier_list', 3, 'no');
                $('select[name="barrier_id"]').val('');
                $('select[name="barrier_id"] option[value="'+barrierId[0]+'"]').remove();
                $('#select_chosen_barrier').trigger('change');
                $('#select_chosen_barrier').trigger("chosen:updated");
                handleBarrierPagination();

                handleMessages(response, 'barrier_status', true);
                fadeOutAlertMessages();
                applpyEllipses('care-table', 4, 'no');

            },
            error: function(error) {
                $.each(error.responseJSON.errors,function(key,value){
                    $('select[name="'+key+'"]').parent().find('span.error').show().text(value);
                });
            }
        })
    }

    function handleBarrierPagination() {
        $('.barrier_pagination .pagination a').click(function(){
            var url = $(this).attr('href')
            loadBarrierListing(url);
            return false;
        })
    }

    function loadBarrierListing(url)
    {
        $.get(url, function(response){
            $('.barrier_list').html(response.html);
            handleBarrierPagination();
            applpyEllipses('care-table', 4, 'no');
        },'json')
    }

    function deleteBarrier(target)
    {

        bootbox.confirm({
            message: 'Are you sure, you want to delete this barrier?',
            buttons: {
                confirm: {
                    label: 'Yes',
                    // className: 'btn-primary'
                },
                cancel: {
                    label: 'No',
                    //  className: 'btn-primary'
                }
            },
            callback: function (result) {
                var assessmentBarrierId = $(target).attr('data-id');
                if(result){
                    $.post('{{ route("assessment_barrier_delete") }}', {id: assessmentBarrierId}, function(response) {
                        handleMessages(response, 'barrier_status', true);
                        fadeOutAlertMessages();

                        var current_page = $(".barrier_pagination .pagination").find('.active').text();
                        if($('.barrier_list table tbody tr').length == 1) {
                            current_page = current_page-1;
                            if(current_page == 0) {
                                current_page = 1;
                            }
                        }
                        var url = "{{ url('patients/assessment/barriers/list?assessment_id=') }}"+$('[name="assessment_id"]').val()+'&page='+current_page;
                        loadBarrierListing(url);
                    }, 'json');
                }
            }
        });
    }

    function viewBarrier(target)
    {
        var barrierId = $(target).attr('data-id');
        $.get('{{ route("assessment_barrier_by_id") }}?id='+barrierId, function(response){
            $('#barrierOverlay .barrier-view').html(response.html)
            handleMoreInfo();
            $('#barrierOverlay').addClass('show-overlay');
        },'json');
    }

    function closeBarrierDetailSidebar() {
        $(".inner-slide").addClass("slideOutRight");
        setTimeout(function () {
            $(".sidebox-overlay").removeClass("show-overlay");
            $("body").removeClass("hideout");
            $(".inner-slide").removeClass("slideOutRight");
        }, 1000);
    }

    handleBarrierPagination();

    function previousTab(){
        $('#v-pills-tab a[data-type="priority_alignment"]').click();
    }

    function nextTab(){
        if($('select[name="barrier_id"]').val() != '' && $('select[name="barrier_id"]').length == 1) {
            bootbox.alert('Add the selected barrier.');
        } else {
            $('#v-pills-tab a[data-type="vitals"]').click();
        }

    }

    applpyEllipses('care-table', 4, 'no');

    function saveBarriers(is_save) {

         if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="progress_notes"]').click();
           return false;
          }

        if(is_save == '1'){

            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }

         if($('select[name="barrier_id"]').val() != '' && $('select[name="barrier_id"]').length == 1) {
                
                 $.ajaxSetup({
                  type:"POST",
                  headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
                  beforeSend:function(){
                    //  $('.loader_div').waitMe();
                  },
                  complete:function(){
                      $('.loader_div').waitMe('hide');
                      
                  },
                  error:function(error){
                  }
                });
                var assessmentId = $('[name="assessment_id"]').val();
                var barrierId = $('[name="barrier_id"]').val();
                var patientId = $('[name="patient_id"]').val();
                var careplanId = $('[name="careplan_id"]').val();

                $.ajax({
                    url: "{{ route('assessment_barrier_add') }}",
                    data: {barrier_id: barrierId[0], assessment_id: assessmentId, patient_id: patientId, careplan_id: careplanId},
                    type: 'POST',
                    dataType: "json",
                    success: function(response){
                        $('.barrier_list').html(response.html);
                        applpyEllipses('barrier_list', 3, 'no');
                        $('select[name="barrier_id"]').val('');
                        $('select[name="barrier_id"] option[value="'+barrierId[0]+'"]').remove();
                        $('#select_chosen_barrier').trigger('change');
                        $('#select_chosen_barrier').trigger("chosen:updated");
                        handleBarrierPagination();

                        handleMessages(response, 'barrier_status', true);
                        fadeOutAlertMessages();
                        applpyEllipses('care-table', 4, 'no');
                        if(is_save == '1'){
                          saveAssessment();
                        }

                    },
                    error: function(error) {
                        $.each(error.responseJSON.errors,function(key,value){
                            $('select[name="'+key+'"]').parent().find('span.error').show().text(value);
                        });
                    }
                })


              } else {
                    if(is_save == '1'){
                      saveAssessment();
                    }
            }

          
        
         
    }
</script>