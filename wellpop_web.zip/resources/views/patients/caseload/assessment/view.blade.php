@extends('layouts.app')
@section('css')
    <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection
@section('title')
{{ trans('label.view_patient') }}
@endsection
@section('content')

<div class="leftsectionpages">
   <div class="row bread-head">
      <div class="col-md-9">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.case_loads') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.care_plan') }}
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.view_assessment') }}
         </div>
      </div>

    <div class="col-md-3">
           <div class="buttonsbottom view-plan-btn "> <a href="{{ Request::server('HTTP_REFERER') }}/#assessment" class="next backi"><i class="fa fa-angle-left"> </i>&nbsp; Back</a> </div>
    </div>
     
   </div>
   <div class="">
      <div class="patient-view pat-show case-main-wrap">
        @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>true])
         <input type="hidden" name="patient_id" value="{{ encrypt_decrypt('encrypt',$patient['patient_info']->id) }}">
         <input type="hidden" name="careplan_id" value="{{ encrypt_decrypt('encrypt', $assessment->careplan_id) }}">
         <input type="hidden" name="assessment_id" value="{{ encrypt_decrypt('encrypt', $assessment->id) }}">

         <!--              <div class="expandy-accord"> <a class="closeall btn btn-main" accordion-id="#accordionExample">Collapse All</a> <a class="openall btn btn-main" accordion-id="#accordionExample">Expand All</a> </div>-->
         <div class="assess-main">
            <div class="row">
               <div class="col-md-3 col-lg-2">
                 @include('patients.caseload.assessment.sidebar')  
               </div>
               <div class="col-md-9 col-lg-10">
                  <div class="tab-content assess-content loader_div" id="v-pills-tabContent">
                     @include('patients.caseload.assessment.purpose',['is_view' => 1])
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@section('modal_box')
@endsection
@section('script')
@include('layouts.route_name')
<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/caseloads/care_plan.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/caseloads/case_load.js') }}" type="text/javascript"></script> 

<script type="text/javascript">
$.ajaxSetup({
  type:"POST",
  headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
  beforeSend:function(){
      $('.loader_div').waitMe();
  },
  complete:function(){
      $('.loader_div').waitMe('hide');
      applpyEllipses('dataTable', 5, 'no');
  },
  error:function(error){
  }
});
 

// function to click on side bar to load the relative tab
$('body').on('click', '.assess-main .nav-link', function(e) {
     e.preventDefault();

        if($(this).hasClass('active')) {
            return false;
        }

        var type = $(this).data('type');
        var assessmentId = $('[name="assessment_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var patientId = $('[name="patient_id"]').val();

         $.ajax({
            url:"{{ route('patient_assessment_detail_tab', [encrypt_decrypt('encrypt',$patient['patient_info']->id)]) }}",
            type: "GET",
            dataType: "json",
            data: {tab:$(this).data('type'),assessment_id:assessmentId, careplan_id:careplanId, patient_id:patientId,is_view:1},
            success:function(response){
              $('#v-pills-tabContent').html(response.data.html);
  //            $('.asess-btnbox').remove();
              $('.main-head-box').remove();
              $('.barrier-search').remove();
              $(":input").prop("disabled", true);
              $('.goal_review_btn').prop("disabled", false);
              $('.select-flag').remove();
              $('.view_assessment_goal_btn').remove();
              $('textarea').each(function(){
                var $this = $(this);
                $this.replaceWith("<p class='p_font'>" + $this.text() + "</p>");
              });

                $('.asess-btnbox button').prop("disabled", false);
                $('.fa-trash-alt').remove();
              initCustomForms();
              $('.jcf-select').parent().addClass('edit_select')
           },error:function(error) {
                    if(error.status == 500){
                        $('.modal-body').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>Internal Server Error</div>')
                    }
                    else if(error.status == 404){
                        $('.leftsectionpages').prepend('<div class="alert alert-danger alert-dismissible" style="display: block;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>NOT FOUND</div>')
                    }
                    else if(error.status == 403){
                        $('#v-pills-tab a').not(':first').removeClass('active');
                        $('#v-pills-tab a:first').addClass('active');
                    }
            }
        });
   
});

//$('.asess-btnbox').remove();
$('#v-pills-tab a').removeClass('not_assigned');
$(":input").prop("disabled", true);
$('.asess-btnbox button').prop("disabled", false);
initCustomForms();
              $('.jcf-select').parent().addClass('edit_select')
</script>
@endsection