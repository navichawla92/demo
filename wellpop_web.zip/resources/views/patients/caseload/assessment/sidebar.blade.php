 <div class="nav flex-column nav-pills left-bar" id="v-pills-tab" data-type="team" role="tablist" aria-orientation="vertical"> 
   <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" data-type="purpose" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
     {{ trans('label.purpose') }}*  <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-profile-tab" data-toggle="pill" data-type="goal_review" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
      {{ trans('label.goals_review') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-messages-tab" data-toggle="pill"  data-type="content_discussed" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
      {{ trans('label.content_discussed') }} <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-settings-tab" data-toggle="pill" data-type="priority_alignment" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
      {{ trans('label.priority_alignment') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Barriers-tab" data-toggle="pill" data-type="barriers" href="#v-pills-Barriers" role="tab" aria-controls="v-pills-Barriers" aria-selected="false">
      {{ trans('label.barriers') }}  <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Vitals-tab" data-toggle="pill" data-type="vitals" href="#v-pills-Vitals" role="tab" aria-controls="v-pills-Vitals" aria-selected="false">
      {{ trans('label.vitals') }} <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Risk-tab" data-toggle="pill" data-type="risk_assessment" href="#v-pills-Risk" role="tab" aria-controls="v-pills-Risk" aria-selected="false">
      {{ trans('label.risk_assessment') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Intervention-tab" data-toggle="pill" data-type="intervention" href="#v-pills-Intervention" role="tab" aria-controls="v-pills-Intervention" aria-selected="false">
      {{ trans('label.intervention') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
   <a class="nav-link not_assigned" id="v-pills-Progress-tab" data-toggle="pill" data-type="progress_notes" href="#v-pills-Progress" role="tab" aria-controls="v-pills-Progress" aria-selected="false">
      {{ trans('label.progress_notes') }}* <i class="fa fa-check-circle chk-green chk-hide"></i>
   </a>
</div>