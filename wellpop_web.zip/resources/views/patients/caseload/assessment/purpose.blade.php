<div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <h4 class="assess-head">{{ trans('label.purpose') }}</h4>
      <span class="error alert alert-danger" id="careplan_status" style="display: none;"></span>
    <div class="care-box">

      

        @if(!@$assessment)
            @inject('assessment', 'App\Models\CareplanAssessment')
        @endif

        {!! Form::model($assessment,['id' => 'purposeForm', 'files' => true]) !!}
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label>{{ trans('label.purpose') }}</label>
                    {!! Form::select('purpose', get_manageable_fields('careplan_assessment_purpose'), $assessment->purpose, ['class' => 'status_filter customselect']) !!}
                    <span class="error" style="color: red; display: none;"></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>{{ trans('label.via') }}</label>
                    {!! Form::select('via', get_manageable_fields('careplan_assessment_via'), $assessment->via, ['class' => 'status_filter customselect']) !!}
                    <span class="error" style="color: red; display: none;"></span>
                </div>
            </div>
            <div class="col-md-4">
                @if($assessment->assessment_date)
                <p class="show-time">{{ $assessment->assessment_date_time }}</p>
                @else
                <p class="show-time date_time"></p>
                @endif
            </div>
            <input type="hidden" name="tab_name" value="purpose">

            
        </div>
        {!! Form::close() !!}

    </div>


    @if(@$is_view || app('request')->input('is_view',0))
        <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn" onClick="nextTab();">Next</button>
        </div>
        @else
        <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn" onClick="savePurpose(0);">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="savePurpose(2);">{{ trans('label.save') }}</button>
        </div>
    @endif
</div>

<script>

    function savePurpose(is_save) {
        if(is_save == '1'){
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                //  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }
        var patientId = $('[name="patient_id"]').val();
        var careplanId = $('[name="careplan_id"]').val();
        var assessmentId = $('[name="assessment_id"]').val();

        var formData = new FormData($('#purposeForm')[0]);
        formData.append('patient_id', patientId)
        formData.append('careplan_id', careplanId);
        formData.append('assessment_id', assessmentId);

        $.ajax({
            url: '{{ route('patient_assessment_purpose_save') }}',
            data: formData,
            dataType:'JSON',
            contentType: false,
            processData: false,
            success: function(response) {
                $('[name="assessment_id"]').val(response.assessment_id);
                $('[name="careplan_id"]').val(response.careplan_id);
                $('#v-pills-tab a').removeClass('not_assigned');
                $('input,textarea,select').removeClass('changed-input');
                $('#v-pills-tab a[data-type="purpose"]').removeClass('text-red');
                
                $('[name="is_save"]').val(1);
                if(is_save != '2'){
                   $('#v-pills-tab a[data-type="goal_review"]').click();
                }
                $('#v-pills-tab a[data-type="purpose"]').find('i').removeClass('chk-hide');
                if(is_save == '1'){
                    saveAssessment();
                }

            },
            error: function(errors) {
                $.each(errors.responseJSON.errors,function(key,value){
                    if(key == 'careplan_status'){
                        $('#'+key).html(value).addClass('active').show();
                    }
                    else {
                        $('[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                    }
                    
                });
                if(is_save == '1'){
                    saveAssessment();
                }
            }
        })


    }

    function nextTab()
    {
        $('#v-pills-tab a[data-type="goal_review"]').click();
    }
</script>