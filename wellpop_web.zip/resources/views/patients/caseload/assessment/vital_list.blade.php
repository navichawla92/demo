<table class="table">
   <thead>
      <tr>
         <th>{{ trans('label.serial_number_short_form') }}</th>
         <th>{{ trans('label.date_measured') }}</th>
         <th>{{ trans('label.weight') }}</th>
         <th>{{ trans('label.aic') }}</th>
         <th>{{ trans('label.blood_pressure') }}</th>
         <th>{{ trans('label.pulse') }}</th>
      </tr>
   </thead>


   <tbody>
      @if($vitals->total())
         @php
            $i = ($vitals->currentPage() - 1) * $vitals->perPage() + 1;
         @endphp
         @foreach($vitals as $vital)
            <tr>
               <td>{{ $i }}</td>
               <td>{{ $vital->created_at }}</td>
               <td>{{ $vital->weight }}</td>
               <td>{{ $vital->a1c }}</td>
               <td>{{ $vital->blood_pressure_high }}/{{ $vital->blood_pressure_low }}</td>
               <td>{{ $vital->pulse }}</td>
            </tr>
            @php
               $i++;
            @endphp
         @endforeach
      @else
         <tr>
            <td colspan="6">No records found!</td>
         </tr>
      @endif

   </tbody>
</table>


<div class="vital_pagination">
   {{ $vitals->links() }}
</div>