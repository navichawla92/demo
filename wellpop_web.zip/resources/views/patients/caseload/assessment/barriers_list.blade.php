 <table class="table">
   <thead>
      <tr>
         <th>{{ trans('label.serial_number_short_form') }}</th>
         <th>{{ trans('label.date_added') }}</th>
         <th>{{ trans('label.barrier_title') }}</th>
         <th>{{ trans('label.action') }}</th>

      </tr>
   </thead>
   <tbody>

      @if($assessmentBarriers->total())
         @php
            $i = ($assessmentBarriers->currentPage() - 1) * $assessmentBarriers->perPage() + 1;
         @endphp
         @foreach($assessmentBarriers as $key => $assessmentBarrier)
            <tr>
               <td>{{ $i }}</td>
               <td>{{ $assessmentBarrier->created_at }}</td>
               <td>{{ $assessmentBarrier->barrier->title }}</td>
               <td>
                  @if($is_careplan)
                  <a class="dropdown-item barrier-detail" data-id="{{ encrypt_decrypt('encrypt',$assessmentBarrier->barrier->id) }}" onclick="viewBarrier(this)"><i class="fa fa-eye"></i> </a>
                  @else
                  <div class="dropdown more-btn dropup" style="position: static;">
                     <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>...</span> </button>
                     <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                        <a class="dropdown-item barrier-detail" data-id="{{ encrypt_decrypt('encrypt',$assessmentBarrier->barrier->id) }}" onclick="viewBarrier(this)"><i class="fa fa-eye"></i> View Details</a>
                        <a class="dropdown-item" data-id="{{ encrypt_decrypt('encrypt',$assessmentBarrier->id) }}" onclick="deleteBarrier(this)"><i class="fa fa-times"></i> Remove Barrier</a>
                     </div>
                  </div>
                  @endif
               </td>
            </tr>
            @php
               $i++;
            @endphp
         @endforeach
      @else
         <tr>
            <td colspan="4">No records found!</td>
         </tr>
      @endif


   </tbody>
</table>

 <div class="barrier_pagination">
     {{ $assessmentBarriers->links() }}
 </div>