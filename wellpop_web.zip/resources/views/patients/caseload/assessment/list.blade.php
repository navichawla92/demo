<table class="table">
            <thead>
              <tr>
                  <th>Sr. No.</th>
                  <th>Assessment ID</th>
                  <th>Assessment Date</th>
                  @if(!$is_careplan)
                  <th>Care Plan ID</th>
                  @endif
                  <th>Assessment By</th>
                  <th>Role</th>
                  <th>Interventions</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>

                @if(count($assessmentList))
               <?php  $index=($assessmentList->perPage() * ($assessmentList->currentPage()- 1))+1; ?>
               <?php  $i = 0;?>
                @foreach($assessmentList as $assessment)

                 <tr>
                  <td>{{ $index }}</td>
                  <td>{{ $assessment->code }}</td>
                  <td>{{ $assessment->assessment_date }}</td>
                   @if(!$is_careplan)
                  <td>{{ $assessment->careplan->code }}</td>
                  @endif
                  <td>{{ $assessment->user->name }}</td>
                  <td>{{ $assessment->userRole->name }}</td>
                  <td> {!! $assessment->intervention->flag_name !!} </td>
                  <td>
                    @if(!$is_careplan)
                      <div class="dropdown more-btn dropup">
                          <button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>...</span> </button>
                          <div class="dropdown-menu " aria-labelledby="dropdownMenu2">
                              <a class="dropdown-item"  href="{{ route('patient_assessment_view', [encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', $assessment->id)]) }}"><i class="fa fa-eye"></i> View Assessment</a>
                              @if($activeCarePlan && $assessment->careplan->id == $activeCarePlan->id)
                              <a class="dropdown-item" data-patient_id="{{encrypt_decrypt('encrypt', $patient->id)}}"  data-assessment_id="{{ encrypt_decrypt('encrypt',$assessment->id) }}" onclick="copyAssessment(this)"><i class="fa fa-recycle"></i> Copy Assessment</a>
                              @endif
                             


                          </div>
                      </div>
                      @else
                      <a class="dropdown-item"  href="{{ route('patient_assessment_view', [encrypt_decrypt('encrypt', $patient->id),encrypt_decrypt('encrypt', $assessment->id)]) }}"><i class="fa fa-eye"></i> </a>
                      @endif
                  </td>
                 </tr>
                <?php  $index++; ?>
               @endforeach

                @else
               <tr><td>{{ trans('label.no_record_found') }}</td></tr>
               @endif
            </tbody>
</table>
<?php echo $assessmentList->render(); ?>


<script>
    function copyAssessment(target)
    {
        var assessmentId = $(target).attr('data-assessment_id');
        var patientId = $(target).attr('data-patient_id');

        $.post('{{ route('patient_assessment_copy') }}', {
            patient_id: patientId,
            assessment_id: assessmentId
        }, function (response) {
            window.location.href = response.redirectUrl;
        }, 'json');

    }
</script>
