<div class="tab-pane fade active show" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
   <h4 class="assess-head">Priority Alignment</h4>
   @if($data['questions'] && $data['questions']->count())
   <div class="care-box">
      <form action="javascript:;" method="post" id="priorityAlignmentForm">
         @php
         $questionCount = 1;
         @endphp
         @foreach($data['questions'] as $question)
         <div class="qus-box">
            <div class="row">
               <div class="col-md-12 col-lg-6">
                  <p><span class="ques">Ques.{{ $questionCount }}</span>{{ $question->description }}</p>
               </div>
               <div class="col-md-12 col-lg-6 inner-option">
                  <ul class="two-opt low-opt questions_{{$question->id}}_value">
                     @if($question->metric->name == 'Scale' || $question->metric->name == 'Binary')
                     <?php $values = $question->metric->getValueArray(); ?>
                     @foreach($values as $key => $value)
                     <li>
                        <input type="radio" id="question_{{$question->id}}_{{$key}}" name="questions[{{$question->id}}][value]" value="{{$value}}" @if($question->getAnswer() == $value) checked @endif>
                        <label for="question_{{$question->id}}_{{$key}}">{{$value}}</label>
                     </li>
                     @endforeach
                      <span class="error" style="color:red"></span> 
                     @endif
                  </ul>
               </div>
            </div>
         </div>
         @php
         $questionCount++;
         @endphp
            <input type="hidden" name="questions[{{$question->id}}][temp]">
         @endforeach
         <input type='hidden' name="valid" value="{{$data['validation']}}">
         <input type='hidden' name="item_type" value="priority_alignment">
         <input type="hidden" name="tab_name" value="priority_alignment">
      </form>
   </div>


      @if(app('request')->input('is_view',0))
         <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
         </div>
      @else
         <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn" onClick="savePriorityAlignment(0);">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="savePriorityAlignment(2);">{{ trans('label.save') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">{{ trans('label.previous') }}</button>
         </div>
      @endif


   @endif
</div>
<script>
   function savePriorityAlignment(is_save) {
    
       if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="barriers"]').click();
           return false;
       }

        if(is_save == '1'){
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');

              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');

              },
              error:function(error){
              }
            });

        }

       var patientId = $('[name="patient_id"]').val();
       var assessmentId = $('[name="assessment_id"]').val();
       var formData = new FormData($('#priorityAlignmentForm')[0]);
        $("span.error").html('').hide();
       formData.append( 'patient_id',patientId);
       formData.append( 'assessment_id',assessmentId);
 
        
        $.ajax({
               url:"{{ route('patient_assessment_question_save') }}",
               type:"POST",
               data:formData,
               processData: false,
               contentType: false,
               dataType: "json",
                success:function(data){
                    $('input,textarea,select').removeClass('changed-input');
                    $('#is_anything_change').val('');
                    $("span.error").text('');
                    $('input,textarea,select').removeClass('changed-input');
                    //$('#v-pills-tab a[data-type="barriers"]').click();
                    $('#v-pills-tab a[data-type="priority_alignment"]').removeClass('text-red');
                    $('#v-pills-tab a[data-type="priority_alignment"]').find('i').removeClass('chk-hide');
                    $('[name="is_save"]').val(1);
                    if(is_save == '1'){
                      saveAssessment();
                    }
                    if(is_save == '0'){
                      $('#v-pills-tab a[data-type="barriers"]').click();
                    }
                   
                },
                error:function(error){
                    $.each(error.responseJSON.errors,function(key,value){
                        var element = key.replace(/\./g, '_');
                        $('.'+element).find('span.error').show().text(value);
                        console.log($('.' + element).html());
                    });
                    if(is_save == '1'){
                      saveAssessment();
                    }
               }
      });
   }


   function previousTab(){
       $('#v-pills-tab a[data-type="content_discussed"]').click();
   }

   function nextTab(){
       $('#v-pills-tab a[data-type="barriers"]').click();
   }
   
</script>