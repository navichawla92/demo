<div class="tab-pane fade active show" id="v-pills-Risk" role="tabpanel" aria-labelledby="v-pills-Risk-tab">
   <h4 class="assess-head">Risk Assessment</h4>
   @if($data['questions'] && $data['questions']->count())
    <form action="javascript:;" method="post" id="riskAssessmentForm">
      <div class="care-box">
         @foreach($data['questions'] as $question)
         <div class="qus-box risk-ques">
            <div class="row">
               <div class="col-md-12 col-lg-5">
                  <p>{{ $question->description }}</p>
               </div>
               <div class="col-md-6 col-lg-5 inner-option">
                  @if($question->metric->name == 'Scale' || $question->metric->name == 'Binary')
                  <ul class="two-opt low-opt questions_{{$question->id}}_value">
                     <?php $values = $question->metric->getValueArray(); ?>
                     @foreach($values as $key => $value)
                     <li>
                        <input type="radio" id="question_{{$question->id}}_{{$key}}" name="questions[{{$question->id}}][value]" value="{{$value}}" @if($question->getAnswer() == $value) checked @endif>
                        <label for="question_{{$question->id}}_{{$key}}">{{$value}}</label>
                     </li>
                     @endforeach
                     <span class="error" style="color:red"></span>
                  </ul>
                  @endif
                  @if($question->metric->name == 'Note')
                  <div class="textfieldglobal questions_{{$question->id}}_value">
                     <input maxlength="3" name="questions[{{$question->id}}][value]" type="text" value="{{ $question->getAnswer() }}" placeholder="No. of active medication">
                     <span class="error" style="color:red"></span>
                  </div>
                  @endif
               </div>
               @if($question->no_of_visits)
               <div class="col-md-6 col-lg-2 inner-option questions_{{$question->id}}_visit">
                  <div class="textfieldglobal">
                     <input maxlength="3" name="questions[{{$question->id}}][visit]" type="text" value="{{ $question->getVisits() }}" placeholder="No. of visits">
                     <span class="error" style="color:red"></span>
                  </div>
               </div>
               @endif
            </div>
         </div>
            <input type="hidden" name="questions[{{$question->id}}][temp]">
         @endforeach

         <input type='hidden' name="valid" value="{{$data['validation']}}">
         <input type='hidden' name="item_type" value="risk_assessment">
         <input type="hidden" name="tab_name" value="risk_assessment">
      </div>
   </form>




      @if(app('request')->input('is_view',0))
         <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn" onclick="nextTab()">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
         </div>
      @else
         <div class="asess-btnbox">
            <button class="btn btn-primary basic-btn"  onClick="saveRiskAssessment(0);">{{ trans('label.next') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="saveRiskAssessment(2);">{{ trans('label.save') }}</button>
            <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">{{ trans('label.previous') }}</button>
         </div>
      @endif

   @endif
</div>
<script>
   function saveRiskAssessment(is_save) {

        if(is_save == 0 && $('.changed-input').length == 0) {
           $('#v-pills-tab a[data-type="intervention"]').click();
           return false;
        }

        if(is_save == '1'){
            console.log('here');
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                 // $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }
       var patientId = $('[name="patient_id"]').val();
       var assessmentId = $('[name="assessment_id"]').val();
       var formData = new FormData($('#riskAssessmentForm')[0]);
       $("span.error").text('');
        formData.append( 'patient_id',patientId);
        formData.append( 'assessment_id',assessmentId);

        $.ajax({
               url:"{{ route('patient_assessment_question_save') }}",
               type:"POST",
               data:formData,
               processData: false,
               contentType: false,
               dataType: "json",
                success:function(data){
                    $('input,textarea,select').removeClass('changed-input');
                    $('#is_anything_change').val('');
                    $("span.error").text('');
                    $('input,textarea,select').removeClass('changed-input');
                    //$('#v-pills-tab a[data-type="intervention"]').click();
                    $('#v-pills-tab a[data-type="risk_assessment"]').removeClass('text-red');
                    $('#v-pills-tab a[data-type="risk_assessment"]').find('i').removeClass('chk-hide');
                    $('[name="is_save"]').val(1);

                    if(is_save == '1'){
                      saveAssessment();
                    }
                    if(is_save == '0'){
                      $('#v-pills-tab a[data-type="intervention"]').click();
                    }
                },
                error:function(error) {
                   $.each(error.responseJSON.errors,function(key,value){
                       var element = key.replace(/\./g, '_');
                       $('.'+element).find('span.error').show().text(value);
                       console.log($('.' + element).html());
                   });
                   if(is_save == '1'){
                    saveAssessment();
                   }
                }
      });

   }

   function previousTab(){
       $('#v-pills-tab a[data-type="vitals"]').click();
   }

   function nextTab()
   {
       $('#v-pills-tab a[data-type="intervention"]').click();
   }

</script>