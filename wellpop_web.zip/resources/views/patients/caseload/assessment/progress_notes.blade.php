 <div class="tab-pane fade active show" id="v-pills-Progress" role="tabpanel" aria-labelledby="v-pills-Progress-tab">
	<h4 class="assess-head">{{ trans('label.progress_notes') }}</h4>
    <div id="save_notes">
                <div class="alert alert-danger hide">
                    <div class="alert-message"></div>
                </div>
    </div>

	 <form action="javascript:;" method="post" id="addProgressNoteForm">
		 <div class="care-box">
			 <textarea class="form-control" maxlength="10000" name="progress_notes" placeholder="Enter your notes here">{{ $assessment->overall_notes }}</textarea>
			 <span class="error" style="color:red;"></span>
		 </div>

		 @if(app('request')->input('is_view',0))
			 <div class="asess-btnbox">
				 <button class="btn btn-primary basic-btn button_margin_right" onClick="previousTab();">Previous</button>
			 </div>
		 @else
			 <div class="asess-btnbox">
				 <button class="btn btn-primary basic-btn" onclick="saveProgress('2');">{{ trans('label.save') }}</button>
				 <button class="btn btn-primary basic-btn button_margin_right"  onClick="previousTab();">{{ trans('label.previous') }}</button>
			 </div>
		 @endif
		 <input type="hidden" name="tab_name" value="progress_notes">

	 </form>
</div>

<script>
	 function saveProgress(is_save)
	 {     
        if(is_save == '1'){
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                //  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });
        }
        else{
            $.ajaxSetup({
              type:"POST",
              headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              beforeSend:function(){
                  $('.loader_div').waitMe();
              },
              complete:function(){
                  $('.loader_div').waitMe('hide');
                  
              },
              error:function(error){
              }
            });

        }
         var assessmentId = $('[name="assessment_id"]').val();
         var formData = new FormData($('#addProgressNoteForm')[0]);
         $("span.error").html('').hide();
         formData.append( 'assessment_id',assessmentId);

         $.ajax({
             url: "{{ route('assessment_progress_note_add') }}",
             type: 'POST',
             data:formData,
             processData: false,
             contentType: false,
             dataType: "json",
             success: function(response){
                 $('span.error').text('');
                 $('input,textarea,select').removeClass('changed-input');
                 $('#v-pills-tab a[data-type="progress_notes"]').removeClass('text-red');
                 $('#v-pills-tab a[data-type="progress_notes"]').find('i').removeClass('chk-hide');

                 $('[name="is_save"]').val(1);
                 handleMessages(response, 'save_notes', true);
                 fadeOutAlertMessages();
                if(is_save == '1'){
                    saveAssessment();
                }
             },
             error: function(error) {
                 $.each(error.responseJSON.errors,function(key,value){
                     $('textarea[name="'+key+'"]').parent().find('span.error').show().text(value);
                 });
                 if(is_save == '1'){
                    saveAssessment();
                 }
             }
            
         })
	 }

     function previousTab() {
      $('#v-pills-tab a[data-type="intervention"]').click();
    }
</script>


