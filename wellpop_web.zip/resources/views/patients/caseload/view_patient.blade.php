@extends('layouts.app')

@section('css')
   <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
@endsection

@section('title')
    {{ trans('label.view_patient') }}
@endsection

@section('content')

   <div class="leftsectionpages">
      <div class="patient-view pat-show case-main-wrap">
         <div class="patient_header_section message_data1">
            @include('patients.caseload.sections.header-patient-info', ['patient' => $patient['patient_info'],'is_form'=>false])
         </div>
         <div class="expandy-accord">
            <a class="closeall btn btn-main" accordion-id="#accordionExample">{{ trans('label.collapse_all') }}</a>
            <a class="openall btn btn-main" accordion-id="#accordionExample">{{ trans('label.expand_all') }}</a>
         </div>
         <div class="caseload-spybox">
            <div id="maindiv">
               <div class="clear">
                  <div class="row">
                     <div class="col-md-3 col-lg-2">
                        <div id="sidebar">
                           <div id="checkdiv"></div>
                           <nav class="">
                              <ul>
                                 <li><a href="#profile" class="active">{{ trans('label.profile') }} </a></li>
                                 <li><a href="#team">{{ trans('label.care_team') }} </a></li>
                                 <li><a href="#insurance">{{ trans('label.insurance_payer') }} </a></li>
                                 <li><a href="#release">{{ trans('label.releases') }}  </a></li>
                                 <li><a href="#initial">{{ trans('label.initial_assessment') }} </a></li>
                                 <li><a href="#plan">{{ trans('label.care_plan') }}  </a></li>
                                 <li><a href="#medication">{{ trans('label.medications') }}  </a></li>
                                 <li><a href="#allergy">{{ trans('label.allergies_list') }}  </a></li>
                                 <li><a href="#assessment">{{ trans('label.assessments') }}  </a></li>
                                 <li><a href="#checkpoint">{{ trans('label.checkpoints') }}  </a></li>
                                 <li><a href="#intervention">{{ trans('label.interventions') }} </a></li>
                                 <!--
                                    <li><a href="#review">Reviews</a></li>
                                    <li><a href="#timeline">Timeline</a></li>
                                    <li><a href="#dashboard">Patient Dashboard</a></li>
                                    <li><a href="#summary">Care Summary</a></li>
                                    <li><a href="#discharge">Discharge</a></li>
                                    -->
                              </ul>
                           </nav>
                        </div>
                        <!-- sidebar div end -->
                     </div>
                     <div class="col-md-9 col-lg-10">
                        <div id="content">
                           <div class="accordion" id="accordionExample">

                              <section id="profile" class="profile_section">
                                 @include('patients.caseload.sections.patient_profile_details', ['patient' => $patient['patient_info']])
                              </section>

                              @include('patients.caseload.sections.wellpop_care_team', ['patient' => $patient['patient_info'], 'otherContacts' => $patient['patient_other_info']['otherContacts']])

                              <section id="insurance">
                                 @include('patients.caseload.sections.insurance', ['patient' => $patient['patient_info'], 'insurance' => $patient['patient_other_info']])
                              </section>

                              <section id="release">
                                 @include('patients.caseload.sections.release_forms', ['patient' => $patient['patient_info'],'patientConsentForm' => $patientConsentForm])
                              </section>
                              <section id="initial">
                                 @include('patients.caseload.sections.initial_assessments', ['patient' => $patient['patient_info']])
                              </section>
                              <section id="plan">
                                  @include('patients.caseload.sections.care_plan',['patient' => $patient['patient_info'],'carePlanList' => $carePlanList])
                              </section>
                              <section id="medication">
                                 @include('patients.caseload.sections.medication_listing',['patient' => $patient['patient_info']])
                              </section>
                              <section id="allergy">
                                 @include('patients.caseload.sections.allergy_listing',['patient' => $patient['patient_info']])
                                
                              </section>
                              <section id="assessment">
                                 @include('patients.caseload.sections.care_plan_assessments',['patient' => $patient['patient_info'],'assessmentList'=>$assessmentList,'activeCarePlan'=>$activeCarePlan])
                              </section>
                              <section id="checkpoint">
                                  @include('patients.caseload.sections.checkpoints',['patient' => $patient['patient_info'],'checkpointList'=>$checkpointList,'activeCarePlan'=>$activeCarePlan])
                              </section>
                              <section id="intervention">
                                 @include('patients.caseload.sections.intervention',['patient' => $patient['patient_info'],'interventionList'=>$interventionList])
                              </section>
                           </div>
                           <!-- contain div end -->
                        </div>
                     </div>
                  </div>
                  <!-- container div end -->
               </div>
               <!-- maindiv end -->
            </div>
         </div>
      </div>
   </div>
   <a id="goTop"><i class="fa fa-arrow-up"></i></a>
   
   @include('patients.caseload.edit_patient_assignments_modal',['patient' => $patient['patient_info'], 'careTeam' => $careTeam])

   <div class="modal fade" id="editPatient" tabindex="-1" role="dialog" aria-labelledby="editPatientLabel" aria-hidden="true">
      <div class="edit_patient_modal">
         @include('patients.caseload.edit_patient_info_modal', ['patient' => $patient['patient_info']])
      </div>
   </div>

@endsection
@section('modal_box')
  
<!--historysidebox  -->
<div class="sidebox-overlay" id="medicationHistoryOverlay"></div>
<div class="sidebox-overlay" id="allergyHistoryOverlay"></div>

@endsection
@section('script')
@include('layouts.route_name')
<script src="{{ asset('js/caseloads/care_plan.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/caseloads/case_load.js') }}" type="text/javascript"></script> 

<script>
$(document).on('hidden.bs.modal', '#editPatient',function () {
  $('span.error').hide().removeClass('active');
  document.getElementById("patient-info-form").reset();
       var image = "{{ $patient['patient_info']->image}}";
       if(image != ''){

       }
       else{
           $('.patient-info-pro-pic-upload').show();
           $('.patient_pro_pic_preview span.imgcross').hide();
       }
       $('.patient_pro_pic_preview img').attr('src',"{{ $patient['patient_info']->image ? config('filesystems.s3_patient_images_full_path').$patient['patient_info']->id.'/'.$patient['patient_info']->image :  asset('images/noimage.jpg') }}");
   })

     //patient profile image remove on cross click code
     $(document).on('click','.patient_pro_pic_preview span.imgcross',function(){
         $('input[type=hidden][name=upload_image_or_not]').val('yes');
         $('input[type=file][name=image]').val('');
         $('.patient_pro_pic_preview img').attr('src',"{{ asset('images/noimage.jpg') }}");
         $('.patient_pro_pic_preview span.imgcross').hide();
         $('.patient-info-pro-pic-upload').show();
         $('#invalid_image_error').html('').removeClass('active');
     });

      $(document).on('hidden.bs.modal', '.md_assessment_data',function () {
        $('input,textarea,select').removeClass('changed-input');
        $('.md_assessment_data').find('form').trigger('reset');
        $('span.error').hide().removeClass('active');
      });
</script>
@endsection

