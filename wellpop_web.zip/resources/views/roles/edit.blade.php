@extends('admin.layouts.app')

@section('title', '| Edit Privilege')

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="{{ URL::to('privileges') }}">All Privileges</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Edit Privilege</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          @if(session()->has('message.level'))
              <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                {!! session('message.content') !!}
              </div>
          @endif  
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-body form">
                        {{ Form::model($role, array('route' => array('privileges.update', $role->id), 'method' => 'PUT')) }}
                            <div class="form-body">
                                <div class="form-group">
                                    {{ Form::label('name', 'Role Name',['class'=>'col-md-3 control-label']) }}
                                    <div class="col-md-9">
                                        {{ Form::text('name', null, array('class' => 'form-control input-inline input-medium','readonly' => '')) }}
                                        <span style="color:red;" class="error"></span>
                                    </div>
                                </div>
                                 @if ($errors->has('permissions'))
									<span class="invalid-feedback" role="alert">
										<strong>{{ $errors->first('permissions') }}</strong>
									</span>
								 @endif
                                <h5><b>Assign Permissions</b></h5>
                                @foreach ($permissions as $permission)

                                    {{Form::checkbox('permissions[]',  $permission->id, $role->permissions ) }}
                                    {{Form::label($permission->name, ucfirst($permission->name)) }}<br>

                                @endforeach
                                <br>
                                 
                            </div>
                            <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        {{ Form::submit('Update', array('class' => 'btn green')) }}
                                        <a href="{{ URL::to('privileges') }}" class="btn default">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>

@endsection
