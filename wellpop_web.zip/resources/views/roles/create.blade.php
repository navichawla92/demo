@extends('admin.layouts.app')

@section('title', '| Add Role')

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>My Profile</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          @if (count($errors) > 0)
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-body form">
                        {{ Form::open(array('url' => 'roles')) }}
                            <div class="form-body">
                                <div class="form-group">
                                    {{ Form::label('name', 'Name',['class'=>'col-md-3 control-label']) }}
                                    <div class="col-md-9">
                                        {{ Form::text('name', '', array('class' => 'form-control input-inline input-medium')) }}
                                        <span style="color:red;" class="error"></span>
                                    </div>
                                </div>

                                <div class='form-group'>
                                    {{ Form::label('permissions', 'Assign Permissions',['class'=>'col-md-12 control-label']) }}
                                    @foreach ($permissions as $permission)
                                        {{ Form::checkbox('permissions[]',  $permission->id ) }}
                                        {{ Form::label($permission->name, ucfirst($permission->name)) }}<br>
                                    @endforeach
                                </div>
                            </div>
                            <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        {{ Form::submit('Add', array('class' => 'btn green')) }}
                                        <a href="{{ route('login') }}" class="btn default">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection