<div class="rightlistbar non-print">
  <nav class="nav nav_main" id="nav">
    <div class="nav-holder" id="menu-drop">
      <ul>
        @role(CASEMANAGER)
          <li class="{{ ($active == 'patient_referral')?'active':'' }}" data-toggle="tooltip" ><a href="{{ route('patients') }}"><i class="fa fa-user-friends"></i><p>Patient Referrals</p></a></li>
          <li class="{{ ($active == 'patient_registrations')?'active':'' }}" data-toggle="tooltip" ><a href="{{ route('registrations') }}"><i class="fa fa-notes-medical"></i><p>Registration</p></a></li>
        @endrole
        @role(MANAGERDIRECTOR)
          <li class="{{ ($active == 'patient_registrations')?'active':'' }}" data-toggle="tooltip" ><a href="{{ route('md-registrations') }}"><i class="fa fa-notes-medical"></i><p>Registration</p></a></li>
        @endrole
        @role(COMMUNITYHEALTHWORKER)
          <li class="{{ ($active == 'patient_registrations')?'active':'' }}" data-toggle="tooltip" ><a href="{{ route('chw-registrations') }}"><i class="fa fa-notes-medical"></i><p>Registration</p></a></li>        
		    @endrole
        <li class="{{ ($active == 'case_load')?'active':'' }}" data-toggle="tooltip"><a href="{{ route('patient-caseload') }}"><i class="fa fa-file"></i><p>Case Loads</p></a></li>

        @if(Session::get('previous_patient_id'))
          <li class="{{ ($active == 'case_manager')?'active':'' }}"  data-toggle="tooltip" data-original-title="" title=""><a href="{{ route('caseload_patient_view', Session::get('previous_patient_id')) }}"><i class="fa fa-user-tie"></i>
          <p>Care Manager</p></a></li>
        @endif

        <li data-toggle="tooltip"><a href="javascript:void(0)"><i class="fa fa-calendar"></i><p>Calendars</p></a></li>
        <li data-toggle="tooltip" ><a href="javascript:void(0)"><i class="fa fa-bell"></i><p>Reminders</p></a></li>
        <li data-toggle="tooltip"><a href="javascript:void(0)"><i class="fa fa-clipboard-list"></i><p>Archived Records</p></a></li>
      </ul>
    </div>
  </nav>
</div>
