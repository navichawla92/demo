<script>
var care_team_update_route = "{{ route('update_careplan_team') }}";
var patient_update_route = "{{ route('patient-update') }}";
var registration_md_assessment_medication_save_route = "{{ route('registration_md_assessment_medication_save') }}";
var caseload_save_or_upload_medication_route = "{{ route('caseload_save_or_update_medication') }}";
var caseload_save_or_upload_allergy_route = "{{ route('caseload_save_or_update_allergy') }}";


const UPDATE_MEDICATION_STATUS_ROUTE = "{{ route('caseload_update_medication_status') }}";
const UPDATE_ALLERGY_STATUS_ROUTE = "{{ route('caseload_update_allergy_status') }}";

const UPDATE_CAREPLAN_STATUS_ROUTE = "{{ route('caseload_update_careplan_status') }}";

</script>
