<div class="headerpop non-print">
  <div class="row">
    <div class="col-3">
      <div class="logoheader"><a href="{{ route('login') }}"><img src="{{ asset('images/WellPopUpdatedEPS.png') }}" alt=""/></a></div>
    </div>
    <div class="col-9">
      <div class="rightsidetop">
        <div class="profilediv"> 
          <span class="profie-img">
            <img src="@if(Auth::user()->image) {{ config('filesystems.s3_user_images_full_path').Auth::id().'/'.Auth::user()->image }} @else {{ asset('images/dummy_user.png') }} @endif" alt=""/>
          </span>
          <div class="dropdown">
            <div class="contentnameheader dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{!! strlen(\Auth::user()->name) > 20 ? substr(\Auth::user()->name,0,20)."..." : \Auth::user()->name !!}</div>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="{{ route('my_profile',[Auth::user()->roles->pluck('name')[0]]) }}">My Profile</a> <a class="dropdown-item" href="{{ route('logout') }}">Logout</a> </div>
          </div>
        </div>
        <div class="notificationbell">
          <div class="bellicons"><img src="{{ asset('images/bell.png') }}"  alt=""/><span></span></div>
        </div>
      </div>
      <a href="#" class="drop-opener"> <span></span> <span></span> <em class=""></em> </a> </div>
  </div>
</div>