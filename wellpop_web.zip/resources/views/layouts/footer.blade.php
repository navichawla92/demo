<script src="{{ asset('js/jquery.min.js') }}" type="text/javascript"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script> 
<script src="{{ asset('js/owl.carousel.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/fontawesome.min.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/jquery.main.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/waitMe.js') }}" type="text/javascript"></script>  
<script src="{{ asset('js/bootbox.min.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/jstz.min.js') }}" type="text/javascript"></script> 
<script type="text/javascript">
    var path = "http://localhost/blog/public/";
    $(document).on('click change','input,select,textarea',function(){
        if($(this).attr('type') != 'file' && !$(this).is("select"))
          $(this).val($.trim($(this).val()));
        
        if($(this).attr('name') == 'patient_concern[]' || $(this).attr('name') == 'patient_concern_other')
          $(this).parents('.personliving').find('span.error').hide().removeClass('active');

        //for CM assessment tabs
        if($(this).attr('name') == 'advance_healthcare_checkboxes[]' || $(this).attr('name') == 'polst_checkboxes[]' || $(this).attr('name') == 'identifying_issues[]' || $(this).attr('name') == 'patient_functioning[]')
          $('input[name="'+$(this).attr('name')+'"]:first').parent().parent().parent().find('span.error').html('').removeClass('active').hide();        //for CM assessment advanced directive tab
        
        //for CM assessment tabs other checkbox
        if($(this).attr('name') == 'identifying_issues_other')
          $('input[name="identifying_issues[]"]:first').parent().parent().parent().find('span.error').html('').removeClass('active').hide();          
        if($(this).attr('name') == 'lives_with' || $(this).attr('name') == 'living_with_other')
          $(this).parents('.personliving').find('span.error').hide().removeClass('active');
        
        $(this).nextAll("span.error").first().hide().removeClass('active');
        $(this).parent().find('span.error').hide().removeClass('active');
    });
    
    $.ajaxSetup({
        type:"POST",
        headers: {
    			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    		},
        beforeSend:function(){
            $('body').waitMe();
        },
        complete:function(){
            $('body').waitMe('hide');
        },
        error:function(error){
            $.each(error.responseJSON.errors,function(key,value){
                $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            });

            jQuery('html, body').animate({
                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
            }, 500);

        }
    });
    
    /*
     //Un comment this code after development complete
   //  disable ctrl u 
    document.onkeydown = function(e) {
        if (
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 123 || 
             e.keyCode === 117)) {
           // alert('not allowed');
            return false;
        } else {
            return true;
        }
	};
    //  disable ctrl  f12 
    document.onkeypress = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
           //alert('No F-12');
            return false;
        }
    }
    document.onmousedown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
            //alert('No F-keys');
            return false;
        }
    }

  //  disable Right Click  f12
	var message="Sorry, right-click has been disabled"; 
	function clickIE() {if (document.all) {(message);return false;}} 
	function clickNS(e) {if 
	(document.layers||(document.getElementById&&!document.all)) { 
	if (e.which==2||e.which==3) {(message);return false;}}} 
	if (document.layers) 
	{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
	else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
	document.oncontextmenu=new Function("return false") 
 */

   /* function phoneNumberPrefix(){
        $(".phone_number_class").each(function(){
           if (this.value.length < 2) {
                this.value = '+1';
              } else if (this.value.indexOf('+1') !== 0) {
                this.value = '+1' + this.value;
            }
        })
    }

    $('.phone_number_class').keyup(function(e) {
          console.log(e.which);
          if (this.value.length < 2) {
            this.value = '+1';
          } else if (this.value.indexOf('+1') !== 0) {
            this.value = '+1' + String.fromCharCode(e.which);
        }
    });*/

    
    //  check if input changed and unsaved before reload
    window.onbeforeunload = function() {
      /*
      ==if auto-logout functionality causing page-reload then allow it don't show any alert 
      ==no matter data changed and un;-saved
      */
      if ($('.changed-input').length && !$('div.ui-dialog[aria-describedby="sessionTimeout-dialog"]').is(':visible')){
             return "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page.";
      }
      else {
      }      
    }

    //  set the default timezone on load
    $.each(document.cookie.split(/; */), function()  {
          
      document.cookie = 'name=client_timezone; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        var splitCookie = this.split('=');
        if (this.indexOf('client_timezone') == 0) {
          document.cookie = splitCookie[0] + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        }

      });     
      var tz = jstz.determine(); // Determines the time zone of the browser client
      var tz_cookie =  tz.name();
      document.cookie = 'client_timezone='+tz_cookie;


    // hide all validation error after 5 sec
    function fadeOutAlertMessages(){
      setTimeout(function(){
           $(document).find('.alert-success').slideUp(500);
           $(document).find(".alert-error").slideUp(500);
           $(document).find(".alert-danger").slideUp(500);
       },5000);
    }    

    // put ellipses on required table tds if characters are longer than 30 characters
    function applpyEllipses(table_identifier, no_of_tds, any_link_in_td){
          if($('.'+table_identifier+' table tr td').length > 1)
          {
            $('.'+table_identifier+' table tr').find('td:lt('+no_of_tds+')').each(function(i, v){
                var len = $(this).clone().children().remove().end().text().length;
                if(len > 30 && $(this).children().length == 0)
                {
                  var text = $(this).clone().children().remove().end().text();  
                  $(this).attr('title', text);
                  $(this).html(text.substring(0,30)+'...');
                }
                else if(any_link_in_td == 'yes' && $(this).children().length > 0)
                {
                  var text = $(this).find('a').clone().children().remove().end().text();
                  if(text.length > 30)
                  {
                      var children = $(this).find('a').children().prop('outerHTML');
                      $(this).attr('title', text);
                      $(this).find('a').children().remove().end().text('');
                      $(this).find('a').html('');           
                      $(this).find('a').html(children+text.substring(0,30)+'...');           
                  }
                }
            });
          }
    }

    $(document).on('ready', function(){
      fadeOutAlertMessages();
    });

/* Changes for table */

      function table_load(){
      $(".table-responsive").on('click', '.dropdown-toggle', function(event) {

        if ($('.dropdown-menu').length) {
          var elm = $('.dropdown-menu'),
            docHeight = $(document).height(),
            docWidth = $(document).width(),
            btn_offset = $(this).offset(),
            btn_width = $(this).outerWidth(),
            btn_height = $(this).outerHeight(),
            elm_width = elm.outerWidth(),
            elm_height = elm.outerHeight(),
            table_offset = $(".table-responsive").offset(),
            table_width = $(".table-responsive").width(),
            table_height = $(".table-responsive").height(),
            tableoffright = table_width + table_offset.left,
            tableoffbottom = table_height + table_offset.top,
            rem_tablewidth = docWidth - tableoffright,
            rem_tableheight = docHeight - tableoffbottom,
            elm_offsetleft = btn_offset.left,
            elm_offsetright = btn_offset.left + btn_width,
            elm_offsettop = btn_offset.top + btn_height,
            btn_offsetbottom = elm_offsettop,
            left_edge = (elm_offsetleft - table_offset.left) < elm_width,
            top_edge = btn_offset.top < elm_height,
            right_edge = (table_width - elm_offsetleft) < elm_width,
            bottom_edge = (tableoffbottom - btn_offsetbottom) < elm_height;

          var table_offset_bottom = docHeight - (table_offset.top + table_height);
          // console.log(table_offset_bottom + " table_offset_bottom");

          var touchTableBottom = (btn_offset.top + btn_height + (elm_height * 2)) - table_offset.top;


          var bottomedge = touchTableBottom > table_offset_bottom;

          if (left_edge) {
            $(this).addClass('left-edge');
          } else {
            $('.dropdown-menu').removeClass('left-edge');
          }
          if (bottom_edge) {
            $(this).parent().addClass('dropup');
            // $(this).parent().removeClass('dropdown');
          } else {
            $(this).parent().removeClass('dropup');
            // $(this).parent().addClass('dropdown');
          }

        }
      });
		  
//use if table height is below 300
var table_smallheight = $('.table-responsive'),
        positioning = table_smallheight.parent();
		/*if(table_smallheight.height() < 249 && (!table_smallheight.hasClass("primary_table") ||  !table_smallheight.hasClass("secondary_table"))){
			table_smallheight.addClass('fix_table_height');
		}
		else {
			table_smallheight.removeClass('fix_table_height');
		}*/
		if (table_smallheight.height() < 320) {
		  positioning.addClass('positioning');
		  $('.table-responsive .dropdown,.table-responsive .dropup').css('position','static');

		}else{
		  positioning.removeClass('positioning');
		  $('.table-responsive .dropdown,.table-responsive .dropup').css('position','relative');
		
		}
  }  

  table_load();


  function handleMoreInfo(){
    
    // Configure/customize these variables.
    var showChar = 90;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Show more >";
    var lesstext = "Show less";
    

    $('.more_info').each(function() {
        var content = $(this).html();
 
        if(content.length > showChar) {
 
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
 
            var html = c + '<span class=" more-texty moreellipses">' + ellipsestext+ '&nbsp;</span>\
            <span class="more-texty morecontent"><span>' + h + '</span>\
            &nbsp;&nbsp;<a href="" class=" more-texty morelink">' + moretext + '</a>\
            </span>';
 
            $(this).html(html);
        }
 
    });
 
    $(".morelink").click(function(){
      //  console.log('jhehe');
        if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
           // console.log($(this));
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });


  }

 // handleMoreInfo();

</script>
@yield('script')
