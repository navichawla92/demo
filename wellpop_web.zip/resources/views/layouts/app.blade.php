<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Wellpop: @yield('title')</title>
    
    <!-- Styles -->
    @include('layouts.head')
    <link href="{{ asset('css/jquery-ui.css') }}" rel="stylesheet">

</head>
<body>
    <div class="wrapper">
      <div class="page-wrap">
        <div class="main">
          @include('layouts.header')
          <div class="submainfulldata">
            @include('layouts.aside')
            @yield('content')
            <div class="modal fade" id="patientinfopop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      
           </div>
          </div>
        </div>
      </div>
    </div>
    @yield('modal_box')
    @if(Session::get('password_expire_time'))
        <div class="modal fade" id="password_expire" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">                
                        <h4 class="modal-title">{{trans('label.password_expire_modal_header')}}</h4>
                    </div>
                    <div class="modal-body">                
                        <p>{{trans('label.password_expire_modal_text')}}</p>
                    </div>
                    <div class="modal-footer">                      
                        <button type="button" id="not_change_password" class="btn btn-default">{{trans('label.no')}}</button>
                        <button type="button" id="change_password" class="btn btn-primary">{{trans('label.yes')}}</button>
                    </div>
                </div>

            </div>

        </div>
    @endif

</body>
@include('layouts.footer')
<script src="{{ asset('js/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/session_timeout.min.js') }}" type="text/javascript"></script>  
<script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/inputmask.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/bootstrap.min.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/wellpop.js') }}" type="text/javascript"></script>
<script type="text/javascript">
    $.sessionTimeout({
        message: 'Your session will be locked in five minute.',
        logoutUrl: '{{ route("logout") }}',
        redirUrl: '{{ route("logout") }}',
        keepAliveUrl: '{{ route("keep-session-alive") }}',
        warnAfter: 600000,
        redirAfter: 900000,
        keepAlive:false,
        keepBtnClass: 'btn btn-success',
        keepBtnText: 'Extend session',
        logoutBtnClass: 'btn btn-light',
        logoutBtnText: 'Log me out'
    });

    
    $(document).on('click', '.viewDetail', function(e) {
       e.preventDefault();
       // var patientId = $(".ref_patient_id").val();
       var patientId = $(".ref_patient_id").data('id');
        $.ajax({
        url:"{{ route('patient-view') }}",
        type: "GET",
        data: {id:patientId},
        dataType: "html",
        success:function(data){
           $('#patientinfopop').html(data); 
           $('#patientinfopop').modal('show');
        }
      });
    });

    /***************password-update**************/
    @if(Session::has('password_expire_time'))
        $('#password_expire').modal('show');
   
        $(document).on('click', '#change_password', function(){
            window.location.href="{{ route('my_profile',[Auth::user()->roles->pluck('name')[0]]) }}";
             //route('my_profile')
        });

        $(document).on('click', '#not_change_password', function(e){
            e.stopPropagation();

            $.ajax({
                url: "{{ route('updatePasswordExpiry') }}",
                type: "GET",
                //processData: false,
                headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success:function(data){
                 //   alert('Password expire time add next 15 days');
                    $('#password_expire').modal('hide');
                },
                error:function(data){
                    
                }
             });
        });
    @endif

    function addTooltipTolabel(){
        // code for add the title to all the label field with class name lablefieldsname
        document.querySelectorAll('label').forEach(function (elem) {
            elem.setAttribute('title', elem.textContent);
        });
    }
    addTooltipTolabel();

</script>
@yield('common_script')

@stack('scripts')
</html>
