@extends('admin.layouts.app')

@section('title')
   Housing Assistances Listing
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                 <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Housing Assistances</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="fa fa-medkit font-dark"></i>
                            <span class="caption-subject bold uppercase">Available Housing Assistances</span>
                        </div>
                        <div class="btn-group pull-right">
                            <a href="{{route('registry_type1-create',[$sub_active])}}" id="sample_editable_1_new" class="btn sbold green"> <i class="fa fa-plus"></i> Add new Housing Assistance
                               
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered table-hover table-checkable order-column datatable">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Organization</th>
                                    <th>Counselor name</th>
                                    <th>Counselor title</th>
                                     <th>Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        ajax: '{{ route('datatable/getRegistryType1',[$sub_active]) }}',
        columns: [
           // {data: 'id', name: 'id', searchable: false},
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'name', name: 'name',orderable: false},
            {data: 'contact_name', name: 'contact_name',orderable: false},
            {data: 'contact_title', name: 'contact_title',orderable: false},
            {data: 'address_line1', name: 'address_line1',orderable: false},
            {data: 'action', name: 'action',orderable: false, searchable: false},
        ]
    });
});
</script>
@endsection
