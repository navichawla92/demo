@extends('admin.layouts.app')

@section('title')
   {{ $registry->id ? "Edit Housing Assistance" : "Add new Housing Assistance"}}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                 <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                    <i class="fa fa-circle"></i>
                </li>
                 <li>
                    <a href="{{ route('get_listing',[$sub_active]) }}">Housing Assistances</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $registry->id ? "Edit Housing Assistance" : "Add new Housing Assistance"}}</span>
                </li>
            </ul>   
        </div>
        <!-- END PAGE BAR -->
        <div class="">
            <!-- BEGIN SAMPLE FORM PORTLET-->
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-plus font-dark"></i>
                        <span class="caption-subject font-dark bold">{{ $registry->id ? "Edit Housing Assistance" : "Add new Housing Assistance"}}</span>
                    </div>
                </div>
                 @if ($errors->has('type'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('type') }}</strong>
                    </span>
                @endif

                <div class="portlet-body form">
                    {!! Form::model($registry,['id'=>'add_housing_assistance_data_form']) !!}
                     <div class="row">
                        <div class='col-md-6'>
                            <input type="hidden" name="id" class="ref_field_id" value="{{$registry->id ? \Crypt::encrypt($registry->id) : '' }}">

                            <div class="form-group">
                                {{ Form::label('name', 'Organization Name') }}*
                                @if(!$registry->id)
                                    {{ Form::text('name', null, array('class' => 'form-control')) }}
                                @else
                                    {{ Form::text('name', null, array('class' => 'form-control','readonly' => '')) }}
                                @endif
                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <input type="hidden" name="type" value="{{$sub_active}}">
                             <div class="form-group">
                                {{ Form::label('phone_number', 'Phone Number') }}*
                                  <div class="row">
                                      <div class="col-md-2">
                                        {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center form-control','disabled'=>true]) !!} 
                                      </div>
                                     <div class="col-md-10">
                                    {!! Form::text('phone_number',null,['class' => 'set_phone_format form-control']) !!}
                                    <span class="error" style="color:red"></span>
                                    </div>
                                </div>
                               
                                @if ($errors->has('phone_number'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('address_line1', 'Address Line 1') }}*
                                {{ Form::text('address_line1', null, array('class' => 'form-control')) }}
                                @if ($errors->has('address_line1'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('address_line1') }}</strong>
                                    </span>
                                @endif
                            </div>
                             <div class="form-group">
                                {{ Form::label('address_line2', 'Address Line 2') }}
                                {{ Form::text('address_line2', null, array('class' => 'form-control')) }}
                                @if ($errors->has('address_line2'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('address_line2') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('city', 'City') }}*
                                {{ Form::text('city', null, array('class' => 'form-control')) }}
                                @if ($errors->has('city'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('city') }}</strong>
                                    </span>
                                @endif
                            </div>
                             <div class='row'>
                                 <div class='col-md-6'>
                            <div class="form-group">
                                {{ Form::label('state', 'State') }}*
                                 {!! Form::select('state_id',$states,null,array("class" => "form-control")) !!}
                                @if ($errors->has('state_id'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('state_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                            </div>
                             <div class='col-md-6'>
                             <div class="form-group">
                                {{ Form::label('zip', 'Zip Code') }}*
                                {{ Form::text('zip', null, array('class' => 'form-control','maxlength'=>'5')) }}
                                @if ($errors->has('zip'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('zip') }}</strong>
                                    </span>
                                @endif
                            </div>              
                            </div>              
                            </div>              
                        </div>
                        <div class='col-md-6'>
                           
                            
                            <div class="form-group">
                                {{ Form::label('fax', 'FAX') }}
                                {{ Form::text('fax', null, array('class' => 'form-control')) }}
                                @if ($errors->has('fax'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fax') }}</strong>
                                    </span>
                                @endif
                            </div>
                             <div class="form-group">
                                {{ Form::label('web_address', 'Web Address') }}
                                {{ Form::text('web_address', null, array('class' => 'form-control')) }}
                                @if ($errors->has('web_address'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('web_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('contact_name', 'Counselor Person Name') }}
                                {{ Form::text('contact_name', null, array('class' => 'form-control')) }}
                                @if ($errors->has('contact_name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('contact_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                            <div class="form-group">
                                {{ Form::label('contact_phone', 'Counselor Person Phone') }}
                                  <div class="row">
                                      <div class="col-md-2">
                                        {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center form-control','disabled'=>true]) !!} 
                                      </div>
                                     <div class="col-md-10">
                                    {!! Form::text('contact_phone',null,['class' => 'set_phone_format form-control']) !!}
                                    <span class="error" style="color:red"></span>
                                    </div>
                                </div>
                               
                                @if ($errors->has('contact_phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('contact_phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                             <div class="form-group">
                                {{ Form::label('contact_title', 'Counselor Person Title') }}
                                {{ Form::text('contact_title', null, array('class' => 'form-control')) }}
                                @if ($errors->has('contact_title'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('contact_title') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group">
                                {{ Form::label('contact_email', 'Counselor Person Email') }}
                                {{ Form::text('contact_email', null, array('class' => 'form-control')) }}
                                @if ($errors->has('contact_email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('contact_email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-offset-10 col-md-4">
                             <button type="button" class="btn blue save_button" onClick="javascript:formData('#add_housing_assistance_data_form')" > {{ $registry->id ? 'Update' : 'Add' }}</button> 
                            <a href="{{ route('get_listing',[$sub_active]) }}" class="btn default">Cancel</a>
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
           </div>
        </div>
    <!-- END CONTENT BODY -->
    </div>
</div>
<!-- END CONTENT -->
@endsection

@section('script')
<script type="text/javascript">

</script>
@endsection

