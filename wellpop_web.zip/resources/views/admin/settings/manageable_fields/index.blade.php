@extends('admin.layouts.app')

@section('title')
   {{ trans('label.manageable_fields') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                  <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.settings') }}</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.manageable_fields') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-wrench font-dark"></i>
                            <span class="caption-subject bold uppercase">{{ trans('label.available_fields') }} </span>
                        </div>
                        <div class="btn-group pull-right">
                            <a href="{{route('field-create')}}" id="sample_editable_1_new" class="btn sbold green"> <i class="fa fa-plus"></i> {{ trans('label.add_new_field') }}
                               
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered table-hover table-align-left datatable">
                            <thead>
                                <tr>
                                    <th> {{ trans('label.serial_number_short_form') }} </th>
                                    <th>{{ trans('label.field_type') }} </th>
                                    <th>{{ trans('label.field_value') }} </th>
                                 <!--   <th>Action</th> -->
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort: false,
        language: {
          searchPlaceholder: "{{trans('label.search_by_field')}}",
        },
        ajax: '{{ route('datatable/getManageAbleField') }}',
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'type', name: 'type',orderable: false},
            {data: 'name', name: 'name',orderable: false},
           // {data: 'action', name: 'action',orderable: false, searchable: false},
        ]
    });
});
</script>
@endsection
