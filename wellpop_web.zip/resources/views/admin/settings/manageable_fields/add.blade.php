@extends('admin.layouts.app')

@section('title')
   {{ $manageablefield->id ? "Edit Manageable Field" : "Add new Manageable Field"}}
@endsection

@section('content')
<?php
    $setting_field_type=setting_field_type();
?>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                    <i class="fa fa-circle"></i>
                </li>
                 <li>
                    <a href="{{ route('manageablefields') }}">Manageable Fields</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $manageablefield->id ? "Edit Manageable Field" : "Add new Manageable Field"}}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold">{{ $manageablefield->id ? "Edit Manageable Field" : "Add new Manageable Field"}}</span>
                        </div>
                    </div>

                    <div class="portlet-body form">

                        {!! Form::model($manageablefield, ['class'=>'form-horizontal']) !!}
                        <input type="hidden" name="field_id" class="ref_field_id" value="{{$manageablefield->id ? \Crypt::encrypt($manageablefield->id) : '' }}">
                            <div class="form-group">
                                <label for="type" class="col-md-2 control-label">Type</label>
                                <div class="col-md-4">
                                    {!! Form::select('type', array('' => 'Please select') + $setting_field_type,null,array("class" => "form-control")) !!} 
                                     @if ($errors->has('type'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('type') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Name</label>
                                <div class="col-md-4">
                                    {{ Form::text('name', null, array('class' => 'form-control')) }}
                                     @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    {{ $manageablefield->id ? Form::submit('Update', array('class' => 'btn blue save_button')) :Form::submit('Add', array('class' => 'btn blue'))}}
                                    <a href="{{ route('manageablefields') }}" class="btn default">Cancel</a>
                                </div>
                            </div>
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

