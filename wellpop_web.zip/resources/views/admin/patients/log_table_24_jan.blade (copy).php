
<?php
$newEncrypter = new \Illuminate\Encryption\Encrypter(salt($key), Config::get( 'app.cipher' ) );
?>
<div class="row">
  <input type='hidden' class='item-exist' value={{$itemExit}}>

  @foreach($logs as $log)
  <div class="col-md-6">
    <div class="timeline">
      <!-- TIMELINE ITEM -->
      <div class="timeline-item">
        <div class="timeline-badge">
          <img class="timeline-badge-userpic" src="@if($log->user->image) {{ config('filesystems.s3_user_images_full_path').$log->user->id.'/'.$log->user->image }} @else {{ asset('images/dummy_user.png') }} @endif" alt=""/> 
        </div>
        <div class="timeline-body">
          <div class="timeline-body-arrow"> </div>
          <div class="timeline-body-head">
            <div class="timeline-body-head-caption">
              <a href="javascript:;" class="timeline-body-title font-blue-madison">{{$log->user->name }} {{ 
                $log->event }} a Patient  {{ return_log_model($log->auditable_type) }}
              </a>
              <span class="timeline-body-time font-grey-cascade">{{ \Carbon\Carbon::parse($log->created_at)->format('M, d Y') }}</span>
            </div>
          </div>
          <div class="timeline-body-content">
            <span class="font-grey-cascade">
<?php
if($log->auditable_type == 'App\Models\Patient' /* && $log->id == '70 */){
    $valueModify=$log->getModified();
    $dataOld='';
    $dataNew='';
    $model_name = new \App\Models\Patient;
   // echo $log->id;
    echo "<table class='table'> 
    <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
    foreach ($valueModify as $modifykey => $value) {
        if($log->event =='created'){
          if(in_array($modifykey,$model_name->getEncryptableValue())){
            $dataNew='';
            if($value['new'] != ''){
              $dataNew = $newEncrypter->decrypt($value['new']); 
            }

            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
            }
          }
          else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
            $dataOld='';
            $dataNew='';
            if($value['new'] != ''){
              $dataNew = $value['new'];
              if(is_array($value['new'])) {
                $dataNew = implode(',',$value['new']);
              }
            }

            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }

         /* else if($modifykey == 'lives_with_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];
            if($dataOld ==''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";;
            }

          }*/

          else if($modifykey == 'patient_concern_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];
            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";;  }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }
          else if($modifykey == 'contract_payer_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'pcp_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'referral_source_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }
          else if($modifykey == 'state_name_log') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];
            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";

            }
            else {
              echo "<tr><td>Patient State </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'language_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'hospice_provider_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'home_health_provider_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'icd_code_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

          }
          else if($modifykey == 'specialist_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
          }
          else if($modifykey == 'rehab_information_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }
          else if($modifykey == 'housing_assistance_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }
          else if($modifykey == 'mental_health_assistance_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }
          }
          else if($modifykey == 'is_insured') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld =='' && $dataNew == 1){
              echo "<tr><td>Insurance Information required </td><td></td><td>TRUE</td></tr>";
            }
            else {
              echo "<tr><td>Insurance Information required </td><td></td><td>FALSE</td></tr>";
            }
          }

        }
        else{

            if(in_array($modifykey,$model_name->getEncryptableValue())){
              $dataOld='';
              $dataNew='';
              if($value['old'] != ''){
                $dataOld = $newEncrypter->decrypt($value['old']); 
              }
              if($value['new'] != ''){
                $dataNew = $newEncrypter->decrypt($value['new']); 
              }

              if($dataOld != $dataNew){

                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
              else if($dataOld == ''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
              $dataOld='';
              $dataNew='';
              if($value['old'] != ''){
                $dataOld = $value['old'];
                if(is_array($value['old'])) {
                $dataOld = implode(',',$value['old']);
                }

              }
              if($value['new'] != ''){
                $dataNew = $value['new'];
                if(is_array($value['new'])) {
                  $dataNew = implode(',',$value['new']);
                }
              }
              if($dataOld != $dataNew){
                if($modifykey == 'registration_status'){
                 // $dataNew = $dataNew;
                  $dataNew = $model_name->getLogStatus($dataNew);
                }
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
                          
              }
              else if($dataOld == ''){
                if($modifykey == 'registration_status'){
                  $dataOld = $model_name->getLogStatus($dataOld);
                }
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }

            else if($modifykey == 'lives_with_name') {
                $dataOld=$value['old'];
                $dataNew=$value['new'];

                if($dataOld =='' && $dataNew !=''){
                  echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
                }
                else if($dataOld !='' && $dataNew !=''){
                  echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
                }
                else {
                  echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td></td></tr>";
                }
            }

            else if($modifykey == 'patient_concern_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }
            else if($modifykey == 'contract_payer_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }

            else if($modifykey == 'pcp_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }
            else if($modifykey == 'referral_source_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }

            else if($modifykey == 'state_name_log') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }
            else if($modifykey == 'language_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }
            else if($modifykey == 'hospice_provider_name') {
            $dataOld=$value['old'];
            $dataNew=$value['new'];

            if($dataOld ==''){
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
            }
            else {
              echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
            }

            }
            else if($modifykey == 'home_health_provider_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }

            }
            else if($modifykey == 'icd_code_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if($modifykey == 'specialist_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if($modifykey == 'rehab_information_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if($modifykey == 'housing_assistance_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if($modifykey == 'mental_health_assistance_name') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld ==''){
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td></td><td>".$dataNew."</td></tr>";
              }
              else {
                echo "<tr><td>".trans('label.'.$modifykey)." </td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
              }
            }
            else if($modifykey == 'is_insured') {
              $dataOld=$value['old'];
              $dataNew=$value['new'];

              if($dataOld =='' && $dataNew == 1){
                echo "<tr><td>Insurance Information required </td><td></td><td>TRUE</td></tr>";
              }
              else {
                echo "<tr><td>Insurance Information required </td><td></td><td>FALSE</td></tr>";
              }

            }
        }
    }
}
if($log->auditable_type == 'App\Models\PatientData'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  $model_name = new \App\Models\PatientData;
    if($log->event =='created'){

      if($valueModify['type'] && $valueModify['type']['new']=='document'){
        if($valueModify['name'] && $valueModify['name']['new']){
          $name  = $newEncrypter->decrypt($valueModify['name']['new']); 
      }
      if($valueModify['value'] && $valueModify['value']['new']){
        $file = $newEncrypter->decrypt($valueModify['value']['new']); 
      }

      echo "added a document to pateint with info ".$name." ".$file." </br>";


      }

    if($valueModify['type'] && $valueModify['type']['new']=='notes'){
      if($valueModify['name'] && $valueModify['name']['new']){
        $name  = $newEncrypter->decrypt($valueModify['name']['new']); 
    }
    if($valueModify['value'] && $valueModify['value']['new']){
     $file = $newEncrypter->decrypt($valueModify['value']['new']); 
    }

      echo "added a notes to pateint with info ".$name." ".$file." </br>";
    }
  }
  if($log->event =='deleted') {
    $valueModify=$log->getModified();
    $dataOld='';
    $dataNew='';
    if($valueModify['type'] && $valueModify['type']['old']=='document'){
       if($valueModify['name'] && $valueModify['name']['old']){
        $name  = $newEncrypter->decrypt($valueModify['name']['old']); 
      }
      if($valueModify['value'] && $valueModify['value']['old']){
       $file = $newEncrypter->decrypt($valueModify['value']['old']); 
      }

      echo "delete a document to pateint with info ".$name." ".$file." </br>";

      if(isset($valueModify['comment']) && $valueModify['comment']['old'] !=''){
      echo "reason : ".$valueModify['comment']['old'];
      }

    }

  }
}

if($log->auditable_type == 'App\Models\PatientPhoneCall'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
  $model_name = new \App\Models\PatientPhoneCall;
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['new'] != ''){
            $dataNew = $value['new']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }

      }

    }
}
if($log->auditable_type == 'App\Models\PatientAssignment'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
  $model_name = new \App\Models\PatientAssignment;
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['new'] != ''){
            $dataNew = $value['new']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
      if($log->event =='deleted'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['old'] != ''){
            $dataNew = $value['old']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
    }
}

if($log->auditable_type == 'App\Models\PatientAssessment'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
  $model_name = new \App\Models\PatientAssessment;
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['new'] != ''){
            $dataNew = $value['new']; 
            if($modifykey == 'comment_type'){
              $dataNew = return_comment_type_log($value['new']); 
            }
            
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
    }
}

if($log->auditable_type == 'App\Models\PatientAllergy'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
  $model_name = new \App\Models\PatientAllergy;
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['new'] != ''){
            $dataNew = $value['new']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
      if($log->event =='deleted'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['old'] != ''){
            $dataNew = $value['old']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
    }
}

if($log->auditable_type == 'App\Models\PatientMedication'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
  $model_name = new \App\Models\PatientMedication;
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['new'] != ''){
            $dataNew = $value['new']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['new'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
      if($log->event =='deleted'){
        if(in_array($modifykey,$model_name->getNonEncryptableValue())){
          $dataNew='';
          if($value['old'] != ''){
            $dataNew = $value['old']; 
          }
          if($dataNew !=''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
        }
        else if($modifykey == 'type_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
        else if($modifykey == 'assigned_by_name') {
            $dataNew=$value['old'];
            if($dataNew !=''){
              echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";

            }
        }
      }
    }
}

if($log->auditable_type == 'App\Models\PatientInsurance'){
  $valueModify=$log->getModified();
  $dataOld='';
  $dataNew='';
  $model_name = new \App\Models\PatientInsurance;
  echo "<table class='table'> 
  <thead><tr> <th> Label </th> <th> Old Value</th>  <th> New Value</th></tr></thead><tbody>";
    foreach ($valueModify as $modifykey => $value) {
      if($log->event =='created'){
        if(in_array($modifykey,$model_name->getEncryptableValue())){
          $dataOld='';
          $dataNew='';

          if($value['new'] != ''){
            $dataNew = $newEncrypter->decrypt($value['new']); 
          }
          echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
        }
        else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
          $dataOld='';
          $dataNew='';
          if(isset($value['old']) && $value['old'] != ''){
            $dataOld = $value['old'];
          if(is_array($value['old'])) {
            $dataOld = implode(',',$value['old']);
          }

          }
          if($value['new'] != ''){
            $dataNew = $value['new'];
            if(is_array($value['new'])) {
              $dataNew = implode(',',$value['new']);
            }
          }
          echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";

        }

        else if($modifykey == 'insurance_name') {
          $dataOld=$value['old'];
          $dataNew=$value['new'];
          if($dataOld ==''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td></td><td>".$dataNew."</td></tr>";
          }
          else {
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
          }
        }

      }
      else{

      if(in_array($modifykey,$model_name->getEncryptableValue())){
        $dataOld='';
        $dataNew='';
        if($value['old'] != ''){
          $dataOld = $newEncrypter->decrypt($value['old']); 
        }
        if($value['new'] != ''){
          $dataNew = $newEncrypter->decrypt($value['new']); 
        }
          echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
        }
        else if($modifykey == 'insurance_name') {
          $dataOld=$value['old'];
          $dataNew=$value['new'];

          if($dataOld == ''){
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
          }
          else {
            echo "<tr><td>".trans('label.'.$modifykey)."</td><td>".$dataOld."</td><td>".$dataNew."</td></tr>";
          }

        }
      }
    }

  echo "</tbody></table>";
}
?>
</tbody></table>
</span>
</div>
</div>
</div>
<!-- END TIMELINE ITEM -->
</div>
</div>
@endforeach

</div>   




