@extends('admin.layouts.app')

@section('title')
   {{ trans('label.patients_listings') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.available_patients') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="fa fa-user-md font-dark"></i>
                            <span class="caption-subject bold uppercase"> {{ trans('label.available_patients') }} </span>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered table-hover loader_div table-align-left datatable">
                            <thead>
                                <tr>
                                    <th>{{ trans('label.serial_number_short_form') }}</th>
                                    <th>{{ trans('label.name') }} </th>
                                    <th>{{ trans('label.case_number') }} </th>
                                    <th>{{ trans('label.status') }} </th>
                                    <th>{{ trans('label.action') }} </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('js/ajaxSetup.js') }}" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort:false,
        ajax: '{{ route('datatable/getPatients') }}',
        language: {
          searchPlaceholder: "{{trans('label.search_by_referral_number')}}",
        },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'name', name: 'name',orderable: false},
            {data: 'case_number', name: 'case_number',orderable: false},
            {data: 'case_status', name: 'case_status',orderable: false},
            {data: 'action', name: 'action',orderable: false, searchable: false},
        ]
    });
});
</script>
@endsection
