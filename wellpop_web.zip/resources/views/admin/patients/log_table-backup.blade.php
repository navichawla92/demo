
	<?php
	$newEncrypter = new \Illuminate\Encryption\Encrypter(salt($key), Config::get( 'app.cipher' ) );
	?>
    <div class="row">
    <input type='hidden' class='item-exist' value={{$itemExit}}>
	
    @foreach($logs as $log)
        <div class="col-md-6">
            <div class="timeline">
                <!-- TIMELINE ITEM -->
                <div class="timeline-item">
                    <div class="timeline-badge">
                        <img class="timeline-badge-userpic" src="@if($log->user->image) {{ asset('images/profile_pics/'.$log->user->image) }} @else {{ asset('images/dummy_user.png') }} @endif" alt=""/> 
                        </div>
                    <div class="timeline-body">
                        <div class="timeline-body-arrow"> </div>
                        <div class="timeline-body-head">
                            <div class="timeline-body-head-caption">
                                <a href="javascript:;" class="timeline-body-title font-blue-madison">{{$log->user->name }} {{ $log->event }} a Patient </a>

                                <span class="timeline-body-time font-grey-cascade">{{ \Carbon\Carbon::parse($log->created_at)->format('M, d Y') }}</span>
                            </div>
                        </div>
                        <div class="timeline-body-content">
                            <span class="font-grey-cascade">
                        <?php
                        if($log->auditable_type == 'App\Models\Patient' /* && $log->id == '70 */){
                             $valueModify=$log->getModified();
                             $dataOld='';
                             $dataNew='';
                             $model_name = new \App\Models\Patient;
                         //    print_r($model_name->getEncryptableValue());
                            foreach ($valueModify as $modifykey => $value) {
                                if($log->event =='created'){
                                    if(in_array($modifykey,$model_name->getEncryptableValue())){
                                      
                                        $dataNew='';
                                        
                                        if($value['new'] != ''){
                                        $dataNew = $newEncrypter->decrypt($value['new']); 
                                        }
                                        
                                         if($dataNew !=''){
                                            echo "Create patient with value of ".trans('message.'.$modifykey).' : '.$dataNew.'</br> </br>';
                                        }
                                    }
                                     else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
                                        $dataOld='';
                                        $dataNew='';
                                        if($value['new'] != ''){
                                            $dataNew = $value['new'];
                                        if(is_array($value['new'])) {
                                            $dataNew = implode(',',$value['new']);
                                            }
                                        }

                                        if($dataNew !=''){
                                        echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br></br>';
                                        }
                                    }

                                    else if($modifykey == 'lives_with_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new lives with :".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated lives with from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }

                                    else if($modifykey == 'patient_concern_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new patient concern with :".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient concern from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'contract_payer_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new patient contract payer with :".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient contract payer from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'pcp_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new PCP Information with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient PCP Information from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                     else if($modifykey == 'referral_source_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new Referral Source with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient Referral Source from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'state_name_log') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new State with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient State from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                     else if($modifykey == 'language_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new Language with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient Language from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'is_insured') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld =='' && $dataNew == 1){
                                        echo "Add Insurance Information to not required and remove the Insurances </br>";
                                       }
                                       else {
                                         echo "Add Insurance Information to required </br>";
                                       }

                                    }

                                }
                                else{

                                    if(in_array($modifykey,$model_name->getEncryptableValue())){
                                        $dataOld='';
                                        $dataNew='';
                                        if($value['old'] != ''){
                                        $dataOld = $newEncrypter->decrypt($value['old']); 
                                        }
                                        if($value['new'] != ''){
                                        $dataNew = $newEncrypter->decrypt($value['new']); 
                                        }

                                       if($dataOld != $dataNew){
                                        echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';
                                       }
                                        else if($dataOld == ''){
                                            echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';

                                        }
                                    }
                                    else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
                                        $dataOld='';
                                        $dataNew='';
                                        if($value['old'] != ''){
                                            $dataOld = $value['old'];
                                        if(is_array($value['old'])) {
                                            $dataOld = implode(',',$value['old']);
                                        }
                                        
                                        }
                                        if($value['new'] != ''){
                                        $dataNew = $value['new'];
                                        if(is_array($value['new'])) {
                                            $dataNew = implode(',',$value['new']);
                                        }
                                        }

                                      ///  if($dataOld != $dataNew){
                                       if($dataOld != $dataNew){
                                        echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';
                                       }
                                        else if($dataOld == ''){
                                            echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';

                                        }

                                    }

                                    else if($modifykey == 'lives_with_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld =='' && $dataNew !=''){
                                        echo "Added new lives with :".$dataNew;
                                       }
                                       else if($dataOld !='' && $dataNew !=''){
                                        echo "updated lives with from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "remove lives with from patient. </br>";
                                       }

                                    }

                                    else if($modifykey == 'patient_concern_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new patient concern with :".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient concern from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'contract_payer_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new patient contract payer with : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient contract payer from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }

                                    else if($modifykey == 'pcp_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new PCP Information with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient PCP Information from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                     else if($modifykey == 'referral_source_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new Referral Source with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient Referral Source from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }

                                    else if($modifykey == 'state_name_log') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new State with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient State from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'language_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){
                                        echo "Added new Language with name : ".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated patient Language from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                    else if($modifykey == 'is_insured') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld =='' && $dataNew == 1){
                                        echo "Add Insurance Information to not required </br>";
                                       }
                                       else {
                                         echo "Add Insurance Information to required </br>";
                                       }

                                    }
                                }
                            }
                        }
                        if($log->auditable_type == 'App\Models\PatientData'){
                             $valueModify=$log->getModified();
                             $dataOld='';
                             $dataNew='';
                             $model_name = new \App\Models\PatientData;
                         //    print_r($model_name->getEncryptableValue());
                             
                              if($valueModify['type'] && $valueModify['type']['new']=='document'){
                                 if($valueModify['name'] && $valueModify['name']['new']){
                                    $name  = $newEncrypter->decrypt($valueModify['name']['new']); 
                                 }
                                 if($valueModify['value'] && $valueModify['value']['new']){
                                     $file = $newEncrypter->decrypt($valueModify['value']['new']); 
                                 }
                                        
                                echo "added a document to pateint with info ".$name." ".$file." </br>";


                              }
                               if($valueModify['type'] && $valueModify['type']['new']=='notes'){
                                 if($valueModify['name'] && $valueModify['name']['new']){
                                    $name  = $newEncrypter->decrypt($valueModify['name']['new']); 
                                 }
                                 if($valueModify['value'] && $valueModify['value']['new']){
                                     $file = $newEncrypter->decrypt($valueModify['value']['new']); 
                                 }
                                        
                                    echo "added a notes to pateint with info ".$name." ".$file." </br>";


                              }
 
                        }


                         if($log->auditable_type == 'App\Models\PatientInsurance'){
                             $valueModify=$log->getModified();
                             $dataOld='';
                             $dataNew='';
                             $model_name = new \App\Models\PatientInsurance;
                         //    print_r($model_name->getEncryptableValue());
                            foreach ($valueModify as $modifykey => $value) {
                                if($log->event =='created'){
                                    if(in_array($modifykey,$model_name->getEncryptableValue())){
                                        $dataOld='';
                                        $dataNew='';
                                        
                                        if($value['new'] != ''){
                                        $dataNew = $newEncrypter->decrypt($value['new']); 
                                        }

                                      //  if($dataOld != $dataNew){
                                        echo "Create patient insurance with value of ".trans('message.'.$modifykey).' : '.$dataNew.'</br> </br>';
                                     //   }
                                    }
                                    else if(in_array($modifykey,$model_name->getNonEncryptableValue())) {
                                        $dataOld='';
                                        $dataNew='';
                                       // print_r($value);
                                        if(isset($value['old']) && $value['old'] != ''){
                                            $dataOld = $value['old'];
                                        if(is_array($value['old'])) {
                                            $dataOld = implode(',',$value['old']);
                                        }
                                        
                                        }
                                        if($value['new'] != ''){
                                        $dataNew = $value['new'];
                                        if(is_array($value['new'])) {
                                            $dataNew = implode(',',$value['new']);
                                        }
                                        }
                                        
                                      ///  if($dataOld != $dataNew){
                                        echo "change value  of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';

                                    }

                                    else if($modifykey == 'insurance_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld ==''){

                                        echo "Added new ".$valueModify['type']['new']." insurance with name :".$dataNew.'</br></br>';
                                       }
                                       else {
                                        echo "updated ".$valueModify['type']['old']." insurance from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }

                                }
                                else{

                                    if(in_array($modifykey,$model_name->getEncryptableValue())){
                                        $dataOld='';
                                        $dataNew='';
                                        if($value['old'] != ''){
                                        $dataOld = $newEncrypter->decrypt($value['old']); 
                                        }
                                        if($value['new'] != ''){
                                        $dataNew = $newEncrypter->decrypt($value['new']); 
                                        }

                                      //  if($dataOld != $dataNew){
                                        echo "change value of ".trans('message.'.$modifykey).' from '.$dataOld.' to '.$dataNew.'</br> </br>';
                                     //   }
                                    }
                                     else if($modifykey == 'insurance_name') {
                                        $dataOld=$value['old'];
                                        $dataNew=$value['new'];
                                       
                                       if($dataOld == ''){
                                        echo "update new ".$valueModify['type']['new']." insurance with name :".$dataNew.'</br></br>';
                                       }
                                       else {
                                            echo "updated insurance from :".$dataOld." to : ".$dataNew.'</br></br>';
                                       }

                                    }
                                }
                            }
                        }
                        ?>
                         </span>
                        </div>
                    </div>
                </div>
                <!-- END TIMELINE ITEM -->
            </div>
        </div>
    @endforeach

    </div>   

          


