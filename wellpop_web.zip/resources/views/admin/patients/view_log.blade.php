@extends('admin.layouts.app')

@section('title')
   Log
@endsection

@section('css')
   <link href="{{ asset('assets/layouts/layout/css/todo.css') }}" rel="stylesheet" type="text/css" />
@endsection

@section('content')
<!-- BEGIN CONTENT -->



<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
<div class="page-content" id="post-data">
    <!-- BEGIN PAGE BAR -->
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="{{ route('login') }}">Dashboard</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="{{ route('patient-list') }}">All Patients</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>Activity Logs</span>
            </li>
        </ul>
    </div>
    <!-- END PAGE BAR -->
    @include('admin.patients.log_table')





</div>    
</div>               
@endsection

@section('script')
<script type="text/javascript">


    var page = 1;
    $(window).scroll(function() {
        if($(window).scrollTop() + $(window).height()+50 >= $(document).height()) {
            var itemExit=$('.item-exist').val();
            if(itemExit !='0'){
                 page++;
                 loadMoreData(page);
            }
           
        }
    });


    function loadMoreData(page){
      $.ajax(
            {
                url: '?page=' + page,
                type: "get",
            })
            .done(function(data)
            {   
                if(data.html == " "){
                    $('.ajax-load').html("No more records found");
                    return;
                }
               // $('.ajax-load').hide();
                $("#post-data").append(data.html);
                $(".item-exist").val(data.itemExit);
            })
            .fail(function(jqXHR, ajaxOptions, thrownError)
            {
                  alert('server not responding...');
            });
    }

</script>
@endsection

