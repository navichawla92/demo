<!-- BEGIN SIDEBAR -->
<div class="page-sidebar-wrapper">
    <!-- BEGIN SIDEBAR -->
    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
    <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
    <div class="page-sidebar navbar-collapse collapse">
        <!-- BEGIN SIDEBAR MENU -->
        <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
        <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
        <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
        <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
        <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
        <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
            <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
            <li class="nav-item {{ ($active == 'users')?'active':'' }}">
                <a href="{{ route('users') }}" class="nav-link ">
                    <i class="fa fa-users"></i>
                    <span class="title">Users</span>
                    @if($active == 'users')
                        <span class="selected"></span>
                    @endif
                </a>
            </li>
            <li class="nav-item {{ ($active == 'patients')?'active':'' }}">
                <a href="{{route('patient-list')}}" class="nav-link ">
                    <i class="fa fa-user-md"></i>
                    <span class="title">Patients</span>
                    @if($active == 'patients')
                        <span class="selected"></span>
                    @endif
                </a>
            </li>
            <li class="nav-item {{ ($active == 'privileges')?'active':'' }}">
                <a href="{{ URL::to('privileges') }}" class="nav-link ">
                    <i class="fa fa-legal"></i>
                    <span class="title">Privileges</span>
                    @if($active == 'privileges')
                        <span class="selected"></span>
                    @endif
                </a>
            </li>
            <li class="nav-item {{ ($active == 'settings')?'active open':'' }}">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-gears"></i>
                    <span class="title">Settings</span>
                    @if($active == 'settings')
                        <span class="selected"></span>
                    @endif
                    <span class="arrow {{ ($active == 'settings')?'open':'' }}"></span>
                </a>
                <ul class="sub-menu" style="display: {{ ($active == 'settings')?'active open':'' }};">
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'manageable_fields')?'open':'' }}">
                        <a href="{{ route('manageablefields') }}" class="nav-link ">
                            <span class="title">Manageable Fields</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'contract_payers')?'open':'' }}">
                        <a href="{{ route('registries', 'contract_payers') }}" class="nav-link ">
                            <span class="title">Contract Payers</span>
                        </a>
                    </li>
                   

                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'insurances')?'open':'' }}">
                        <a href="{{ route('registries', 'insurances') }}" class="nav-link ">
                            <span class="title">Insurances</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'pcp_informations')?'open':'' }}">
                        <a href="{{ route('registries', 'pcp_informations') }}" class="nav-link ">
                            <span class="title">PCP Informations</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'referral_sources')?'open':'' }}">
                        <a href="{{ route('registries', 'referral_sources') }}" class="nav-link ">
                            <span class="title">Referral Source</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'emergency_departments')?'open':'' }}">
                        <a href="{{ route('registries', 'emergency_departments') }}" class="nav-link ">
                            <span class="title">Emergency Departments</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'rehabs')?'open':'' }}">
                        <a href="{{ route('registries', 'rehabs') }}" class="nav-link ">
                            <span class="title">Rehab Information</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'hospice_providers')?'open':'' }}">
                        <a href="{{ route('registries', 'hospice_providers') }}" class="nav-link ">
                            <span class="title">Hospice Providers</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'specialities')?'open':'' }}">
                        <a href="{{ route('registries', 'specialities') }}" class="nav-link ">
                            <span class="title">Specialty</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'housing_assistances')?'open':'' }}">
                        <a href="{{ route('registries', 'housing_assistances') }}" class="nav-link ">
                            <span class="title">Housing Assistance</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'mental_health_assistances')?'open':'' }}">
                        <a href="{{ route('registries', 'mental_health_assistances') }}" class="nav-link ">
                            <span class="title">Mental Health Assistance</span>
                        </a>
                    </li>
                     <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'home_health_providers')?'open':'' }}">
                        <a href="{{ route('registries', 'home_health_providers') }}" class="nav-link ">
                            <span class="title">Home Health Provider</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item {{ ($active == 'care-plan')?'active open':'' }}">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-tasks"></i>
                    <span class="title">Care Plan</span>
                    @if($active == 'care-plan')
                        <span class="selected"></span>
                    @endif
                    <span class="arrow {{ ($active == 'care-plan')?'open':'' }}"></span>
                </a>
                <ul class="sub-menu" style="display: {{ ($active == 'care-plan')?'active open':'' }};">
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'diagnosis')?'open':'' }}">
                        <a href="{{ route('diagnosis') }}" class="nav-link ">
                            <span class="title">Diagnosis</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'tools')?'open':'' }}">
                        <a href="{{ route('get_careplan_tools') }}" class="nav-link ">
                            <span class="title">Tools</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'goals')?'open':'' }}">
                        <a href="{{ route('get_careplan_goals') }}" class="nav-link ">
                            <span class="title">Goals</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'barriers')?'open':'' }}">
                       <a href="{{ route('get_careplan_barriers') }}" class="nav-link ">
                            <span class="title">Barriers</span>
                        </a>
                    </li>

                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'contents')?'open':'' }}">
                       <a href="{{ route('get_content_discussed') }}" class="nav-link ">
                            <span class="title">Content Discussed</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'metrices')?'open':'' }}">
                        <a href="{{ route('get_careplan_settings',['metrices']) }}" class="nav-link ">
                            <span class="title">Metrices</span>
                        </a>
                    </li>
                    <li class="nav-item  {{ (isset($sub_active) &&  $sub_active == 'flags')?'open':'' }}">
                        <a href="{{ route('get_careplan_settings',['flags']) }}" class="nav-link ">
                            <span class="title">Flags</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- END SIDEBAR MENU -->
        <!-- END SIDEBAR MENU -->
    </div>
    <!-- END SIDEBAR -->
</div>
<!-- END SIDEBAR -->
