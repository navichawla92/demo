<!-- BEGIN FOOTER -->
<div class="page-footer">
  <div class="page-footer-inner">   {{ date("Y") }} &copy; Wellpop
   
  </div>
  <div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
  </div>
</div>
<!-- END FOOTER -->

<script src="{{ asset('assets/global/plugins/jquery.min.js') }}" type="text/javascript"></script> 
<script src="{{ asset('assets/global/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/waitMe.js') }}" type="text/javascript"></script>  
<script src="{{ asset('js/bootbox.min.js') }}" type="text/javascript"></script>



<script src="{{ asset('assets/global/plugins/js.cookie.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/jquery.blockui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js') }}" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="{{ asset('assets/global/scripts/datatable.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/datatables/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js') }}" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="{{ asset('assets/global/scripts/app.min.js') }}" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="{{ asset('assets/pages/scripts/table-datatables-responsive.min.js') }}" type="text/javascript"></script>
<!-- END PAGE LEVEL SCRIPTS -->
<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="{{ asset('assets/layouts/layout/scripts/layout.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/layouts/layout/scripts/demo.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/jstz.min.js') }}" type="text/javascript"></script> 
<script type="text/javascript">
 $('body').waitMe();
 $.ajaxSetup({
        type:"POST",
        headers: {
    			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    		},
        beforeSend:function(){
            $('body').waitMe();
        },
        complete:function(){
            $('body').waitMe('hide');
        },
        error:function(error){
            $.each(error.responseJSON.errors,function(key,value){
                $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
                $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            });

            jQuery('html, body').animate({
                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
            }, 500);

        }
    });
  $.each(document.cookie.split(/; */), function()  {
          
      document.cookie = 'name=client_timezone; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        var splitCookie = this.split('=');
        if (this.indexOf('client_timezone') == 0) {
          document.cookie = splitCookie[0] + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        }

      });     
      var tz = jstz.determine(); // Determines the time zone of the browser client
      var tz_cookie =  tz.name();
      document.cookie = 'client_timezone='+tz_cookie;


$(document).on('click',".delete_model_by_id",function(event){
	event.preventDefault();
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
	console.log(CSRF_TOKEN);
	var id = $(this).data('id');
   var model = $(this).data('model');
   var type = $(this).data('type');
   var message = 'Are you sure you want to delete this item?';

   if(model != 'Registry') {
       message = message.replace("item", model.toLowerCase());
       //message = 'Are you sure you want to delete this tool?';
   }

  /* if(model == 'Diagnosis'){
       message = 'Are you sure you want to delete this diagnosis?';
   }


  if(model == 'Goal'){
      message = 'Are you sure you want to delete this goal?';
  }*/

   bootbox.confirm(message, function(result) {
       if(result)
       {
           $.ajax({
               url:"{{ route('registry_delete') }}",
               data:{id:id,model:model,type:type},
               success:function(data){
                   location.reload();
               },
               error:function(data){
                   location.reload();
               }
           });
       }
   });

});      


// hide all validation error after 5 sec
$(document).ready(function(){
  fadeOutAlertMessages();
});

// hide all validation error after 5 sec
    function fadeOutAlertMessages(){
      setTimeout(function(){
           $(document).find('.alert-success').slideUp(500);
           $(document).find(".alert-error").slideUp(500);
           $(document).find(".alert-danger").slideUp(500);
       },5000);
    } 

function formData(formId){
    $(".set_phone_format").inputmask('remove');
      $(formId).find(".save_button").attr("disabled", "disabled");
    $(formId).submit();
}

$(".nav-link").on("click", function(){
  $('.datatable').DataTable().state.clear();
});

$(document).ready(function() {
    $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});
   
});

 function applpyEllipses(table_identifier, no_of_tds, any_link_in_td){
          if($('.'+table_identifier+' tr td').length > 1)
          {
            $('.'+table_identifier+' tr').find('td:lt('+no_of_tds+')').each(function(i, v){
                var len = $(this).clone().children().remove().end().text().length;
                if(len > 40 && $(this).children().length == 0)
                {
                  var text = $(this).clone().children().remove().end().text();  
                  $(this).attr('title', text);
                  $(this).html(text.substring(0,40)+'...');
                }
            });
          }
    }

function saveFormWithoutAjax(formId,btn){
    $(formId).find(".save_button").attr("disabled", "disabled");
    if(btn == 'save_and_close'){
        $(formId).submit(function(eventObj) {
            $(this).append('<input type="hidden" name="submit_btn_type" value=1>');
            return true;
        });
    }
    else if(btn == 'save_and_add_new'){
        $(formId).submit(function(eventObj) {
            $(this).append('<input type="hidden" name="submit_btn_type" value=0>');
            return true;
        });
    }
    $(formId).submit();
}
    
function add_cross_to_search(){  
  $(".dataTables_filter input[type='search']").addClass('pad_right');
  $(".dataTables_filter input[type='search']").keypress(function(){
      if($('.search_cross').length <1)
      $(this).after('<i class="fa fa-times search_cross"></i>');
  })
  $(document).on('click',".search_cross",function(event){
    $(".dataTables_filter").find('.search_cross').remove();
    $(".datatable").DataTable().search("").draw()
  });   
  if($(".dataTables_filter input[type='search']").val() && $(".dataTables_filter input[type='search']").val().length > 0)
    $(".dataTables_filter input[type='search']").after('<i class="fa fa-times search_cross"></i>');
}



$(window).load(function(){
   $('body').waitMe('hide'); 
   add_cross_to_search();
});
</script>

@yield('script')
