<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Wellpop: @yield('title')</title>
        
        <!-- Styles -->
        @include('admin.layouts.head')
        <link href="{{ asset('css/jquery-ui.css') }}" rel="stylesheet">
        <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">

    </head>
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
    
        @include('admin.layouts.header')

        <div class="page-container">
            @include('admin.layouts.aside')
            @yield('content')
        </div>
    
        @include('admin.layouts.footer')
    
        <script src="{{ asset('js/jquery-ui.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('js/session_timeout.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
        <script src="{{ asset('js/inputmask.js') }}" type="text/javascript"></script>
        <script type="text/javascript">
            $.sessionTimeout({
                message: 'Your session will be locked in five minute.',
                logoutUrl: '{{ route("admin-logout") }}',
                redirUrl: '{{ route("admin-logout") }}',
                keepAliveUrl: '{{ route("keep-session-alive") }}',
                warnAfter: 600000,
                redirAfter: 900000,
                keepAlive:false,
                keepBtnClass: 'btn btn-success',
                keepBtnText: 'Extend session',
                logoutBtnClass: 'btn btn-light',
                logoutBtnText: 'Log me out'
            });
        </script>

    </body>
</html>
