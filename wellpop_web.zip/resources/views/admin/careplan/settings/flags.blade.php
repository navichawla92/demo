@extends('admin.layouts.app')

@section('title')
   {{ trans('label.flags_listing') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
         <div class="page-bar">
            <ul class="page-breadcrumb">
                  <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.care_plan') }} </span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.flags') }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="fa fa-flag font-dark"></i>
                            <span class="caption-subject bold uppercase">{{ trans('label.flags') }}</span>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover table-align-center datatable">
                            <thead>
                                <tr>
                                    <th width="50%">{{ trans('label.flag_name') }} </th>
                                    <th width="50%">{{ trans('label.flag_color') }} </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort:false,
       // ajax: '{{ route('datatable/getManageAbleField') }}',
        ajax: '{{ route('datatable/get_careplan_settings',[$sub_active]) }}',
        columns: [
            {data: 'name', name: 'name',orderable: false},
            {data: 'value', name: 'value',orderable: false},
        ],
        "bPaginate": false,
        "bFilter": false,
        "bInfo": false
    });
});
</script>
@endsection
