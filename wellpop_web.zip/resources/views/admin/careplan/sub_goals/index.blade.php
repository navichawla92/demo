  <div class="personliving">
    @if(session()->has('message.SubGoal-level'))
        <div class="alert alert-{{ session('message.SubGoal-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.description') }}</th>
            <th> {{ trans('label.role') }} </th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($subgoals))
            <?php  $index=($subgoals->perPage() * ($subgoals->currentPage()- 1))+1; ?>
            @foreach($subgoals as $subgoal)
                
              <tr>
                <td>{{$index}}</td>
                <td>{{ $subgoal->description }}</td>
                <td>{{ $subgoal->getRoles() }}</td>
                <td>
                    <a href="javascript:;"
                       data-id="{{ $subgoal->id }}"
                       data-description="{{ $subgoal->description }}"
                       data-roles="{{ implode(',', $subgoal->assigned_roles) }}"
                       onclick="editSubGoal(this)"
                       style="color:orange"
                       class=""
                       title="Edit"><i class="fa fa-pencil"></i>
                    </a>
                    <a style="color:red" href="javascript:;" data-id="{{ encrypt_decrypt('encrypt', $subgoal->id) }}" data-type="subgoals" onclick="deleteGoalByType(this)"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>
  <div class="subgoals-pagination" data-table-class="subgoals_table">
    @if(count($subgoals))
      <?php echo $subgoals->appends(['goal_id' => encrypt_decrypt('encrypt',$goal->id), 'type' => 'subgoals'])->render(); ?>
    @endif
  </div>