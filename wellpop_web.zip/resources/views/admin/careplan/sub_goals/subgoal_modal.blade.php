<div class="modal addTypeModal fade" data-backdrop="static" data-keyboard="false" id="add_subgoals" tabindex="-1" role="basic" aria-hidden="true">

    {!! Form::Open(['id' => 'add_subgoals-form']) !!}
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">{{trans('label.sub_goals_steps_tasks')}}</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            {{ Form::label('description',trans('label.enter_sub_goal_description')) }}*
                            {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"1000"]) !!}
                            <span class="error" style="color:red"></span>
                        </div>
                        <div class='form-group'>
                        {{ Form::label('role',trans('label.select_role')) }}* <br>
                            @foreach ($roles as $role)
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="assigned_roles[]" value="{{ $role->id }}">{{ ucfirst($role->name) }}
                                </label>
                            @endforeach
                        {!! Form::hidden('goal_id', $goal->id ? encrypt_decrypt('encrypt', $goal->id) : 0 ,array("class" => "goal_id")) !!} <br>
                        {!! Form::hidden('id',0) !!}
                         <span class="error roles_error" style="color:red"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_subgoals-form','save_and_close','subgoals')" >Save and Close</button>
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_subgoals-form','save_and_add_new','subgoals')">Save and Add New</button>
                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    {!! Form::close() !!}
</div>



