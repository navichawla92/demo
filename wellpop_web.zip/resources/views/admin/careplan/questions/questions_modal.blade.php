<div class="modal addTypeModal fade" data-backdrop="static" data-keyboard="false" id="add_questions" tabindex="-1" role="basic" aria-hidden="true">

    {!! Form::Open(['id' => 'add_questions-form']) !!}
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">{{ trans('label.add_question') }} Add Question </h4>
            </div>
            <div class="modal-body">
                 <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            {{ Form::label('description',trans('label.enter_question')) }}*
                            {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"1000"]) !!}
                            <span class="error" style="color:red"></span>
                        </div>
                        <div class="form-group">
                            {{ Form::label('metric_id', trans('label.metric')) }}*
                            {!! Form::select('metric_id', ['' => 'Please Select'] + $metrics->toArray(),null,array("class" => "form-control")) !!}
                            <span class="error" style="color:red"></span>
                        </div>

                        <div class='form-group'><br>
                            {{ Form::label('role',trans('label.select_role')) }}* <br> 
                            @foreach ($roles as $role)
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="assigned_roles[]" value="{{ $role->id }}">
                                    <span>{{ ucfirst($role->name) }}</span>
                                </label>
                            @endforeach
                            {!! Form::hidden('goal_id', $goal->id ? encrypt_decrypt('encrypt', $goal->id) : 0 ,array("class" => "goal_id")) !!} <br>
                            {!! Form::hidden('id',0) !!}
                             <span class="error roles_error" style="color:red"></span>
                        </div>
                    </div>
                </div>
                 
            </div>
            <div class="modal-footer">
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_questions-form','save_and_close','questions')" >{{ trans('label.save_and_close') }}</button>
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_questions-form','save_and_add_new','questions')">{{ trans('label.save_and_add_new') }}</button>
                <button type="button" class="btn default" data-dismiss="modal">{{ trans('label.cancel') }}</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    {!! Form::close() !!}
</div>
