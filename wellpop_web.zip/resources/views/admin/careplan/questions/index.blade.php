  <div class="personliving">
    @if(session()->has('message.Questions-level'))
        <div class="alert alert-{{ session('message.Questions-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.question') }}</th>
            <th>{{ trans('label.metric') }}</th>
            <th> {{ trans('label.role') }} </th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($questions))
            <?php  $index=($questions->perPage() * ($questions->currentPage()- 1))+1; ?>
            @foreach($questions as $question)
                
              <tr>
                <td>{{$index}}</td>
                <td>{{ $question->description }}</td>
                <td>{{ $question->metric->name }}</td>
                <td>{{ $question->getRoles() }}</td>
                <td>
                  <a href="javascript:;"
                     data-id="{{ encrypt_decrypt('encrypt', $question->id) }}"
                     data-description="{{ $question->description }}"
                     data-roles="{{ implode($question->assigned_roles,',') }}"
                     data-metric-id="{{ $question->metric_id }}"

                     onclick="editQuestion(this)"
                     style="color:orange"
                     class=""
                     title="Edit"><i class="fa fa-pencil"></i></a>
                    <a style="color:red" href="javascript:;" data-id="{{ encrypt_decrypt('encrypt', $question->id) }}" data-type="questions" onclick="deleteGoalByType(this)"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>


<div class="questions-pagination" data-table-class="questions_table">
      @if(count($questions))
          <?php echo $questions->appends(['goal_id' => encrypt_decrypt('encrypt',$goal->id), 'type' => 'questions'])->render(); ?>
      @endif
</div>