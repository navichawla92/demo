<div class="modal addTypeModal fade" data-backdrop="static" data-keyboard="false" id="add_barriers" tabindex="-1" role="basic" aria-hidden="true">
     {!! Form::Open(['id' => 'add_barriers-form']) !!}

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">{{ trans('label.add_barriers') }} </h4>
            </div>
            
            
              <div class="modal-body">
                  <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            {{ Form::label('barrier_id', trans('label.add_barriers_from_registry')) }}*
                            {!! Form::select('barrier_id[]',[],null,array("class" => "multi_select_chosen",'id'=>"select_chosen_barriers",'multiple','data-type'=>'barriers', 'data-placeholder' => trans('label.search_by_barrier_title'))) !!}
                            <span class="error" style="color:red"></span>
                        </div>
                        
                        {!! Form::hidden('goal_id', $goal->id ? encrypt_decrypt('encrypt', $goal->id) : 0 ,array("class" => "goal_id")) !!} <br>
                        {!! Form::hidden('id',0) !!}
                    </div>
                  </div>
                 
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_barriers-form','save_and_close','barriers')" >{{ trans('label.save_and_close') }}</button>
               
                <button type="button" class="btn default" data-dismiss="modal">{{ trans('label.cancel') }}</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    {!! Form::close() !!}
</div>

<div class="modal fade view_modal viewbarriers" id="view_barrier" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">{{ trans('label.view_barrier_details') }} </h4>
            </div>
            <div class="modal-body">
                <p> <b>{{ trans('label.barrier_id') }}</b>:<span class="barrier_id"></span></p>
                <p> <b>{{ trans('label.barrier_title') }}</b>:<span class="barrier_title"></span></p>
                <p> <b>{{ trans('label.barrier_desc') }}</b>:<span class="barrier_description"></span></p>
                <p> <b>{{ trans('label.barrier_solution') }}</b>:<span class="barrier_solution"></span></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn default" data-dismiss="modal">{{ trans('label.close') }}</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
