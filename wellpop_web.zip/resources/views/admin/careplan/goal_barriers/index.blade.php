  <div class="personliving">
    @if(session()->has('message.Barriers-level'))
        <div class="alert alert-{{ session('message.Barriers-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>{{ trans('label.barrier_id') }}</th>
            <th> {{ trans('label.barrier_title') }} </th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($barriers))
            <?php  $index=($barriers->perPage() * ($barriers->currentPage()- 1))+1; ?>
            @foreach($barriers as $barrier)
                
              <tr>
                <td>{{$index}}</td>
                <td>{{ $barrier->code }}</td>
                <td>{{ $barrier->title }}</td>
                <td>
                  <div class="dropdown more-btn dropup">
                      <a href="javascript:;"
                         data-id="{{ encrypt_decrypt('encrypt', $barrier->id) }}"
                         data-barrier_description="{{ $barrier->description }}"
                         data-barrier_id="{{ $barrier->code }}"
                         data-barrier_solution="{{ $barrier->solution }}"
                         data-barrier_title="{{ $barrier->title }}"
                         style="color:orange" class="view_barriers" title="View">
                         <i class="fa fa-eye"></i>
                      </a>
                    <a style="color:red" href="javascript:;"
                       data-id="{{ encrypt_decrypt('encrypt', $barrier->id) }}"
                       data-type="barriers"
                       onclick="deleteGoalByType(this)"><i class="fa fa-trash" aria-hidden="true"></i></a>

                  </div>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>

<div class="barriers-pagination" data-table-class="barriers_table">
    @if(count($barriers))
       <?php echo $barriers->appends(['goal_id' => encrypt_decrypt('encrypt',$goal->id), 'type' => 'barriers'])->render(); ?>
    @endif
</div>







