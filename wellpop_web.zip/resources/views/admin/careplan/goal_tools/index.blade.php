  <div class="personliving">
    @if(session()->has('message.Tools-level'))
        <div class="alert alert-{{ session('message.Tools-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th> {{trans('label.tool_id')}} </th>
            <th> {{trans('label.tool_desc')}} </th>
            <th> {{trans('label.tool_type')}} </th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($tools))
            <?php  $index=($tools->perPage() * ($tools->currentPage()- 1))+1; ?>
            @foreach($tools as $tool)
                
              <tr>
                <td>{{$index}}</td>
                <td>{{ $tool->code }}</td>
                <td>{{ $tool->description }}</td>
                <td>{{ $tool->type }}</td>
                <td>

                    <a style="color:orange"
                       href="javascript:;"
                       data-id="{{ $tool->code }}"
                       data-title="{{ $tool->title }}"
                       data-description="{{ $tool->description }}"
                       data-type="{{ $tool->type }}"
                       data-location="@if($tool->type == 'Online') {{ $tool->location }} @else {{ config('filesystems.s3_tool_documents_full_path').$tool->location }} @endif"
                       onclick="viewToolDetails(this)"
                       target="_blank"
                    ><i class="fa fa-eye" aria-hidden="true"></i></a>

                    <a style="color:red" href="javascript:;" data-id="{{ encrypt_decrypt('encrypt', $tool->id) }}" data-type="tools" onclick="deleteGoalByType(this)"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>


<div class="tools-pagination" data-table-class="tools_table">
  @if(count($tools))
      <?php echo $tools->appends(['goal_id' => encrypt_decrypt('encrypt',$goal->id), 'type' => 'tools'])->render(); ?>
  @endif
</div>

