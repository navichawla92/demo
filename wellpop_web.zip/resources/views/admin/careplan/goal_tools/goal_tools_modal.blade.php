<div class="modal addTypeModal fade" data-backdrop="static" data-keyboard="false" id="add_tools" tabindex="-1" role="basic" aria-hidden="true">

    {!! Form::Open(['id' => 'add_tools-form']) !!}
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title"> {{ trans('label.add_tools_aids') }} </h4>
            </div>
            <div class="modal-body">
                  <div class="row">
                    <div class="col-md-10">
                        <div class="form-group">
                            {{ Form::label('tool_id', trans('label.add_tools_from_registry')) }}*
                            {!! Form::select('tool_id[]',[],null,array("class" => "multi_select_chosen",'id'=>"select_chosen_tools",'multiple','data-type'=>'tools', 'data-placeholder' => trans('label.search_by_tool_or_id'))) !!}
                            <span class="error" style="color:red"></span>
                        </div>
                        
                        {!! Form::hidden('goal_id', $goal->id ? encrypt_decrypt('encrypt', $goal->id) : 0 ,array("class" => "goal_id")) !!} <br>
                        {!! Form::hidden('id',0) !!}
                    </div>
                  </div>
                 
            </div>
             <div class="modal-footer">
                <button type="button" class="btn blue model_box_save" onClick="javascript:saveModalByType('#add_tools-form','save_and_close','tools')" >{{ trans('label.save_and_close') }}</button>
                <button type="button" class="btn default" data-dismiss="modal">{{ trans('label.cancel') }}</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    {!! Form::close() !!}
</div>
