<div class="modal fade view_modal viewTool" id="view_tool" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">View Tool Details </h4>
            </div>
            <div class="modal-body">
                <p> <b>{{trans('label.tool_id')}}</b>: <span class="tool_id"></span></p>
                <p> <b>{{trans('label.view_tool_title')}}</b>: <span class="tool_title"></span></p>
                <p> <b>{{trans('label.tool_desc')}}</b>:     <span class="tool_description"></span></p>
                <p> <b>{{trans('label.tool_type')}}</b>:     <span class="tool_type"></span></p>
                <p> <b>{{trans('label.tool_link')}}</b>: <span class="tool_location"></span></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn default" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
