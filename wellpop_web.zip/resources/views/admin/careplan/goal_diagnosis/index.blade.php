  <div class="personliving">
    @if(session()->has('message.Diagnosis-level'))
        <div class="alert alert-{{ session('message.Diagnosis-level') }} alert-dismissible"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          {!! session('message.content') !!}
        </div>
    @endif 
    <div class="table-responsive care-table common-note-table" style="overflow: auto;" id="notes_table" data-tab-name="notes">
      <table class="table">
        <thead>
          <tr>
            <th>{{ trans('label.serial_number_short_form') }}</th>
            <th>Diagnosis Title</th>
            <th>{{ trans('label.action') }}</th>
          </tr>
        </thead>
        <tbody>
          @if(count($diagnosis))
            <?php  $index=($diagnosis->perPage() * ($diagnosis->currentPage()- 1))+1; ?>
            @foreach($diagnosis as $diagnosisData)
                
              <tr>
                <td>{{$index}}</td>
                <td>{{ $diagnosisData->title }}</td>
                <td>
                  <div class="dropdown more-btn dropup">
                    <a style="color:red" href="javascript:;" data-id="{{ encrypt_decrypt('encrypt', $diagnosisData->id) }}" data-type="diagnosis" onclick="deleteGoalByType(this)"><i class="fa fa-trash" aria-hidden="true"></i></a>  
                  </div>
                </td>
              </tr>
              <?php  $index++; ?>
            @endforeach
          @else
            <tr> <td>{{ trans('label.no_record_found') }} </td></tr>
          @endif
        </tbody>
      </table>
      
    </div>
  </div>


<div class="diagnosis-pagination" data-table-class="diagnosis_table">
  @if(count($diagnosis))
      <?php echo $diagnosis->appends(['goal_id' => encrypt_decrypt('encrypt',$goal->id), 'type' => 'diagnosis'])->render(); ?>
  @endif
</div>