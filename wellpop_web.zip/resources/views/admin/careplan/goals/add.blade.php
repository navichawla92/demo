@extends('admin.layouts.app')

@section('title')
   {{ $goal->id ? trans('label.edit_goal') : trans('label.add_new_goal') }}
@endsection

@section('content')
<?php
    $goal_type = goal_type();
    $is_flag = is_flag();
?>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}"> {{trans('label.dashboard')}} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{trans('label.care_plan')}} </span>
                    <i class="fa fa-circle"></i>
                </li>
                 <li>
                    <a href="{{ route('get_careplan_goals') }}"> {{trans('label.goals')}} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $goal->id ? trans('label.edit_goal') : trans('label.add_new_goal') }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->

        <div class="nav-top">
        <div class="row">
            <div class="col-md-7 ">
               <h4>{{ $goal->id ? trans('label.edit_goal') : trans('label.add_new_goal') }}</h4>
            </div>
             <div class="col-md-5 ">
                <div class="btn-boxy">
                
                    <button type="button" class="btn blue save_button " onClick="javascript:saveForm('#add_goal_form','save_and_add_new')" >{{trans('label.save')}}</button>

                    <button type="button" class="btn blue save_button" onClick="javascript:saveForm('#add_goal_form','save_as_draft')" >{{trans('label.save_as_draft')}}</button>
               
                    <a class="btn default close_form" href="#" > {{trans('label.cancel')}}</a>
             </div>
             </div>

        </div>
    </div>
     <div class="nav-box">
        <div class="row">

          <div class="col-md-3 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
            <nav class="navigation" id="mainNav">
                <a class="navigation__link active" href="#1"> {{ trans('label.enter_goal_details') }} </a>
                <a class="navigation__link {{ $goal->id ? '' : 'disable_section' }}" href="#2">{{ trans('label.add_sub_goals') }} </a>
                <a class="navigation__link {{ $goal->id ? '' : 'disable_section' }}" href="#3">{{ trans('label.add_questions') }} </a>
                <a class="navigation__link {{ $goal->id ? '' : 'disable_section' }}" href="#4">{{ trans('label.add_tools') }} </a>
                <a class="navigation__link {{ $goal->id ? '' : 'disable_section' }}" href="#5">{{ trans('label.add_barriers') }} </a>
                <a class="navigation__link {{ $goal->id ? '' : 'disable_section' }}" href="#6">{{ trans('label.goal_alignment') }} </a>
            </nav>
          </div>
          <div class="col-md-9 loader_div">          

            <div class="page-section hero" id="1">
                   <div class="portlet-body form">
                    {!! Form::model($goal, ['id'=>'add_goal_form']) !!}
                    <span class="error" id="goal_assignment_subgoal_required" style="color:red"></span>
                   

                    <input type="hidden" class="is_added" name="is_added">
                    <input type="hidden" name="id" class="ref_field_id" value="{{$goal->id ? encrypt_decrypt('encrypt', $goal->id) : '' }}">
                       <div class="row">
                        <div class='col-md-10'>
                        <div class="form-group">
                            {{ Form::label('title', trans('label.enter_goal_title')) }}*
                            {{ Form::text('title', null, array('class' => 'form-control','maxlength'=>'1000')) }}
                            <span class="help-block" style="font-size: 13px; margin-top:0;">Note: Goal title is required to enter the details of sub goals, questions, tools, barriers & solution and diagnosis.</span>
                            <span class="error" style="color:red"></span>
                        </div>
                        <div class="form-group">
                            {{ Form::label('description',trans('label.enter_goal_description')) }}*
                            {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"10000"]) !!}
                            <span class="error" style="color:red"></span>
                        </div>
                       <div class='row'>
                            <div class='col-md-4'>
                                <div class="form-group">
                                    {{ Form::label('type', trans('label.goal_type')) }}*
                                      {!! Form::select('type', array('' => trans('label.please_select')) + $goal_type,null,array("class" => "form-control goal_type")) !!} 
                                     <span class="error" style="color:red"></span>
                                </div>
                            </div>

                            {!! Form::hidden('goal_id', $goal->id ? encrypt_decrypt('encrypt', $goal->id) : '',array("id" => "goal_id")) !!}



                            <div class='col-md-4'>
                                <div class="form-group">

                                @if($goal->id)
                                {{ Form::label('metric_id', trans('label.metric')) }}*
                                    {!! Form::select('metric_id', array('' => trans('label.please_select')) + $metrics->toArray(),null,array("class" => "form-control")) !!}
                                @else
                                    {{ Form::label('metric_id', trans('label.metric')) }}*
                                    {!! Form::select('metric_id', array('' => trans('label.please_select')) + $metrics->toArray(),null,array("class" => "form-control","disabled"=>true)) !!}
                                @endif
                                    <span class="error" style="color:red"></span>
                                </div>
                            </div>
                             <div style="display: none" class="metricIdOption">{{json_encode($metrics->toArray())}} </div>
                            <div class='col-md-4'>
                                <div class="form-group">
                                    {{ Form::label('flag', trans('label.flags')) }}
                                    {!! Form::select('flag', array('' => trans('label.please_select')) + $is_flag,null,array("class" => "form-control")) !!}
                                    <span class="error" style="color:red"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div> 
                    {{ Form::close() }}         
                </div>
            </div>
            <div class="goal_data {{ $goal->id ? '' : 'disable_section' }}">
                <div class="page-section" id="2">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                 <i class="fa fa-wrench font-dark"></i>
                                <span class="caption-subject bold uppercase"> {{ trans('label.sub_goals_steps_tasks') }} </span>
                            </div>
                            <div class="btn-group pull-right">
                                <a href="#" id="sample_editable_1_new" class="btn sbold green" onClick="javascript:openModalByType('subgoals')"> <i class="fa fa-plus"></i> {{trans('label.add')}} </a>
                            </div>
                        </div>
                        <div class="portlet-body subgoals_table">
                           @include('admin.careplan.sub_goals.index')
                        </div>
                    </div>
                </div>
                <div class="page-section" id="3">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                 <i class="fa fa-wrench font-dark"></i>
                                <span class="caption-subject bold uppercase">  {{ trans('label.questions_to_ask') }}  </span>
                            </div>
                            <div class="btn-group pull-right">
                                <a href="javascript:;" id="sample_editable_1_new" class="btn sbold green" onClick="javascript:openModalByType('questions')"> <i class="fa fa-plus"></i> {{trans('label.add')}} </a>
                            </div>
                        </div>
                        <div class="portlet-body questions_table">
                            @include('admin.careplan.questions.index')
                        </div>
                    </div>
                </div>
                <div class="page-section" id="4">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                 <i class="fa fa-wrench font-dark"></i>
                                <span class="caption-subject bold uppercase"> {{ trans('label.tools_aids') }}  </span>
                            </div>
                            <div class="btn-group pull-right">
                                <a href="javascript:;" id="sample_editable_1_new" class="btn sbold green" onClick="javascript:openModalByType('tools')"> <i class="fa fa-plus"></i> {{trans('label.add')}} </a>
                            </div>
                        </div>
                        <div class="portlet-body tools_table">
                            @include('admin.careplan.goal_tools.index')
                        </div>
                    </div>
                </div>
                <div class="page-section" id="5">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                 <i class="fa fa-wrench font-dark"></i>
                                <span class="caption-subject bold uppercase"> {{ trans('label.barriers_and_solutions') }} </span>
                            </div>
                            <div class="btn-group pull-right">
                                <a href="javascript:;" id="sample_editable_1_new" class="btn sbold green" onClick="javascript:openModalByType('barriers')"> <i class="fa fa-plus"></i> {{trans('label.add')}} </a>
                            </div>
                        </div>
                        <div class="portlet-body barriers_table">
                            @include('admin.careplan.goal_barriers.index')
                        </div>
                    </div>
                </div>
                <div class="page-section" id="6">
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                 <i class="fa fa-wrench font-dark"></i>
                                <span class="caption-subject bold uppercase"> {{ trans('label.goal_alignment_to_diagnosis') }} </span>
                            </div>
                            <div class="btn-group pull-right">
                                <a href="javascript:;" id="sample_editable_1_new" class="btn sbold green" onClick="javascript:openModalByType('diagnosis')"> <i class="fa fa-plus"></i> {{trans('label.add')}} </a>
                            </div>
                        </div>
                        <div class="portlet-body diagnosis_table">
                            @include('admin.careplan.goal_diagnosis.index')
                        </div>
                    </div>
                </div>
            </div>
                <!-- END SAMPLE FORM PORTLET-->
          </div>
        </div>
    </div>
    </div>
</div>

<!-- Modal Box for Subgoals -->
@include('admin.careplan.sub_goals.subgoal_modal')

<!-- Modal Box for Questions -->

@include('admin.careplan.questions.questions_modal')

<!-- Modal Box for Barriers -->

@include('admin.careplan.goal_barriers.barriers_modal')

<!-- Modal Box for Tools -->

@include('admin.careplan.goal_tools.goal_tools_modal')
@include('admin.careplan.goal_tools.view_tool_modal')

<!-- Modal Box for Diagnosis -->

@include('admin.careplan.goal_diagnosis.goal_diagnosis_modal')

@endsection

@section('script')
<script src="{{ asset('js/ajaxSetup.js') }}" type="text/javascript"></script> 
<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
<script type="text/javascript">

function saveForm(formId,button_pressed){
    $(formId).find(".save_button").attr("disabled", "disabled");
    $('span.error').hide().removeClass('active');
    var formData = new FormData($(formId)[0]);
    if(button_pressed == 'save_and_proceed'){
            formData.append('status',3);
    }
    else if(button_pressed == 'save_as_draft'){
            formData.append('status',0);
    }
    else if(button_pressed == 'save_and_add_new'){
            formData.append('status',1);
    }
    $.ajax({
        url:"{{ route('goal-edit') }}",
        data:formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success:function(data){
          $(formId).find(".save_button").removeAttr("disabled");
          if(button_pressed !='save_and_proceed'){
            $('input,textarea,select').removeClass('changed-input');
          }
          $(formId).find(".save_and_proceed").hide();
          $('input[type=hidden][name=goal_id]').val(data.encrypted_goal_id);
          $('.goal_data').removeClass('disable_section');
          $('.page-section').each(function(i) {
            $('.navigation a').removeClass('disable_section');
          });
          if(button_pressed == 'save_as_draft' || button_pressed == 'save_and_add_new'){
            window.location.href="{{ route('get_careplan_goals') }}";
          }

        },
        error:function(error){
            $(formId).find(".save_button").removeAttr("disabled");
            $.each(error.responseJSON.errors,function(key,value) {

                if(key === 'goal_assignment_subgoal_required' || key === 'goal_assignment_question_required'  || key === 'goal_assignment_diagnosis_required' ) {
                    $('#'+key+'').html(value).addClass('active').show();
                  //  $('#'+key+'').html(value).addClass('active').show()
                } else {
                    $('input[name="'+key+'"]',$(formId)).parent().find('span.error').html(value).addClass('active').show();
                    $('textarea[name="'+key+'"]',$(formId)).parent().find('span.error').html(value).addClass('active').show();
                    $('select[name="'+key+'"]',$(formId)).parent().find('span.error').html(value).addClass('active').show();
                }

            });

            jQuery('html, body').animate({
                scrollTop: jQuery(document).find('.error.active:first').parent().offset().top-200
            }, 500);
           

        }
    });
}


function openModalByType(type){
    let goal_id = $('#goal_id').val();
    if(goal_id) {

        if(type === 'subgoals') {
            var form = $('#add_subgoals-form');
            $('[name="id"]',form).val(0);
            form[0].reset();
            $('.modal-title', $('#add_subgoals')).text('Add Sub Goals/Steps/Tasks');
        }


        if(type === 'questions') {
            var form = $('#add_questions-form');
            $('[name="id"]',form).val(0);
            form[0].reset();
            $('.modal-title', $('#add_questions')).text('Add Question');
        }

        if(type === 'diagnosis' || type === 'tools' || type === 'barriers' ) {
            $(".multi_select_chosen option").remove();
            $('.multi_select_chosen').val('').trigger('chosen:updated');
            $('.multi_select_chosen').val('').trigger('chosen:updated');
        }

        $('#add_'+type+'').find('.goal_id').val(goal_id);
        $('#add_'+type+'').modal('show');
        if(type == 'tools'){
            chosenDropDown('select_chosen_tools')
        }
        if(type == 'diagnosis'){
            chosenDropDown('select_chosen_diagnosis')
        }
        if(type == 'barriers'){
            chosenDropDown('select_chosen_barriers')
        }
    }
    else {
    //  alert('please create a goal');
    }
}


function saveModalByType(formId,button_pressed,type){
    $(formId).find(".model_box_save").attr("disabled", "disabled");
    $('span.error').hide().removeClass('active');
    var formData = new FormData($(formId)[0]);
    formData.append('save_type',type);
    $.ajax({
        url:"{{ route('goal-data') }}",
        data:formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success:function(data){
          $(formId).find(".model_box_save").removeAttr("disabled");
          if(button_pressed == 'save_and_close'){
               $('#add_'+type+'').modal('hide');
               $(formId).find('input[name=id]').val('');
          }
          if(type === 'diagnosis' || type === 'tools' || type === 'barriers') {
                $(".multi_select_chosen option").remove();
                $('.multi_select_chosen').val('').trigger('chosen:updated');
                $('.multi_select_chosen').val('').trigger('chosen:updated');
          }
          $(formId)[0].reset();
          initializePaginationByType(type, true);
          if(button_pressed == 'save_and_add_new')
          {
              $('.' + type + '_table').addClass('hide_success');
          } else {
              $('.' + type + '_table').removeClass('hide_success');
          }

        fadeOutAlertMessages();
    },
    error:function(error){
        $(formId).find(".model_box_save").removeAttr("disabled");
        $.each(error.responseJSON.errors,function(key,value){
             $(formId).find('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
             $(formId).find('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
             $(formId).find('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
             if(key == 'assigned_roles'){
                $(formId).find('.roles_error').html(value).addClass('active').show();
             }
             if(key == 'tool_id'){
                $(formId).find('select[name="tool_id[]"]').parent().find('span.error').html(value).addClass('active').show();
             }
             if(key == 'diagnosis_id'){
                $(formId).find('select[name="diagnosis_id[]"]').parent().find('span.error').html(value).addClass('active').show();
             }
        }); 

    }
  });
}



$(window).scroll(function() {
        var scrollDistance = $(window).scrollTop();
      //  $('.page-section').css('min-height',430);
        $('.page-section').each(function(i) {
            if ($(this).position().top <= scrollDistance && $('input[type=hidden][name=goal_id]').val() !='') {
              //  console.log($('.navigation a.active').attr('href'));
               // console.log($($('.navigation a.active').attr('href')).height());
                $('.navigation a.active').removeClass('active');
                $('.navigation a').removeClass('disable_section');
                $('.navigation a').eq(i).addClass('active');
                console.log($('.navigation a').eq(i).attr('href'));
                
            }
        });
}).scroll();



$(document).ready(function(){
  $(".multi_select_chosen").chosen({ width:'100%' });
});

  function chosenDropDown(selectID) {
      var xhr = {
          abort: function () {
          }
      };
      var selectData = [];           // data for unique id array
      var type = $('#' + selectID).data('type');
      $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
          minLength: 1,
          source: function (request, response) {
          $('#' + selectID + '_chosen .no-results').hide();
          var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
          $.ajax({
              url: "{{ route('get_data_list_by_type') }}",
              data: {data: inputData, selected_code: $('#' + selectID).val(), type: $('#' + selectID).data('type'), goal_id: $('#goal_id').val()},
              type: 'GET',
              dataType: "json",
              beforeSend: function () {

              },
              success: function (data) {
                  $('#' + selectID).find('option').not(':selected').remove();
                  $.map(data.html, function (item) {
                      if ($.inArray(item.id, selectData) == -1) {
                          if (type == 'tools') {
                              $('#' + selectID).append('<option value="' + item.id + '" data-id = "' + item.id + '">' + item.code + '- ' + item.description + '</option>')
                          }
                          else if (type == 'diagnosis' || type == 'barriers') {
                              $('#' + selectID).append('<option value="' + item.id + '" data-id = "' + item.id + '">' + item.code + '- ' + item.title + '</option>')
                          }
                      }
                  });

                  $('#' + selectID).trigger("chosen:updated");
                  $('.chosen-search-input').val(inputData);
              }
          });
          }
      });

      // Chosen event listen on input change eg: after select data / deselect this function will be trigger
      $('#' + selectID).on('change', function () {
          var domArray = $('#' + selectID).find('option:selected');
          selectData = [];
          for (var i = 0, length = domArray.length; i < length; i++) {
              selectData.push($(domArray[i]).data('id'));
          }
          $('#' + selectID).html(domArray);
          $('#' + selectID).trigger("chosen:updated");
      });

  }

function initializePaginationByType(type, isUpdateReloading = false, initialReloading = false)
{
    if(isUpdateReloading) {
        var containerClass = $('.'+type+'-pagination').attr('data-table-class');
        var current_page =  $('.'+type+'-pagination .pagination').find('.active').text();
        if(current_page != '') {
            var baseURL = $('.'+type+'-pagination .pagination a').eq(0).attr('href');
            var url = new URL(baseURL);
            var query_string = url.search;
            var search_params = new URLSearchParams(query_string);
            search_params.set('page', current_page);
            search_params.set('isListing', 0);
            url.search = search_params.toString();
            baseURL = url.toString();

        } else {
            var goalId = $('#goal_id').val();
            baseURL = '{{ url('admin/careplan/goals/save_data') }}?goal_id='+goalId+'&type='+type+'&isListing=0';
        }

        $.ajax({
            type:'get',
            url: baseURL,
            success:function(data){
                $('.is_added').addClass('changed-input');
                $('.'+containerClass).html(data.html);

                initializePaginationByType(type);
               /* jQuery('html, body').animate({
                    scrollTop: jQuery(document).find('.alert-success:visible').parent().offset().top-200-$('.nav-top').height()
                }, 500);*/
                var id = jQuery(document).find('.alert-success:visible:last').parent().parent().parent().parent().attr('id');
                $('.nav-box a[href=\\#' + id + ']').trigger('click');
                applpyEllipses('table', 5, 'no');
            },
        });
    }

if(initialReloading) {
    var containerClass = $('.'+type+'-pagination').attr('data-table-class');
    var goalId = $('#goal_id').val();
    baseURL = '{{ url('admin/careplan/goals/save_data') }}?goal_id='+goalId+'&type='+type+'&isListing=1';
    $.ajax({
        type:'get',
        url: baseURL,
        success:function(data){
            $('.'+containerClass).html(data.html);
            initializePaginationByType(type);
            applpyEllipses('table', 5, 'no');
        },
    });
}


$('.'+type+'-pagination .pagination a').click(function() {
    var containerClass = $(this).parentsUntil('.'+type+'-pagination').parent().attr('data-table-class');
    $.ajax({
        type:'get',
        url: $(this).attr("href"),
        success:function(data){
            $('.'+containerClass).html(data.html);
            initializePaginationByType(type);
            applpyEllipses('table', 5, 'no');
        },
    });
    return false;
});

}




</script>

<script>
    initializePaginationByType('subgoals');
    initializePaginationByType('diagnosis');
    initializePaginationByType('questions');
    initializePaginationByType('barriers');
    initializePaginationByType('tools');
    function deleteGoalByType(target)
    {
        var message = "Are you sure, you want to remove this?";
        if($(target).attr('data-type') == 'subgoals') {
            message = "Are you sure you want to delete this sub goal?";
        }

        if($(target).attr('data-type') == 'questions') {
            message = "Are you sure you want to delete this question?";
        }

        if($(target).attr('data-type') == 'tools') {
            message = "Are you sure you want to delete this tool?";
        }

        if($(target).attr('data-type') == 'barriers') {
            message = "Are you sure you want to delete this barrier?";
        }

        if($(target).attr('data-type') == 'diagnosis') {
            message = "Are you sure you want to delete this diagnosis?";
        }

        bootbox.confirm({ 
        message: message,
        callback: function(result){  
          if (result) {
                var id = $(target).attr('data-id');
                var type = $(target).attr('data-type');
                var goal_id = $('input[name=goal_id]').val();
                
                 $.post('{{ route('delete-goal-data') }}', {id: id, type: type,goal_id:goal_id}, function (response) {
                    initializePaginationByType(type, false, true);
                 }, 'json');
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
    }
$('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox') {
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
          $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
          $(this).removeClass('changed-input');
        }
        else {
          $(this).addClass('changed-input');
        }     
    } else {
        if($(this).hasClass('chosen-search-input')){

        }
        else{
          if($(this).val() == '') {
              $(this).removeClass('changed-input');
          } else {
              $(this).addClass('changed-input');
          }

        }  
    }
});

$('body').on('click', '.close_form', function(e) {
    e.preventDefault();
    closeForm();
});



function closeForm(){
  if ($('.changed-input').length){
      bootbox.confirm({ 
        message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
        callback: function(result){  
          if (result) {
            $('input,textarea,select').removeClass('changed-input');
            window.location.href="{{ route('get_careplan_goals') }}";
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      })
  }
  else {
    window.location.href="{{ route('get_careplan_goals') }}";
  }
}


// for modal box close event
$(document).on('hidden.bs.modal', '.addTypeModal',function () {
    $('.addTypeModal').find('input,textarea,select').removeClass('changed-input');
    $('.addTypeModal').find('form').trigger('reset');
    $('span.error').hide().removeClass('active');
})
// for click on side bar or logout button
$(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
  if ($('.changed-input').length){
    bootbox.alert("{{ trans('message.unsaved_error_message') }}");
    return false;
  }
});




//  check if input changed and unsaved before reload
window.onbeforeunload = function() {
    if ($('.changed-input').length && !$('div.ui-dialog[aria-describedby="sessionTimeout-dialog"]').is(':visible')){
        return "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page.";
    }

    else {
    }      
}


$('body').on('click', '.view_barriers', function(e) {
        e.preventDefault();
        $.each($(this).data(), function(i, v) {
            $('#view_barrier').find('.'+i).parent().show();
            if(i == 'barrier_description' || i == 'barrier_solution'){
             //$('#view_barrier').find('.'+i).text(v);  
                $('#view_barrier').find('.'+i).html('<pre>'+v+'</pre>'); 
            }
            else {
              $('#view_barrier').find('.'+i).text(v);  
            }
                    
         });
        $('#view_barrier').modal('show');
});


function viewToolDetails(target) {
    var modal = $('#view_tool');

    $.each($(target).data(), function(key, value) {
        if(key == 'location') {
            $('.tool_location', modal).html('<a href="'+ value +'" target="_blank">{{trans("label.tool_view_link")}}</a>');
        } else {
            $('.tool_'+key, modal).text(value);
        }
    });
    modal.modal('show');
}



function editQuestion(target) {
    var form = $('#add_questions-form');
    form[0].reset();

    var id = $(target).attr('data-id');
    var description = $(target).attr('data-description');
    var roles = $(target).attr('data-roles');
    var metricId = $(target).attr('data-metric-id');

    roles = roles.split(',');
    for(var i = 0; i < roles.length;i++) {
        $(':checkbox[value="'+roles[i]+'"]', form).prop('checked', 'checked');
    }

    $('[name="description"]', form).val(description);
    $('[name="metric_id"]', form).val(metricId);
    $('[name="id"]', form).val(id);
    $('#add_questions').modal('show');
    $('.modal-title', $('#add_questions')).text('Edit Question');
}

function editSubGoal(target)
{
    var form = $('#add_subgoals-form');
    form[0].reset();

    var id = $(target).attr('data-id');
    var description = $(target).attr('data-description');
    var roles = $(target).attr('data-roles');
    roles = roles.split(',');

    for(var i = 0; i < roles.length;i++) {
        $(':checkbox[value="'+roles[i]+'"]', form).prop('checked', 'checked');
    }
    $('[name="description"]', form).val(description);
    $('[name="id"]', form).val(id);
    $('#add_subgoals').modal('show');
    $('.modal-title', $('#add_subgoals')).text('Edit Sub Goals/Steps/Tasks');
}

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 100) {
        //clearHeader, not clearheader - caps H
        $("#mainNav").addClass("fixHead");
        $(".nav-top").addClass("fix_nav_top");
        $(".nav-box").addClass("fix_nav_box");
    }
    else{
        $("#mainNav").removeClass("fixHead"); 
        $(".nav-top").removeClass("fix_nav_top");
        $(".nav-box").removeClass("fix_nav_box");
    }
}); //missing )


$('.nav-box a.navigation__link').click(function(event){
    event.preventDefault();
    //console.log($('.nav-top').height());
    $('#6').css('padding-bottom','0px')
    if($.attr(this, 'href') == '#1') {
        scroll = $($.attr(this, 'href')).offset().top-200;
       
    }
/*<<<<<<< HEAD
    else if($.attr(this, 'href') == '#6') {
        scroll = $($.attr(this, 'href')).offset().top-150;
        if($($.attr(this, 'href')).height() <=250)
        $($.attr(this, 'href')).css('min-height','400px')
    }
=======
   /* else if($.attr(this, 'href') == '#6') {

        var vh = $('.nav-top').height();
        var ph = $('.page-header').height();
        alert(vh+ph);
        scroll = $($.attr(this, 'href')).offset().top; 
      //  if($($.attr(this, 'href')).height() <=250)
       // $($.attr(this, 'href')).css('min-height','430px')
    }*/

     else {
         var $container = $('.loader_div');
        var $scrollTo = $($.attr(this, 'href')).find('.portlet-title');
        scroll = $scrollTo.offset().top - $container.offset().top + $container.scrollTop(); 
      //  console.log(scroll);
       // $container.animate({ scrollTop: scroll }, 500);
      //  console.log('hee');
    
    }
     $('html, body').animate({scrollTop: scroll}, 500);

    
});

$('.nav-box a.navigation__link.active').trigger('click');

$(".goal_type").change(function () {
    var end = this.value;
    var obj = jQuery.parseJSON( $('.metricIdOption').text());
    $("#metric_id").find('option').not(':first').remove();
    if(this.value == '') {
        $('#metric_id').val('');
        $('#metric_id').prop("disabled", true);
    } else {
        $('#metric_id').prop("disabled", false);
        if(this.value == 1){
            $.each(obj, function(idx, obj) {
                $('#metric_id')
                    .append($("<option></option>")
                        .attr("value",idx)
                        .text(obj));
            });
            $("#metric_id option:contains('Note')").remove();
        }
        else {
            $.each(obj, function(idx, obj) {
                $('#metric_id')
                    .append($("<option></option>")
                        .attr("value",idx)
                        .text(obj));
            });

            $("#metric_id option:contains('Binary')").remove();
            $("#metric_id option:contains('Scale')").remove();
            $("#metric_id option:contains('Level')").remove();
            $("#metric_id option:contains('Note')").attr('selected','selected');
        }
    }

});

</script>

<script>

  var timeoutID = null;
  function saveTitle(str) {
   if(str.length > 3)
    {
        //alert(str);
        if($('#goal_id').val() == '') {
            saveForm('#add_goal_form','save_and_proceed');
        }
    }
  }
  $("[name='title']",'#add_goal_form').keyup(function(e) {
    clearTimeout(timeoutID);
    timeoutID = setTimeout(saveTitle.bind(undefined, e.target.value), 700);
  });

  $( document ).ready(function() {
    if($(".goal_type").val() == '{{App\Models\Admin\CarePlan\Goal::TYPE_QUALITATIVE}}' ){
        $("#metric_id option:contains('Binary')").remove();
        $("#metric_id option:contains('Scale')").remove();
        $("#metric_id option:contains('Level')").remove();
    }
    else if($(".goal_type").val() == '{{App\Models\Admin\CarePlan\Goal::TYPE_QUANTATIVE}}'){
        $("#metric_id option:contains('Note')").remove();
    }
  });
  applpyEllipses('table', 5, 'no');
</script>
@endsection
