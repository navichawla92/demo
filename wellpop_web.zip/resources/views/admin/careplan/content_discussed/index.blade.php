@extends('admin.layouts.app')

@section('title')
   {{ trans('label.barriers_listing') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                  <li>
                    <a href="{{ route('login') }}"> {{ trans('label.dashboard') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.care_plan') }} </span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.content_discussed') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                             <i class="fa fa-wrench font-dark"></i>
                            <span class="caption-subject bold uppercase"> {{trans('label.available_content_discussed')}} </span>
                        </div>
                        <div class="btn-group pull-right">
                            <a href="{{route('content-create')}}" id="sample_editable_1_new" class="btn sbold green">
                                <i class="fa fa-plus"></i> {{trans('label.add_content_discussed')}} </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered table-hover table-align-left datatable loader_div">
                            <thead>
                                <tr>
                                    <th> {{trans('label.serial_number_short_form')}} </th>
                                    <th> {{trans('label.content_discussed_id')}} </th>
                                    <th> {{trans('label.content_discussed_title')}} </th>
                                    <th> {{trans('label.action')}} </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('js/ajaxSetup.js') }}" type="text/javascript"></script> 
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort:false,
        language: {
          searchPlaceholder: "{{trans('label.search_by_content_discussed')}}",
        },
        ajax: '{{ route('datatable/get_content_discussed_list') }}',
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'code', name: 'code',orderable: false},
            {data: 'title', name: 'title',orderable: false},
            {data: 'action', name: 'action',orderable: false, searchable: false},
        ],
        "fnDrawCallback": function(settings, json) {
          applpyEllipses('loader_div', 5, 'no');
        }
    });
});
</script>
@endsection
