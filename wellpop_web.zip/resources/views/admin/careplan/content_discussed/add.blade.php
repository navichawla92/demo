@extends('admin.layouts.app')

@section('title')
   {{ $content->id ? trans('label.edit_content_discussed') : trans('label.add_new_content_discussed') }}
@endsection

@section('content')

<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}"> {{trans('label.dashboard')}} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{trans('label.care_plan')}} </span>
                    <i class="fa fa-circle"></i>
                </li>
                 <li>
                    <a href="{{ route('get_content_discussed') }}"> {{trans('label.content_discussed')}} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $content->id ? trans('label.edit_barrier') : trans('label.add_new_content_discussed') }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold">{{ $content->id ? trans('label.edit_content_discussed') : trans('label.add_new_content_discussed') }}</span>
                        </div>
                    </div>

                    <div class="portlet-body form">
                         @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif

                        {!! Form::model($content, ['id'=>'add_content_form']) !!}
                        <input type="hidden" name="id" class="ref_field_id" value="{{$content->id ? encrypt_decrypt('encrypt', $content->id) : '' }}">
                           <div class="row">
                         <div class="col-md-6">

                            <div class="form-group">
                                {{ Form::label('title', trans('label.enter_content_title')) }}*
                                {{ Form::text('title', null, array('class' => 'form-control','maxlength'=>'100')) }}
                                @if ($errors->has('title'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('description', trans('label.enter_content_desc')) }}*
                                {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"10000"]) !!}
                                @if ($errors->has('description'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                       </div>
                       <div class="col-md-offset-1 col-md-10">
                            <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_content_form','save_and_close')" > {{ $content->id ? trans('label.update_and_close') : trans('label.save_and_close') }}</button>
                            @if(!$content->id)
                            <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_content_form','save_and_add_new')" >   {{ trans('label.save_and_add_new') }}
                            </button> 
                            @endif
                            <a href="{{ route('get_content_discussed') }}" class="btn default">{{ trans('label.cancel') }}</a>
                        </div>
                       
                      </div> 
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

