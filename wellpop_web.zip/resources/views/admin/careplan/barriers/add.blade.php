@extends('admin.layouts.app')

@section('title')
   {{ $barrier->id ? trans('label.edit_barrier') : trans('label.add_new_barrier') }}
@endsection

@section('content')
<?php
    $tool_type = tool_type();
?>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}"> {{ trans('label.dashboard') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.care_plan') }} </span>
                    <i class="fa fa-circle"></i>
                </li>
                 <li>
                    <a href="{{ route('get_careplan_barriers') }}"> {{ trans('label.barriers') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $barrier->id ? trans('label.edit_barrier') : trans('label.add_new_barrier') }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold">{{ $barrier->id ? trans('label.edit_barrier') : trans('label.add_new_barrier') }}</span>
                        </div>
                    </div>

                    <div class="portlet-body form">
                         @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif

                        {!! Form::model($barrier, ['id'=>'add_tool_form']) !!}
                        <input type="hidden" name="id" class="ref_field_id" value="{{$barrier->id ? encrypt_decrypt('encrypt', $barrier->id) : '' }}">
                           <div class="row">
                         <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('category_id', trans('label.select_barrier_category')) }}*
                                 {!! Form::select('category_id', $barrier_categories, null, ['class' => 'form-control']) !!}
                                @if ($errors->has('category_id'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('category_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('title', trans('label.enter_barrier_title')) }}*
                                {{ Form::text('title', null, array('class' => 'form-control','maxlength'=>'100')) }}
                                @if ($errors->has('title'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('description', trans('label.enter_barrier_desc')) }}*
                                {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"10000"]) !!}
                                @if ($errors->has('description'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                {{ Form::label('solution', trans('label.suggestions')) }}*
                                {!! Form::textarea('solution', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"10000"]) !!}
                                @if ($errors->has('solution'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('solution') }}</strong>
                                    </span>
                                @endif
                            </div>
                       </div>
                       <div class="col-md-offset-1 col-md-10">
                            <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_tool_form','save_and_close')" > {{ $barrier->id ? trans('label.update_and_close') : trans('label.save_and_close') }}</button>
                            @if(!$barrier->id)
                            <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_tool_form','save_and_add_new')" >   {{ trans('label.save_and_add_new') }}
                            </button> 
                            @endif
                            <a href="{{ route('get_careplan_barriers') }}" class="btn default">{{ trans('label.cancel') }}</a>
                        </div>
                       
                      </div> 
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

