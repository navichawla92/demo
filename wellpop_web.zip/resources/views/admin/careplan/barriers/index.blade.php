@extends('admin.layouts.app')

@section('title')
   {{ trans('label.barriers_listing') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                  <li>
                    <a href="{{ route('login') }}"> {{ trans('label.dashboard') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.care_plan') }} </span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.barriers') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered goal_table">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                             <i class="fa fa-wrench font-dark"></i>
                            <span class="caption-subject bold uppercase"> {{ trans('label.available_barriers') }} </span>
                        </div>
                        <div class="btn-group pull-right">
                            <a href="{{route('barrier-create')}}" id="sample_editable_1_new" class="btn sbold green"> <i class="fa fa-plus"></i> {{ trans('label.add_new_barrier') }} </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered table-hover table-align-left datatable loader_div">
                            <thead>
                                <tr>
                                    <th> {{ trans('label.serial_number_short_form') }} </th>
                                    <th> {{ trans('label.barrier_id') }} </th>
                                    <th> {{ trans('label.barrier_title') }} </th>
                                    <th> {{ trans('label.barrier_category') }} </th>
                                    <th> {{ trans('label.action') }} </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('js/ajaxSetup.js') }}" type="text/javascript"></script> 
<script type="text/javascript">
$(document).ready(function() {
   /* $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort:false,
        language: {
          searchPlaceholder: "{{trans('label.search_by_barrier')}}",
        },
        ajax: '{{ route('datatable/get_careplan_barriers') }}',
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'code', name: 'code',orderable: false},
            {data: 'title', name: 'title',orderable: false},
            {data: 'category', name: 'category',orderable: false,searchable: false},
            {data: 'action', name: 'action',orderable: false, searchable: false},
        ],
        "fnDrawCallback": function(settings, json) {
          applpyEllipses('loader_div', 5, 'no');
        }
    });*/
});

$(document).ready(function() {

    var extensions = {
        "sFilter": "dataTables_filter custom_filter_class",
    };
    $.extend($.fn.dataTableExt.oStdClasses, extensions);
    $.extend($.fn.dataTableExt.oJUIClasses, extensions);

    window.table = $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: true,
        bSort: false,
        language: {
            searchPlaceholder: "Search by Barrier ID/Title",
            emptyTable:     "No matching records found"
        },
        ajax: {
            url: '{{ route('datatable/get_careplan_barriers') }}',
            data: function ( d ) {
                d.category = $('.custom_filter_class select').val();
            }
        },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'code', name: 'code',orderable: false},
            {data: 'title', name: 'title',orderable: false},
            {data: 'category', name: 'category',orderable: false,searchable: false},
            {data: 'action', name: 'action',orderable: false, searchable: false},
        ],
        "fnDrawCallback": function(settings, json) {
          //  alert( 'DataTables has finished its initialisation.' );
          applpyEllipses('loader_div', 5, 'no');
        }
    });

    @php
   
        $options = '<option value="">All</option>';
        foreach($barrier_categories as $barrier_categorie => $value){
            $options.= '<option value="'.$barrier_categorie.'"> '.$value.' </option>';
        }
    @endphp

    $('.custom_filter_class').prepend('<label>Search by category: </label> <select onchange="filterByStatus(this)" class="form-control input-sm input-small input-inline">' +
        '{!! $options !!}' +
        '</select> ');
});

function filterByStatus(target) {
    window.table.draw();
}
</script>
@endsection
