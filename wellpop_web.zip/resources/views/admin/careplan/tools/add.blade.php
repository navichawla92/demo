@extends('admin.layouts.app')

@section('title')
    {{ $tool->id ? trans('label.edit_tool') : trans('label.add_new_tool') }}
@endsection

@section('content')
    <?php $tool_type = tool_type(); ?>
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->
            <!-- BEGIN PAGE BAR -->
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <a href="{{ route('login') }}"> {{trans('label.dashboard')}} </a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <span> {{trans('label.care_plan')}} </span>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <a href="{{ route('get_careplan_tools') }}"> {{trans('label.tools')}} </a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <span>{{ $tool->id ? trans('label.edit_tool') : trans('label.add_new_tool') }}</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE BAR -->
            <!-- END PAGE HEADER-->
            <div class="row">
                <div class="col-md-12 ">
                    <!-- BEGIN SAMPLE FORM PORTLET-->
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">
                                <i class="icon-plus font-dark"></i>
                                <span class="caption-subject font-dark bold">{{ $tool->id ? trans('label.edit_tool') : trans('label.add_new_tool') }}</span>
                            </div>
                        </div>

                        <div class="portlet-body form">
                            @if(session()->has('message.level'))
                                <div class="alert alert-{{ session('message.level') }} alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    {!! session('message.content') !!}
                                </div>
                            @endif

                            {!! Form::model($tool, ['id'=>'add_tool_form', 'enctype' => 'multipart/form-data']) !!}
                            <input type="hidden" name="id" class="ref_field_id"
                                   value="{{$tool->id ? encrypt_decrypt('encrypt', $tool->id) : '' }}">
                            <div class="row">
                                <div class="col-md-6">

                                    <div class="form-group">
                                        {{ Form::label('title', trans('label.tool_title')) }}*
                                        {{ Form::text('title', null, array('class' => 'form-control','maxlength'=>'100')) }}
                                        @if ($errors->has('title'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('title') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    <div class="form-group">
                                        {{ Form::label('description', trans('label.enter_tool_desc')) }}*
                                        {!! Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"10000"]) !!}
                                        @if ($errors->has('description'))
                                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                        @endif
                                    </div>

                                    <div class="form-group">
                                        {{ Form::label('type', trans('label.choose_tool_type')) }}*
                                        {!! Form::select('type', array('' => 'Please select') + $tool_type,null,array("class" => "form-control")) !!}
                                        @if ($errors->has('type'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('type') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                    @if($tool->type === 'Pdf')
                                       <div class='pdf_link'>
                                        Pdf Link:
                                        <a href="{{ config('filesystems.s3_tool_documents_full_path').$tool->file_path }}" target="_blank">
                                            {{ $tool->file_path }}
                                        </a> <br> <br>
                                        </div>
                                        <input type='hidden' name='is_upload' value='1'>
                                    @endif

                                    <div class="form-group Pdf_type" @if(!(old('type') === 'Pdf' || $tool->type === 'Pdf')) style="display: none;" @endif>
                                        <div class="browsebutton">
                                           {{ Form::label('file_path', trans('label.tool_type_Pdf')) }}
                                          <div class="browsebuttontext"> Browse 
                                            {{ Form::file('file_path',  array('class' => 'form-control','maxlength'=>'1000', 'accept' => 'application/pdf')) }}
                                          </div>
                                           @if ($errors->has('file_path'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('file_path') }}</strong>
                                            </span>
                                        @endif
                                          <div class="filenamecross">
                                            <span id="selected_doc_name" style="color:black"> No file selected </span>
                                            <span style="color:red;display:none;cursor:pointer;" id="delete_selected_doc">X</span>
                                          </div>
                                        </div>
                                       
                                    </div>

                                    <div class="form-group online_type" @if(!(old('type') === 'Online' || $tool->type === 'Online')) style="display: none;" @endif>
                                        {{ Form::label('link', trans('label.tool_type_online')) }}*
                                        {{ Form::text('link', $tool->location, array('class' => 'form-control','maxlength'=>'1000')) }}
                                        @if ($errors->has('link'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('link') }}</strong>
                                            </span>
                                        @endif
                                    </div>

                                </div>
                                <div class="col-md-offset-1 col-md-10">
                                    <button type="button" class="btn blue save_button"
                                            onClick="javascript:saveFormWithoutAjax('#add_tool_form','save_and_close')"> {{ $tool->id ? trans('label.update_and_close') : trans('label.save_and_close') }}</button>
                                    @if(!$tool->id)
                                        <button type="button" class="btn blue save_button"
                                                onClick="javascript:saveFormWithoutAjax('#add_tool_form','save_and_add_new')">   {{ trans('label.save_and_add_new') }}
                                        </button>
                                    @endif
                                    <a href="{{ route('get_careplan_tools') }}"
                                       class="btn default">{{ trans('label.cancel') }}</a>
                                </div>

                            </div>
                            {{ Form::close() }}
                        </div>
                    </div>
                    <!-- END SAMPLE FORM PORTLET-->
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        var form = $('#add_tool_form');
        $('select[name="type"]',form).change(function(){
           if($(this).val() === 'Online') {
               $('.online_type').show();
               $('#add_tool_form').find('input[type=file]').val("");
               $('.Pdf_type').hide();
               $('.pdf_link').hide();
           }

           if($(this).val() === 'Pdf'){
               $('.online_type').hide();
               $('.Pdf_type').show();
               $('.pdf_link').show();
           }

           if($(this).val() === '') {
               $('.online_type').hide();
               $('.Pdf_type').hide();
               $('.pdf_link').hide();
           }
        });

       $(document).on('change','input[type=file][name=file_path]',function(e){
            $("#selected_doc_name").html(e.target.files[0].name);
            $("#delete_selected_doc").show();
        });

        $(document).on('click','#delete_selected_doc',function(e){
            $('#add_tool_form').find('input[type=file]').val("");
            $("#selected_doc_name").html('No file selected');
            $("#delete_selected_doc").hide();
        });

        $(document).ready(function(){
            var form = $('#add_tool_form');
            var tool_type = $('select[name="type"]',form).val();
            if(tool_type === 'Pdf'){
               $('.online_type').hide();
               $('.Pdf_type').show();
               $('.pdf_link').show();
           }
           if(tool_type === '') {
               $('.online_type').hide();
               $('.Pdf_type').hide();
               $('.pdf_link').hide();
           }
           if(tool_type === 'Online') {
               $('.online_type').show();
               $('.Pdf_type').hide();
               $('.pdf_link').hide();
           }
        });
    </script>
@endsection
