@extends('admin.layouts.app')

@section('title')
   {{ trans('label.add_diagnosis') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.care_plan') }}</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="{{ route('diagnosis') }}">Diagnosis</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.add_diagnosis') }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold uppercase">{{ trans('label.add_diagnosis') }}</span>
                        </div>
                    </div>

                    <div class="portlet-body form">
                         @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif

                        {!! Form::open(['route' => 'diagnosis','class'=>'form-horizontal','id'=>'add_diagnosis_form']) !!}
							@include('admin.careplan.diagnosis.form')
                            <div class="form-group">
                                <div class="col-md-offset-1 col-md-10">
                                    <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_diagnosis_form','save_and_close')" > {{ trans('label.save_and_close') }}</button>
                                    <button type="button" class="btn blue save_button" onClick="javascript:saveFormWithoutAjax('#add_diagnosis_form','save_and_add_new')" > {{ trans('label.save_and_add_new') }}</button>
                                    <a href="{{ route('diagnosis') }}" class="btn default"> {{ trans('label.cancel') }}</a>
                                </div>
                            </div>
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection



@section('script')

<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
@include('layouts.icd_code_js')
<script type="text/javascript">
// icd code dynamic options
$(document).ready(function(){
  icdCodeDynamic();
  $("#metric_id option:contains('Note')").remove();
});

</script>
@endsection
