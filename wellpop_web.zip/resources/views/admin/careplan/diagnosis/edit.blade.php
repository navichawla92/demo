@extends('admin.layouts.app')

@section('title')
    {{ trans('label.edit_diagnosis') }} 
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.care_plan') }}</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="{{ route('diagnosis') }}">{{ trans('label.diagnosis') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span> {{ trans('label.edit_diagnosis') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold uppercase"> {{ trans('label.edit_diagnosis') }} </span>
                        </div>
                    </div>

                    <div class="portlet-body form">
						{{ Form::model($diagnosis, array('route' => array('diagnosis.update', encrypt_decrypt('encrypt', $diagnosis->id)), 'method' => 'PUT','class'=>'form-horizontal')) }}
							@include('admin.careplan.diagnosis.form')
                            <div class="form-group">
                                <div class="col-md-offset-1 col-md-10">
                                    {{ Form::submit(trans('label.update_and_close'), array('class' => 'btn blue')) }}
                                    <a href="{{ route('diagnosis') }}" class="btn default"> {{ trans('label.cancel') }} </a>
                                </div>
                            </div>
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
@include('layouts.icd_code_js')
<script type="text/javascript">
// icd code dynamic options
$(document).ready(function(){
  icdCodeDynamic();
  $("#metric_id option:contains('Note')").remove();
});
</script>
@endsection
