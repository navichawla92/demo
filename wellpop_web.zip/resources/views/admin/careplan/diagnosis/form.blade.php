<div class="row">
	<div class='col-md-6'>
		<div class="form-group">
			{{ Form::label('title', trans('label.enter_diagnosis_title')) }}*
			{{ Form::text('title', null, array('class' => 'form-control','maxlength'=>'100')) }}
			@if ($errors->has('title'))
				<span class="invalid-feedback" role="alert">
					<strong>{{ $errors->first('title') }}</strong>
				</span>
			@endif
		</div>
		<div class="form-group"> @php
			if(old('icd_code')) {
				$selectedIcdCodes = collect(old('icd_code'));
			} else {
				$selectedIcdCodes = $diagnosis->icd_codes()->where('version',$diagnosis->current_version)->pluck('icd_code_id');
			}
		@endphp
			{{ Form::label('icd_code', trans('label.ICD_10_Codes_for_diagnosis')) }}*
			{!! Form::select('icd_code[]',$icd_codes,$selectedIcdCodes,array("class" => "Icd_class",'id'=>"icdCode",'multiple','data-placeholder' => trans('label.search_by_icd_code'))) !!}
			@if ($errors->has('icd_code'))
				<span class="invalid-feedback" role="alert">
					<strong>{{ $errors->first('icd_code') }}</strong>
				</span>
			@endif
		</div>
		
		<div class="form-group">
			{{ Form::label('metric_id', trans('label.metric')) }}*
			{!! Form::select('metric_id',$metrices,null,array("class" => "form-control", 'placeholder' => 'Please Select')) !!}
			@if ($errors->has('metric_id'))
				<span class="invalid-feedback" role="alert">
					<strong>{{ $errors->first('metric_id') }}</strong>
				</span>
			@endif
		</div>
		
		<div class="form-group">
			{{ Form::label('description', trans('label.enter_diagnosis_description')) }}*
			{{ Form::textarea('description', null, array('class' => 'form-control','maxlength'=>'10000')) }}
			@if ($errors->has('description'))
				<span class="invalid-feedback" role="alert">
					<strong>{{ $errors->first('description') }}</strong>
				</span>
			@endif
		</div>
	</div> 
</div>
