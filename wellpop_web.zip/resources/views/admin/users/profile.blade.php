@extends('admin.layouts.app')

@section('title')
  My Profile
@endsection

@section('content')
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="{{ route('login') }}">Dashboard</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>My Profile</span>
                            </li>
                        </ul>
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- END PAGE HEADER-->
                    <div class="row">
                      @if(session()->has('message.level'))
                          <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {!! session('message.content') !!}
                          </div>
                      @endif  
                      <div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-body form">
                                   
                                        <div class="form-body">
                                            <div class="form-group ">
                                                <label class="control-label col-md-3">Profile Picture</label>
                                                <div class="col-md-3 patient_pro_pic_preview">
                                                    <div class="admin-profile-img">
                                                      <img id="previewHolder" alt="Uploaded Image Preview Holder" src="@if($user->image) {{ config('filesystems.s3_user_images_full_path').$user->id.'/'.$user->image }} @else {{ asset('images/dummy_user.png') }} @endif" width="150"/>
                                                       <span class="imgcross" <?php if(!$user->image) echo 'style="display:none;"'; ?>>X</span>
                                                      <form enctype="multipart/form-data" id="upload_pic" role="form" method="POST" action="" <?php if($user->image) echo 'style="display:none;"'; ?>>
                                                        <input type="hidden" name="_token" value="{{ csrf_token()}}">
                                                        <input type="file" name="image" value="" id="profile_pic" class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg">
                                                        <span class="error" style="color:red"></span>
                                                      </form>
                                                      <span class="error" style="color:red"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button id="pro_pic_btn" disabled="" type="button" onClick="javascript:changePic()" class="btn green">Submit</button>
                                                    <a href="{{ route('login') }}" class="btn default">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                   
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>

                        <div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-body form">
                                    <form class="form-horizontal" role="form">
                                        <div class="form-body">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Full Name</label>
                                                <div class="col-md-9">
                                                    <!-- <input type="text" class="form-control input-inline input-medium" placeholder="Enter text"> -->
                                                    {!! Form::text('name',$user->name,['class' => 'form-control input-inline input-medium', 'placeholder' => 'Enter full name']) !!}
                                                    <span style="color:red;" class="error"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="button" onClick="javascript:updateName()" class="btn green">Submit</button>
                                                    <a href="{{ route('login') }}" class="btn default">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>

                        <div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-body form">
                                    <form class="form-horizontal" role="form">
                                        <div class="form-body">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Password</label>
                                                <div class="col-md-9">
                                                    <input type="password" class="form-control input-inline input-medium" placeholder="Enter text" name="password">
                                                    <div class="clearfix"></div>
                                                    <span style="color:red;" class="error"></span>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Confirm Password</label>
                                                <div class="col-md-9">
                                                    <input type="password" class="form-control input-inline input-medium" placeholder="Enter text" name="password_confirmation">
                                                    <div class="clearfix"></div>
                                                    <span style="color:red;" class="error"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="button" onClick="javascript:changePassword()" class="btn green">Submit</button>
                                                    <a href="{{ route('login') }}" class="btn default">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>
                    </div>
                </div>
            </div>
@endsection

@section('script')
<script type="text/javascript">

function updateName(){
  $.ajax({
    url:"{{ route('admin-update-personal-info') }}",
    data:{name:$('input[name=name]').val(),'_token':"{{ csrf_token() }}"},
    // processData: false,
    // contentType: false,
    dataType: "json",
    success:function(data){
      window.location.reload();
    }
  });
}

function changePassword(){
    $('span.error').hide();
  $.ajax({
    url:"{{ route('admin-change-password') }}",
    data:{password:$('input[name=password]').val(),password_confirmation:$('input[name=password_confirmation]').val(),'_token':"{{ csrf_token() }}"},
    // processData: false,
    // contentType: false,
    dataType: "json",
    success:function(data){
      window.location.reload();
    }
  });
}

function changePic(){
  $.ajax({
      url:"{{ route('admin-change-pic') }}",
      data:new FormData($("#upload_pic")[0]),
      dataType:'json',
      processData: false,
      contentType: false,
      success:function(response){
        window.location.reload();
      },
    });
}

$("#profile_pic").change(function() {
    $('#pro_pic_btn').attr('disabled',false);
    readURL(this);
    $('#pro_pic_btn').attr('disabled',false);
    readURL(this);
    $('.patient_pro_pic_preview span.imgcross').show();
    $('#upload_pic').hide();
});

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#previewHolder').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}
//user profile image remove on cross click code
$(document).on('click','.patient_pro_pic_preview span.imgcross',function(){
  $('input[type=file][name=image]').val('');
  $('.patient_pro_pic_preview span.imgcross').hide();
  $('.patient_pro_pic_preview img').attr('src',"{{ asset('images/dummy_user.png') }}");
  $('#upload_pic').show();
  
});
</script>
@endsection
