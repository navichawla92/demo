@extends('admin.layouts.app')

@section('title')
   {{ trans('label.users_listing') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.all_users') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-users font-dark"></i>
                            <span class="caption-subject bold uppercase"> {{ trans('label.all_users') }} </span>
                        </div>
                        <div class="btn-group pull-right">

                            <a href="{{route('addUser')}}" id="sample_editable_1_new" class="btn sbold green"> <i class="fa fa-plus"></i> {{ trans('label.add_new_user') }}
                               
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover loader_div table-align-left datatable">
                            <thead>
                                <tr>
                                    <th>{{ trans('label.serial_number_short_form') }}</th>
                                    <th>{{ trans('label.name') }} </th>
                                    <th>{{ trans('label.email') }} </th>
                                    <th>{{ trans('label.role') }} </th>
                                    <th>{{ trans('label.status') }} </th>
                                    <th>{{ trans('label.action') }} </th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script src="{{ asset('js/ajaxSetup.js') }}" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        bSort: false,
        ajax: "{{ route('datatable/getUsers') }}",
        language: {
          searchPlaceholder: "{{trans('label.search_by_email')}}",
        },
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
            {data: 'name', name: 'name',orderable: false},
            {data: 'email', name: 'email',orderable: false},
            {data: 'role', name: 'role',orderable: false},
            {data: 'status', name: 'status',orderable: false, searchable: false},
            {data: 'actions', name: 'actions',orderable: false, searchable: false},
        ]
    });
});

function changeStatus(model,action,id,text){
        bootbox.confirm({ 
        message: "Are you sure, you want to "+text+" this user?", 
        callback: function(result){  
          if (result) {
            $.ajax({
                url:"{{ route('change-user-status') }}",
                data:{id:id,status:action},
                success:function(data){
                    window.location.reload();
                }
            });
          }
        }
      })
}
</script>
@endsection
