@extends('admin.layouts.app')

@section('title')
   {{ trans('label.add_new_user') }}
@endsection

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">{{ trans('label.dashboard') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="{{ route('users') }}"> {{ trans('label.all_users') }} </a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ trans('label.add_new_user') }} </span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-plus font-dark"></i>
                            <span class="caption-subject font-dark bold uppercase">{{ trans('label.add_new_user') }}</span>
                        </div>
                    </div>

                    <div class="portlet-body form">

                        {!! Form::model($casemanager, ['class'=>'form-horizontal']) !!}
                        <div class="row">
                        <div class="col-md-6">
                             <div class="form-group">
                                  {{ Form::label('title', trans('label.role')) }}*
                                

                                 {!! Form::select('roles',$roles,null,array("class" => "form-control", 'placeholder' => 'Please Select')) !!}
                                    
                                    @if ($errors->has('roles'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('roles') }}</strong>
                                    </span>
                                @endif
                               
                            </div>
                            <div class="form-group">
                                {{ Form::label('title', trans('label.name')) }}*
                                 {{ Form::text('name', null, array('class' => 'form-control','placeholder' =>'Name')) }}
                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                                
                            </div>

                            <div class="form-group">
                               
                                {{ Form::label('title', trans('label.email')) }}*
                                    {{ Form::text('email', null, array('class' => 'form-control','placeholder' =>'Email')) }}
                                     @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                    @endif
    
                            </div>
                            <div class="form-group">
                                    {{ Form::label('phone', 'Phone Number') }}*
                                      <div class="row">
                                          <div class="col-md-2">
                                            {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center form-control','disabled'=>true]) !!} 
                                          </div>
                                         <div class="col-md-10">
                                        {!! Form::text('phone',null,['class' => 'set_phone_format form-control']) !!}
                                        <span class="error" style="color:red"></span>
                                        </div>
                                    </div>
                                   
                                    @if ($errors->has('phone'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('phone') }}</strong>
                                        </span>
                                    @endif
                                </div>
                           
                        </div>
                         <div class="form-group">
                                <div class="col-md-offset-1 col-md-10">
                                    {{ Form::submit('Add', array('class' => 'btn blue')) }}
                                    <a href="{{ route('login') }}" class="btn default">{{ trans('label.cancel') }} </a>
                                </div>
                            </div>
                    </div>
                           
                        {{ Form::close() }}         
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">

</script>
@endsection
