@extends('admin.layouts.app')

@section('title')
   {{ $type_heading }} Listing
@endsection

@section('content')
@php    
    $icons = [
        'contract_payers' => 'fa-thumbs-o-up',
        'insurances' => 'fa-medkit',
        'pcp_informations' => 'fa-stethoscope',
        'referral_sources' => 'fa-registered',
        'emergency_departments' => 'fa-medkit',
        'rehabs' => 'fa-medkit',
        'hospice_providers' => 'fa-medkit',
        'specialities' => 'fa-stethoscope',
        'housing_assistances' => 'fa-medkit',
        'mental_health_assistances' => 'fa-medkit',
        'home_health_providers' => 'fa-medkit'
    ];
@endphp
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
                <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                 <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $type_heading }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->

        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="fa {{ $icons[$type] }} font-dark"></i>
                            <span class="caption-subject bold uppercase">Available {{ $type_heading }}</span>
                        </div>
                        <div class="btn-group pull-right">
                            <a href="{{ route('add_new_registry', $type) }}" id="sample_editable_1_new" class="btn sbold green"> <i class="fa fa-plus"></i> Add new
                               
                            </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if(session()->has('message.level'))
                            <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                {!! session('message.content') !!}
                            </div>
                        @endif
                        <!-- <table class="table table-striped table-bordered table-hover table-checkable order-column datatable"> -->
                        {!! $dataTable->table() !!}
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
    $.ajaxSetup({
    type:"POST",
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
    beforeSend:function(){
        $('.loader_div').waitMe();
    },
    complete:function(){
        $('.loader_div').waitMe('hide');
        applpyEllipses('dataTable', 5, 'no');
    },
    error:function(error){
    }
});

</script>

{!! $dataTable->scripts() !!}

<script>
    $('.table.dataTable').addClass('table-align-left');
     
</script>

@endsection
