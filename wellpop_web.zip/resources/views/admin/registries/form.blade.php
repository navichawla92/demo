@extends('admin.layouts.app')

@section('title')
   {{ $model->id ? "Edit" : "Add"}} {{ $type_heading }}
@endsection

@section('content')
<!-- BEGIN CONTENT -->
 <?php
    $confirmationField= array(1 => 'Yes',0=>'No');
?>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                  <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="{{ route('registries', $type) }}">{{ $type_heading }}</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>{{ $model->id ? "Edit" : "Add"}} {{ $type_heading }}</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <div class="">
            <!-- BEGIN SAMPLE FORM PORTLET-->
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-plus font-dark"></i>
                        <span class="caption-subject font-dark bold">{{ $model->id ? "Edit" : "Add"}} {{ $type_heading }}</span>
                    </div>
                </div>

                <div class="portlet-body form">
                    {!! Form::model($model,['id'=>'add_new_form']) !!}
                        <input type="hidden" name="type" value="{{ $type }}">    
                        <div class="row">            
                             @include('admin.registries.'.$type.'_form')
                            <div class="col-md-offset-1 col-md-10">
                               <button type="button" class="btn blue save_button" onClick="javascript:formData('#add_new_form')" > {{ $model->id ? 'Update' : 'Add' }}</button>     
                                <a href="{{ route('registries', $type) }}" class="btn default">Cancel</a>
                            </div>
                        </div>
                    {{ Form::close() }}
                </div>
            </div>

<!--- end for html for add -->

        </div>
    </div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {
    $('.start_datepicker').datepicker({
        autoclose: true,
        format: 'mm-dd-yyyy',
        endDate: '-0d'
    }).on("changeDate", function (selected) {
            var minDate = new Date(selected.date.valueOf());
            $(".end_datepicker").datepicker("setStartDate", minDate);
    });

    $(".end_datepicker").datepicker({
            autoclose: true,
            format: "mm-dd-yyyy",
        })
        .on("changeDate", function (selected) {
            var minDate = new Date(selected.date.valueOf());
            $(".start_datepicker").datepicker("setEndDate", minDate);
    });
});
</script>
@endsection

