<div class='col-md-6'>
    <div class="form-group">
        {{ Form::label('org_name', 'Organisation Name') }}*
        @if(!$model->id)
            {{ Form::text('org_name', null, array('class' => 'form-control')) }}
        @else
            {{ Form::text('org_name', null, array('class' => 'form-control','readonly'=>'')) }}
        @endif
        @if ($errors->has('org_name'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('org_name') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('code', 'Code') }}
        {{ Form::text('code', null, array('class' => 'form-control')) }}
        @if ($errors->has('code'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('code') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('phone_number', 'Phone Number') }}*
          <div class="row">
              <div class="col-md-2">
                {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center form-control','disabled'=>true]) !!} 
              </div>
             <div class="col-md-10">
            {!! Form::text('phone_number',null,['class' => 'set_phone_format form-control']) !!}
            <span class="error" style="color:red"></span>
            </div>
        </div>
       
        @if ($errors->has('phone_number'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('phone_number') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('address_line1', 'Address Line 1') }}*
        {{ Form::text('address_line1', null, array('class' => 'form-control')) }}
        @if ($errors->has('address_line1'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('address_line1') }}</strong>
            </span>
        @endif
    </div>
     <div class="form-group">
        {{ Form::label('address_line2', 'Address Line 2') }}
        {{ Form::text('address_line2', null, array('class' => 'form-control')) }}
        @if ($errors->has('address_line2'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('address_line2') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('city', 'City') }}*
        {{ Form::text('city', null, array('class' => 'form-control')) }}
        @if ($errors->has('city'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('city') }}</strong>
            </span>
        @endif
    </div>
    <div class='row'>
        <div class='col-md-6'>
            <div class="form-group">
                {{ Form::label('state', 'State') }}*
                 {!! Form::select('state_id',$states,null,array("class" => "form-control")) !!}
                @if ($errors->has('state_id'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('state_id') }}</strong>
                    </span>
                @endif
            </div>
        </div>
        <div class='col-md-6'>
         <div class="form-group">
            {{ Form::label('zip', 'Zip Code') }}*
            {{ Form::text('zip', null, array('class' => 'form-control','maxlength'=>'5')) }}
            @if ($errors->has('zip'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('zip') }}</strong>
                </span>
            @endif
        </div>
        </div>
    </div>         
</div>
<div class='col-md-6'>
    <div class="form-group">
        {{ Form::label('email', 'Email Address') }}
        {{ Form::text('email', null, array('class' => 'form-control')) }}
        @if ($errors->has('email'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('email') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('fax', 'FAX') }}
        {{ Form::text('fax', null, array('class' => 'form-control')) }}
        @if ($errors->has('fax'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('fax') }}</strong>
            </span>
        @endif
    </div>
     <div class="form-group">
        {{ Form::label('web_address', 'Web Address') }}
        {{ Form::text('web_address', null, array('class' => 'form-control')) }}
        @if ($errors->has('web_address'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('web_address') }}</strong>
            </span>
        @endif
    </div>
    <div class="form-group">
        {{ Form::label('contact_name', 'Contact Person Name') }}
        {{ Form::text('contact_name', null, array('class' => 'form-control')) }}
        @if ($errors->has('contact_name'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('contact_name') }}</strong>
            </span>
        @endif
    </div>
    
    <div class="form-group">
        {{ Form::label('contact_phone', 'Contact Person Phone') }}
          <div class="row">
              <div class="col-md-2">
                {!! Form::text('phone_code','+1',['class' => 'phone_number_class text-center form-control','disabled'=>true]) !!} 
              </div>
             <div class="col-md-10">
            {!! Form::text('contact_phone',null,['class' => 'set_phone_format form-control']) !!}
            <span class="error" style="color:red"></span>
            </div>
        </div>
       
        @if ($errors->has('contact_phone'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('contact_phone') }}</strong>
            </span>
        @endif
    </div>
     <div class="form-group">
        {{ Form::label('contact_title', 'Contact Person Title') }}
        {{ Form::text('contact_title', null, array('class' => 'form-control')) }}
        @if ($errors->has('contact_title'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('contact_title') }}</strong>
            </span>
        @endif
    </div>

    <div class="form-group">
        {{ Form::label('contact_email', 'Contact Person Email') }}
        {{ Form::text('contact_email', null, array('class' => 'form-control')) }}
        @if ($errors->has('contact_email'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('contact_email') }}</strong>
            </span>
        @endif
    </div>
</div>