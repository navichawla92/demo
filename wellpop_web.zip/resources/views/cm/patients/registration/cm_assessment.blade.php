@extends('layouts.app')

@section('css')

@endsection

@section('title')
 {{ trans('label.patient_registration') }}
@endsection

@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.patient_assessment') }}
         </div>
      </div>
   </div>
   <div class="tabsmain">
      <div class="row">
         <div class="col-md-8">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
               <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'advanced_directive_tab')?'active':'' }}" id="advanced-li" href="#advanced-directive-content" role="tab" aria-controls="home" aria-selected="true" data-toggle="tab">{{ trans('label.advanced_directive') }}</a> </li>
               <li class="nav-item"> <a class="nav-link" id="home-safety-li" data-toggle="{{ ($patient->cm_tab_completed >=1)?'tab':'' }}" href="#home-safety-content" role="tab" aria-controls="profile" aria-selected="false">{{ trans('label.home_safety_evaluation') }}</a> </li>
               <li class="nav-item"> <a class="nav-link" id="assessment-li" data-toggle="{{ ($patient->cm_tab_completed >= 2)?'tab':'' }}" href="#assessment-content" role="tab" aria-controls="assessment-content" aria-selected="false">{{ trans('label.cm_assessment') }}</a> </li>
            </ul>
         </div>
         <div class="col-md-4 smalltextunderheading paddingbtm15">
            <div class="document-notetabs">
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'document')?'active':'' }}" id="document-tab" href="#document" role="tab" data-toggle="tab" aria-controls="contact" aria-selected="false"> {{ trans('label.documents') }} </a> </li>
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'note')?'active':'' }}" id="note" data-toggle="tab" href="#notes" role="tab" aria-controls="contact" aria-selected="false">{{ trans('label.notes') }}</a> </li>
               </ul>
            </div>
         </div>
      </div>
      <div class="tab-content" id="myTabContent">
         <div class="tab-pane fade {{ ($active_tab == 'advanced_directive_tab')?'show active':'' }}" id="advanced-directive-content" role="tabpanel" aria-labelledby="home-tab">
            @include('cm.patients.registration.advanced_directive_tab')
         </div>
         <!--	second tab	-->
         <div class="tab-pane fade" id="home-safety-content" role="tabpanel" aria-labelledby="profile-tab">
            @if($patient->cm_tab_completed >= 1)
              @include('cm.patients.registration.home_safety_evaluation_tab')
            @endif
         </div>
         <!--fourth tab-->
         <div class="tab-pane fade" id="assessment-content" role="tabpanel" aria-labelledby="contact-tab">
            @if($patient->cm_tab_completed >= 2)
              @include('patients.common.assessment_comments_tab')
            @endif
         </div>
         <!--document	-->
         <div class="tab-pane fade {{ ($active_tab == 'document')?'active show':'' }}" id="document" role="tabpanel" aria-labelledby="contact-tab">
            @include('patients.common.patient_documents_tab')
         </div>
         <!--notes	-->
         <div class="tab-pane fade {{ ($active_tab == 'note')?'active show':'' }}" id="notes" role="tabpanel" aria-labelledby="contact-tab">
             @include('patients.common.patient_notes_tab')
         </div>
      </div>
   </div>
</div>
@endsection

@section('common_script')
  @include('patients.common.common_script')
@endsection  

@section('script')
   <script type="text/javascript">
   /*
    *--------Advanced Directive Tab--------
    *Scripting for 1st tab starts from here 
   */
   $(document).ready(function(){

      $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

      //call PCP-Info function to select already filled value if any
      dynamicDropDown('#pcp_information', 'pcp_');
      dynamicDropDown('#hhp_dropdown', 'hhp_');
      dynamicDropDown('#hp_dropdown', 'hp_');

      //on change of PCP-Info select
      $(document).on('change', '.dynamic_dropdown', function(e) {
         dynamicDropDown('#'+$(this).attr('id'),$(this).data('class_initial'));
      });
      addOldValue();

      //for other checkbox
      $(document).on('change','input[type=checkbox][name=durable_medical_equipment_other],input[type=checkbox][name=identifying_issues_other]',function() {
        if(this.checked) {
          $('#identifying_issues').html('').removeClass('active').hide();
          $(this).parent().parent().parent().parent().find('.is_other').show();
        }else{
          $(this).parent().parent().parent().parent().find('.is_other').hide();
          $(this).parent().parent().parent().parent().find('.is_other').find('input').removeClass('changed-input');
        }
      });

      fadeOutAlertMessages();

   });

   function dynamicDropDown(dropdownId,class_initial) {
     if($(dropdownId+' option:selected').val() != ''){

       if($(dropdownId).parent().parent().parent().find('.readonly_field:first').is(":hidden")){
         $(dropdownId).parent().parent().parent().find('.readonly_field span.error').hide().removeClass('active');
       }

       $(dropdownId).parent().parent().parent().find('.readonly_field').show();
       $.each($(dropdownId+' option:selected').data(), function(i, v) {
           $(dropdownId).parent().parent().parent().find('.'+class_initial+i).val(v);
       });
     }else{
       $(dropdownId).parent().parent().parent().find('.readonly_field').hide();
     }
   }

  function saveform(button_pressed,formId,tab)
  {

    $('span.error').hide().removeClass('active');

    //unmask value of phone number fields
    $(".set_phone_format").inputmask('remove');

    var formData = new FormData($(formId)[0]);

    $.ajax({
      url:"{{ route('registration_cm_assessment_save') }}",
      data:formData,
      processData: false,
      contentType: false,
      dataType: "json",
      success:function(data)
      {
        $('input,textarea,select').removeClass('changed-input');
        if(button_pressed == 'saveandclose' || button_pressed == 'movetopre' || button_pressed == 'movetoreg')
        {
          window.location.href="{{ route('registration_patient_view', encrypt($patient->id))  }}";
        }
        else if(button_pressed == 'saveandnext')
        {
          //enable phone masking again 
          $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

          if(tab == 1)
          {
            $.ajax({  
                url:"{{ route('registration_cm_assessment_get_home_safety_tab_html') }}",
                type: "GET",
                dataType: "html",
                data: {
                  tab: 'home-safety-html',
                  patient_id:"{{ encrypt($patient->id) }}"
                },
                success:function(data){

                  $('#home-safety-li').attr('data-toggle','tab')
                  $('#home-safety-content').html(data);

                  //move to next available tab
                  $('.nav-tabs a.active').parent().next('li').find('a').trigger('click');
                  initCustomForms();
                  //scroll top
                  jQuery('html, body').animate({
                      scrollTop: jQuery('body').offset().top
                  }, 500);
                  addOldValue();
                  addTooltipTolabel();
               }
            });
          }
          else if(tab == 2)
          {
            $.ajax({  
                url:"{{ route('registration_cm_assessment_get_home_safety_tab_html') }}",
                type: "GET",
                dataType: "html",
                data: {
                  tab: 'assessment-html',
                  patient_id:"{{ encrypt($patient->id) }}"
                },
                success:function(data){

                  $('#assessment-li').attr('data-toggle','tab')
                  $('#assessment-content').html(data);

                  //move to next available tab
                  $('.nav-tabs a.active').parent().next('li').find('a').trigger('click');
                  initCustomForms();
                  //scroll top
                  jQuery('html, body').animate({
                      scrollTop: jQuery('body').offset().top
                  }, 500);
                  addOldValue();
                  addTooltipTolabel();
               }
            });
          }
        }
      },
      error:function(error){

        //enable phone masking again 
        $(".set_phone_format").inputmask("(999) 999-9999",{showMaskOnFocus : false, showMaskOnHover : false});

        $.each(error.responseJSON.errors,function(key,value){
          if(key == 'advance_healthcare_checkboxes' || key == 'polst_checkboxes'){
            $('input[name="'+key+'[]"]:first').parent().parent().parent().find('span.error').html(value).addClass('active').show();
          }
          else if(key == 'patient_functioning' || key == 'identifying_issues'){
            $('#'+key).html(value).addClass('active').show();
          }else{
            $('input[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('select[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
            $('textarea[name="'+key+'"]').parent().find('span.error').html(value).addClass('active').show();
          }
        }); 
        
        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);     
      }
    });
  }

  // for all keyup,keydown, change for every input field

  $('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
          $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
          $(this).removeClass('changed-input');
        }
        else {
          $(this).addClass('changed-input');
        }     
    }
   /* else if($(this).attr("name") != 'comment') {
      $(this).addClass('changed-input');
    }*/
    else {
       $(this).addClass('changed-input');
    }
    
    //for radio button changes alert
    if($(this).attr('type') == 'radio'){
      if($(this).attr("old_value") == $(this).val()){
          $(this).removeClass('changed-input');
          $('input[name="'+$(this).attr("name")+'"]').removeClass('changed-input');
      }
      else{
        $(this).addClass('changed-input');
      }
    }    
  });

  // for click on side bar or logout button
  $(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
    if ($('.changed-input').length){
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }
  });
  
  //hide error on select a value
  $(document).on('change', 'input[type=checkbox][name="identifying_issues[]"]',function() {
    if($(this).is(":checked")){
      $('#identifying_issues').html('').removeClass('active').hide();
    }
  });  

  //hide error on select a value
  $(document).on('change', 'input[type=checkbox][name="patient_functioning[]"]',function() {
    if($(this).is(":checked")){
      $('#patient_functioning').html('').removeClass('active').hide();
    }
  }); 


  // for cancel button on every form
  $('body').on('click', '.close_form', function(e) {
      e.preventDefault();
      closeForm();
  });

  function addOldValue(){
      $("input,textarea,select").each(function(){
        if($(this).attr('type') == 'radio'){
            if ($(this).is(":checked")) {
              $(this).attr('old_value',$(this).val());
            }
        }else{
          $(this).attr('old_value',$(this).val());

        } 
      })
  }

  function closeForm(){
    if ($('.changed-input').length){
      bootbox.confirm({ 
        message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
        callback: function(result){  
          if (result) {
            $('input,textarea,select').removeClass('changed-input');
            window.location.href="{{ route('registrations') }}";
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      });
    }
    else {
      window.location.href="{{ route('registrations') }}";
    }
  }  

  // for tab changes

  $('#myTab2 li a.nav-link').on('click',function(e){
    if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
      $('#myTab li a.nav-link').removeClass('active');
    }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
      e.preventDefault();
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }else{
      e.preventDefault();
    }
  });

  $('#myTab li a.nav-link').on('click',function(e){
      if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
        $('#myTab2 li a.nav-link').removeClass('active');
      }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
      e.preventDefault();
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }else{
      e.preventDefault();
    }
  });

  $(document).on('change', '.not_required_checkbox', function(){
        if(this.checked) {
          $('.pcp_informations_div').hide();
          $('#pcp_information').val('');
          initCustomForms();
          dynamicDropDown('#pcp_information', 'pcp_');
          
        }else{
           $('.pcp_informations_div').show();
        }
  });

  // show/hide full code div based on value yes or no
  $(document).ready(function() {
    $(".advance_directiove_radio_btn").click(function() {
        var value = $(this).val();
        if(value == 'no'){
          $('.'+$(this).attr('name')).hide();
          $('.'+$(this).attr('name')).find('input').removeClass('changed-input');
          $('.'+$(this).attr('name')).find('input').prop("checked", false);
          $('.'+$(this).attr('name')).find('input').parent('.jcf-checkbox').removeClass('jcf-checked');
          $('.'+$(this).attr('name')).find('input').parent('.jcf-checkbox').addClass('jcf-unchecked');
        }
        else if(value == 'yes') {
          $('.'+$(this).attr('name')).show();
        }
    });
  });

  </script>
@endsection  

