@include('patients.common.profile_status_bar')
{!! Form::model($patient,['id' => 'advanced-directive-tab-form']) !!}
   {!! Form::hidden('patient_id', encrypt($patient->id)) !!}
   {!! Form::hidden('step_number', '1') !!}
   <div class="personliving">   
    <div class="safety-box">            
         <span class="headingpage">{{ trans('label.advanced_health_care_directive') }}</span>
         <div class="clearfix"></div>
         <div class="row check-body radio-check">
            <div class="col-3">
               <p class="file-p">{{ trans('label.on_file') }}? </p>
            </div>
            <div class="col-lg-3 col-md-6">
               <div class="checkdiv">
                  {!! Form::radio('advance_healthcare_on_file', 'yes', false, ['class' => 'customradio advance_directiove_radio_btn']) !!}
                  <label>{{ trans('label.yes') }}</label>
                  {!! Form::radio('advance_healthcare_on_file', 'no', false, ['class' => 'customradio advance_directiove_radio_btn']) !!}
                  <label>{{ trans('label.no') }}</label>
               </div>
            </div>
         </div>
         <div class="clearfix"></div>
         <div class="row check-body advance_healthcare_on_file"  style="{{ ($patient->advance_healthcare_on_file == 'no') ? 'display: none' : '' }}">
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('advance_healthcare_checkboxes[]', 'full_code', (($patient->advance_healthcare_checkboxes) && in_array('full_code', $patient->advance_healthcare_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->advance_healthcare_checkboxes) && in_array('full_code', $patient->advance_healthcare_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label>{{ trans('label.full_code') }}</label>
               </div>
               <span class="error" style="color:red"></span>
            </div>
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('advance_healthcare_checkboxes[]', 'dnr', (($patient->advance_healthcare_checkboxes) && in_array('dnr', $patient->advance_healthcare_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->advance_healthcare_checkboxes) && in_array('dnr', $patient->advance_healthcare_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label>{{ trans('label.dnr') }}</label>
               </div>
            </div>
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('advance_healthcare_checkboxes[]', 'limited_treatment', (($patient->advance_healthcare_checkboxes) && in_array('limited_treatment', $patient->advance_healthcare_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->advance_healthcare_checkboxes) && in_array('limited_treatment', $patient->advance_healthcare_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label>{{ trans('label.limited_treatment') }}</label>
               </div>
            </div>
         </div>
         <span class="smalltextunderheading"> {{ trans('label.durable_power_of_attorney_details') }} </span>
         <div class="clearfix"></div>
         <div class="row">
            <div class="col-3">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.name') }} </label>
                  {!! Form::text('advance_healthcare_attorney_name',null,array('class' => 'form-control','maxlength' => '50')) !!}
                  <span class="error" style="color:red"></span>
               </div>
            </div>
            <div class="col-3">
               <div class="form-group">
                  <label class="labelfieldsname">{{ trans('label.phone_number') }}</label>
                  {!! Form::text('advance_healthcare_attorney_phone',null,array('class' => 'form-control set_phone_format')) !!}
                  <span class="error" style="color:red"></span>
               </div>
            </div>
            <div class="col-3">
               <div class="form-group">
                  <label class="labelfieldsname">{{ trans('label.relation') }}</label>
                    <?php
                        $relationshipOptions = relationship_array();
                    ?>
                    {!! Form::select('advance_healthcare_attorney_relation', array('' => 'Please select') + $relationshipOptions,null,array("class" => "customselect")) !!}
                    <span class="error" style="color:red"></span>
               </div>
            </div>
         </div>
      </div>               
      <div class="clearfix"></div> 
      <div class="safety-box">              
         <span class="headingpage mt-20"> {{ trans('label.polst') }}</span>
         <div class="clearfix"></div>
         <div class="row check-body radio-check">
            <div class="col-3">
               <p class="file-p"> {{ trans('label.on_file') }}? </p>
            </div>
            <div class="col-lg-3 col-md-6">
               <div class="checkdiv">
                  {!! Form::radio('polst_on_file', 'yes', false, ['class' => 'customradio advance_directiove_radio_btn']) !!}
                  <label> {{ trans('label.yes') }}</label>
                  {!! Form::radio('polst_on_file', 'no', false, ['class' => 'customradio advance_directiove_radio_btn']) !!}
                  <label> {{ trans('label.no') }}</label>
               </div>
               <span class="error" style="color:red"></span>
            </div>
         </div>
         <div class="row check-body polst_on_file" style="{{ ($patient->polst_on_file == 'no') ? 'display: none' : '' }}">
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('polst_checkboxes[]', 'full_code', (($patient->polst_checkboxes) && in_array('full_code', $patient->polst_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->polst_checkboxes) && in_array('full_code', $patient->polst_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label>{{ trans('label.full_code') }}</label>
               </div>
               <span class="error" style="color:red"></span>
            </div>
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('polst_checkboxes[]', 'dnr', (($patient->polst_checkboxes) && in_array('dnr', $patient->polst_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->polst_checkboxes) && in_array('dnr', $patient->polst_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label> {{ trans('label.dnr') }}</label>
               </div>
            </div>
            <div class="col-md-3">
               <div class="checkdiv">
                  {!! Form::checkbox('polst_checkboxes[]', 'limited_treatment', (($patient->polst_checkboxes) && in_array('limited_treatment', $patient->polst_checkboxes) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->polst_checkboxes) && in_array('limited_treatment', $patient->polst_checkboxes))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label> {{ trans('label.limited_treatment') }}</label>
               </div>
            </div>
            <span class="error" style="color:red"></span>
         </div>
         <div class="clearfix"></div>
         <div class="row">
            <div class="col-md-5">
               <p class="smalltextunderheading margnbootom"> {{ trans('label.pcp_information') }}
               <span class="checkdiv">
                 {!! Form::checkbox('pcp_not_required', null, (($patient->pcp_not_required == 1) ? true : false), ['class' => 'customcheck not_required_checkbox', 'data-section_class' => 'substance_abuse_section', 'old-data'=>($patient->pcp_not_required == 1) ? 'jcf-checked':'jcf-unchecked']) !!}
                  <label>{{ trans('label.none') }}</label>
               </span>
             </p>
            </div>
         </div>
         <div class="clearfix"></div>
         <div class="row pcp_informations_div" style="{{ ($patient->pcp_not_required == 1) ? 'display: none' : '' }}"">
            <div class="col-sm-5 ">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.doctor_name') }}</label>
                  <select name="pcp_id" class="dynamic_dropdown customselect" id='pcp_information' data-class_initial="pcp_">
                     <option value=""> {{ trans('label.please_select') }}</option>
                     @foreach($pcp_informations as $key=>$pcp_information)
                      <option value="{{ $pcp_information->id }}" data-address_line1="{{ $pcp_information->address_line1 }}" data-address_line2="{{ $pcp_information->address_line2 }}" data-city="{{ $pcp_information->city }}" data-zip_code="{{ $pcp_information->zip }}" data-contact_name="{{ $pcp_information->contact_name }}" data-contact_phone="{{ $pcp_information->contact_phone }}" data-contact_email="{{ $pcp_information->contact_email }}" data-contact_title="{{ $pcp_information->contact_title }}" data-speciality="{{ $pcp_information->speciality }}" data-org_name="{{ $pcp_information->org_name }}" data-state_id="{{ $pcp_information->state_id }}" data-state_name="{{ $pcp_information->state_name }}" data-phone="{{ $pcp_information->phone_number }}" data-fax="{{ $pcp_information->fax }}" data-email="{{ $pcp_information->email }}" data-web_address="{{ $pcp_information->web_address }}"

                         @if ($pcp_information->id === $patient->pcp_id) selected @endif
                       >{{$pcp_information->name}} </option>
                     @endforeach
                   </select>
                   <span class="error" style="color:red"></span>
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.email_address') }}</label>
                  <input type="text" class="form-control pcp_email" disabled="">
               </div>
            </div>
            <div class="col-sm-5">
               <div class="form-group readonly_field">
                  <label class="labelfieldsname"> {{ trans('label.org_name') }}</label>
                  <input type="text" class="form-control pcp_org_name" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.speciality') }}</label>
                  <input type="text" class="form-control pcp_speciality" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.fax') }}</label>
                        <input type="text" class="form-control pcp_fax" disabled="">
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="labelfieldsname"> {{ trans('label.phone_number') }}</label>
                        <input type="text" class="form-control pcp_phone set_phone_format" disabled="">
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.web_address') }} </label>
                  <input type="text" class="form-control pcp_web_address" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_name') }} </label>
                  <input type="text" class="form-control pcp_contact_name" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_phone') }} </label>
                  <input type="text" class="form-control pcp_contact_phone set_phone_format" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname">{{ trans('label.contact_person_title') }} </label>
                  <input type="text" class="form-control pcp_contact_title" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_email') }} </label>
                  <input type="text" class="form-control pcp_contact_email" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_1') }} </label>
                  <input type="text" class="form-control pcp_address_line1" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_2') }} </label>
                  <input type="text" class="form-control pcp_address_line2" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.city') }}</label>
                  <input type="text" class="form-control pcp_city" disabled="">
               </div>
            </div>
            <div class="col-md-5 readonly_field">
               <div class="row">
                  <div class="col-md-7">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.state') }} </label>
                        <input class="form-control pcp_state_name" type="text" disabled="" name="emergency_person1_state_id">
                     </div>
                  </div>
                  <div class="col-md-5 readonly_field">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.zip_code') }} </label>
                        <input maxlength="5" type="text" class="pcp_zip_code" disabled="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="personliving">
      <div class="safety-box">
         <span class="headingpage mb-10"> {{ trans('label.home_health_provider') }}</span>
         <br>
         <div class="clearfix"></div>
         <div class="row">
            <div class="col-sm-5">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.org_name') }}</label>
                  <select id="hhp_dropdown" name="home_health_provider_id" class="dynamic_dropdown customselect" data-class_initial="hhp_">
                     <option value=""> {{ trans('label.please_select') }} </option>
                     @foreach($home_health_providers as $key=>$home_health_provider)
                      <option value="{{ $home_health_provider->id }}" data-address_line1="{{ $home_health_provider->address_line1 }}" data-address_line2="{{ $home_health_provider->address_line2 }}" data-city="{{ $home_health_provider->city }}" data-zip_code="{{ $home_health_provider->zip }}" data-contact_name="{{ $home_health_provider->contact_name }}" data-contact_phone="{{ $home_health_provider->contact_phone }}" data-contact_email="{{ $home_health_provider->contact_email }}" data-contact_title="{{ $home_health_provider->contact_title }}" data-state_id="{{ $home_health_provider->state_id }}" data-state_name="{{ $home_health_provider->state_name }}" data-phone="{{ $home_health_provider->phone_number }}" data-fax="{{ $home_health_provider->fax }}" data-email="{{ $home_health_provider->email }}" data-web_address="{{ $home_health_provider->web_address }}"

                         @if ($home_health_provider->id === $patient->home_health_provider_id) selected @endif
                       >{{$home_health_provider->org_name}} </option>
                     @endforeach
                  </select>
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.phone_number') }} </label>
                  <input type="text" class="form-control hhp_phone" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.fax') }} </label>
                  <input type="text" class="form-control hhp_fax" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.web_address') }} </label>
                  <input type="text" class="form-control hhp_web_address" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.counsellor_person_name') }} </label>
                  <input type="text" class="form-control hhp_contact_name" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.counsellor_person_phone') }} </label>
                  <input type="text" class="form-control hhp_contact_phone" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname">{{ trans('label.counsellor_person_title') }} </label>
                  <input type="text" class="form-control hhp_contact_title" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.counsellor_person_email') }} </label>
                  <input type="text" class="form-control hhp_contact_email" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_1') }} </label>
                  <input type="text" class="form-control hhp_address_line1" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_2') }} </label>
                  <input type="text" class="form-control hhp_address_line2" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.city') }} </label>
                  <input type="text" class="form-control hhp_city" disabled="">
               </div>
            </div>
            <div class="col-md-5 readonly_field">
               <div class="row">
                  <div class="col-md-7">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.state') }} </label>
                        <input class="form-control hhp_state_name" type="text" disabled="" disabled="">
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.zip_code') }} </label>
                        <input maxlength="10" class="hhp_zip_code" type="text" disabled="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="personliving">
      <div class="safety-box">   
         <span class="headingpage mb-10"> {{ trans('label.hospice_provider') }} </span>
         <div class="clearfix"></div>
         <div class="row">
            <div class="col-sm-5">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.org_name') }} </label>
                  <select id="hp_dropdown" name="hospice_provider_id" class="dynamic_dropdown customselect" data-class_initial="hp_">
                     <option value=""> {{ trans('label.please_select') }} </option>
                     @foreach($hospic_providers as $key=>$hospic_provider)
                      <option value="{{ $hospic_provider->id }}" data-address_line1="{{ $hospic_provider->address_line1 }}" data-address_line2="{{ $hospic_provider->address_line2 }}" data-city="{{ $hospic_provider->city }}" data-zip_code="{{ $hospic_provider->zip }}" data-contact_name="{{ $hospic_provider->contact_name }}" data-contact_phone="{{ $hospic_provider->contact_phone }}" data-contact_email="{{ $hospic_provider->contact_email }}" data-contact_title="{{ $hospic_provider->contact_title }}" data-state_id="{{ $hospic_provider->state_id }}" data-state_name="{{ $hospic_provider->state_name }}" data-phone="{{ $hospic_provider->phone_number }}" data-fax="{{ $hospic_provider->fax }}" data-email="{{ $hospic_provider->email }}" data-web_address="{{ $hospic_provider->web_address }}"

                         @if ($hospic_provider->id === $patient->hospice_provider_id) selected @endif
                       >{{$hospic_provider->org_name}} </option>
                     @endforeach
                  </select>
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.phone_number') }} </label>
                  <input type="text" class="form-control hp_phone" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.fax') }} </label>
                  <input type="text" class="form-control hp_fax" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.web_address') }} </label>
                  <input type="text" class="form-control hp_web_address" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_name') }} </label>
                  <input type="text" class="form-control hp_contact_name" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_phone') }} </label>
                  <input type="text" class="form-control hp_contact_phone" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_title') }} </label>
                  <input type="text" class="form-control hp_contact_title" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.contact_person_email') }} </label>
                  <input type="text" class="form-control hp_contact_email" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_1') }} </label>
                  <input type="text" class="form-control hp_address_line1" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.address_line_2') }} </label>
                  <input type="text" class="form-control hp_address_line2" disabled="">
               </div>
            </div>
            <div class="col-sm-5 readonly_field">
               <div class="form-group">
                  <label class="labelfieldsname"> {{ trans('label.city') }} </label>
                  <input type="text" class="form-control hp_city" disabled="">
               </div>
            </div>
            <div class="col-md-5 readonly_field">
               <div class="row">
                  <div class="col-md-7">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.state') }} </label>
                        <input class="form-control hp_state_name" type="text" disabled="" disabled="">
                     </div>
                  </div>
                  <div class="col-md-5">
                     <div class="textfieldglobal">
                        <label class="labelfieldsname"> {{ trans('label.zip_code') }} </label>
                        <input maxlength="5" class="hp_zip_code" type="text" disabled="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
{!! Form::close() !!}

<div class="buttonsbottom">
   <button type="button" class="next" onClick="javascript:saveform('saveandnext','#advanced-directive-tab-form','1')">{{trans('label.save_and_next')}}</button>
   <button type="button" class="next" onClick="javascript:saveform('saveandclose','#advanced-directive-tab-form','1')">{{trans('label.save_and_close')}}</button>
   <a href="#" class="close close close_form">{{ trans('label.cancel') }}</a> 
</div>