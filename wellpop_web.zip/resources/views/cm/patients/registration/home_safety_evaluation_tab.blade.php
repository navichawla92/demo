@include('patients.common.profile_status_bar')
{!! Form::model($patient,['id' => 'home-safety-tab-form']) !!}
   {!! Form::hidden('patient_id', encrypt($patient->id)) !!}
   {!! Form::hidden('step_number', '2') !!}
   <div class="patient-detail personliving">
      <div class="row">
         <div class="col md-5">
            <div class="safety-box">
               <div class="headingpage">{{ trans('label.patient_functioning') }}</div>
               <div class="clearfix"></div>
               <span class="smalltextunderheading checklabel">{{ trans('label.check_one_which_is_applicable') }}</span>
                <span class="error" id='patient_functioning' style="color: red; display: none;"></span>
               <div class="clearfix"></div>
              
               <div class="row check-body">

                  @foreach($patient_functionings as $key=>$patient_functioning)
                     <div class="col-xl-6 col-md-12">  
                        <div class="checkdiv">
                           {!! Form::checkbox('patient_functioning[]', $key, (($patient->patient_functioning) && in_array($key, $patient->patient_functioning) ? true : false),['class'=>'customcheck','old-data'=>(($patient->patient_functioning) && in_array($key, $patient->patient_functioning))? 'jcf-checked':'jcf-unchecked']) !!}
                           <label class="labelfieldsname">{{ $patient_functioning }}</label>
                        </div>
                    </div>
                  @endforeach

                  
                  <div class="col-sm-12">
                     <div class="form-group mt-10">
                        <label class="labelfieldsname">{{ trans('label.comment') }}</label>
                        {!! Form::textarea('patient_functioning_text', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"1000"]) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col md-5">
            <div class="safety-box">
               <div class="clearfix"></div>
               <div class="headingpage">{{ trans('label.durable_medical_equipment') }}</div>
               <span class="smalltextunderheading checklabel">{{ trans('label.check_one_which_is_applicable') }}</span>
               <div class="clearfix"></div>
               <div class="row check-body">
                  


                  @foreach($durable_medical_equipments as $key=>$durable_medical_equipment)
                     <div class="col-xl-6 col-md-12">  
                        <div class="checkdiv">
                           {!! Form::checkbox('durable_medical_equipment[]', $key, (($patient->durable_medical_equipment) && in_array($key, $patient->durable_medical_equipment) ? true : false),['class'=>'customcheck','old-data'=>(($patient->durable_medical_equipment) && in_array($key, $patient->durable_medical_equipment))? 'jcf-checked':'jcf-unchecked']) !!}
                           <label class="labelfieldsname">{{ $durable_medical_equipment }}</label>
                        </div>
                    </div>
                  @endforeach
                  
                  <div class="col-xl-6 col-md-12">
                     <div class="checkdiv">
                        {!! Form::checkbox('durable_medical_equipment_other', null, (($patient->durable_medical_equipment_other) ? true : false), ['class' => 'customcheck','old-data'=>($patient->durable_medical_equipment_other)? 'jcf-checked':'jcf-unchecked']) !!}
                        <label class="labelfieldsname">{{ trans('label.other') }}</label>
                     </div>
                  </div>
                  
                  <div class="col-xl-6 col-md-12">
                     <div class="checkdiv is_other textfieldglobal" {!! ((!$patient->durable_medical_equipment_other) ? 'style="display:none;"' : '') !!}>
                        {!! Form::text('durable_medical_equipment_other_text', null, ['class' => 'form-control','maxlength' => '100']) !!}
                        <span class="error" id="living_with_other_text" style="color: red; display: none;"></span>
                     </div>
                  </div>
                  <div class="col-sm-12">
                     <div class="form-group mt-10">
                        <label class="labelfieldsname">{{ trans('label.comment') }}</label>
                        {!! Form::textarea('durable_medical_equipment_text', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"1000"]) !!}
                        <span class="error" style="color: red; display: none;"></span>
                     </div>
                  </div>
               </div>
             </div>  
         </div>
      </div>
      <div class="clearfix"></div>
      <div class="safety-box">
      <div class="headingpage">{{ trans('label.identifying_issues') }}</div>
      <span class="smalltextunderheading checklabel ">{{ trans('label.check_one_which_is_applicable') }}</span>
      <span class="error" id='identifying_issues' style="color: red; display: none;"></span>
      <div class="clearfix"></div>
      <div class="row check-body">

         @foreach($identifying_issues as $key=>$identifying_issue)
            <div class="col-md-4">  
               <div class="checkdiv">
                  {!! Form::checkbox('identifying_issues[]', $key, (($patient->identifying_issues) && in_array($key, $patient->identifying_issues) ? true : false),['class'=>'customcheck','old-data'=>(($patient->identifying_issues) && in_array($key, $patient->identifying_issues))? 'jcf-checked':'jcf-unchecked']) !!}
                  <label class="labelfieldsname">{{ $identifying_issue }}</label>
               </div>
           </div>
         @endforeach

         
         <div class="col-md-4">
            <div class="checkdiv">
               {!! Form::checkbox('identifying_issues_other', null, (($patient->identifying_issues_other) ? true : false), ['class' => 'customcheck','old-data'=>($patient->identifying_issues_other)? 'jcf-checked':'jcf-unchecked']) !!}
               <label class="labelfieldsname">{{ trans('label.other') }}</label>
            </div>
         </div>

         <div class="col-md-4">
            <div class="checkdiv is_other textfieldglobal" {!! ((!$patient->identifying_issues_other) ? 'style="display:none;"' : '') !!}>
               {!! Form::text('identifying_issues_other_text', null, ['class' => 'form-control','maxlength' => '100']) !!}
               <span class="error" id="living_with_other_text" style="color: red; display: none;"></span>
            </div>
         </div>

         <div class="col-sm-8">
            <div class="form-group mt-10">
               <label class="labelfieldsname">{{ trans('label.comment') }}</label>
               <!-- <textarea name="identifying_issues_text" type="text" class="form-control"></textarea> -->
               {!! Form::textarea('identifying_issues_text', null, ['class' => 'form-control', 'rows' => 2, 'cols' => 40,'maxlength' =>"1000"]) !!}
               <span class="error" style="color: red; display: none;"></span>
            </div>
         </div>
         </div>
      </div>
      <div class="buttonsbottom">
         <button type="button" class="next" onClick="javascript:saveform('saveandnext','#home-safety-tab-form','2')">{{trans('label.save_and_next')}}</button>
         <button type="button" class="next" onClick="javascript:saveform('saveandclose','#home-safety-tab-form','2')">{{trans('label.save_and_close')}}</button>
         <a href="#" class="close close close_form">{{ trans('label.cancel') }}</a> 
      </div>
   </div>
{!! Form::close() !!}