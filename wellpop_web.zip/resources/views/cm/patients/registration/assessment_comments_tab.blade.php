@include('patients.common.assessment_comments_tab')
<div class="buttonsbottom comment-btn">
   <button class="next model_box_save"  onClick="javascript:saveAssessmentform('saveandclose','#patient-assessment-form')">Save & Close</button>
   <button class="movetable model_box_save" onClick="javascript:saveAssessmentform('complete_assessment','#patient-assessment-form')">Complete Assessment</button>
</div>
