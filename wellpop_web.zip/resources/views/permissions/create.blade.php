@extends('admin.layouts.app')

@section('title', '| Create Permission')

@section('content')
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="{{ route('login') }}">Dashboard</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>My Profile</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- END PAGE HEADER-->
        <div class="row">
          @if(session()->has('message.level'))
              <div class="alert alert-{{ session('message.level') }} alert-dismissible"> 
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                {!! session('message.content') !!}
              </div>
          @endif  
          <div class="col-md-12 ">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <div class="portlet light bordered">
                    <div class="portlet-body form">
                        {{ Form::open(array('url' => 'permissions')) }}
                            <div class="form-body">
                                <div class="form-group">
                                    {{ Form::label('name', 'Name',['class'=>'col-md-3 control-label']) }}
                                    <div class="col-md-9">
                                        {{ Form::text('name', '', array('class' => 'form-control input-inline input-medium')) }}
                                        <span style="color:red;" class="error"></span>
                                    </div>
                                </div>

                                @if(!$roles->isEmpty())
                                    <h4>Assign Permission to Roles</h4>

                                    @foreach ($roles as $role) 
                                        {{ Form::checkbox('roles[]',  $role->id ) }}
                                        {{ Form::label($role->name, ucfirst($role->name)) }}<br>

                                    @endforeach
                                @endif
                            </div>
                            <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        {{ Form::submit('Add', array('class' => 'btn green')) }}
                                        <a href="{{ route('login') }}" class="btn default">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>
    </div>
</div>
@endsection