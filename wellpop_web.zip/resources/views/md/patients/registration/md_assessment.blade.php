@extends('layouts.app')

@section('css')
  <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
  <link href="{{ asset('css/chosen.min.css') }}" rel="stylesheet">
@endsection

@section('title')
 {{ trans('label.patient_registration') }}
@endsection

@section('content')
<div class="leftsectionpages">
   <div class="row">
      <div class="col-md-6">
         <div class="headingpage">
            <div class="firstname">{{ trans('label.patient_registration') }}</div>
            <span><i class="fas fa-angle-right"></i></span>{{ trans('label.patient_assessment') }}
         </div>
      </div>
   </div>
   <div class="tabsmain">
      <div class="row">
         <div class="col-md-8">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
               <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'medical_tab')?'active':'' }}" id="medical-li" href="#medical-content" role="tab" aria-controls="home" aria-selected="true" data-toggle="tab">{{ trans('label.medical') }}</a> </li>
               <li class="nav-item"> <a class="nav-link" id="assessment-li" data-toggle="{{ ($patient->md_tab_completed >= 1)?'tab':'' }}" href="#assessment-content" role="tab" aria-controls="assessment-content" aria-selected="false">{{ trans('label.md_assessment') }}</a> </li>
            </ul>
         </div>
         <div class="col-md-4 smalltextunderheading paddingbtm15">
            <div class="document-notetabs">
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'document')?'active':'' }}" id="document-tab" href="#document" role="tab" data-toggle="tab" aria-controls="contact" aria-selected="false"> {{ trans('label.documents') }} </a> </li>
                  <li class="nav-item"> <a class="nav-link {{ ($active_tab == 'note')?'active':'' }}" id="note" data-toggle="tab" href="#notes" role="tab" aria-controls="contact" aria-selected="false">{{ trans('label.notes') }} </a> </li>
               </ul>
            </div>
         </div>
      </div>
      <div class="tab-content" id="myTabContent">
         <div class="tab-pane fade {{ ($active_tab == 'medical_tab')?'show active':'' }}" id="medical-content" role="tabpanel" aria-labelledby="home-tab">
            @include('md.patients.registration.medical_tab')
         </div>
         <!-- second tab  -->
         <div class="tab-pane fade" id="assessment-content" role="tabpanel" aria-labelledby="contact-tab">
            @if($patient->md_tab_completed >= 1)
              @include('patients.common.assessment_comments_tab')
            @endif
         </div>
         <!--document -->
         <div class="tab-pane fade {{ ($active_tab == 'document')?'active show':'' }}" id="document" role="tabpanel" aria-labelledby="contact-tab">
            @include('patients.common.patient_documents_tab')
         </div>
         <!--notes  -->
         <div class="tab-pane fade {{ ($active_tab == 'note')?'active show':'' }}" id="notes" role="tabpanel" aria-labelledby="contact-tab">
             @include('patients.common.patient_notes_tab')
         </div>
      </div>
   </div>
</div>
@include('patients.allergies.add_allergy',['type'=>''])
@include('patients.medications.add_medication', ['type' => 'md_assessment'])
@endsection

@section('common_script')
  @include('patients.common.common_script')
@endsection  

@section('script')
   <script src="{{ asset('js/chosen.jquery.min.js') }}" type="text/javascript"></script>
   <script type="text/javascript">
   /*
    *--------Advanced Directive Tab--------
    *Scripting for 1st tab starts from here 
   */
   $(document).ready(function(){
      $(".Icd_class").chosen({ width:'100%' });
      addOldValue();

      //On change not required checkbox for any of the option
      $(document).on('change', '.not_required_checkbox', function(){
        if(this.checked) {
          $('.'+$(this).data('section_class')).addClass('disable-not-section');
          $('#'+this.name).html('').addClass('active').hide();
        }else{
          $('.'+$(this).data('section_class')).removeClass('disable-not-section');
        }
      });      

      //On change not required checkbox for any of the option
      $(document).on('change', 'input[type=checkbox][name="substance_abuse[]"]', function(){
        $('#substance_abuse_not_required').html('').removeClass('active').hide();
      });

     //enable medications listing
     $('body').on('click', '#medication_listing .pagination a', function(e) {
      e.preventDefault();
      var url = "{{ route('registration_md_assessment_medications_listing', [encrypt($patient->id)]) }}"+'?page='+ $(this).text();
      var patient_id = $('input[type=hidden][name=patient_id]').val();
      $.ajax({
          url:url,
          type:"GET",
          data:{patient_id:patient_id},
          dataType: "json",
          success:function(data){
            $('#medication_listing').html(data.html);
          },
          error:function(data){
            alert('error');
          }
        });
     });          

     //enable allergies listing
     $('body').on('click', '#allergies_listing .pagination a', function(e) {
      e.preventDefault();
      var url = "{{ route('registration_md_assessment_allergies_listing', [encrypt($patient->id)]) }}"+'?page='+ $(this).text();
      var patient_id = $('input[type=hidden][name=patient_id]').val();
      $.ajax({
          url:url,
          type:"GET",
          data:{patient_id:patient_id},
          dataType: "json",
          success:function(data){
            $('#allergies_listing').html(data.html);
          },
          error:function(data){
            alert('error');
          }
        });
     });     




   });

  function saveform(button_pressed,formId)
  {
    $('span.error').hide().removeClass('active');

    var formData = new FormData($(formId)[0]);

    $.ajax({
      url:"{{ route('registration_md_assessment_save') }}",
      data:formData,
      processData: false,
      contentType: false,
      dataType: "json",
      success:function(data)
      {
        $('input,textarea,select').removeClass('changed-input');
        if(button_pressed == 'saveandclose' || button_pressed == 'movetopre' || button_pressed == 'movetoreg')
        {
          window.location.href="{{ route('md-registrations')  }}";
        }
        else if(button_pressed == 'saveandnext')
        {
          $.ajax({  
              url:"{{ route('registration_md_assessment_get_assessment_tab_html') }}",
              type: "GET",
              dataType: "html",
              data: {
                tab: 'assessment-html',
                patient_id:"{{ encrypt($patient->id) }}"
              },
              success:function(data){

                //check if not required ticked then clear selected checkboxes
                if($('input[type=checkbox][name=substance_abuse_not_required]').is(":checked")){
                  $("input[type=checkbox][name='substance_abuse[]']").prop("checked", false);
                }                

                //check if medication not required ticked then clear medications listing
                if($('input[type=checkbox][name=medication_not_required]').is(":checked")){
                    $("#medication_listing table tbody").html(
                      '<tr><td>No record found</td></tr>'
                    );
                    $("#medication_listing ul.pagination").remove();
                }                

                //check if allergies not required ticked then clear allergies listing
                if($('input[type=checkbox][name=allergy_not_required]').is(":checked")){
                    $("#allergies_listing table tbody").html(
                      '<tr><td>No record found</td></tr>'
                    );
                    $("#allergies_listing ul.pagination").remove();
                }

                $('#assessment-li').attr('data-toggle','tab')
                $('#assessment-content').html(data);

                //move to next available tab
                $('.nav-tabs a.active').parent().next('li').find('a').trigger('click');
                initCustomForms();
                //scroll top
                jQuery('html, body').animate({
                    scrollTop: jQuery('body').offset().top
                }, 500);
                addOldValue();
             }
          });

        }
      },
      error:function(error){
        $.each(error.responseJSON.errors,function(key,value){
          if(key == 'substance_abuse'){
            $('#substance_abuse_not_required').html(value).addClass('active').show();
          }
          else if(!key.indexOf("icd_code"))
          {
            $('#icd_code').html(value).addClass('active').show();
          
          }
          else if(key == 'icd_code' || key == 'allergy_not_required' || key == 'medication_not_required'){
            $('#'+key).html(value).addClass('active').show();
          }
          else {

          }
        }); 
        
        jQuery('html, body').animate({
            scrollTop: jQuery(document).find('.error.active:first').parent().offset().top
        }, 500);     
      }
    });
  }  


  // for all keyup,keydown, change for every input field
  $('body').on('change keyup keydown', 'input, textarea, select', function (e) {
    if($(this).attr("old_value") == $(this).val() && $(this).attr('type') != 'checkbox'){
        $(this).removeClass('changed-input');
    }
    else if($(this).attr('type') == 'checkbox'){
        if($(this).is(":checked") && $(this).attr("old-data") == 'jcf-checked'){
          $(this).removeClass('changed-input');
        }
        else if(!$(this).is(":checked") && $(this).attr("old-data") == 'jcf-unchecked'){
          $(this).removeClass('changed-input');
        }
        else {
          $(this).addClass('changed-input');
        }     
    }
    else if(!$(this).hasClass('chosen-search-input')) {
        $(this).addClass('changed-input');
    }
    else {
     //   $(this).addClass('changed-input');
    }
    
    //for radio button changes alert
    if($(this).attr('type') == 'radio'){
      if($(this).attr("old_value") == $(this).val()){
          $(this).removeClass('changed-input');
          $('input[name="'+$(this).attr("name")+'"]').removeClass('changed-input');
      }
      else{
        $(this).addClass('changed-input');
      }
    }    
  });


  // for cancel button on every form
  $('body').on('click', '.close_form', function(e) {
      e.preventDefault();
      closeForm();
  });

  function addOldValue(){
      $("input,textarea,select").each(function(){
        if($(this).attr('type') == 'radio'){
            if ($(this).is(":checked")) {
              $(this).attr('old_value',$(this).val());
            }
        }else{
          $(this).attr('old_value',$(this).val());

        } 
      })
  }

  function closeForm(){
    if ($('.changed-input').length){
      bootbox.confirm({ 
        message: "There is some unsaved data which will be lost if you close/reload this page. Are you sure you still want to close/reload this page?", 
        callback: function(result){  
          if (result) {
            $('input,textarea,select').removeClass('changed-input');
            window.location.href="{{ route('md-registrations') }}";
          }
          else {
            bootbox.hideAll();
            return false;
          }
        }
      });
    }
    else {
      window.location.href="{{ route('md-registrations') }}";
    }
  }  

  // for tab changes

  $('#myTab2 li a.nav-link').on('click',function(e){
    if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
      $('#myTab li a.nav-link').removeClass('active');
    }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
      e.preventDefault();
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }else{
      e.preventDefault();
    }
  });

  $('#myTab li a.nav-link').on('click',function(e){
      if($(this).attr('data-toggle') == 'tab' && !$('.changed-input').length){
        $('#myTab2 li a.nav-link').removeClass('active');
      }else if($(this).attr('data-toggle') == 'tab' && $('.changed-input').length && !$(this).hasClass('active')){
      e.preventDefault();
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }else{
      e.preventDefault();
    }
  });



// icd code dynamic options
$(document).ready(function(){
  //setup before functions
    var typingTimer;                //timer identifier
    var xhr = {abort: function () {  }};  //time in ms (2 seconds)
    var selectID = 'icdCode';    //Hold select id
    var selectData = [];           // data for unique id array
   /* $('#' + selectID + '_chosen .chosen-choices input').keyup(function(e){
        
        // Change No Result Match text to Searching.
        //$('#' + selectID + '_chosen .no-results').html('');
        $('#' + selectID + '_chosen .no-results').hide();
        
    //    var keyValue = $('#' + selectID + '_chosen .chosen-choices input').val();
         if(e.which != 16)
         {
            doneTyping(selectID);
         }
        //doneTyping();
    });*/

  $('#' + selectID + '_chosen .chosen-choices input').autocomplete({
      minLength:1,
      source: function( request, response ) {
         $('#' + selectID + '_chosen .no-results').hide();
         var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();
          $.ajax({
        url:"{{ route('ico_code_list') }}",
        data: {data: inputData, patient_id:"{{ encrypt($patient->id) }}",selected_code : $('#' + selectID).val()},
        type:'POST',
        dataType: "json",
        beforeSend: function(){
          // Change No Result Match to Getting Data beforesend
       //   $('#' + selectID + '_chosen .no-results').html('Getting Data = "'+$('#' + selectID + '_chosen .chosen-choices input').val()+'"');

        },
        success: function( data ) { 

          $('#' + selectID ).find('option').not(':selected').remove();
          
          $.map( data.html, function( item ) {
            if($.inArray(item.id,selectData) == -1){
              $('#' + selectID ).append('<option value="'+item.id+'" data-id = "'+item.id+'">' + item.code + '- '+ item.name+ '</option>');
            }
          });
          $('#' + selectID ).trigger("chosen:updated");
          $('.chosen-search-input' ).val(inputData);
        }
      });
      }
  });

  //user is "finished typing," do something
    function doneTyping () {

        var inputData = $('#' + selectID + '_chosen .chosen-choices input').val();  //get input data
        //if(xhr)
        
          xhr.abort();
          xhr = $.ajax({
          url:"{{ route('ico_code_list') }}",
          data: {data: inputData, patient_id:"{{ encrypt($patient->id) }}"},
          type:'POST',
          dataType: "json",
          beforeSend: function(){
            // Change No Result Match to Getting Data beforesend
            //$('#' + selectID + '_chosen .no-results').html('Getting Data = "'+$('#' + selectID + '_chosen .chosen-choices input').val()+'"');

          },
          success: function( data ) { 
            
            $('#' + selectID ).find('option').not(':selected').remove();

            $.map( data.html, function( item ) {
              if($.inArray(item.id,selectData) == -1){
                $('#' + selectID ).append('<option value="'+item.id+'" data-id = "'+item.id+'">' + item.code + '</option>');
              }
            });
            $('#' + selectID ).trigger("chosen:updated");
            $('.chosen-search-input' ).val(inputData);
          }
        });

    }

  // Chosen event listen on input change eg: after select data / deselect this function will be trigger
    $('#' + selectID ).on('change', function() {
      // get select jquery object
      var domArray = $('#' + selectID ).find('option:selected');
      // empty array data
      selectData = [];
      for (var i = 0, length = domArray.length; i < length; i++ ){
        // Push unique data to array (for matching purpose)
        selectData.push( $(domArray[i]).data('id') );

      }
      // Replace select <option> to only selected option
      $('#' + selectID ).html(domArray);

      // Update chosen again after replace selected <option>
      $('#' + selectID ).trigger("chosen:updated");

      });
});
  
  // for click on side bar or logout button
  $(document).on('click','#menu-drop li a,.profilediv .dropdown-item',function(e){
    if ($('.changed-input').length){
      bootbox.alert("{{ trans('message.unsaved_error_message') }}");
      return false;
    }
  });
  
  // for modal box close event
$(document).on('hidden.bs.modal', '.md_assessment_data',function () {
    $('input,textarea,select').removeClass('changed-input');
    $('.md_assessment_data').find('form').trigger('reset');
    $('span.error').hide().removeClass('active');
});

 $(window).ready(function(){
  $('input,textarea,select').removeClass('changed-input');
 });
  </script>
@endsection  

