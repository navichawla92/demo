@include('patients.common.profile_status_bar')
{!! Form::model($patient,['id' => 'medical-tab-form']) !!}
   {!! Form::hidden('patient_id', encrypt($patient->id)) !!}
   {!! Form::hidden('step_number', '1') !!}
   <div class="personliving">
      <div class="safety-box">
         <div class="col-md-7 col-4">
          <div class="row">
        <div class="headingpage"> {{ trans('label.medical_diagnosis') }}* </div>
        <div class="clearfix"></div>
       
           {!! Form::select('icd_code[]', $icd_codes, null, array("class" => "Icd_class",'id'=>"icdCode",'multiple')) !!}
           <span class="error" id="icd_code" style="color:red"></span>
        </div>
     </div>
      </div>
   </div>
   <div class="personliving">
      <div class="safety-box">
        <div class="headingpage">
          <span class="med-head">{{ trans('label.substance_abuse') }}</span>
          <div class="checkdiv not-req"> 
            {!! Form::checkbox('substance_abuse_not_required', null, (($patient->substance_abuse_not_required == 1) ? true : false), ['class' => 'customcheck not_required_checkbox', 'data-section_class' => 'substance_abuse_section', 'old-data'=>($patient->substance_abuse_not_required == 1) ? 'jcf-checked':'jcf-unchecked']) !!}
            <label>{{ trans('label.not_required') }}</label>
          </div>
        </div>
        <span class="error" id="substance_abuse_not_required" style="color:red"></span>
        <span class="smalltextunderheading checklabel substance_abuse_section {{ ($patient->substance_abuse_not_required == 1) ? 'disable-not-section' : '' }}"> {{ trans('label.check_one_which_is_applicable') }}</span>
        <div class="clearfix"></div>
        <div class="row check-body abuse-box substance_abuse_section {{ ($patient->substance_abuse_not_required == 1) ? 'disable-not-section' : '' }}">
           <div class="col">
              <div class="checkdiv">
                 {!! Form::checkbox('substance_abuse[]', 'etoh', (($patient->substance_abuse) && in_array('etoh', $patient->substance_abuse) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->substance_abuse) && in_array('etoh', $patient->substance_abuse))? 'jcf-checked':'jcf-unchecked']) !!}
                 <label> {{ trans('label.etoh') }} </label>
              </div>
           </div>
           <div class="col col-3">
              <div class="checkdiv">
                 {!! Form::checkbox('substance_abuse[]', 'methamphetamines', (($patient->substance_abuse) && in_array('methamphetamines', $patient->substance_abuse) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->substance_abuse) && in_array('methamphetamines', $patient->substance_abuse))? 'jcf-checked':'jcf-unchecked']) !!}
                 <label> {{ trans('label.methamphetamines') }} </label>
              </div>
           </div>
           <div class="col">
              <div class="checkdiv">
                 {!! Form::checkbox('substance_abuse[]', 'opiates', (($patient->substance_abuse) && in_array('opiates', $patient->substance_abuse) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->substance_abuse) && in_array('opiates', $patient->substance_abuse))? 'jcf-checked':'jcf-unchecked']) !!}
                 <label> {{ trans('label.opiates') }}</label>
              </div>
           </div>
           <div class="col col-3">
              <div class="checkdiv">
                 {!! Form::checkbox('substance_abuse[]', 'benzodiazepines', (($patient->substance_abuse) && in_array('benzodiazepines', $patient->substance_abuse) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->substance_abuse) && in_array('benzodiazepines', $patient->substance_abuse))? 'jcf-checked':'jcf-unchecked']) !!}
                 <label> {{ trans('label.benzodiazepines') }}</label>
              </div>
           </div>
           <div class="col col-2">
              <div class="checkdiv">
                 {!! Form::checkbox('substance_abuse[]', 'marijuana', (($patient->substance_abuse) && in_array('marijuana', $patient->substance_abuse) ? true : false), ['class' => 'customcheck','old-data'=>(($patient->substance_abuse) && in_array('marijuana', $patient->substance_abuse))? 'jcf-checked':'jcf-unchecked']) !!}
                 <label> {{ trans('label.marijuana') }}</label>
              </div>
           </div>
        </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="personliving custom-medical-box">
      <div class="headingpage buttonmargin margnbootom">
		  <span class="med-head">{{ trans('label.medication') }}  </span>
        <div class="checkdiv not-req"> 
          {!! Form::checkbox('medication_not_required', null, (($patient->medication_not_required == 1) ? true : false), ['class' => 'customcheck not_required_checkbox', 'data-section_class' => 'medication_section', 'old-data'=>($patient->medication_not_required == 1) ? 'jcf-checked':'jcf-unchecked']) !!}
          <label>{{ trans('label.not_required') }} </label>
        </div>

        <button type="button" class="btn btn-primary basic-btn medication_section {{ ($patient->medication_not_required == 1) ? 'disable-not-section' : '' }}" id="add_new_medication"> {{ trans('label.add_new_medication') }} </button>
      </div>
       <span class="error" id="medication_not_required" style="color:red"></span>  
      <div class="clearfix"></div>
      <div class="table-responsive care-table medication_section {{ ($patient->medication_not_required == 1) ? 'disable-not-section' : '' }}" id="medication_listing">         
        @include('patients.medications.medication_listing',['type'=>'','is_careplan'=>0])            
      </div>

   </div>
   <div class="clearfix"></div>
   <div class="personliving custom-medical-box">
      <div class="headingpage buttonmargin margnbootom">
		  <span class="med-head">{{ trans('label.allergies') }}</span>
        <div class="checkdiv not-req"> 
          {!! Form::checkbox('allergy_not_required', null, (($patient->allergy_not_required == 1) ? true : false), ['class' => 'customcheck not_required_checkbox', 'data-section_class' => 'allergies_section', 'old-data'=>($patient->allergy_not_required == 1) ? 'jcf-checked':'jcf-unchecked']) !!}
          <label>{{ trans('label.not_required') }}</label>
        </div>
        <button type="button" class="btn btn-primary basic-btn allergies_section {{ ($patient->allergy_not_required == 1) ? 'disable-not-section' : '' }}" id="add_new_allergy">{{ trans('label.add_new_allergy') }} </button> 
      </div>
       <span class="error" id="allergy_not_required" style="color:red"></span>  
      <div class="clearfix"></div>
      <div class="table-responsive care-table allergies_section {{ ($patient->allergy_not_required == 1) ? 'disable-not-section' : '' }}" id="allergies_listing">
        @include('patients.allergies.allergies_listing',['type'=>'','is_careplan'=>0])
      </div>
   </div>
{!! Form::close() !!}

<div class="buttonsbottom">
   <button type="button" class="next" onClick="javascript:saveform('saveandnext','#medical-tab-form','1')">{{ trans('label.save_and_next') }}</button>
   <button type="button" class="next" onClick="javascript:saveform('saveandclose','#medical-tab-form','1')">{{ trans('label.save_and_close') }}</button>
   <a href="#" class="close close close_form">{{ trans('label.cancel') }}</a> 
</div>